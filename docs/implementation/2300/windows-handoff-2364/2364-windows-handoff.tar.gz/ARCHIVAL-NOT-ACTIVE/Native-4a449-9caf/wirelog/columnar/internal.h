/*
 * columnar/internal.h - wirelog Columnar Backend Internal Types
 *
 * Copyright (C) CleverPlant
 * Licensed under LGPL-3.0
 * For commercial licenses, contact: inquiry@cleverplant.com
 *
 * INTERNAL HEADER - not installed, not part of public API.
 *
 * Private type definitions and constants for the columnar nanoarrow backend.
 * Extracted from backend/columnar_nanoarrow.c to enable modular splitting.
 */

#ifndef WL_COLUMNAR_INTERNAL_H
#define WL_COLUMNAR_INTERNAL_H

#define _GNU_SOURCE

#include "columnar/columnar_nanoarrow.h"
#include "columnar/diff_arrangement.h"
#include "columnar/diff_trace.h"
#include "columnar/delta_pool.h"
#include "columnar/mem_ledger.h"
#include "columnar/mem_ledger_publication.h"
#include "columnar/source_access.h"
#include "columnar/memory_governor.h"
#include "columnar/lftj.h"
#include "columnar/spill.h"
#include "columnar/continuation.h"
#include "columnar/kfusion_adaptive.h"
#include "columnar/progress.h"
#include "columnar/eval_tdd_channel.h"
#include "columnar/tdd_channel.h"
#include "session.h"
#include "evaluation_control.h"
#include "intern.h"
#include "workqueue.h"
#include "arena/arena.h"
#include "arena/compound_arena.h"
#include "wirelog-types.h"

#include "nanoarrow/nanoarrow.h"

#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define WL_COLUMNAR_CMP_INCOMPATIBLE INT_MIN

/* Float lanes use the existing 64-bit storage but retain binary64 semantics. */
static inline double
wl_columnar_float_from_bits(int64_t bits)
{
    double value;
    memcpy(&value, &bits, sizeof(value));
    return value;
}

static inline int64_t
wl_columnar_float_to_bits(double value)
{
    int64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    return bits;
}

/* These representation-only helpers deliberately avoid address-taken float
 * temporaries. Inlining memcpy-based conversions into integer cell access
 * also instruments that hot path with ASan fake-stack allocations on GCC/ARM.
 * Float lanes already require IEEE binary64; arithmetic still uses the
 * conversion helpers above. */
static inline bool
wl_columnar_float_bits_valid(int64_t bits)
{
    const uint64_t exponent = UINT64_C(0x7ff0000000000000);
    return ((uint64_t)bits & exponent) != exponent;
}

static inline bool
wl_columnar_float_bits_zero(int64_t bits)
{
    return ((uint64_t)bits & UINT64_C(0x7fffffffffffffff)) == 0;
}

static inline int
wl_columnar_float_compare_bits(int64_t left_bits, int64_t right_bits)
{
    if (!wl_columnar_float_bits_valid(left_bits)
        || !wl_columnar_float_bits_valid(right_bits))
        return WL_COLUMNAR_CMP_INCOMPATIBLE;
    if (wl_columnar_float_bits_zero(left_bits)
        && wl_columnar_float_bits_zero(right_bits))
        return 0;
    const uint64_t sign = UINT64_C(0x8000000000000000);
    uint64_t left = (uint64_t)left_bits;
    uint64_t right = (uint64_t)right_bits;
    /* Reverse the negative encodings and place positives above negatives. */
    left = (left & sign) ? ~left : left ^ sign;
    right = (right & sign) ? ~right : right ^ sign;
    return left < right ? -1 : left > right ? 1 : 0;
}

#ifdef _MSC_VER
#include <windows.h> /* For GetTickCount64() in now_ns() */
#include <intrin.h>  /* For _BitScanForward64 */
#endif

/* ======================================================================== */
/* Platform Shims                                                           */
/* ======================================================================== */

/* Marks a return value that a caller must not discard.  GCC/Clang only:
 * the Windows leg builds with MSVC cl.exe, which rejects GNU attributes.
 *
 * There is no -Werror in this build, so the attribute does not fail a
 * compile on its own; it earns its keep through the clang-tidy ratchet,
 * which fails on any diagnostic in an allowlisted libwirelog source and
 * sees -Wunused-result through the -Wall every target carries.
 *
 * WL_IGNORE_RESULT marks a discard that is deliberate.  A plain (void)
 * cast does not silence warn_unused_result on GCC -- only clang honours
 * that -- so the value has to be bound and then discarded.  Using the
 * macro rather than an ad-hoc dummy keeps intentional discards greppable
 * and stops them from reading like oversights. */
#if defined(_MSC_VER)
#define WL_MUST_CHECK
#define WL_IGNORE_RESULT(expr) ((void)(expr))
#else
#define WL_MUST_CHECK __attribute__((warn_unused_result))
#define WL_IGNORE_RESULT(expr)                \
        do {                                      \
            __typeof__(expr) wl_ignored_ = (expr); \
            (void)wl_ignored_;                    \
        } while (0)
#endif

/* GCC/Clang extension not supported on MSVC */
#ifdef _MSC_VER
#define UNUSED
/* MSVC: __builtin_ctzll not available; use _BitScanForward64 */
static inline int
ctzll(unsigned long long x)
{
    unsigned long index;
    if (_BitScanForward64(&index, x)) {
        return (int)index;
    }
    return 64; /* undefined for x=0, but we don't call it with x=0 */
}
#define __builtin_ctzll(x) ctzll(x)
#else
#define UNUSED __attribute__((unused))
#endif

/* ======================================================================== */
/* Profiling Helper                                                         */
/* ======================================================================== */

/*
 * now_ns: return monotonic time in nanoseconds.
 * Uses clock_gettime(CLOCK_MONOTONIC) on POSIX systems,
 * GetTickCount64() on Windows MSVC.
 * Returns 0 on platforms where time function is unavailable (non-fatal).
 */
static inline uint64_t
now_ns(void)
{
#ifdef _MSC_VER
    /* Windows MSVC: use GetTickCount64() in milliseconds, convert to nanoseconds.
     * Returns milliseconds since system startup (monotonic). */
    return GetTickCount64() * 1000000ULL;
#else
    /* POSIX: use clock_gettime with CLOCK_MONOTONIC. */
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0)
        return 0;
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
#endif
}

/* ======================================================================== */
/* Constants                                                                */
/* ======================================================================== */

#define COL_REL_INIT_CAP 64u
#define COL_STACK_MAX 32u
#define COL_FILTER_STACK WL_PLAN_EXPR_STACK_MAX
#define MAX_ITERATIONS 4096u
#define EVAL_STRIDE 8u /* sub-passes per outer iteration (Issue #237) */

#ifdef WL_SESSION_TEST_HOOKS
extern uint32_t wl_columnar_eval_serial_test_iteration_limit;
extern uint32_t wl_columnar_session_test_iteration_limit;
extern void (*wl_columnar_session_test_iteration_checkpoint)(
    wl_evaluation_control_t *, uint32_t, bool);
#endif

static inline uint32_t
wl_columnar_eval_serial_iteration_limit(void)
{
#ifdef WL_SESSION_TEST_HOOKS
    if (wl_columnar_eval_serial_test_iteration_limit)
        return wl_columnar_eval_serial_test_iteration_limit;
#endif
    return MAX_ITERATIONS;
}
#define MAX_STRATA 32
#define MAX_RULES 64
#define COL_MAT_CACHE_MAX 64u
#define COL_MAT_CACHE_LIMIT_BYTES (100ULL * 1024ULL * 1024ULL)
#define COL_ARR_CACHE_MAX 128u
#define COL_ARR_CACHE_LIMIT_BYTES (256ULL * 1024ULL * 1024ULL) /* 256 MB default */

typedef enum wl_columnar_internal_tdd_fallback_reason {
    WL_COLUMNAR_INTERNAL_TDD_FALLBACK_NONE = 0,
    WL_COLUMNAR_INTERNAL_TDD_FALLBACK_NON_RECURSIVE,
    WL_COLUMNAR_INTERNAL_TDD_FALLBACK_SNAPSHOT_INELIGIBLE,
    WL_COLUMNAR_INTERNAL_TDD_FALLBACK_NO_EXCHANGE,
    WL_COLUMNAR_INTERNAL_TDD_FALLBACK_UNSAFE_PLAN,
    WL_COLUMNAR_INTERNAL_TDD_FALLBACK_ADAPTIVE_WORKERS,
    WL_COLUMNAR_INTERNAL_TDD_FALLBACK_REASON_COUNT
} wl_columnar_internal_tdd_fallback_reason_t;

/* ======================================================================== */
/* Column-Major Allocation Helpers (Phase C, Issue #332)                    */
/* ======================================================================== */

/** Allocate a column-major buffer: columns[col][row]. Returns NULL on failure. */
static inline int64_t **
col_columns_alloc(uint32_t ncols, uint32_t capacity)
{
    if (ncols == 0)
        return NULL;
    int64_t **cols = (int64_t **)calloc(ncols, sizeof(int64_t *));
    if (!cols)
        return NULL;
    for (uint32_t c = 0; c < ncols; c++) {
        cols[c] = (int64_t *)malloc(capacity > 0
            ? (size_t)capacity * sizeof(int64_t) : sizeof(int64_t));
        if (!cols[c]) {
            for (uint32_t j = 0; j < c; j++)
                free(cols[j]);
            free((void *)cols);
            return NULL;
        }
    }
    return cols;
}

/** Free a column-major buffer. */
static inline void
col_columns_free(int64_t **cols, uint32_t ncols)
{
    if (!cols)
        return;
    int64_t **cursor = cols;
    for (uint32_t c = 0; c < ncols; c++, cursor++)
        free(*cursor); /* NOLINT(clang-analyzer-security.ArrayBound) */
    free((void *)cols);
}

/** Realloc each column to new_cap. Returns 0 on success, ENOMEM on failure. */
static inline int
col_columns_realloc(int64_t **cols, uint32_t ncols, uint32_t new_cap)
{
    for (uint32_t c = 0; c < ncols; c++) {
        int64_t *nc = (int64_t *)realloc(cols[c],
                (size_t)new_cap * sizeof(int64_t));
        if (!nc)
            return ENOMEM;
        cols[c] = nc;
    }
    return 0;
}

/** Resize all columns transactionally. Returns 0 on success, ENOMEM on failure. */
static inline int
col_columns_realloc_atomic(int64_t **cols, uint32_t ncols, uint32_t old_cap,
    uint32_t new_cap)
{
    int64_t **replacement = (int64_t **)calloc(ncols, sizeof(int64_t *));
    if (!replacement)
        return ENOMEM;
    for (uint32_t c = 0; c < ncols; c++) {
        replacement[c] = (int64_t *)malloc((size_t)new_cap
                * sizeof(int64_t));
        if (!replacement[c]) {
            for (uint32_t i = 0; i < c; i++)
                free(replacement[i]);
            free((void *)replacement);
            return ENOMEM;
        }
        if (cols[c]) {
            uint32_t copy_cap = old_cap < new_cap ? old_cap : new_cap;
            memcpy(replacement[c], cols[c],
                (size_t)copy_cap * sizeof(int64_t));
        }
    }
    for (uint32_t c = 0; c < ncols; c++) {
        free(cols[c]);
        cols[c] = replacement[c];
    }
    free((void *)replacement);
    return 0;
}

/** Copy one row from a col_rel_t into a column-major destination buffer. */
static inline void
col_columns_copy_row(int64_t **dst_cols, uint32_t dst_row,
    int64_t *const *src_cols, uint32_t src_row, uint32_t ncols)
{
    for (uint32_t c = 0; c < ncols; c++)
        dst_cols[c][dst_row] = src_cols[c][src_row];
}

/* ======================================================================== */
/* Relation Storage                                                         */
/* ======================================================================== */

/*
 * col_rel_t: in-memory columnar relation.
 *
 * Tuples are stored column-major: columns[col][row] (Phase C, Issue #332).
 * Column names enable JOIN key resolution (variable name -> position).
 * The ArrowSchema provides Arrow-compatible type metadata.
 *
 * Deep Copy Semantics (Issue #555, rule R-3):
 *   When col_rel_deep_copy() creates a transient copy:
 *   - pool_owned and arena_owned are set to false on the destination
 *   - Caller owns the copy and must free it explicitly via
 *     col_rel_destroy(); a governed heap descriptor cannot use
 *     col_rel_free_contents() + free(struct)
 *   - delta_pool_reset() and arena reclaim will NOT touch the copy,
 *     since both flags are false
 *   - mem_ledger is also NULL on the copy (Issue #554, R-1)
 *   See wirelog/columnar/ownership_flags_design.md for the full rationale.
 */
typedef struct col_rel {
    char *name;                /* owned, null-terminated                */
    uint32_t ncols;            /* columns per tuple (0 = nullary)       */
    int64_t **columns;         /* owned, column-major: columns[col][row] */
    wirelog_column_type_t *column_types; /* physical type per lane       */
    uint32_t nrows;            /* current row count                     */
    uint32_t capacity;         /* allocated row capacity                */
    char **col_names;          /* owned array of ncols owned strings    */
    struct ArrowSchema schema; /* owned Arrow schema (lazy-inited)      */
    bool schema_ok;            /* true after schema is initialised      */
    /* Sorted-prefix tracking for incremental consolidation (issue #94).
     * After consolidation, sorted_nrows == nrows (all rows sorted+unique).
     * Appending new rows leaves sorted_nrows unchanged: rows [0..sorted_nrows)
     * are sorted, rows [sorted_nrows..nrows) are an unsorted suffix.
     * Enables O(D log D + N) merge instead of O(N log N) full sort. */
    uint32_t sorted_nrows;
    /* Persistent merge buffer for consolidation (issue #94).
     * Reused across iterations to avoid per-consolidation malloc/free.
     * Grows via realloc as needed; freed only on relation destruction. */
    int64_t **merge_columns;
    uint32_t merge_buf_cap; /* capacity in rows */
    /* Base row count for delta propagation (issue #83).
     * After initial eval convergence, base_nrows == nrows. On incremental
     * insert, nrows grows but base_nrows stays fixed. Rows[base_nrows..nrows)
     * are the delta (new EDB facts not yet propagated). */
    uint32_t base_nrows;
    /* Timestamp tracking (optional): NULL when disabled.
     * When non-NULL, timestamps[i] records the provenance of data row i.
     * Physical capacity can exceed columns during rollback or shrink. */
    col_delta_timestamp_t *timestamps;
    /* Physical timestamp allocation, independent of column capacity. */
    uint32_t timestamp_capacity;
    /* Pool ownership flag (issue #123).
     * true  = struct was allocated from delta_pool; do not free() the struct
     *         (lifecycle managed by allocator pool).
     * false = struct was heap-allocated via calloc(); free() on destroy.
     * Deep copies (#553) always set this to false (R-3, #555). */
    bool pool_owned;
    /* Arena ownership flag for data buffer.
     * true  = column buffers were allocated from wl_arena_t; do not free()
     *         (lifecycle managed by arena allocator).
     *         On growth (append_row), data is migrated to heap (malloc+memcpy).
     * false = column buffers were heap-allocated via malloc(); normal free().
     * Deep copies (#553) always set this to false (R-3, #555). */
    bool arena_owned;
    /* Memory ledger reference (Issue #224): when non-NULL, data buffer
     * growth/free events are reported to this ledger under
     * WL_MEM_SUBSYS_RELATION.  Set by operators that produce output
     * relations (e.g. col_op_join).  NULL for EDB and pool temporaries. */
    wl_mem_ledger_t *mem_ledger;
    /* Retained EDB admission.  This is deliberately separate from the
     * accounting ledger: the token represents the relation's live heap
     * footprint and is only attached to session-owned input relations. */
    wl_columnar_memory_governor_ref_t *memory_governor;
    /* Heap descriptor, name, and this token remain charged for the entire
     * descriptor lifetime. Pool descriptors are charged by their pool. */
    wl_columnar_memory_reservation_t descriptor_reservation;
    uint64_t descriptor_reserved_bytes;
    /* Heap-owned schema names, types, and nested ArrowSchema allocations. */
    wl_columnar_memory_reservation_t metadata_reservation;
    uint64_t metadata_reserved_bytes;
    /* A pool descriptor owns its heap name until publication promotes it. */
    wl_columnar_memory_reservation_t pool_name_reservation;
    uint64_t pool_name_reserved_bytes;
    /* The persistent TDD hash table is independent of relation payload. */
    wl_columnar_memory_reservation_t dedup_reservation;
    uint64_t dedup_reserved_bytes;
    /* Set when governed admission was denied while preparing this relation. */
    uint8_t memory_budget_denial_pending;
    wl_columnar_memory_reservation_t retained_reservation;
    uint64_t retained_reserved_bytes;
    /* Bytes currently charged to WL_MEM_SUBSYS_TIMESTAMP for this relation's
     * timestamps[] array (Issue #1380).  Maintained by
     * col_rel_ledger_reconcile()/col_rel_ledger_release(); always 0 when
     * mem_ledger is NULL. */
    uint64_t ledger_ts_bytes;
    /* Scratch buffer for col_rel_row() gather (Phase C, Issue #332).
     * Preallocated before governed publication; ungoverned relations may
     * allocate it lazily. Freed in free_contents. */
    int64_t *row_scratch;
    /* Zero-copy retraction backup (issue #300).
     * col_stratum_step_retraction_nonrecursive saves the live columns pointer
     * here before clearing the relation for retraction evaluation, then
     * restores it afterwards without any memcpy. The timestamp pointer and
     * its physical capacity move with the rows. All backup fields are
     * NULL/0 outside retraction evaluation. */
    int64_t **retract_backup_columns;
    col_delta_timestamp_t *retract_backup_timestamps;
    uint32_t retract_backup_timestamp_capacity;
    uint32_t retract_backup_nrows;
    uint32_t retract_backup_base_nrows;
    uint32_t retract_backup_capacity;
    uint32_t retract_backup_sorted_nrows;
    /* Zero-copy column sharing for worker sessions (Issue #334, 6B).
     * When col_shared[c] is true, columns[c] is borrowed (not owned) and
     * must NOT be freed on destroy. NULL when no sharing is active. */
    bool *col_shared;
    /* Tiered sorted-run tracking for incremental consolidation (#369).
     * Instead of one sorted prefix, maintain up to COL_MAX_RUNS independently
     * sorted+unique segments. Dedup checks all runs via binary search.
     * Compaction merges all runs when count exceeds threshold.
     * run_count == 0 means legacy single-prefix mode (sorted_nrows only). */
#define COL_MAX_RUNS 8
    uint32_t run_count;
    uint32_t run_ends[COL_MAX_RUNS]; /* run i spans [run_ends[i-1]..run_ends[i]) */
    /* Retraction backup for run tracking (#369). */
    uint32_t retract_backup_run_count;
    uint32_t retract_backup_run_ends[COL_MAX_RUNS];
    /* Hash-set dedup for TDD worker IDB (Issue #361).
     * When non-NULL, consolidation uses O(D) hash lookup instead of O(N)
     * merge walk.  Allocated by tdd_init_workers_hybrid for IDB relations,
     * freed on relation destruction.  NULL for non-TDD relations. */
    uint64_t *dedup_slots;     /* open-addressing hash table (0 = empty) */
    uint32_t dedup_cap;        /* power of 2 */
    uint32_t dedup_count;
    /* Issue #535: RDF named-graph support.
     * When has_graph_column == true, column at index graph_col_idx holds
     * the graph_id for each row, used for EXCHANGE partitioning and
     * metadata joining via __graph_metadata.  Set at relation creation
     * from plan's edb_has_graph_column[]; default false via calloc. */
    bool has_graph_column;
    uint32_t graph_col_idx;
    /* Compound-column metadata (Issue #532: inline tier).
     *
     * Relation-level summary of how compound columns are stored.  For
     * relations with no compound columns, all four fields are zero/NULL
     * and ncols == logical column count (no expansion).
     *
     * compound_kind
     *   WIRELOG_COMPOUND_KIND_NONE   -- no compound columns (default)
     *   WIRELOG_COMPOUND_KIND_INLINE -- >=1 inline compound column; the
     *                                   physical schema (ncols/columns)
     *                                   has been expanded, each inline
     *                                   compound occupying `arity`
     *                                   contiguous physical slots.
     *   WIRELOG_COMPOUND_KIND_SIDE   -- compound values live in a
     *                                   side-relation; physical schema
     *                                   matches the logical schema one-
     *                                   to-one (no expansion).
     *
     * compound_count
     *   Number of inline-kind logical columns in this relation.  Zero
     *   when compound_kind != INLINE.
     *
     * compound_arity_map / compound_arity_len
     *   Owned array of compound_arity_len logical entries. Entry
     *   i is the expansion arity of logical column i: 1 for a scalar
     *   column, N (>=1) for an inline compound of arity N. NULL exactly
     *   when compound_arity_len is zero. Freed on relation destruction.
     *
     * inline_physical_offset
     *   Physical column index at which the first inline compound slot
     *   begins.  Zero when compound_kind != INLINE.  When non-zero it
     *   matches the prefix-sum of compound_arity_map entries that
     *   precede the first inline compound.
     *
     * Every map read is bounded by compound_arity_len and validates that
     * positive entries sum to physical ncols.
     */
    wirelog_compound_kind_t compound_kind;
    uint32_t compound_count;
    uint32_t *compound_arity_map;
    uint32_t compound_arity_len;
    uint32_t inline_physical_offset;

    /* Issue #1038: the relation's declared *physical* width, propagated from
     * the plan at session creation, or 0 when there is nothing to enforce.
     *
     * Without it a relation's width was whatever its first producer supplied
     * -- col_session_insert() set the schema lazily from the caller's ncols
     * and nothing compared that against the `.decl`.  A host inserting an
     * inline-compound relation at its *logical* width established it too
     * narrow, and a destructuring rule then read a slot nobody wrote.
     *
     * 0 covers two cases that are both correctly unenforced: a relation with
     * no `.decl` (legitimate and caller-defined), and the degenerate
     * zero-arity `.decl p()`, which carries no data for a width check to
     * protect.  Using 0 rather than a sentinel keeps every calloc()
     * allocation path correct by default, as the block above requires. */
    uint32_t declared_ncols;

    /* Internal snapshot identity and invalidation generations (#1441).
     *
     * These fields intentionally remain at the end of the structure.  The
     * prefix above is an existing private layout consumed by arrangement
     * fixtures and other in-tree mirrors; inserting new fields in that
     * prefix changes their offsets even though col_rel_t is private.
     *
     * relation_identity is stable for the lifetime of this relation object;
     * copies get their own identity.  view_generation describes logical
     * values, row order, and schema/type interpretation.  The storage
     * generation describes backing-buffer replacement or ownership changes.
     * UINT64_MAX is a poisoned value: once a counter reaches it, equality
     * must not be used as evidence that two snapshots match. */
    uint64_t relation_identity;
    uint64_t view_generation;
    uint64_t storage_generation;

    /* Source-storage ownership for zero-copy shared views (Issue #1493).
    * Shared views canonicalize this pointer to the ultimate relation that
    * owns the borrowed column buffers. Alias chains are never persisted:
    * an alias has storage_alias_borrows == 0, while the root counts its
    * direct and flattened aliases. The borrow count is atomic because
    * worker alias retirement may update it while peer readers are active;
    * mutation admission must still recheck it under the owner writer. */
    struct col_rel *storage_owner;
    uint64_t storage_owner_identity;
    uint64_t storage_owner_generation;
    wl_atomic_u64 storage_alias_borrows;

    /* Operation-scoped readers protect the ultimate storage owner from
     * checked destruction. The descriptor gate also protects alias metadata
     * while the canonical owner is resolved or its shared view is replaced. */
    wl_columnar_source_access_gate_t source_access;
    wl_columnar_source_access_gate_t descriptor_access;
    /* Intrusive session-owned deferred-destruction registry link.  A relation
     * may be present in at most one session registry at a time; the owner
     * pointer makes that invariant explicit even for a one-element list. */
    struct col_rel *deferred_relation_next;
    struct wl_col_session_t *deferred_relation_session;
} col_rel_t;

/* Roles and caller-owned mutation storage must remain unchanged at their
 * original addresses until
 * finish. Roles contain descriptors only; owners are resolved after exclusion. */
typedef enum {
    WL_COLUMNAR_RELATION_PAYLOAD_MUTATION = 1,
    WL_COLUMNAR_RELATION_METADATA_DETACH = 2
} wl_columnar_relation_mutation_role_flags_t;

typedef struct {
    col_rel_t *relation;
    wl_columnar_relation_mutation_role_flags_t role_flags;
} wl_columnar_relation_mutation_role_t;

typedef struct {
    col_rel_t *relation;
    wl_columnar_source_access_writer_t writer;
} wl_columnar_relation_mutation_descriptor_t;

typedef struct {
    col_rel_t *owner;
    wl_columnar_source_access_writer_t writer;
} wl_columnar_relation_mutation_owner_t;

typedef struct {
    col_rel_t *relation;
    uint64_t owner_identity;
    uint64_t owner_generation;
    uint64_t borrows;
} wl_columnar_relation_mutation_initialization_t;

struct wl_columnar_relation_mutation_set;
typedef struct {
    uintptr_t identity;
    uint64_t acquisition_nonce;
    struct wl_columnar_relation_mutation_set *set;
    col_rel_t *relation;
    col_rel_t *owner;
    size_t descriptor_slot;
    size_t owner_slot;
    size_t self_owner_slot;
    uint64_t relation_identity;
    uint64_t relation_generation;
    uint64_t owner_identity;
    uint64_t owner_generation;
    wl_columnar_relation_mutation_role_flags_t role_flags;
    bool detached;
    bool storage_transitioned;
} wl_columnar_relation_mutation_lease_t;

struct wl_columnar_relation_terminal_sequence;
typedef struct wl_columnar_relation_mutation_set {
    uintptr_t identity;
    uint64_t acquisition_nonce;
    const wl_columnar_relation_mutation_role_t *roles;
    wl_columnar_relation_mutation_descriptor_t *descriptors;
    wl_columnar_relation_mutation_owner_t *owners;
    wl_columnar_relation_mutation_lease_t *leases;
    wl_columnar_relation_mutation_initialization_t *initializations;
    size_t descriptor_count;
    size_t owner_count;
    size_t lease_count;
    size_t initialization_count;
    size_t descriptors_acquired;
    size_t owners_acquired;
    struct wl_columnar_relation_terminal_sequence *terminal_sequence;
    uint32_t terminal_expected_events;
    uint32_t terminal_observed_events;
    bool terminal_sequence_consumed;
    bool published;
} wl_columnar_relation_mutation_set_t;

typedef enum {
    WL_COLUMNAR_RELATION_TERMINAL_GRID_SWAP = 1u << 0,
    WL_COLUMNAR_RELATION_TERMINAL_TIMESTAMP_RETIRE = 1u << 1
} wl_columnar_relation_terminal_event_t;

/* A zero-initialized, transaction-local record for storage publications after
 * incremental consolidation has completed every fallible preparation step.
 * Its event mask is consumed by relation-specific publication helpers. */
typedef struct wl_columnar_relation_terminal_sequence {
    uintptr_t identity;
    wl_columnar_relation_mutation_set_t *set;
    wl_columnar_relation_mutation_lease_t *lease;
    col_rel_t *relation;
    col_rel_t *owner;
    int64_t **columns_before;
    int64_t **merge_columns_before;
    col_delta_timestamp_t *timestamps_before;
    size_t descriptor_slot;
    size_t owner_slot;
    size_t self_owner_slot;
    uintptr_t descriptor_writer_identity;
    uintptr_t owner_writer_identity;
    uintptr_t self_writer_identity;
    uint64_t relation_identity;
    uint64_t owner_identity;
    uint64_t relation_generation;
    uint64_t owner_generation;
    uint32_t capacity_before;
    uint32_t merge_capacity_before;
    uint32_t timestamp_capacity_before;
    uint32_t expected_events;
    uint32_t observed_events;
    bool detached_before;
    bool storage_transitioned_before;
    bool armed;
    bool consumed;
} wl_columnar_relation_terminal_sequence_t;

/* Single-entry storage lives with the operation, including its role mapping. */
typedef struct {
    wl_columnar_relation_mutation_set_t set;
    wl_columnar_relation_mutation_role_t role;
    wl_columnar_relation_mutation_descriptor_t descriptor;
    wl_columnar_relation_mutation_owner_t owners[2];
    wl_columnar_relation_mutation_lease_t lease;
    wl_columnar_relation_mutation_initialization_t initialization;
} wl_columnar_relation_mutation_single_t;

/* Fixed one-role admission, fully inert original-frame storage only.
 * Controlled failure cleanup and the dedicated finish are noncancellable:
 * failed release retains remaining authority for retry in the original frame
 * with the original execution result. Finish follows the caller's publication
 * cutoff; terminal sequences are unsupported.
 * NULL control delegates to raw admission after the inert preflight. Successful
 * raw acquisition is compatible with dedicated finish. Raw admission failure
 * keeps existing generic-unwind semantics, not the new retained-authority
 * guarantee, and may leave role fields after resetting the set. Do not finish
 * an already reset raw set or reuse its non-inert frame. Reinitialize role
 * residue only after independently verifying all authority has retired. */
int wl_columnar_relation_mutation_single_acquire_controlled(col_rel_t *,
    wl_columnar_relation_mutation_single_t *, wl_evaluation_control_t *);
/* Caller-attempt-bound admission for initialized private scalar self-owners.
 * Requires live relation/control and exclusive inert original frame; control
 * lifecycle is externally serialized. Frame, relation and control storage
 * must not overlap. Callbacks may not free or forge original frame/tokens,
 * or mutate protected descriptor shape. NULL control or zero/stale ID returns
 * EINVAL without debit or frame mutation. No alias, pool, arena, compound or
 * lazy-owner expansion. Every forward admission hook validates the original ID
 * before another
 * hook, claim or debit. Success uses the dedicated noncancellable finish below.
 * Failure retires only original authority; a failed release retains the frame
 * for caller drain/fail-stop, even if an initiating positive error masks the
 * release error. Never discard a frame with retained authority. Mandatory
 * cleanup release hooks are exempt from forward ID checks and polling.
 * The finite read-only bootstrap is an explicit uncharged exception, included
 * retrospectively in the first admitted region. */
int wl_columnar_relation_mutation_single_acquire_attempt_controlled(col_rel_t *,
    wl_columnar_relation_mutation_single_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_relation_mutation_single_finish_controlled(
    wl_columnar_relation_mutation_single_t *, int, wl_evaluation_control_t *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_relation_test_before_nonce_cas)(
    wl_evaluation_control_t *, uint64_t);
/* slot0=descriptor, slot1/2=owner0/1; fail before touching live authority. */
extern int (*wl_columnar_relation_test_single_release)(
    wl_columnar_relation_mutation_single_t *, unsigned);
uint64_t wl_columnar_relation_test_single_nonce_replace(uint64_t);
#endif

int col_rel_mutation_set_acquire(wl_columnar_relation_mutation_set_t *set,
    const wl_columnar_relation_mutation_role_t *roles, size_t role_count,
    wl_columnar_relation_mutation_descriptor_t *descriptors,
    size_t descriptor_cap,
    wl_columnar_relation_mutation_owner_t *owners, size_t owner_cap,
    wl_columnar_relation_mutation_lease_t *leases, size_t lease_cap,
    wl_columnar_relation_mutation_initialization_t *initializations,
    size_t initialization_cap);
wl_columnar_relation_mutation_lease_t *col_rel_mutation_set_lease(
    wl_columnar_relation_mutation_set_t *set, size_t index);
int col_rel_mutation_lease_validate(
    const wl_columnar_relation_mutation_lease_t *lease,
    const col_rel_t *expected_relation);
int col_rel_mutation_set_finish(wl_columnar_relation_mutation_set_t *set,
    bool commit);
int wl_columnar_relation_terminal_sequence_begin(
    wl_columnar_relation_terminal_sequence_t *sequence,
    wl_columnar_relation_mutation_lease_t *lease, uint32_t expected_events);
void wl_columnar_relation_terminal_sequence_publish_grid_swap(
    wl_columnar_relation_terminal_sequence_t *sequence);
void wl_columnar_relation_terminal_sequence_publish_timestamp_retirement(
    wl_columnar_relation_terminal_sequence_t *sequence);
int wl_columnar_relation_terminal_sequence_finish(
    wl_columnar_relation_terminal_sequence_t *sequence);
#ifdef WL_TEST_MUTATION_SET_HOOK
void wl_columnar_relation_test_set_mutation_nonce(uint64_t next_nonce);
uint64_t wl_columnar_relation_test_mutation_nonce_peek(void);
uint64_t wl_columnar_relation_test_lease_validations_peek(void);
bool wl_columnar_relation_test_terminal_sequence_validate(
    const wl_columnar_relation_terminal_sequence_t *sequence);
#endif
#ifdef WL_TEST_MUTATION_SET_HOOK
int wl_columnar_relation_test_mutation_lease_advance_storage(
    wl_columnar_relation_mutation_lease_t *lease, uint64_t prior_generation);
#endif
/* Metadata detach publishes the independent binding before its final atomic
 * old-owner borrow decrement. The caller must never access that old owner
 * again through this lease after successful release. */
int col_rel_storage_alias_release_locked(col_rel_t *alias,
    wl_columnar_relation_mutation_lease_t *lease);

/* Prepared terminal retirement of an independent heap relation. The token
 * holds the descriptor and source writers from prepare through cancel or
 * commit; callers must keep the descriptor pointer stable and must not copy,
 * move, or use the token from another thread during that interval. */
typedef struct wl_columnar_relation_retirement_token {
    col_rel_t *relation;
    wl_columnar_source_access_writer_t descriptor_writer;
    wl_columnar_source_access_writer_t source_writer;
    bool transient_backing_allowed;
} wl_columnar_relation_retirement_token_t;

/* A private, fully staged publication for a canonical relation.  The staged
 * relation owns every buffer until commit or discard; the writer token keeps
 * the destination's canonical owner stable across that interval. */
typedef struct col_rel_replacement {
    col_rel_t *staged;
    wl_columnar_memory_reservation_t reservation;
    wl_columnar_memory_reservation_t metadata_reservation;
    wl_columnar_memory_reservation_t dedup_reservation;
    wl_columnar_source_access_writer_t writer;
    uint64_t reserved_bytes;
    uint64_t metadata_reserved_bytes;
    uint64_t dedup_reserved_bytes;
    bool reservation_active;
    bool metadata_reservation_active;
    bool dedup_reservation_active;
    bool writer_acquired;
} col_rel_replacement_t;

/* Private governed source image. The source writer remains held until commit
 * or discard; callers may mutate only the image returned by get(). */
typedef struct col_rel_mutable_image {
    col_rel_t *source;
    col_rel_t *image;
    wl_columnar_source_access_writer_t writer;
} col_rel_mutable_image_t;

/* Private, resumable retirement for the deliberately narrow managed-merge
 * relation shape. The relation and this record remain at stable addresses on
 * the creating thread until every token receipt is acknowledged. */
typedef enum wl_columnar_relation_managed_retirement_phase {
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_INERT = 0,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_ACQUIRE_WRITERS,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_VALIDATE,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_DETACH_DESCRIPTOR,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_DETACH_METADATA,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_DETACH_DEDUP,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_DETACH_RETAINED,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_DETACH_GOVERNOR,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_COLUMN_0,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_COLUMN_1,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_COLUMNS_ARRAY,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_MERGE_COLUMN_0,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_MERGE_COLUMN_1,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_MERGE_COLUMNS_ARRAY,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_ROW_SCRATCH,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_COLUMN_TYPES,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_RELEASE_SCHEMA,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_ZERO_DESCRIPTOR,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_FREE_DESCRIPTOR,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_CONSUME_TERMINAL_WRITERS,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_RETIRE_METADATA,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_RETIRE_DEDUP,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_RETIRE_RETAINED,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_RETIRE_DESCRIPTOR,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_ACK_METADATA,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_ACK_DEDUP,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_ACK_RETAINED,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_ACK_DESCRIPTOR,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_RELEASE_GOVERNOR,
    WL_COLUMNAR_RELATION_MANAGED_RETIREMENT_DONE
} wl_columnar_relation_managed_retirement_phase_t;

typedef struct wl_columnar_relation_managed_retirement {
    uintptr_t identity;
    col_rel_t *relation;
    uintptr_t original_relation_address;
    wl_columnar_memory_governor_ref_t *governor_ref;
    wl_columnar_memory_governor_t *governor;
    wl_columnar_source_access_gate_round_t gate_round;
    wl_columnar_relation_managed_retirement_phase_t phase;
    wl_columnar_memory_reservation_t tokens[4];
    wl_columnar_memory_retirement_receipt_t receipts[4];
    uint64_t token_bytes[4];
    uint64_t token_owner_bits[4];
    bool receipt_started[4];
    bool token_empty[4];
} wl_columnar_relation_managed_retirement_t;

/* Reversible scalar retirement preparation followed by irreversible disposal.
 * Keep this receipt at its original address. READY holds terminal writer claims;
 * cancel is allowed only before commit. After commit the descriptor belongs to
 * the receipt and must never be used by another owner, including after free. */
typedef struct {
    wl_columnar_relation_managed_retirement_t storage;
    wl_mem_ledger_t *ledger;
    uint64_t ledger_bytes;
    uint64_t ledger_timestamp_bytes, timestamp_bytes;
    uint32_t owned_columns;
    uint32_t column, prior_column;
    unsigned phase;
    bool ready, committed;
} wl_columnar_relation_scalar_retirement_t;
int wl_columnar_relation_scalar_retirement_begin(
    wl_columnar_relation_scalar_retirement_t *, col_rel_t *);
int wl_columnar_relation_scalar_retirement_prepare(
    wl_columnar_relation_scalar_retirement_t *, wl_evaluation_control_t *,
    uint64_t);
/* Finite preparation splits the four token validations into separate turns.
 * Ledger step handles phase12 once; caller funds metadata128 and immediately
 * drains/cancels every local ledger publication before returning. */
enum {
    WL_COLUMNAR_RELATION_SCALAR_FINITE_PAYLOAD = 21
};
int wl_columnar_relation_scalar_retirement_prepare_finite(
    wl_columnar_relation_scalar_retirement_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_relation_scalar_retirement_ledger_step_finite(
    wl_columnar_relation_scalar_retirement_t *, wl_evaluation_control_t *,
    uint64_t);
/* Address-stable parent ledger journal across separate real grants. Never
 * wrap DESCRIBE/COMMIT in the old metadata128 prefix. The ACK/no-ledger branch
 * alone owns that extracted metadata action; actual caller/return bounds
 * remain the enabling parent's qualification obligation. Capture COMMIT's
 * actual report before the next generation, using retirement_capture_owned.
 * The relation descriptor stays alive until applied ACK advances phase12. */
int wl_columnar_relation_scalar_retirement_ledger_step_described(
    wl_columnar_relation_scalar_retirement_t *,
    wl_columnar_mem_ledger_retirement_journal_t *, const void *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_relation_scalar_retirement_cancel(
    wl_columnar_relation_scalar_retirement_t *);
int wl_columnar_relation_scalar_retirement_commit(
    wl_columnar_relation_scalar_retirement_t *);
int wl_columnar_relation_scalar_retirement_step(
    wl_columnar_relation_scalar_retirement_t *, wl_evaluation_control_t *,
    uint64_t);

/* Metered asynchronous scalar initialization. Actual parent owns target lifetime,
 * scalar storage and original control ref, freezes selection before BOOT hooks,
 * and proves no live scalar receipt is overwritten. ZERO clears64 bytes per
 * step, TOKENS initializes one reservation, and BIND publishes identity last.
 * This initializer owns no
 * relation/ref/gate; DONE means genuinely BEGUN, never READY. Parent latches
 * begun ownership immediately at BIND, before separately funded RESET. */
typedef enum {
    WL_COLUMNAR_RELATION_SCALAR_INIT_INERT,
    WL_COLUMNAR_RELATION_SCALAR_INIT_ZERO,
    WL_COLUMNAR_RELATION_SCALAR_INIT_TOKENS,
    WL_COLUMNAR_RELATION_SCALAR_INIT_BIND,
    WL_COLUMNAR_RELATION_SCALAR_INIT_DONE
} wl_columnar_relation_scalar_retirement_init_phase_t;
typedef struct wl_columnar_relation_scalar_retirement_initializer {
    struct wl_columnar_relation_scalar_retirement_initializer *identity;
    const void *parent;
    wl_columnar_relation_scalar_retirement_t *retirement;
    col_rel_t *relation;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid, busy;
    size_t zero_offset;
    unsigned token_index;
    wl_columnar_relation_scalar_retirement_init_phase_t phase;
} wl_columnar_relation_scalar_retirement_initializer_t;
int wl_columnar_relation_scalar_retirement_init_begin(
    wl_columnar_relation_scalar_retirement_initializer_t *, const void *,
    wl_columnar_relation_scalar_retirement_t *, col_rel_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_relation_scalar_retirement_init_step(
    wl_columnar_relation_scalar_retirement_initializer_t *, const void *,
    wl_columnar_relation_scalar_retirement_t *, col_rel_t *,
    wl_evaluation_control_t *, uint64_t, bool *);
/* RESET drops only initializer progress. Parent already acknowledges a DONE
 * begun receipt, or abandons pre-BIND initialization with no writer claims. */
int wl_columnar_relation_scalar_retirement_init_reset(
    wl_columnar_relation_scalar_retirement_initializer_t *, const void *,
    wl_evaluation_control_t *, uint64_t);
/* Parent authenticates uncommitted receipt lifetime/native ownership. Release
 * its genuine writer claims only, invalidate READY, then parent enters CLEAR.
 * Scalar storage is cleared later with separate actual funding. */
int wl_columnar_relation_scalar_retirement_ready_validate(
    const wl_columnar_relation_scalar_retirement_t *, const col_rel_t *,
    col_relation_snapshot_t);
int wl_columnar_relation_scalar_retirement_release_claims_controlled(
    wl_columnar_relation_scalar_retirement_t *, wl_evaluation_control_t *,
    uint64_t);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_relation_scalar_retirement_init_test_checkpoint)(
    wl_columnar_relation_scalar_retirement_initializer_t *,
    wl_evaluation_control_t *, unsigned);
extern void (*wl_columnar_relation_scalar_retirement_init_test_after_step)(
    wl_columnar_relation_scalar_retirement_initializer_t *,
    wl_evaluation_control_t *);
#endif

/* One-funded-action-at-a-time builder for a private, unnamed binary INT64
 * relation. On a terminal allocation failure, relation retains all partial
 * ownership so it can be passed to managed_retirement_begin().  abandon()
 * puts a builder stopped before READY into that FAILED shape; the recursive
 * route's abort cleanup and the candidate merge cleanup call it. */
typedef enum wl_columnar_relation_managed_binary_build_phase {
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_INERT = 0,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_DESCRIPTOR,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_SHAPE,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_RESERVE_RETAINED,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_COMMIT_RETAINED,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_COLUMNS_ARRAY,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_COLUMN_0,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_COLUMN_1,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_MERGE_COLUMNS_ARRAY,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_MERGE_COLUMN_0,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_MERGE_COLUMN_1,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_ROW_SCRATCH,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_COLUMN_TYPES,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_READY,
    WL_COLUMNAR_RELATION_MANAGED_BINARY_BUILD_FAILED
} wl_columnar_relation_managed_binary_build_phase_t;

typedef struct wl_columnar_relation_managed_binary_build {
    uintptr_t identity;
    col_rel_t *relation;
    wl_columnar_memory_governor_ref_t *governor_ref;
    wl_columnar_relation_managed_binary_build_phase_t phase;
    uint64_t retained_bytes;
    uint64_t allocation_units_remaining;
    wl_columnar_relation_managed_binary_build_phase_t allocation_phase;
    uint64_t allocation_control_identity;
    uint64_t allocation_attempt_id;
    uint32_t capacity;
    int failure_status;
} wl_columnar_relation_managed_binary_build_t;

/* Resumable private union of an unnamed, private two-column INT64 source and
 * candidate. Source rows must be canonical and sorted; candidate rows may be
 * arbitrary-order and duplicated. Both inputs are read-only. The caller keeps
 * both descriptors alive and excludes all raw-pointer use until cleanup DONE.
 * Initialize the address-bound record with { 0 }; all calls stay on its creator
 * thread. Both inputs must share the same governor, including both NULL. */
typedef enum wl_columnar_managed_candidate_phase {
    WL_COLUMNAR_MANAGED_CANDIDATE_INERT = 0,
    WL_COLUMNAR_MANAGED_CANDIDATE_BUILD_REPLACEMENT,
    WL_COLUMNAR_MANAGED_CANDIDATE_BUILD_SCRATCH,
    WL_COLUMNAR_MANAGED_CANDIDATE_COPY_SOURCE,
    WL_COLUMNAR_MANAGED_CANDIDATE_COPY_CANDIDATE,
    WL_COLUMNAR_MANAGED_CANDIDATE_SORT,
    WL_COLUMNAR_MANAGED_CANDIDATE_DEDUP,
    WL_COLUMNAR_MANAGED_CANDIDATE_COUNT_NOVEL,
    WL_COLUMNAR_MANAGED_CANDIDATE_BUILD_DELTA,
    WL_COLUMNAR_MANAGED_CANDIDATE_EMIT_DELTA,
    WL_COLUMNAR_MANAGED_CANDIDATE_READY,
    WL_COLUMNAR_MANAGED_CANDIDATE_ABORT_CLEANUP,
    WL_COLUMNAR_MANAGED_CANDIDATE_SUCCESS_CLEANUP,
    WL_COLUMNAR_MANAGED_CANDIDATE_DONE
} wl_columnar_managed_candidate_phase_t;

typedef struct wl_columnar_managed_candidate_merge {
    uintptr_t identity;
    col_rel_t *source;
    const col_rel_t *candidate;
    wl_evaluation_control_t *control;
    uint64_t control_attempt_id;
    col_relation_snapshot_t source_snapshot;
    col_relation_snapshot_t candidate_snapshot;
    wl_columnar_source_access_gate_round_t input_gates;
    wl_columnar_relation_managed_binary_build_t replacement_build;
    wl_columnar_relation_managed_binary_build_t scratch_build;
    wl_columnar_relation_managed_binary_build_t delta_build;
    wl_columnar_relation_managed_retirement_t retirements[3];
    wl_columnar_managed_candidate_phase_t phase;
    uint32_t source_rows;
    uint32_t candidate_rows;
    uint32_t input_rows;
    uint32_t capacity;
    uint32_t copy_row;
    uint32_t copy_column;
    uint32_t sort_width;
    uint32_t sort_left;
    uint32_t sort_mid;
    uint32_t sort_right;
    uint32_t sort_i;
    uint32_t sort_j;
    uint32_t sort_out;
    uint32_t sort_selected_row;
    uint32_t sort_copy_column;
    uint32_t sort_compare_column;
    uint32_t dedup_read;
    uint32_t dedup_write;
    uint32_t dedup_compare_column;
    uint32_t dedup_copy_column;
    uint32_t search_row;
    uint32_t search_low;
    uint32_t search_high;
    uint32_t search_mid;
    uint32_t search_column;
    uint32_t novel_count;
    uint32_t emit_row;
    uint32_t emit_write;
    uint32_t emit_column;
    uint32_t cleanup_index;
    int terminal_status;
    bool sort_source_scratch;
    bool sort_selected;
    bool dedup_copy_active;
    bool search_active;
    bool search_found;
    bool retirement_started[3];
    bool result_transferred;
} wl_columnar_managed_candidate_merge_t;

/* Parent-owned sibling, never inside the inline target being cleared. Raw
 * APIs remain synchronous; the private parent must exclude every raw target
 * entry/reset/free while this actual action/report owner is pending. */
typedef enum {
    WL_COLUMNAR_MANAGED_MERGE_ACK_INERT,
    WL_COLUMNAR_MANAGED_MERGE_ACK_RETIREMENTS,
    WL_COLUMNAR_MANAGED_MERGE_ACK_TOKENS,
    WL_COLUMNAR_MANAGED_MERGE_ACK_CLEAR,
    WL_COLUMNAR_MANAGED_MERGE_ACK_COMPLETE
} wl_columnar_managed_merge_ack_phase_t;
typedef struct wl_columnar_managed_candidate_merge_ack_progress {
    struct wl_columnar_managed_candidate_merge_ack_progress *identity;
    const void *parent;
    wl_columnar_managed_candidate_merge_t *target;
    wl_evaluation_control_t *support;
    uint64_t support_identity, support_id;
    size_t clear_offset;
    unsigned retirement_index, token_index, clear_atomic_index;
    wl_columnar_managed_merge_ack_phase_t phase;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t actor;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD actor;
#else
    pthread_t actor;
#endif
    bool busy, performed, report_pending, ack_prepaid, physical_done;
} wl_columnar_managed_candidate_merge_ack_progress_t;

/* A resumable, private incremental consolidation. Initialize the object with
 * { 0 } before begin. The object and its writer are address- and thread-bound;
 * keep it in one frame and pass by pointer.
 * EAGAIN from advance means only that this call's work slice was consumed;
 * the private candidate and source writer remain live for a later call.
 * Terminal control stops and execution errors discard the attempt. */
typedef enum wl_columnar_merge_incremental_delta_phase {
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_INERT = 0,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_COPY_DEDUP,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_COPY,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_FAST_OLD_MAX,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_FAST_CHECK,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_SORT,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_DEDUP,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_COUNT_NOVEL,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_ALLOC_DELTA,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_EMIT_DELTA,
    WL_COLUMNAR_MERGE_INCREMENTAL_DELTA_DONE
} wl_columnar_merge_incremental_delta_phase_t;

typedef struct wl_columnar_merge_incremental_delta_attempt {
    uintptr_t identity;
    col_rel_mutable_image_t transaction;
    const col_rel_t *candidate;
    wl_columnar_source_access_reader_t candidate_reader;
    col_rel_t *delta;
    wl_evaluation_control_t *control;
    uint64_t control_attempt_id;
    col_relation_snapshot_t source_snapshot;
    col_relation_snapshot_t candidate_snapshot;
    uint32_t old_nrows;
    uint32_t source_nrows;
    uint32_t candidate_nrows;
    uint32_t input_nrows;
    uint32_t run_count;
    uint32_t run_ends[COL_MAX_RUNS];
    wl_columnar_merge_incremental_delta_phase_t phase;
    bool no_op;
    bool external_candidate;
    bool candidate_reader_held;
    bool candidate_first;
    uint32_t dedup_copy_cursor, dedup_copy_count, dedup_copy_occupied;
    uint32_t copy_row, copy_column;
    uint32_t max_old_row, fast_scan_row;
    bool fast_path;
    uint32_t sort_width, sort_left, sort_mid, sort_right;
    uint32_t sort_i, sort_j, sort_out, sort_copy_column;
    uint32_t sort_copy_row;
    bool sort_source_primary;
    bool sort_run_active;
    bool sort_copy_active;
    uint32_t dedup_input, dedup_write, dedup_copy_column;
    bool dedup_copy_active;
    uint32_t novel_row, novel_run, search_low, search_high;
    bool novel_search_active;
    bool novel_found;
    uint32_t novel_count;
    uint32_t emit_input, emit_run, emit_low, emit_high;
    uint32_t emit_copy_column, emit_count;
    bool emit_search_active, emit_found;
    bool emit_copy_active;
    bool compare_active, compare_zero_charged;
    uint8_t compare_left_grid, compare_right_grid;
    uint32_t compare_left_row, compare_right_row, compare_column;
} wl_columnar_merge_incremental_delta_attempt_t;

/* Caller holds the canonical source writer. Creates a governed, empty
 * relation with the source's schema and interpretation metadata but no name,
 * rows, timestamps, or shared storage. */
int wl_columnar_relation_new_empty_governed_like_locked(col_rel_t *source,
    col_rel_t **out);
int wl_columnar_relation_mutable_image_prepare_empty(col_rel_t *source,
    col_rel_mutable_image_t *transaction, uint32_t capacity);

int wl_columnar_merge_incremental_delta_attempt_begin(col_rel_t *source,
    uint32_t old_nrows, wl_columnar_merge_incremental_delta_attempt_t *attempt,
    wl_evaluation_control_t *control);
/* Merge separately staged positive-arity INT64 tuples without modifying
 * candidate. The source must be a canonical sorted relation; candidate may
 * be unsorted. Zero-column, timestamped, and compound relations are unsupported.
 * On commit, source becomes set(source U candidate) and delta is
 * set(candidate) - set(source). Inputs are held stable through commit/abort.
 * EAGAIN from advance is a same-control-attempt slice; terminal stops discard
 * the attempt, so a retry begins fresh from unchanged inputs. */
int wl_columnar_merge_incremental_delta_attempt_begin_candidate(
    col_rel_t *source, const col_rel_t *candidate,
    wl_columnar_merge_incremental_delta_attempt_t *attempt,
    wl_evaluation_control_t *control);
int wl_columnar_merge_incremental_delta_attempt_advance(col_rel_t *source,
    wl_columnar_merge_incremental_delta_attempt_t *attempt,
    wl_evaluation_control_t *control, uint64_t work_budget);
int wl_columnar_merge_incremental_delta_attempt_commit(col_rel_t *source,
    wl_columnar_merge_incremental_delta_attempt_t *attempt,
    col_rel_t **delta_out,
    int *out_fast_path, wl_evaluation_control_t *control);
int wl_columnar_merge_incremental_delta_attempt_abort(col_rel_t *source,
    wl_columnar_merge_incremental_delta_attempt_t *attempt);

/* The boundary that matters is thread affinity, not the return code.
 *
 * discard() is a no-op when the transaction records no source.  Otherwise it
 * aborts on the same three conditions that make commit() return EINVAL for a
 * live transaction: a writer token whose owner is not this source, whose
 * identity is not the token's own address, or whose thread is not this one.
 * So: discard unconditionally, on the thread that ran prepare() and through
 * the same object.  The token is bound to its own address, so discarding a
 * by-value copy of the transaction aborts; from another thread neither
 * commit() nor discard() is usable.
 *
 * commit() also returns EINVAL for a null, zeroed or image-cleared
 * transaction.  discard() stays correct in each of those, and for the
 * image-cleared one it is required: it releases the writer that would
 * otherwise keep col_rel_destroy_checked returning EBUSY, which
 * col_rel_destroy discards, leaking the relation and its credit.  commit()
 * returns EBUSY when the source or image no longer validates or the image has
 * acquired a name, a pool or another governor; it publishes nothing and the
 * transaction stays live.
 *
 * prepare() returns EINVAL on a null argument and EBUSY on an already-live
 * transaction, touching neither, so a second call cannot orphan the first
 * one's writer.  It also returns EBUSY from the writer acquisition itself, so
 * EBUSY does not mean the transaction was already live.  Every failure after
 * the acquisition leaves it inert: no source or image recorded and no writer
 * held.  On 0 it is live and owns the source writer. */
int col_rel_mutable_image_prepare(col_rel_t *source,
    col_rel_mutable_image_t *transaction);
col_rel_t *col_rel_mutable_image_get(col_rel_mutable_image_t *transaction);
int col_rel_mutable_image_commit(col_rel_mutable_image_t *transaction);
void col_rel_mutable_image_discard(col_rel_mutable_image_t *transaction);

#ifdef WL_TEST_APPEND_HOOK
/* Test-only seam for the append ownership-transition window.  This is not
 * part of the installed/public header surface. */
typedef void (*wl_columnar_append_transition_hook_t)(col_rel_t *);
extern wl_columnar_append_transition_hook_t
    wl_columnar_append_transition_hook;
#endif

#ifdef WL_TEST_SET_HOOK
/* Test-only seam for the checked-set COW transition window. */
typedef void (*wl_columnar_set_transition_hook_t)(col_rel_t *);
extern wl_columnar_set_transition_hook_t wl_columnar_set_transition_hook;
#endif

#ifdef WL_TEST_RELATION_RESIZE_HOOK
/* Test-only seam for forcing the private resize preparation to fail. */
extern bool wl_columnar_relation_test_fail_prepare_resize;
/* One-based real allocation ordinal; zero disables the growth fault. */
extern uint32_t wl_columnar_relation_test_growth_fail_allocation;
extern void (*wl_columnar_relation_test_reader_after_descriptor)(
    const col_rel_t *);
extern void (*wl_columnar_relation_test_rebind_after_descriptor)(
    const col_rel_t *);
extern void (*wl_columnar_relation_test_rebind_before_publication)(
    const col_rel_t *);
extern void (*wl_columnar_relation_test_after_retired_storage_free)(
    const col_rel_t *);
wl_columnar_continuation_status_t
wl_columnar_join_pipeline_test_reserve(col_rel_t *out, uint32_t rows,
    int *error_out);
void wl_columnar_relation_test_fail_next_prepare_resize(void);
void wl_columnar_relation_test_fail_next_reservation_commit(void);
void wl_columnar_relation_test_fail_next_metadata_alloc(void);
void wl_columnar_relation_test_watch_next_rollback_cleanup(void);
bool wl_columnar_relation_test_rollback_cleanup_was_ordered(void);
void wl_columnar_relation_test_fail_next_compact_rollback(void);
void wl_columnar_relation_test_fail_next_compact_commit(void);
void wl_columnar_relation_test_fail_next_governed_copy_payload_alloc(void);
bool wl_columnar_relation_test_governed_copy_payload_alloc_pending(void);
void wl_columnar_relation_test_clear_governed_copy_payload_alloc(void);
void wl_columnar_relation_test_fail_next_mutable_image_overflow(void);
void wl_columnar_relation_test_clear_mutable_image_overflow(void);
void wl_columnar_relation_test_clear_prepare_resize(void);
void wl_columnar_relation_test_fail_next_commit_publication(void);
void wl_columnar_memory_governor_test_refuse_next_release(void);
int wl_columnar_relation_test_commit_replacement_locked(col_rel_t *dst,
    col_rel_replacement_t *replacement);
#endif

#ifdef WL_SESSION_TEST_HOOKS
void wl_columnar_relation_test_fail_next_governed_timestamp_alloc(void);
bool wl_columnar_relation_test_governed_timestamp_alloc_pending(void);
typedef enum {
    WL_COLUMNAR_RADIX_ADMISSION_BEFORE = 1,
    WL_COLUMNAR_RADIX_ADMISSION_AFTER = 2
} wl_columnar_radix_admission_phase_t;
typedef void (*wl_columnar_radix_admission_test_hook_t)(const col_rel_t *,
    uint64_t, uint64_t, uint64_t, wl_columnar_radix_admission_phase_t,
    wl_columnar_memory_admission_status_t);
extern wl_columnar_radix_admission_test_hook_t
    wl_columnar_radix_admission_test_hook;
#endif

#ifdef WL_TEST_CONSOLIDATE_HOOK
/* Test-only probes for the two consolidation COW windows. */
typedef enum wl_columnar_consolidation_test_stage {
    WL_COLUMNAR_CONSOLIDATION_TEST_SORT_AFTER_DETACH = 1,
    WL_COLUMNAR_CONSOLIDATION_TEST_APPEND_AFTER_DETACH = 2
} wl_columnar_consolidation_test_stage_t;
typedef void (*wl_columnar_consolidation_transition_hook_t)(col_rel_t *,
    wl_columnar_consolidation_test_stage_t);
extern wl_columnar_consolidation_transition_hook_t
    wl_columnar_consolidation_transition_hook;
#endif

/* MSVC in its default C mode neither defines __STDC_VERSION__ >= 201112L
 * nor accepts offsetof() inside _Static_assert (C2059); mirror the guard
 * used by diff_trace.c so the layout contract is still checked everywhere
 * else. */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L
/* Preserve the legacy mirror prefix: name, ncols, columns, column_types,
 * nrows, and capacity must precede all #1441 generation state. */
_Static_assert(offsetof(col_rel_t, name) == 0,
    "col_rel_t name must remain the first field");
_Static_assert(offsetof(col_rel_t, ncols) == sizeof(char *),
    "col_rel_t ncols offset changed");
_Static_assert(offsetof(col_rel_t, columns) > offsetof(col_rel_t, ncols),
    "col_rel_t columns must follow ncols");
_Static_assert(offsetof(col_rel_t, column_types) > offsetof(col_rel_t, columns),
    "col_rel_t column_types must follow columns");
_Static_assert(offsetof(col_rel_t, nrows) > offsetof(col_rel_t, column_types),
    "col_rel_t nrows must follow column_types");
_Static_assert(offsetof(col_rel_t, capacity) > offsetof(col_rel_t, nrows),
    "col_rel_t capacity must follow nrows");
_Static_assert(offsetof(col_rel_t, relation_identity) >
    offsetof(col_rel_t, declared_ncols),
    "relation generation fields must remain outside the legacy prefix");
#endif /* C11 _Static_assert */

#define WL_COLUMNAR_REL_GENERATION_INVALID UINT64_MAX

static inline col_relation_snapshot_t
wl_columnar_relation_snapshot(const col_rel_t *rel)
{
    col_relation_snapshot_t snapshot = { 0, 0, 0 };
    if (rel) {
        snapshot.relation_identity = rel->relation_identity;
        snapshot.view_generation = rel->view_generation;
        snapshot.storage_generation = rel->storage_generation;
    }
    return snapshot;
}

static inline bool
wl_columnar_relation_snapshot_valid(col_relation_snapshot_t snapshot)
{
    return snapshot.relation_identity != 0
           && snapshot.view_generation != WL_COLUMNAR_REL_GENERATION_INVALID
           && snapshot.storage_generation != WL_COLUMNAR_REL_GENERATION_INVALID;
}

static inline bool
wl_columnar_relation_snapshot_equal(col_relation_snapshot_t left,
    col_relation_snapshot_t right)
{
    return wl_columnar_relation_snapshot_valid(left)
           && wl_columnar_relation_snapshot_valid(right)
           && left.relation_identity == right.relation_identity
           && left.view_generation == right.view_generation
           && left.storage_generation == right.storage_generation;
}

/* Generation counters are intentionally checked rather than wrapping.  A
 * saturated counter is invalid for cache equality; the next cache unit will
 * use wl_columnar_relation_generation_valid() before accepting a hit. */
static inline bool
wl_columnar_relation_generation_valid(uint64_t generation)
{
    return generation != WL_COLUMNAR_REL_GENERATION_INVALID;
}

static inline int
wl_columnar_relation_generation_advance(uint64_t *generation)
{
    if (!generation)
        return EINVAL;
    if (*generation >= WL_COLUMNAR_REL_GENERATION_INVALID - 1u) {
        *generation = WL_COLUMNAR_REL_GENERATION_INVALID;
        return EOVERFLOW;
    }
    (*generation)++;
    return 0;
}

static inline void
wl_columnar_relation_touch_view(col_rel_t *rel)
{
    if (rel)
        (void)wl_columnar_relation_generation_advance(&rel->view_generation);
}

static inline void
wl_columnar_relation_touch_storage(col_rel_t *rel)
{
    if (rel) {
        (void)wl_columnar_relation_generation_advance(
            &rel->storage_generation);
        if (!rel->storage_owner || rel->storage_owner == rel)
            rel->storage_owner_generation = rel->storage_generation;
    }
}

static inline void
wl_columnar_relation_touch_replacement(col_rel_t *rel)
{
    wl_columnar_relation_touch_view(rel);
    wl_columnar_relation_touch_storage(rel);
}

/* Bulk relation writers use raw row helpers and publish one logical touch at
 * their commit point.  Keeping these helpers separate prevents a row loop
 * from advancing the generation once per copied row. */

/* Float lanes are stored as binary64 bits but invalid values are rejected at
 * the relation boundary.  Sorting/consolidation also has entry points that
 * operate on relations assembled by older internal callers, so validate the
 * invariant before a comparator can return WL_COLUMNAR_CMP_INCOMPATIBLE. */
static inline bool
wl_columnar_relation_float_values_valid(const col_rel_t *rel)
{
    if (!rel)
        return false;
    if (rel->nrows == 0)
        return true;
    if (rel->ncols == 0)
        return rel->relation_identity != 0
               && rel->view_generation != 0
               && rel->storage_generation != 0;
    if (!rel->columns)
        return false;
    if (!rel->column_types)
        return true;
    for (uint32_t c = 0; c < rel->ncols; c++) {
        if (rel->column_types[c] != WIRELOG_TYPE_FLOAT)
            continue;
        for (uint32_t row = 0; row < rel->nrows; row++) {
            if (!wl_columnar_float_bits_valid(rel->columns[c][row]))
                return false;
        }
    }
    return true;
}

static inline uint64_t
wl_columnar_float_canonical_bits(int64_t bits)
{
    if (wl_columnar_float_bits_zero(bits))
        return 0;
    return (uint64_t)bits;
}

static inline uint64_t
wl_columnar_value_key(const col_rel_t *rel, uint32_t col, int64_t bits)
{
    if (rel && rel->column_types
        && rel->column_types[col] == WIRELOG_TYPE_FLOAT)
        return wl_columnar_float_canonical_bits(bits);
    return (uint64_t)bits;
}

static inline bool
wl_columnar_value_equal(const col_rel_t *left, uint32_t left_col,
    int64_t left_bits, const col_rel_t *right, uint32_t right_col,
    int64_t right_bits)
{
    wirelog_column_type_t left_type = left && left->column_types
        ? left->column_types[left_col] : WIRELOG_TYPE_INT64;
    wirelog_column_type_t right_type = right && right->column_types
        ? right->column_types[right_col] : WIRELOG_TYPE_INT64;
    /* Join admission and bulk append accept non-float lanes with the same
     * int64 representation, including intern IDs from side compounds whose
     * schema is deliberately all-int64. Metadata differences must not make
     * those equal keys fail a probe. Float bits remain a separate domain. */
    if ((left_type == WIRELOG_TYPE_FLOAT || right_type == WIRELOG_TYPE_FLOAT)
        && left_type != right_type)
        return false;
    if (left_type == WIRELOG_TYPE_FLOAT)
        return wl_columnar_float_compare_bits(left_bits, right_bits) == 0;
    return left_bits == right_bits;
}

static inline uint32_t
wl_columnar_hash_value(uint32_t hash, const col_rel_t *rel, uint32_t col,
    int64_t bits)
{
    uint64_t value = wl_columnar_value_key(rel, col, bits);
    hash ^= (uint32_t)value;
    hash *= 16777619u;
    hash ^= (uint32_t)(value >> 32);
    hash *= 16777619u;
    return hash;
}

/* ======================================================================== */
/* col_rel_t Accessor Layer (Phase C, Issue #332)                           */
/*                                                                          */
/* All cell access to r->columns goes through these accessors.              */
/* Layout: int64_t **columns; columns[col][row]                             */
/* ======================================================================== */

/* Defined in relation.c.  The accessor layer must use the same COW
 * publication path as the bulk mutation entry points. */
int col_rel_cow_unshare(col_rel_t *r, uint32_t new_cap);

/** Read a single cell value at (row, col). */
static inline int64_t
col_rel_get(const col_rel_t *r, uint32_t row, uint32_t col)
{
    return r->columns[col][row];
}

/** Write a single cell value at (row, col) WITHOUT publishing a generation
*  or detaching a shared view.  For parallel fill workers that own disjoint
*  row ranges of a fresh, heap-owned, non-shared output relation: the
*  coordinator publishes the view generation once around the fill, so the
*  workers must not touch the shared counter concurrently (Issue #1441). */
static inline int
col_rel_set_raw(col_rel_t *r, uint32_t row, uint32_t col, int64_t val)
{
    if (!r || !r->columns || row >= r->capacity || col >= r->ncols
        || !r->columns[col] || r->col_shared)
        return EINVAL;
    if (r->column_types && r->column_types[col] == WIRELOG_TYPE_FLOAT) {
        if (!wl_columnar_float_bits_valid(val))
            return EINVAL;
        if (wl_columnar_float_bits_zero(val))
            val = 0;
    }
    r->columns[col][row] = val;
    return 0;
}

/** Gather a row into an internal scratch buffer and return const pointer.
 *  WARNING: returns pointer to internal scratch buffer -- invalidated
 *  by the next col_rel_row() call on the SAME relation. */
static inline const int64_t *
col_rel_row(const col_rel_t *r, uint32_t row)
{
    static const int64_t empty_row = 0;
    if (!r)
        return NULL;
    if (r->ncols == 0)
        return &empty_row;
    col_rel_t *mr = (col_rel_t *)(uintptr_t)r; /* cast away const for scratch */
    if (!mr->row_scratch) {
        /* Governed scratch is admitted and allocated before publication. */
        if (mr->memory_governor)
            return NULL;
        mr->row_scratch = (int64_t *)malloc(r->ncols * sizeof(int64_t));
        if (!mr->row_scratch)
            return NULL;
    }
    for (uint32_t c = 0; c < r->ncols; c++)
        mr->row_scratch[c] = r->columns[c][row];
    return mr->row_scratch;
}

/* col_rel_row_mut: REMOVED -- use col_rel_set() or col_rel_row_copy_in() */

/** Copy one row out into a caller-provided buffer. */
static inline void
col_rel_row_copy_out(const col_rel_t *r, uint32_t row, int64_t *dst)
{
    for (uint32_t c = 0; c < r->ncols; c++)
        dst[c] = r->columns[c][row];
}

/** Copy one row in from a caller-provided buffer. */
static inline int
col_rel_row_copy_in_raw(col_rel_t *r, uint32_t row, const int64_t *src)
{
    if (!r || !src)
        return EINVAL;
    if (r->ncols == 0) {
        return r->relation_identity != 0
               && r->view_generation != 0
               && r->storage_generation != 0
            ? 0
            : EINVAL;
    }
    if (!r->columns)
        return EINVAL;
    for (uint32_t c = 0; c < r->ncols; c++) {
        if (r->columns[c] == NULL)
            return EINVAL;
        int64_t value = 0;
        memcpy(&value, &src[c], sizeof(value));
        if (r->column_types && r->column_types[c] == WIRELOG_TYPE_FLOAT
            && !wl_columnar_float_bits_valid(value))
            return EINVAL;
    }
    for (uint32_t c = 0; c < r->ncols; c++) {
        int64_t value = 0;
        memcpy(&value, &src[c], sizeof(value));
        if (r->column_types && r->column_types[c] == WIRELOG_TYPE_FLOAT
            && wl_columnar_float_bits_zero(value))
            value = 0;
        memcpy(&r->columns[c][row], &value, sizeof(value));
    }
    return 0;
}

static inline int
col_rel_row_copy_in(col_rel_t *r, uint32_t row, const int64_t *src)
{
    int rc = col_rel_row_copy_in_raw(r, row, src);
    if (rc == 0)
        wl_columnar_relation_touch_view(r);
    return rc;
}

/* Copy count consecutive rows in with the per-cell validation and float
 * normalization of col_rel_row_copy_in_raw().  Each FLOAT cell is checked as
 * it is stored, so a failure can leave earlier cells of the batch written
 * past nrows: callers that need an all-or-nothing batch validate it first, as
 * col_rel_append_rows_atomic() does.  Checking in the store loop instead of a
 * separate column-by-column pass keeps a wide all-FLOAT batch to one pass over
 * its input.  The column and type tables are read once: cell stores cannot
 * change them, and rereading them for every cell made the wide-batch loop
 * slower and sensitive to code placement. */
static inline int
col_rel_rows_copy_in_raw(col_rel_t *r, uint32_t row, const int64_t *src,
    uint32_t count)
{
    if (!r || (!src && count != 0))
        return EINVAL;
    if (r->ncols == 0) {
        return r->relation_identity != 0
               && r->view_generation != 0
               && r->storage_generation != 0
            ? 0
            : EINVAL;
    }
    int64_t *const *columns = r->columns;
    const wirelog_column_type_t *types = r->column_types;
    const uint32_t ncols = r->ncols;
    if (!columns)
        return EINVAL;
    for (uint32_t c = 0; c < ncols; c++)
        if (columns[c] == NULL)
            return EINVAL;
    for (uint32_t i = 0; i < count; i++) {
        const int64_t *in = src + (size_t)i * ncols;
        for (uint32_t c = 0; c < ncols; c++) {
            int64_t value = 0;
            memcpy(&value, &in[c], sizeof(value));
            if (types && types[c] == WIRELOG_TYPE_FLOAT) {
                if (!wl_columnar_float_bits_valid(value))
                    return EINVAL;
                if (wl_columnar_float_bits_zero(value))
                    value = 0;
            }
            memcpy(&columns[c][row + i], &value, sizeof(value));
        }
    }
    return 0;
}

/** Compute buffer size in bytes for row_count rows. */
static inline size_t
col_rel_buf_bytes(const col_rel_t *r, uint32_t row_count)
{
    return (size_t)row_count * (size_t)r->ncols * sizeof(int64_t);
}

/* ======================================================================== */
/* Row Scratch Buffer (Issue #1000)                                         */
/*                                                                          */
/* col_rel_row_copy_out() writes r->ncols values, so any buffer handed to   */
/* it must be at least that wide.  A bare int64_t[COL_STACK_MAX] smashes    */
/* the stack for relations wider than COL_STACK_MAX columns.  Use this      */
/* helper instead: it keeps the stack buffer for the common narrow case     */
/* (no allocation, no free) and spills to the heap only past the bound.     */
/*                                                                          */
/*   col_row_buf_t rb;                                                      */
/*   int64_t *const row = col_row_buf_init(&rb, nc);                        */
/*   if (!row) { ...ENOMEM... }                                             */
/*   for (...) { col_rel_row_copy_out(rel, i, row); ... }                   */
/*   col_row_buf_release(&rb);            (on every exit path)              */
/*                                                                          */
/* Two things matter for the hot path.  Hoist the init/release out of       */
/* per-row loops -- initialising inside a loop would malloc once per row    */
/* for wide relations.  And read ->ptr once into a local, as above, rather  */
/* than writing rb.ptr[c] inside the loop: the compiler cannot always prove */
/* the callee did not change ->ptr, so it reloads it every iteration        */
/* (worth ~2% on the crdt bench workload when written the naive way).       */
/* ======================================================================== */

typedef struct {
    int64_t stack[COL_STACK_MAX];
    int64_t *ptr; /* == stack, or heap block; NULL on allocation failure */
} col_row_buf_t;

/** Point @b at a buffer of at least @ncols int64_t.  Returns NULL on OOM. */
static inline int64_t *
col_row_buf_init(col_row_buf_t *b, uint32_t ncols)
{
    b->ptr = (ncols <= COL_STACK_MAX)
        ? b->stack
        : (int64_t *)malloc((size_t)ncols * sizeof(int64_t));
    return b->ptr;
}

/** Release @b.  Safe to call on a failed or already-released buffer. */
static inline void
col_row_buf_release(col_row_buf_t *b)
{
    if (b->ptr && b->ptr != b->stack)
        free(b->ptr);
    b->ptr = NULL;
}

/* ======================================================================== */
/* Row Comparison (Phase B, Issue #330; optimized Issue #334)                */
/*                                                                          */
/* Compare two rows using direct column access for cache efficiency.         */
/* ======================================================================== */

/** Compare two raw rows using the relation's typed lane semantics. */
static inline int
col_rel_row_values_cmp(const col_rel_t *r, const int64_t *left,
    const int64_t *right)
{
    for (uint32_t c = 0; c < r->ncols; c++) {
        if (r->column_types && r->column_types[c] == WIRELOG_TYPE_FLOAT) {
            int cmp = wl_columnar_float_compare_bits(left[c], right[c]);
            if (cmp != 0)
                return cmp;
            continue;
        }
        if (left[c] < right[c])
            return -1;
        if (left[c] > right[c])
            return 1;
    }
    return 0;
}

/** Compare two rows within the same relation lexicographically.
 *  Returns -1, 0, or +1. Direct column access for cache efficiency
 *  (Issue #334). */
static inline int
col_rel_row_cmp(const col_rel_t *r, uint32_t row_a, uint32_t row_b)
{
    uint32_t ncols = r->ncols;
    /* Unrolled fast paths for common widths (ncols=2,4) */
    if (ncols == 2) {
        int cmp0;
        if (r->column_types && r->column_types[0] == WIRELOG_TYPE_FLOAT)
            cmp0 = wl_columnar_float_compare_bits(r->columns[0][row_a],
                    r->columns[0][row_b]);
        else {
            int64_t a0 = r->columns[0][row_a];
            int64_t b0 = r->columns[0][row_b];
            cmp0 = a0 < b0 ? -1 : a0 > b0 ? 1 : 0;
        }
        if (cmp0 != 0)
            return cmp0;
        if (r->column_types && r->column_types[1] == WIRELOG_TYPE_FLOAT)
            return wl_columnar_float_compare_bits(r->columns[1][row_a],
                       r->columns[1][row_b]);
        int64_t a1 = r->columns[1][row_a];
        int64_t b1 = r->columns[1][row_b];
        if (a1 != b1)
            return (a1 < b1) ? -1 : 1;
        return 0;
    }
    if (ncols == 4) {
        for (uint32_t c = 0; c < 4; c++) {
            if (r->column_types && r->column_types[c] == WIRELOG_TYPE_FLOAT) {
                int cmp = wl_columnar_float_compare_bits(
                    r->columns[c][row_a], r->columns[c][row_b]);
                if (cmp != 0)
                    return cmp;
                continue;
            }
            int64_t va = r->columns[c][row_a];
            int64_t vb = r->columns[c][row_b];
            if (va < vb)
                return -1;
            if (va > vb)
                return 1;
        }
        return 0;
    }
    /* General scalar path */
    for (uint32_t c = 0; c < ncols; c++) {
        if (r->column_types && r->column_types[c] == WIRELOG_TYPE_FLOAT) {
            int cmp = wl_columnar_float_compare_bits(
                r->columns[c][row_a], r->columns[c][row_b]);
            if (cmp != 0)
                return cmp;
            continue;
        }
        int64_t va = r->columns[c][row_a];
        int64_t vb = r->columns[c][row_b];
        if (va < vb)
            return -1;
        if (va > vb)
            return 1;
    }
    return 0;
}

/** Compare rows from two different relations. Both must have same ncols.
 *  Direct column access for cache efficiency (Issue #334). */
static inline int
col_rel_row_cmp2(const col_rel_t *ra, uint32_t row_a,
    const col_rel_t *rb, uint32_t row_b)
{
    uint32_t ncols = ra->ncols;
    for (uint32_t c = 0; c < ncols; c++) {
        wirelog_column_type_t left_type = ra->column_types
            ? ra->column_types[c] : WIRELOG_TYPE_INT64;
        wirelog_column_type_t right_type = rb->column_types
            ? rb->column_types[c] : WIRELOG_TYPE_INT64;
        if (left_type != right_type)
            return WL_COLUMNAR_CMP_INCOMPATIBLE;
        if (left_type == WIRELOG_TYPE_FLOAT) {
            int cmp = wl_columnar_float_compare_bits(ra->columns[c][row_a],
                    rb->columns[c][row_b]);
            if (cmp != 0)
                return cmp;
            continue;
        }
        int64_t va = ra->columns[c][row_a];
        int64_t vb = rb->columns[c][row_b];
        if (va < vb)
            return -1;
        if (va > vb)
            return 1;
    }
    return 0;
}

/** Binary search for a row in a sorted region of a relation (#369).
 *  Returns true if an equal row exists in [lo..hi). O(log(hi-lo)). */
static inline bool
col_rel_binary_search_row(const col_rel_t *rel, uint32_t lo, uint32_t hi,
    uint32_t needle)
{
    while (lo < hi) {
        uint32_t mid = lo + (hi - lo) / 2;
        int cmp = col_rel_row_cmp(rel, mid, needle);
        if (cmp == 0)
            return true;
        if (cmp < 0)
            lo = mid + 1;
        else
            hi = mid;
    }
    return false;
}

/**
 * col_agg_better - does @cand beat the running @cur for a MIN/MAX reduce?
 *                  (Issue #965)
 *
 * MIN/MAX used to compare the raw int64 in every case, which for a `symbol`
 * column is its interned id.  Ids are handed out in first-appearance order,
 * so prepending one unrelated fact flipped min() from "zz" to "aa" with no
 * change to the data being reduced.  When the plan says the operand is a
 * string, the comparison is therefore over the strings.
 *
 * There are two reducers -- col_op_reduce() in ops.c and the recursive
 * canonicalisation in eval_serial.c -- and they must agree.  Two copies could
 * drift into a fixpoint that is lexicographic within an iteration and
 * id-ordered across iterations, which is worse than the original bug, so
 * both call this.
 *
 * Ordering, given the intern table @intern:
 *
 *   rank(v) = 1 if wl_intern_reverse(intern, v) != NULL, else 0
 *
 *   - different rank: the rank-1 value wins, for MIN *and* for MAX.
 *   - both rank 1: strcmp of the two strings.
 *   - both rank 0: the int64 comparison, i.e. today's behaviour.
 *
 * A genuine symbol column has rank 1 everywhere and reduces purely
 * lexicographically; rank 0 only appears for a column declared `symbol`
 * whose values were never interned.  Following #963, that mistype is not
 * failed closed: `.decl E(x: symbol, y: symbol)` with integer facts is
 * accepted by the parser and evaluates fine today, and erroring out would
 * turn a working query into no output at all.  The mistype is reported at
 * plan generation instead.
 *
 * Termination.  The naive argument -- "the stored value descends a fixed
 * total order, which is finite, so the fixpoint stops" -- does not hold if
 * rank is read as a property of the value: wl_intern_reverse() succeeds iff
 * `0 <= id < count`, and count *grows during evaluation*, because cat(),
 * substr(), to_upper(), to_lower(), str_replace(), trim() and to_string()
 * all intern their results.  The same pair of values can therefore compare
 * one way early and the other way later, and the order is not fixed.
 *
 * What is true is that rank is monotone.  count never shrinks and entry v
 * is written before count exceeds v, so `rank(v) = 0 -> 1` happens at most
 * once per v and never reverses; and rank 1 always wins.  So a rank change
 * moves a value strictly *towards* better, whichever aggregate is running.
 * Hence at every update the stored value's key strictly improves in the
 * fixed order on the pair set {(rank, string-or-id)}, and both the stored
 * key before and after are drawn from the finitely many keys the finitely
 * many distinct values V can ever take -- at most 2|V| of them, since each
 * value realises at most two.  So each group updates at most 2|V| times and
 * the whole reduction at most 2|G||V| times.  Finite, therefore terminating,
 * without assuming the intern table holds still.
 */
static inline bool
col_agg_better(wirelog_agg_fn_t fn, wl_plan_agg_operand_t domain,
    const wl_intern_t *intern, int64_t cand, int64_t cur)
{
    bool want_max = (fn == WIRELOG_AGG_MAX);

    if (domain == WL_PLAN_AGG_OPERAND_STRING) {
        const char *a = wl_intern_reverse(intern, cand);
        const char *b = wl_intern_reverse(intern, cur);
        if (a && b) {
            int c = strcmp(a, b);
            return want_max ? c > 0 : c < 0;
        }
        /* At most one of the two names a string.  Prefer it -- see the
         * termination note above; this is the step that must not depend on
         * which direction the aggregate runs. */
        if (a || b)
            return a != NULL;
        /* Neither: fall through to the int64 comparison. */
    }

    return want_max ? cand > cur : cand < cur;
}

/** Copy row src_row to dst_row within the same relation.
 *  Column-major: each column copy is independent, no temp buffer needed. */
static inline void
col_rel_row_move_raw(col_rel_t *r, uint32_t dst_row, uint32_t src_row)
{
    if (dst_row == src_row)
        return;
    for (uint32_t c = 0; c < r->ncols; c++)
        r->columns[c][dst_row] = r->columns[c][src_row];
}

static inline void
col_rel_row_move(col_rel_t *r, uint32_t dst_row, uint32_t src_row)
{
    col_rel_row_move_raw(r, dst_row, src_row);
    if (dst_row != src_row)
        wl_columnar_relation_touch_view(r);
}

/**
 * col_materialized_join_t - Cached intermediate join result for CSE
 *
 * Stores the output of a multi-way join operation for reuse across
 * multiple semi-naive iterations. Used by Option 2 + Materialization
 * to avoid redundant computation of shared join prefixes.
 */
typedef struct {
    int64_t *data;         /* owned, row-major int64 buffer         */
    uint32_t nrows;        /* current row count                     */
    uint32_t ncols;        /* columns per tuple                     */
    uint32_t capacity;     /* allocated row capacity (for appending)*/
    uint32_t memory_limit; /* max bytes before eviction             */
    bool is_valid;         /* true if data is current for this iter */
} col_materialized_join_t;

/* ======================================================================== */
/* Materialization Cache (US-006)                                           */
/* ======================================================================== */

/*
 * col_mat_entry_t: one entry in the materialization cache.
 * Keyed by content hashes of left and right input relations.
 * The cache owns result; freed when the entry is evicted or cache cleared.
 */
typedef struct {
    uint64_t left_hash;  /* content hash of left input relation  */
    uint64_t right_hash; /* content hash of right input relation */
    /* Join operation that produced result (Issue #2127): see
     * col_mat_cache_join_signature().  0 for the unkeyed entry points. */
    uint64_t op_signature;
    col_rel_t *result;   /* owned cached join result             */
    size_t mem_bytes;    /* bytes used by result->data           */
    uint64_t lru_clock;  /* logical time of last access          */
    /* Bytes charged to WL_MEM_SUBSYS_CACHE for this entry (Issue #1380).
     * Capacity-based (col_rel_owned_ledger_bytes + timestamps), unlike
     * mem_bytes which is nrows-based and drives the eviction limit. */
    uint64_t ledger_bytes;
    /* Stable identity and borrowed-result lifetime.  Entries are compacted
     * with memmove, so handles must resolve by identity rather than address. */
    uint64_t identity;
    uint32_t pin_count;
    bool eviction_deferred;
    /* Reclaimer metadata is independent from relation/arrangement
     * generations.  It is valid only for an owned, unshared result. */
    uint64_t pin_epoch;
    uint32_t epoch_pin_count;
    uint64_t generation;
    bool owner_alive;
    /* True for every inserted entry: insertion rejects pool/arena/shared or
     * aliased results before transferring ledger ownership. */
    bool owns_result;
    col_relation_snapshot_t left_snapshot;
    col_relation_snapshot_t right_snapshot;
} col_mat_entry_t;

typedef struct wl_columnar_cache_pin {
    /* The cache object must outlive this handle. Production pins are
     * synchronous; callers release them before session/worker teardown.
     * An issued active pin stays at its final address until release or an
     * explicit move. Bitwise copies do not acquire resource authority. */
    struct col_mat_cache *cache;
    uint64_t identity;
    bool active;
    struct wl_columnar_cache_pin *self;
} col_mat_cache_pin_t;

typedef struct col_mat_cache {
    col_mat_entry_t entries[COL_MAT_CACHE_MAX];
    uint32_t count;
    size_t total_bytes;
    uint64_t clock;
    uint64_t hits;   /* cache hit counter  */
    uint64_t misses; /* cache miss counter */
    /* Ledger that cached results are re-parented to on insert (Issue #1380).
     * NULL disables accounting (K-fusion branch sessions). */
    wl_mem_ledger_t *ledger;
    uint64_t next_identity;
    uint64_t next_generation;
    uint64_t pin_epoch;
    /* Every lookup_pin/insert_pin handle must be released before its owning
     * session, worker, or cache is destroyed. */
    uint32_t active_pins;
    wl_mem_reclaimer_handle_t reclaimer_handle;
    bool reclaimer_owner_alive;
} col_mat_cache_t;

/* Pin-free cache recipe primitive. Caller owns zero-initialized, final-address
 * storage and immutable source/op backing through funded END and ACK. Sources
 * use real combined descriptor/storage leases; no cached result is borrowed.
 * Original control is retained until ACK, which needs distinct real funding
 * even after that original attempt has finished/reset. Query is a fixed copied
 * DONE report, never a cache hit/pin capability or an engine-progress action. */
typedef enum {
    WL_COLUMNAR_CACHE_DIGEST_INERT,
    WL_COLUMNAR_CACHE_DIGEST_ACQUIRE,
    WL_COLUMNAR_CACHE_DIGEST_VALIDATE,
    WL_COLUMNAR_CACHE_DIGEST_CELL,
    WL_COLUMNAR_CACHE_DIGEST_ROWS,
    WL_COLUMNAR_CACHE_DIGEST_COLUMNS,
    WL_COLUMNAR_CACHE_DIGEST_SIGNATURE_FIELD,
    WL_COLUMNAR_CACHE_DIGEST_SIGNATURE_BYTE,
    WL_COLUMNAR_CACHE_DIGEST_KEY,
    WL_COLUMNAR_CACHE_DIGEST_SEPARATOR,
    WL_COLUMNAR_CACHE_DIGEST_FILTER,
    WL_COLUMNAR_CACHE_DIGEST_FINAL_LEFT,
    WL_COLUMNAR_CACHE_DIGEST_FINAL_RIGHT,
    WL_COLUMNAR_CACHE_DIGEST_LATCH,
    WL_COLUMNAR_CACHE_DIGEST_READY,
    WL_COLUMNAR_CACHE_DIGEST_END,
    WL_COLUMNAR_CACHE_DIGEST_END_CLEAR,
    WL_COLUMNAR_CACHE_DIGEST_END_RESET,
    WL_COLUMNAR_CACHE_DIGEST_DONE
} wl_columnar_cache_digest_phase_t;

typedef struct {
    uint64_t left_hash, right_hash, signature;
    col_relation_snapshot_t left_snapshot, right_snapshot;
    uint64_t control_identity, attempt_id;
} wl_columnar_cache_digest_result_t;

typedef struct {
    const col_rel_t *relation;
    wl_columnar_source_access_reader_t reader;
    col_relation_snapshot_t snapshot;
    uint32_t rows, width;
    bool held;
} wl_columnar_cache_digest_source_t;

typedef struct wl_columnar_cache_digest_attempt {
    struct wl_columnar_cache_digest_attempt *identity;
    wl_evaluation_control_t *control;
    uint64_t control_identity, attempt_id;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid, busy, control_ref, result_saved;
    wl_columnar_cache_digest_phase_t phase;
    wl_columnar_cache_digest_source_t source[2];
    const wl_plan_op_t *op;
    const char *const *left_keys, *const *right_keys;
    const uint8_t *filter;
    uint32_t kind, key_count, filter_size;
    unsigned char path;
    uint64_t hash[2], signature;
    uint32_t side, row, column, key, key_side, filter_byte, release_side;
    size_t name_byte;
    unsigned char native[8];
    unsigned native_count, native_byte, field;
    int semantic_result;
    wl_columnar_cache_digest_result_t result;
} wl_columnar_cache_digest_attempt_t;

int wl_columnar_cache_digest_begin(wl_columnar_cache_digest_attempt_t *a,
    const col_rel_t *left, const col_rel_t *right, const wl_plan_op_t *op,
    bool diff_path, wl_evaluation_control_t *control, uint64_t attempt_id);
int wl_columnar_cache_digest_step(wl_columnar_cache_digest_attempt_t *a,
    bool *ready);
int wl_columnar_cache_digest_finish(wl_columnar_cache_digest_attempt_t *a,
    wl_evaluation_control_t *funding, uint64_t funding_id, bool *done);
int wl_columnar_cache_digest_abort(wl_columnar_cache_digest_attempt_t *a,
    int initiating_result, wl_evaluation_control_t *funding,
    uint64_t funding_id, bool *done);
int wl_columnar_cache_digest_query(const wl_columnar_cache_digest_attempt_t *a,
    wl_columnar_cache_digest_result_t *result, int *semantic_result);
int wl_columnar_cache_digest_ack(wl_columnar_cache_digest_attempt_t *a,
    wl_evaluation_control_t *funding, uint64_t funding_id);
#ifdef WL_SESSION_TEST_HOOKS
enum {
    WL_COLUMNAR_CACHE_DIGEST_TEST_BEGIN = 1,
    WL_COLUMNAR_CACHE_DIGEST_TEST_STEP,
    WL_COLUMNAR_CACHE_DIGEST_TEST_FINISH,
    WL_COLUMNAR_CACHE_DIGEST_TEST_ABORT,
    WL_COLUMNAR_CACHE_DIGEST_TEST_ACK
};
extern void (*wl_columnar_cache_digest_test_checkpoint)(
    wl_columnar_cache_digest_attempt_t *, wl_evaluation_control_t *, unsigned);
#endif

/* Pin-free copy of a constructor-reachable scalar cache original. Caller
 * owns source lifetime (readers alone cannot borrow an unpinned cache result).
 * Source must be a named canonical standard-schema heap result without stamps
 * or compounds; live aliases of that canonical source are permitted. Output
 * stays constructor-private until funded TAKE; query never transfers it.
 * Explicit governor lifetime is caller-owned through source END; a constructed
 * output retains its own governor ref. Zero initialize final-address storage.
 * Original control ref lasts through funded ACK.
 * Independent cleanup may continue after original finish/reset/cancellation. */
/* Original private constructor ownership, distinct from the legacy context. */
typedef struct {
    col_rel_t *relation;
    char *name;
    int64_t **columns;
    int64_t *scratch;
    char **names;
    wirelog_column_type_t *types;
    col_delta_timestamp_t *timestamps;
    uint32_t columns_owned;
    uint32_t names_owned;
    bool schema_initialized;
    wl_columnar_memory_governor_ref_t *saved_ref;
    bool ref_held;
    bool admitted[3];
    bool committed[3];
    wl_columnar_memory_reservation_t tokens[3];
} wl_columnar_relation_constructor_attempt_t;

typedef enum {
    WL_COLUMNAR_RELATION_CACHE_CTOR_SCHEMA_FORMAT,
    WL_COLUMNAR_RELATION_CACHE_CTOR_SCHEMA_CHILD,
    WL_COLUMNAR_RELATION_CACHE_CTOR_SCHEMA_ROOT,
    WL_COLUMNAR_RELATION_CACHE_CTOR_NAME,
    WL_COLUMNAR_RELATION_CACHE_CTOR_NAMES_TABLE,
    WL_COLUMNAR_RELATION_CACHE_CTOR_TYPES,
    WL_COLUMNAR_RELATION_CACHE_CTOR_TIMESTAMPS,
    WL_COLUMNAR_RELATION_CACHE_CTOR_SCRATCH,
    WL_COLUMNAR_RELATION_CACHE_CTOR_COLUMN,
    WL_COLUMNAR_RELATION_CACHE_CTOR_COLUMNS_TABLE,
    WL_COLUMNAR_RELATION_CACHE_CTOR_NAME_STRING,
    WL_COLUMNAR_RELATION_CACHE_CTOR_DESCRIPTOR,
    WL_COLUMNAR_RELATION_CACHE_CTOR_RETIRED_HOOK,
    WL_COLUMNAR_RELATION_CACHE_CTOR_TOKEN0,
    WL_COLUMNAR_RELATION_CACHE_CTOR_TOKEN1,
    WL_COLUMNAR_RELATION_CACHE_CTOR_TOKEN2,
    WL_COLUMNAR_RELATION_CACHE_CTOR_REF,
    WL_COLUMNAR_RELATION_CACHE_CTOR_DONE
} wl_columnar_relation_cache_constructor_cleanup_t;

#define WL_COLUMNAR_RELATION_CACHE_CONSTRUCTOR_OWNER_FIELDS \
        bool constructor_initialized; \
        wl_columnar_relation_cache_constructor_cleanup_t constructor_cleanup; \
        unsigned constructor_cleanup_index; \
        wl_columnar_relation_constructor_attempt_t constructor

typedef enum {
    WL_COLUMNAR_RELATION_CACHE_COPY_INERT,
    WL_COLUMNAR_RELATION_CACHE_COPY_ACQUIRE,
    WL_COLUMNAR_RELATION_CACHE_COPY_VALIDATE,
    WL_COLUMNAR_RELATION_CACHE_COPY_OWNER,
    WL_COLUMNAR_RELATION_CACHE_COPY_COLUMN,
    WL_COLUMNAR_RELATION_CACHE_COPY_BUILD,
    WL_COLUMNAR_RELATION_CACHE_COPY_CELL,
    WL_COLUMNAR_RELATION_CACHE_COPY_RUN_VALIDATE,
    WL_COLUMNAR_RELATION_CACHE_COPY_RUN_COPY,
    WL_COLUMNAR_RELATION_CACHE_COPY_METADATA,
    WL_COLUMNAR_RELATION_CACHE_COPY_FINAL,
    WL_COLUMNAR_RELATION_CACHE_COPY_LATCH,
    WL_COLUMNAR_RELATION_CACHE_COPY_READY,
    WL_COLUMNAR_RELATION_CACHE_COPY_CONSTRUCTOR_END,
    WL_COLUMNAR_RELATION_CACHE_COPY_END,
    WL_COLUMNAR_RELATION_CACHE_COPY_END_CLEAR,
    WL_COLUMNAR_RELATION_CACHE_COPY_RETIRE_ZERO,
    WL_COLUMNAR_RELATION_CACHE_COPY_RETIRE_TOKENS,
    WL_COLUMNAR_RELATION_CACHE_COPY_RETIRE_BEGIN,
    WL_COLUMNAR_RELATION_CACHE_COPY_RETIRE_PREPARE,
    WL_COLUMNAR_RELATION_CACHE_COPY_RETIRE_COMMIT,
    WL_COLUMNAR_RELATION_CACHE_COPY_RETIRE_STEP,
    WL_COLUMNAR_RELATION_CACHE_COPY_RETIRE_CLEAR,
    WL_COLUMNAR_RELATION_CACHE_COPY_READY_OUTPUT,
    WL_COLUMNAR_RELATION_CACHE_COPY_TAKEN,
    WL_COLUMNAR_RELATION_CACHE_COPY_DISCARDED
} wl_columnar_relation_cache_scalar_copy_phase_t;

typedef struct wl_columnar_relation_cache_scalar_copy_attempt {
    struct wl_columnar_relation_cache_scalar_copy_attempt *identity;
    wl_evaluation_control_t *control;
    uint64_t control_identity, attempt_id;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid, busy, control_ref, result_saved, discarding;
    wl_columnar_relation_cache_scalar_copy_phase_t phase;
    const col_rel_t *source;
    wl_columnar_source_access_reader_t reader;
    col_relation_snapshot_t snapshot;
    bool held, run_valid, retirement_started;
    size_t retirement_offset;
    unsigned retirement_token_index;
    wl_columnar_memory_governor_ref_t *governor;
    col_rel_t *output;
    uint32_t width, rows, capacity, column, row, run, previous_end;
    int semantic_result;
    /* Lazy initialization is separately funded; ACK leaves only inert historic
     * bytes here. No terminal retirement pointer is dereferenced on reuse. */
    wl_columnar_relation_scalar_retirement_t retirement;
    WL_COLUMNAR_RELATION_CACHE_CONSTRUCTOR_OWNER_FIELDS;
} wl_columnar_relation_cache_scalar_copy_attempt_t;

typedef struct {
    uint32_t width, rows, capacity;
    uint64_t control_identity, attempt_id;
    bool taken, discarded;
    int semantic_result;
} wl_columnar_relation_cache_scalar_copy_result_t;

int wl_columnar_relation_cache_scalar_copy_begin(
    wl_columnar_relation_cache_scalar_copy_attempt_t *, const col_rel_t *,
    wl_columnar_memory_governor_ref_t *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_relation_cache_scalar_copy_step(
    wl_columnar_relation_cache_scalar_copy_attempt_t *, bool *);
int wl_columnar_relation_cache_scalar_copy_finish(
    wl_columnar_relation_cache_scalar_copy_attempt_t *,
    wl_evaluation_control_t *, uint64_t, bool *);
int wl_columnar_relation_cache_scalar_copy_abort(
    wl_columnar_relation_cache_scalar_copy_attempt_t *, int,
    wl_evaluation_control_t *, uint64_t, bool *);
int wl_columnar_relation_cache_scalar_copy_take(
    wl_columnar_relation_cache_scalar_copy_attempt_t *,
    wl_evaluation_control_t *, uint64_t, col_rel_t **);
int wl_columnar_relation_cache_scalar_copy_query(
    const wl_columnar_relation_cache_scalar_copy_attempt_t *,
    wl_columnar_relation_cache_scalar_copy_result_t *);
int wl_columnar_relation_cache_scalar_copy_ack(
    wl_columnar_relation_cache_scalar_copy_attempt_t *,
    wl_evaluation_control_t *, uint64_t);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_relation_cache_scalar_copy_test_checkpoint)(
    wl_columnar_relation_cache_scalar_copy_attempt_t *,
    wl_evaluation_control_t *, unsigned);
extern void (*wl_columnar_relation_cache_scalar_copy_test_after_action)(
    wl_columnar_relation_cache_scalar_copy_attempt_t *,
    wl_evaluation_control_t *, wl_columnar_relation_cache_scalar_copy_phase_t);
#endif

/* ======================================================================== */
/* Operator Profiling (WL_PROFILE)                                         */
/* ======================================================================== */

#ifdef WL_PROFILE
typedef struct {
    uint64_t concat_calls;
    uint64_t concat_empty_out;
    uint64_t concat_ns;
    uint64_t join_calls;
    uint64_t join_unary; /* joins where left or right ncols == 1    */
    uint64_t join_empty_out;
    uint64_t join_cache_hit_ns;
    uint64_t join_compute_ns;
} wl_profile_stats_t;
#endif

/* ======================================================================== */
/* Arrangement Registry                                                     */
/* ======================================================================== */

/*
 * col_arr_entry_t: one (rel_name, key_cols) -> arrangement mapping.
 * Stored in the session's flat arrangement registry.
 */
typedef struct {
    char *rel_name;     /* owned copy of relation name    */
    uint32_t *key_cols; /* owned copy of key column array */
    uint32_t key_count;
    col_arrangement_t arr; /* embedded arrangement           */
    uint64_t lru_clock;    /* logical time of last access (Issue #216) */
    size_t mem_bytes;      /* bytes used by ht_head + ht_next arrays   */
    uint32_t pin_count;    /* active internal reader leases */
    bool rebuild_deferred; /* invalidation waits for readers */
    bool evict_deferred;   /* reclaim was requested while pinned */
    col_relation_snapshot_t source_snapshot;
} col_arr_entry_t;

/* Non-public lease for a primary arrangement borrowed by an operator. */
typedef struct {
    col_arr_entry_t *entry;
    col_arrangement_t *arr;
    struct wl_col_session_t *session;
    bool active;
} col_arrangement_pin_t;

/* Allocation-free, address-bound lease for probing one primary arrangement
 * against the exact source relation used to validate it.  #1496 wires the
 * primitive into the unfiltered primary JOIN path only; broader consumers
 * follow after their complete dependency set can be acquired transactionally. */
typedef struct {
    col_arrangement_pin_t arrangement_pin;
    col_arrangement_t *arr;
    const col_rel_t *source;
    col_relation_snapshot_t source_snapshot;
    const col_rel_t *storage_owner;
    uint64_t storage_owner_identity;
    uint64_t storage_owner_generation;
    wl_columnar_source_access_reader_t source_reader;
    uintptr_t identity;
    bool active;
} col_arrangement_probe_t;

#define COL_ARRANGEMENT_PROBE_BUNDLE_MAX 4u
#define COL_ARRANGEMENT_PROBE_DEPENDENCY_MAX 4u

typedef struct {
    col_arrangement_probe_t probe;
    uint32_t ref_count;
} col_arrangement_probe_bundle_slot_t;

typedef struct {
    const col_rel_t *relation;
    const col_rel_t *storage_owner;
    uint64_t storage_owner_identity;
    uint64_t storage_owner_generation;
    wl_columnar_source_access_reader_t reader;
    uint32_t ref_count;
} col_arrangement_probe_dependency_t;

typedef struct {
    col_arrangement_probe_bundle_slot_t
        slots[COL_ARRANGEMENT_PROBE_BUNDLE_MAX];
    col_arrangement_probe_dependency_t
        dependencies[COL_ARRANGEMENT_PROBE_DEPENDENCY_MAX];
    uint32_t count;
    uint32_t dependency_count;
    uintptr_t identity;
    bool active;
} col_arrangement_probe_bundle_t;

/*
 * col_sorted_arr_t: cached sorted copy of a relation by a single key column.
 *
 * Used by WL_PLAN_OP_LFTJ (Issue #195) to avoid re-sorting EDB relations
 * on every semi-naive iteration.  sorted[] is rebuilt when indexed_rows
 * differs from the source relation's nrows.
 */
typedef struct {
    int64_t *sorted;       /* owned row-major sorted copy (nrows * ncols)  */
    uint32_t nrows;        /* rows in sorted copy                          */
    uint32_t ncols;        /* columns per row                              */
    uint32_t key_col;      /* sort key column index                        */
    uint32_t indexed_rows; /* source nrows at last build                  */
    /* Issue #1380: ARRANGEMENT accounting.  ledger_bytes is what is
     * currently charged for sorted[]; 0 when ledger is NULL. */
    wl_mem_ledger_t *ledger;
    uint64_t ledger_bytes;
    col_relation_snapshot_t source_snapshot;
    uint32_t pin_count;    /* active LFTJ readers of sorted[] */
    bool rebuild_deferred; /* source changed while pinned */
} col_sorted_arr_t;

/*
 * col_sorted_arr_entry_t: one (rel_name, key_col) -> sorted arrangement entry.
 * Stored in the session's flat sorted-arrangement registry.
 */
typedef struct {
    char *rel_name; /* owned */
    uint32_t key_col;
    col_sorted_arr_t sarr;
} col_sorted_arr_entry_t;

/* Lease binding a sorted arrangement to its exact source generation while an
 * operator reads the cached row-major buffer.  The source reader also keeps
 * the source storage stable until the lease is released. */
typedef struct {
    col_sorted_arr_entry_t *entry;
    col_sorted_arr_t *arr;
    struct wl_col_session_t *session;
    const col_rel_t *source;
    col_relation_snapshot_t source_snapshot;
    wl_columnar_source_access_reader_t source_reader;
    uintptr_t identity;
    bool active;
} col_sorted_arrangement_probe_t;

/* ======================================================================== */
/* Differential Arrangement Registry (Issue #263)                           */
/* ======================================================================== */

#define WL_DIFF_ARR_REGISTRY_INITIAL_CAP 4u

/*
 * col_diff_arr_entry_t: one (rel_name, key_cols) -> diff_arrangement mapping.
 * Stored in the session's flat differential arrangement registry.
 * Persists across iterations within an epoch for arrangement reuse.
 */
typedef struct {
    char *rel_name;                    /* owned copy of relation name    */
    uint32_t *key_cols;                /* owned copy of key column array */
    uint32_t key_count;
    col_diff_arrangement_t *diff_arr;  /* owned differential arrangement */
    uint64_t generation;               /* replacement/invalidation epoch */
    uint32_t pin_count;                 /* active differential readers */
    bool invalidation_deferred;         /* reset waits for last release */
    bool transaction_pending;           /* uncommitted registry entry */
} col_diff_arr_entry_t;

/* Stable snapshot lease for a differential arrangement.  The flat registry
 * remains address-stable while any differential pin is active; registry
 * growth is rejected until the last lease is released. */
typedef struct {
    col_diff_arr_entry_t *entry;
    col_diff_arrangement_t *arr;
    struct wl_col_session_t *session;
    const col_rel_t *source;
    col_relation_snapshot_t source_snapshot;
    wl_columnar_source_access_reader_t source_reader;
    uint64_t generation;
    bool active;
} col_diff_arrangement_pin_t;

/* Stable host-owned differential registry image. Entries own only pointers;
 * address-bound credits stay in this original record or arrangement objects.
 * A slot owns its replacement iff owned is true; old registry ownership is
 * retained until the coordinated session cutoff. */
typedef struct {
    const col_rel_t *source;
    col_relation_snapshot_t snapshot;
    uint64_t generation;
    bool owned;
} wl_columnar_arrangement_diff_slot_t;

typedef struct {
    col_diff_arr_entry_t *image, *original;
    wl_columnar_arrangement_diff_slot_t *slots;
    uint32_t count, capacity, old_count, old_capacity;
    uint32_t validate, cleanup_index;
    unsigned cleanup_phase, retire_phase, prepare_phase;
    uint64_t array_bytes, metadata_bytes, slots_bytes, old_bytes;
    uint64_t metadata_limit, retire_bytes;
    wl_columnar_memory_reservation_t image_credit, slots_credit, build_credit;
    wl_columnar_memory_reservation_t old_credit, retire_credit;
    wl_columnar_memory_reserved_trim_t trim;
    col_diff_arrangement_t *building, *retiring;
    wl_columnar_memory_governor_ref_t *retire_governor;
    struct wl_mem_ledger *retire_ledger;
    /* Survives physical arrangement/header and array destruction. Only the
     * finite parent adapter uses this original-address report/ACK journal. */
    wl_columnar_mem_ledger_retirement_journal_t ledger_journal;
    bool started, ready, committed, drained, building_initialized;
    bool image_charged, slots_charged, prepared;
} wl_columnar_arrangement_diff_attempt_t;

/* ======================================================================== */
/* Frontier Vtable (Issue #261)                                             */
/* ======================================================================== */

/*
 * col_frontier_ops_t: vtable interface for frontier skip/convergence logic.
 *
 * Abstracts the frontier mechanism behind function pointers to support
 * multiple frontier models (epoch-based, differential, etc.) without
 * changing eval.c or session.c callsites.
 *
 * All methods receive the columnar session as first argument (void* to
 * avoid circular dependency with wl_col_session_t).
 */
typedef struct col_frontier_ops col_frontier_ops_t;

struct col_frontier_ops {
    bool (*should_skip_iteration)(void *sess, uint32_t stratum_idx,
        uint32_t eff_iter);

    bool (*should_skip_rule)(void *sess, uint32_t rule_id,
        uint32_t eff_iter);

    void (*record_stratum_convergence)(void *sess, uint32_t stratum_idx,
        uint32_t outer_epoch,
        uint32_t iteration);

    void (*record_rule_convergence)(void *sess, uint32_t rule_id,
        uint32_t outer_epoch,
        uint32_t iteration);

    void (*reset_stratum_frontier)(void *sess, uint32_t stratum_idx,
        uint32_t outer_epoch);

    void (*reset_rule_frontier)(void *sess, uint32_t rule_id,
        uint32_t outer_epoch);

    void (*init_stratum)(void *sess, uint32_t stratum_idx);
};

/* Default epoch-based frontier vtable (defined in frontier_epoch.c). */
extern const col_frontier_ops_t col_frontier_epoch_ops;

/* Differential frontier vtable (defined in diff_vtable.c). */
extern const col_frontier_ops_t col_frontier_diff_ops;

/* ======================================================================== */
/* Rotation Strategy Vtable (Issue #600)                                    */
/* ======================================================================== */

/*
 * col_rotation_ops_t: vtable interface for arena/handle rotation strategy.
 *
 * Abstracts the per-iteration `wl_arena_reset` and per-epoch
 * `wl_compound_arena_gc_epoch_boundary` callsites behind function pointers
 * so alternative rotation models (e.g. pin-aware reclamation) can be
 * swapped in without touching eval.c or session.c. The default STANDARD
 * strategy passes through to the existing arena APIs.
 *
 * The init/destroy hooks are optional (NULL-safe at the callsite).
 * init returns 0 on success, non-zero on failure (treated as ENOMEM by
 * col_session_create's `oom:` cleanup path).
 */
struct wl_col_session_t; /* forward decl: full type defined below */

typedef struct col_rotation_ops {
    void (*rotate_eval_arena)(struct wl_col_session_t *sess);
    void (*gc_epoch_boundary)(struct wl_col_session_t *sess);
    int (*init)(struct wl_col_session_t *sess);      /* optional, return 0 on success */
    void (*destroy)(struct wl_col_session_t *sess);  /* optional */
} col_rotation_ops_t;

/* Default STANDARD rotation strategy (defined in rotation_standard.c). */
extern const col_rotation_ops_t col_rotation_standard_ops;

/* Pin-aware placeholder rotation strategy (defined in rotation_pinned.c). */
extern const col_rotation_ops_t col_rotation_pinned_ops;

/* ======================================================================== */
/* Session                                                                  */
/* ======================================================================== */

/*
 * col_filt_cache_entry_t: one entry in the filtered-relation cache (Issue #386).
 *
 * The cache is keyed by (rel_name, filter_hash) with filter_data used for
 * full content comparison on hash-match to guard against collisions.
 * All pointer fields are owned by the entry and freed on eviction/destroy.
 */
typedef struct col_filt_cache_entry {
    char *rel_name;          /* owned: base relation name */
    uint64_t filter_hash;    /* FNV-1a hash of right_filter_expr.data */
    uint8_t *filter_data;    /* owned copy of filter expression bytes */
    uint32_t filter_size;    /* byte length of filter_data */
    uint32_t source_nrows;   /* nrows of source rel when entry was built */
    col_relation_snapshot_t source_snapshot;
    col_rel_t *filtered;     /* owned: the filtered relation */
    uint32_t pin_count;      /* active reader leases (Issue #1435) */
    bool evict_deferred;     /* replacement or destruction waits for readers */
    /* Stable heap token for owned key metadata; entries move during cache
     * growth, so the reservation itself must not be embedded here. */
    wl_columnar_memory_reservation_t *metadata_reservation;
} col_filt_cache_entry_t;

/* Non-public lease for a filtered relation borrowed from filt_cache
 * (Issue #1435).  While active, the entry is neither replaced nor moved:
 * a stale token or an invalidation marks it deferred and lookups report it
 * unavailable, and the last release destroys it so the next lookup
 * rebuilds.  Release exactly once. */
typedef struct {
    struct wl_col_session_t *session;
    col_filt_cache_entry_t *entry;
    col_rel_t *rel;
    bool active;
} col_filt_cache_pin_t;

/*
 * col_filt_arr_entry_t: one entry in the filtered arrangement cache (Issue #433).
 *
 * Keyed by (rel_name, filter_hash, key_cols[]).  Unlike darr_entries (cleared
 * per sub-pass), these persist across sub-passes and are invalidated only when
 * col_session_invalidate_arrangements is called for the named relation.
 */
typedef struct col_filt_arr_entry {
    char *rel_name;        /* owned: base relation name */
    uint64_t filter_hash;  /* FNV-1a hash of right_filter_expr */
    uint32_t *key_cols;    /* owned: right-side key column indices */
    uint32_t key_count;
    col_arrangement_t arr; /* owned: hash index over filtered relation */
    col_relation_snapshot_t source_snapshot;
} col_filt_arr_entry_t;

/*
 * wl_col_session_t: Columnar backend session state
 *
 * Memory layout (C11 6.7.2.1 P15 - pointer compatibility):
 *   Offset 0: wl_session_t base
 *     -- Contains: backend pointer (vtable dispatch, set by session.c:38)
 *   Offset sizeof(wl_session_t): columnar-specific fields
 *     -- const wl_plan_t *plan
 *     -- col_rel_t **rels
 *     -- uint32_t nrels
 *     -- uint32_t rel_cap
 *     -- ...
 *
 * The `base` field MUST be the first member so that casting a
 * wl_session_t* to wl_col_session_t* is valid per C11 pointer
 * compatibility (address of struct == address of first member).
 */
typedef struct {
    const char *relation;
    int64_t *row;
    uint32_t ncols;
    int32_t diff;
} wl_col_delta_event_t;

/* Stable session-owned source-reader lease.  The reader token's identity is
* its address, so entries are individually allocated and never moved.  A
* lease is keyed by the worker relation whose columns borrow owner storage;
* this lets refresh and relation retirement update the gate exactly once. */
typedef struct wl_columnar_session_source_lease {
    col_rel_t *borrower;
    col_rel_t *owner;
    uint64_t owner_identity;
    wl_columnar_source_access_reader_t reader;
    struct wl_columnar_session_source_lease *next;
} wl_columnar_session_source_lease_t;

typedef struct wl_columnar_eval_delta_rollback wl_columnar_eval_delta_rollback_t;
typedef struct wl_columnar_eval_delta_observer wl_columnar_eval_delta_observer_t;
typedef struct wl_columnar_eval_delta_observer_build
    wl_columnar_eval_delta_observer_build_t;
typedef struct wl_columnar_eval_delta_observer_prepare
    wl_columnar_eval_delta_observer_prepare_t;

enum wl_columnar_eval_delta_close_validation_call {
    WL_COLUMNAR_EVAL_DELTA_CLOSE_VALIDATE_BEGIN,
    WL_COLUMNAR_EVAL_DELTA_CLOSE_VALIDATE_STEP,
    WL_COLUMNAR_EVAL_DELTA_CLOSE_VALIDATE_READY
};

enum wl_columnar_eval_delta_close_validation_phase {
    WL_COLUMNAR_EVAL_DELTA_CLOSE_VALIDATION_HEADER = 1,
    WL_COLUMNAR_EVAL_DELTA_CLOSE_VALIDATION_ENTRIES,
    WL_COLUMNAR_EVAL_DELTA_CLOSE_VALIDATION_STREAM,
    WL_COLUMNAR_EVAL_DELTA_CLOSE_VALIDATION_CREDITS,
    WL_COLUMNAR_EVAL_DELTA_CLOSE_VALIDATION_READY
};

/* Private CLOSE validation storage is outside the observer. The real Session
 * caller pins both allocations and settles each MAIN report/Source receipt
 * before invoking the next packet or publishing a distinct Native lease.
 * This descriptor and its ready flag never themselves confer DISCARD access. */
typedef struct wl_columnar_eval_delta_observer_close_validation {
    struct wl_columnar_eval_delta_observer_close_validation *identity;
    struct wl_col_session_t *session;
    const void *parent;
    wl_columnar_eval_delta_observer_t *observer;
    size_t extent;
    uint32_t count, index, credit;
    enum wl_columnar_eval_delta_close_validation_phase phase;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t actor;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD actor;
#else
    pthread_t actor;
#endif
    bool actor_valid, busy, ready;
} wl_columnar_eval_delta_observer_close_validation_t;

/* Canonical caller proof supplies validation-only Native lifetime/exclusion.
 * It authenticates the real CLOSE scope, private slot/actor and already
 * settled financial wake. It cannot be replaced by an address/report token. */
int wl_columnar_session_observer_close_validation_prove(
    const struct wl_col_session_t *, const void *,
    const wl_columnar_eval_delta_observer_close_validation_t *,
    wl_evaluation_control_t *, uint64_t, unsigned);
int wl_columnar_eval_delta_observer_close_validation_begin_owned(
    struct wl_col_session_t *, const void *,
    wl_columnar_eval_delta_observer_close_validation_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_delta_observer_close_validation_step_owned(
    struct wl_col_session_t *, const void *,
    wl_columnar_eval_delta_observer_close_validation_t *,
    wl_evaluation_control_t *, uint64_t);
/* Called inside the separately paid LEASE_PUBLISH packet; no admission or
 * resource mutation is appended by this read-only final validation. */
int wl_columnar_eval_delta_observer_close_validation_ready_owned(
    const struct wl_col_session_t *, const void *,
    const wl_columnar_eval_delta_observer_close_validation_t *,
    wl_evaluation_control_t *, uint64_t);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_delta_test_close_validation_checkpoint)(
    struct wl_col_session_t *,
    const wl_columnar_eval_delta_observer_close_validation_t *,
    wl_evaluation_control_t *, uint64_t);
#endif

typedef enum {
    WL_COLUMNAR_EVAL_DELTA_OBSERVER_RETIRE_NONE = 0,
    WL_COLUMNAR_EVAL_DELTA_OBSERVER_RETIRE_BEGIN_ABORT,
    WL_COLUMNAR_EVAL_DELTA_OBSERVER_RETIRE_COMPLETED_STEP,
    WL_COLUMNAR_EVAL_DELTA_OBSERVER_RETIRE_DISCARD,
} wl_columnar_eval_delta_observer_retire_t;

enum wl_columnar_eval_delta_resource_phase {
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_INERT,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_BUILD_READER,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_PREPARE_READER,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_STREAM_READER,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_ENTRY_READER,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_READERS_DONE,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_CURRENT,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_EVENTS,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_STAGING,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_PREPARE_FREE,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_ROWS, WL_COLUMNAR_EVAL_DELTA_RESOURCE_NAME,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_PAYLOAD,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_HOLD,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_METADATA_MOVE,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_OBSERVER_FREE,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_METADATA,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_GOVERNOR,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_BUILD_METADATA,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_BUILD_GOVERNOR,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_BUILD_FREE,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_GC,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_DONE, WL_COLUMNAR_EVAL_DELTA_RESOURCE_CLEAR
};

/* Selected finite observer resource continuation. Actual ownership comes from
 * its caller's live Session and canonical slots, never this phase or quote.
 * It remains outside observer/build/prepare allocations through final ACK. */
typedef struct {
    const void *identity;
    struct wl_col_session_t *session;
    wl_compound_arena_t *arena;
    wl_columnar_eval_delta_observer_t *observer;
    wl_columnar_eval_delta_observer_build_t *build;
    wl_columnar_eval_delta_observer_prepare_t *prepare;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD thread;
#else
    pthread_t thread;
#endif
    bool thread_valid, busy;
    unsigned phase, index, count, token_phase;
    size_t extent, initialized_bytes, clear_offset;
    wl_columnar_eval_delta_observer_retire_t disposition;
    bool build_owned, partial, readers_done, rollback, token_mode_set;
    wl_arena_compound_arena_hold_release_t hold;
    wl_arena_compound_arena_gc_step_t gc;
} wl_columnar_eval_delta_observer_resource_t;

typedef struct {
    int protocol;
    unsigned action;
    uint64_t work;
    bool readers_done, done;
} wl_columnar_eval_delta_observer_resource_quote_t;
typedef struct {
    int protocol;
    unsigned action;
    bool progressed, readers_done, done;
} wl_columnar_eval_delta_observer_resource_reply_t;

enum wl_columnar_eval_delta_observer_retire_credit {
    WL_COLUMNAR_EVAL_DELTA_OBSERVER_CREDIT_STAGING = 1,
    WL_COLUMNAR_EVAL_DELTA_OBSERVER_CREDIT_PAYLOAD,
    WL_COLUMNAR_EVAL_DELTA_OBSERVER_CREDIT_METADATA,
};

/* Durable continuation for a plain STEP whose worker merge completed but
 * checked publication/compaction was refused.  This state contains only
 * bounded scalar cursors; worker contexts and temporary plans are never
 * retained across the public retry. */
enum wl_columnar_plain_step_completion_phase {
    WL_COLUMNAR_PLAIN_STEP_COMPLETION_NONE = 0,
    WL_COLUMNAR_PLAIN_STEP_COMPLETION_FINALIZE_NONREC = 1,
    WL_COLUMNAR_PLAIN_STEP_COMPLETION_EVALUATE_REMAINING = 2,
    WL_COLUMNAR_PLAIN_STEP_COMPLETION_COMPACT = 3,
    WL_COLUMNAR_PLAIN_STEP_COMPLETION_FINALIZE_RECURSIVE = 4,
    WL_COLUMNAR_PLAIN_STEP_COMPLETION_CANONICALIZE_RECURSIVE = 5,
};

typedef struct wl_columnar_eval_stack_cleanup_frame
    wl_columnar_eval_stack_cleanup_frame_t;
#define WL_COLUMNAR_EVAL_STACK_CLEANUP_MAX_FRAMES 32u

typedef enum {
    WL_COLUMNAR_EVAL_CLEANUP_RECEIPT_FREE = 0,
    WL_COLUMNAR_EVAL_CLEANUP_RECEIPT_RESERVED,
    WL_COLUMNAR_EVAL_CLEANUP_RECEIPT_PREPARED,
    WL_COLUMNAR_EVAL_CLEANUP_RECEIPT_TRANSFERRED,
    WL_COLUMNAR_EVAL_CLEANUP_RECEIPT_FREED
} wl_columnar_eval_cleanup_receipt_state_t;

typedef enum {
    WL_COLUMNAR_EVAL_CLEANUP_OUTCOME_FREED = 1,
    WL_COLUMNAR_EVAL_CLEANUP_OUTCOME_TRANSFERRED_TO_PENDING,
    WL_COLUMNAR_EVAL_CLEANUP_OUTCOME_RETAINED_ACTIVE
} wl_columnar_eval_cleanup_outcome_t;

typedef struct {
    uint64_t session_generation;
    uint64_t receipt_id;
    uint64_t plan_epoch;
    uint64_t operation_attempt_id;
    uint64_t operation_id;
} wl_columnar_eval_cleanup_receipt_key_t;

typedef struct {
    wl_columnar_eval_cleanup_receipt_key_t key;
    wl_columnar_eval_cleanup_receipt_state_t state;
    int result;
    int cleanup_result;
    bool committed;
} wl_columnar_eval_cleanup_receipt_t;

struct wl_columnar_retained_eval_entry;

/* Authoritative immutable JOIN input. Never a resident registry relation.
 * All metadata shares reservation; payload owns types and rows. Borrowed fields
 * and readers may not escape a serialized session operation. */
typedef struct wl_columnar_session_cold_relation {
    struct wl_columnar_session_cold_relation *next;
    /* NULL in production; keep layout identical across test-hook builds. */
    col_rel_t *retained_source;
    wl_columnar_memory_reservation_t reservation;
    struct wl_columnar_batch_payload *payload;
    struct wl_columnar_trace_store *loading_trace;
    struct wl_columnar_trace_store_snapshot *trace_snapshot;
    wirelog_column_type_t *trace_types;
    enum { WL_COLUMNAR_COLD_PAYLOAD, WL_COLUMNAR_COLD_LOADING,
           WL_COLUMNAR_COLD_FINISHED } state;
    col_relation_snapshot_t source_snapshot;
    uint64_t cold_storage_generation;
    uint32_t ncols, nrows;
    char *name;
    char **col_names;
} wl_columnar_session_cold_relation_t;

struct wl_columnar_kfusion_cohort;
typedef struct wl_columnar_eval_tdd_run wl_columnar_eval_tdd_run_t;
typedef struct wl_columnar_controlled_step wl_columnar_controlled_step_t;

typedef enum {
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_CALL_BEGIN,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_CALL_OBSERVE,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_CALL_STEP,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_CALL_ACK,
    WL_COLUMNAR_EVAL_DELTA_RESOURCE_CALL_FINISH
} wl_columnar_eval_delta_resource_call_t;

typedef struct {
    int protocol;
    wl_columnar_eval_delta_observer_retire_t disposition;
    bool *acknowledged;
    bool acked;
} wl_columnar_session_observed_observer_permit_t;

wl_columnar_session_observed_observer_permit_t
    wl_columnar_session_observed_observer_prove(struct wl_col_session_t *,
    wl_columnar_controlled_step_t *, wl_columnar_eval_delta_resource_call_t,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
/* Separate canonical MAIN recipient proof, never the legacy abort-financier
 * proof or a copied financial record. It performs no positive admission. */
wl_columnar_session_observed_observer_permit_t
    wl_columnar_session_observed_observer_main_prove(struct wl_col_session_t *,
    wl_columnar_controlled_step_t *, wl_columnar_eval_delta_resource_call_t,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
bool wl_columnar_session_observed_observer_pending(
    const struct wl_col_session_t *);

wl_columnar_eval_delta_observer_resource_reply_t
    wl_columnar_eval_delta_observer_resource_begin_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
wl_columnar_eval_delta_observer_resource_quote_t
    wl_columnar_eval_delta_observer_resource_observe_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
wl_columnar_eval_delta_observer_resource_reply_t
    wl_columnar_eval_delta_observer_resource_step_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
wl_columnar_eval_delta_observer_resource_reply_t
    wl_columnar_eval_delta_observer_resource_ack_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);

/* One MAIN action each. BEGIN/STEP/ACK keep the actual leaf admission;
 * OBSERVE/FINISH extract the existing parent metadata action. No combined
 * OBSERVE+STEP, late factory or financier alias. Whole Native caller/return
 * qualification remains required before activating the corresponding parent. */
wl_columnar_eval_delta_observer_resource_reply_t
    wl_columnar_eval_delta_observer_resource_begin_main_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
wl_columnar_eval_delta_observer_resource_quote_t
    wl_columnar_eval_delta_observer_resource_observe_main_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
wl_columnar_eval_delta_observer_resource_reply_t
    wl_columnar_eval_delta_observer_resource_step_main_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
wl_columnar_eval_delta_observer_resource_reply_t
    wl_columnar_eval_delta_observer_resource_finish_main_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);
wl_columnar_eval_delta_observer_resource_reply_t
    wl_columnar_eval_delta_observer_resource_ack_main_owned(
    struct wl_col_session_t *, wl_columnar_controlled_step_t *,
    wl_columnar_eval_delta_observer_resource_t *, wl_evaluation_control_t *,
    uint64_t);

#ifdef WL_SESSION_TEST_HOOKS
enum {
    WL_COLUMNAR_EVAL_DELTA_TEST_RESOURCE_BEGIN = 1,
    WL_COLUMNAR_EVAL_DELTA_TEST_RESOURCE_ACK,
    WL_COLUMNAR_EVAL_DELTA_TEST_RESOURCE_STEP_BASE = 256
};
extern void (*wl_columnar_eval_delta_test_resource_prefooter)(
    wl_evaluation_control_t *, uint64_t, unsigned);
extern void (*wl_columnar_eval_delta_test_observer_advanced)(
    struct wl_col_session_t *);
int wl_columnar_eval_delta_test_observer_resource_view(
    const struct wl_col_session_t *, uint64_t[16]);
extern uint64_t (*wl_columnar_session_test_observer_resource_limit)(
    const struct wl_col_session_t *, uint64_t);
extern void (*wl_columnar_session_test_observer_resource_finished)(
    const struct wl_col_session_t *, unsigned, wl_evaluation_control_report_t,
    int);
extern void (*wl_columnar_session_test_observer_finance_phase)(
    struct wl_col_session_t *, wl_evaluation_control_t *, uint64_t,
    unsigned, bool, int);
extern void (*wl_columnar_session_test_terminal_advanced)(
    struct wl_col_session_t *, wl_evaluation_control_t *, uint64_t,
    unsigned, unsigned, int);
extern uint64_t (*wl_columnar_session_test_terminal_limit)(
    const struct wl_col_session_t *, uint64_t);
extern void (*wl_columnar_session_test_terminal_finance_phase)(
    struct wl_col_session_t *, bool, wl_evaluation_control_t *, uint64_t,
    unsigned, bool, int);
extern void (*wl_columnar_session_test_terminal_finished)(
    const struct wl_col_session_t *, unsigned, bool,
    wl_evaluation_control_report_t);
enum {
    WL_COLUMNAR_SESSION_TEST_SNAPSHOT_OUTER_RESET = 1,
    WL_COLUMNAR_SESSION_TEST_SNAPSHOT_OUTER_BEFORE_SELECTED,
    WL_COLUMNAR_SESSION_TEST_SNAPSHOT_OUTER_AFTER_SELECTED
};
extern void (*wl_columnar_session_test_snapshot_finish_outer_phase)(
    struct wl_col_session_t *, unsigned);
int wl_columnar_session_test_snapshot_finish_retained_view(
    const struct wl_col_session_t *, uint64_t out[12]);
extern void (*wl_columnar_session_test_snapshot_finish_phase)(
    struct wl_col_session_t *, unsigned, bool, int, bool);
int wl_columnar_session_test_snapshot_finish_view(
    const struct wl_col_session_t *, uint64_t out[8]);
int wl_columnar_session_test_snapshot_prior_view(
    const struct wl_col_session_t *, uint64_t out[8]);
/* Outside BANK, under real admission and bind busy. The generation fields
 * describe actual Step/payload state and convey no controller/Native loan. */
extern void (*wl_columnar_session_test_metadata_bind_phase)(
    struct wl_col_session_t *, unsigned, bool, int, bool, uint64_t, uint64_t,
    bool);
int wl_columnar_session_test_metadata_candidate(const struct wl_col_session_t *,
    uint64_t out[5]);
int wl_columnar_session_test_metadata_bind_view(
    const struct wl_col_session_t *, uint64_t out[10]);
extern void (*wl_columnar_session_test_constructor_error_phase)(
    struct wl_col_session_t *, unsigned, bool, int, bool);
extern void (*wl_columnar_session_test_constructor_outer_source_phase)(
    struct wl_col_session_t *, unsigned, bool, uint64_t, int, bool);
extern void (*wl_columnar_session_test_financier_outer_source_phase)(
    struct wl_col_session_t *, unsigned, unsigned, unsigned, bool, uint64_t,
    int, bool);
bool wl_columnar_session_test_bootstrap_finance_pending(
    const struct wl_col_session_t *);
int wl_columnar_session_test_constructor_error_view(
    const struct wl_col_session_t *, uint64_t out[8]);
int wl_columnar_session_test_producer_disposition_view(
    const struct wl_col_session_t *, uint64_t out[6]);
int wl_columnar_session_test_producer_view(const struct wl_col_session_t *,
    uint64_t out[6]);
/* Quiescent test observation of retained WORK ownership; no Native permit. */
int wl_columnar_session_test_retained_work_owner(
    const struct wl_col_session_t *,
    uint64_t out[8]);
int wl_columnar_session_test_terminal_view(const struct wl_col_session_t *,
    uint64_t[16]);
/* Descriptive MAIN protocol observations, never a Native permission. */
int wl_columnar_session_test_main_view(const struct wl_col_session_t *,
    uint64_t[16]);
extern void (*wl_columnar_session_test_main_birth)(
    const struct wl_col_session_t *, bool, wl_evaluation_control_t *,
    uint64_t, uint64_t, int);
extern void (*wl_columnar_session_test_prepared_native_checkpoint)(
    struct wl_col_session_t *, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_evaluation_control_t *, uint64_t, unsigned);
extern void (*wl_columnar_session_test_prepared_source_event)(
    struct wl_col_session_t *, unsigned, int);
int wl_columnar_session_test_prepared_source_debt_probe(
    struct wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, unsigned);
extern void (*wl_columnar_session_test_main_report_finished)(
    const struct wl_col_session_t *, wl_evaluation_control_t *, uint64_t,
    wl_evaluation_control_report_t);
extern uint64_t (*wl_columnar_session_test_main_limit)(
    const struct wl_col_session_t *, unsigned, unsigned, uint64_t);
extern void (*wl_columnar_session_test_main_finance_phase)(
    struct wl_col_session_t *, wl_evaluation_control_t *, uint64_t,
    unsigned, unsigned, unsigned, bool, int);
extern void (*wl_columnar_session_test_main_action_report)(
    const struct wl_col_session_t *, unsigned, unsigned,
    wl_evaluation_control_report_t, int);
extern void (*wl_columnar_session_test_main_action_advanced)(
    struct wl_col_session_t *, wl_evaluation_control_t *, uint64_t,
    unsigned, unsigned, unsigned, int);
int wl_columnar_session_test_observer_main_view(
    const struct wl_col_session_t *, uint64_t[16]);
bool wl_columnar_session_test_terminal_credit(const struct wl_col_session_t *,
    const wl_columnar_memory_reservation_t *);
bool wl_columnar_session_test_terminal_physical_pending(
    const struct wl_col_session_t *);
bool wl_columnar_session_test_terminal_busy(const struct wl_col_session_t *);
struct wl_columnar_relation_scalar_source;
bool wl_columnar_session_test_frontier_source_current(
    const struct wl_col_session_t *,
    const struct wl_columnar_relation_scalar_source *);
int wl_columnar_session_test_observer_resource_view(
    const struct wl_col_session_t *, uint64_t[12]);
extern void (*wl_columnar_session_test_observer_parent_free)(
    struct wl_col_session_t *);

#endif

struct wl_columnar_eval_private_bindings;
bool wl_columnar_session_controlled_batch_authorized(
    const struct wl_col_session_t *, const wl_evaluation_control_t *,
    uint64_t, uint64_t, const wl_plan_relation_t *,
    const struct wl_columnar_eval_private_bindings *);
typedef struct wl_columnar_tdd_owner_lifetime {
    uint32_t worker_count;
    uint32_t relation_count;
    size_t matrix_slots;
    bool evaluation_active;
    bool dispatch_active;
    void *worker_ctxs;
    wl_columnar_memory_reservation_t reservation;
    /* The stratum's TDD channel (coord->tdd_channel) while this record
     * holds it; retained batches are retired through it. */
    wl_tdd_channel_t *channel;
    /* CONSUMER batches taken from the channel whose payloads have not been
     * retired yet: captured at cleanup or refused by a checked destroy.
     * Linked through batch->next, so appending allocates nothing. */
    wl_tdd_batch_t *retained;
    /* The worker/relation matrix: matrix_slots entries, worker w's starting
     * at w * relation_count. */
    col_rel_t *relations[];
} wl_columnar_eval_tdd_owner_lifetime_t;

typedef enum {
    WL_COLUMNAR_SESSION_STEP_RESET_NONE,
    WL_COLUMNAR_SESSION_STEP_RESET_CLEAR,
    WL_COLUMNAR_SESSION_STEP_RESET_RESTORE,
    WL_COLUMNAR_SESSION_STEP_RESET_BIND,
    WL_COLUMNAR_SESSION_STEP_RESET_READY,
    WL_COLUMNAR_SESSION_STEP_RESET_HANDOFF,
    WL_COLUMNAR_SESSION_STEP_RESET_DELIVERY
} wl_columnar_session_step_reset_phase_t;

typedef enum {
    WL_COLUMNAR_SESSION_STEP_RESET_COMMITTED_DIRTY = 1,
    WL_COLUMNAR_SESSION_STEP_RESET_FAILED_RETRY,
    WL_COLUMNAR_SESSION_STEP_RESET_FAILED_RETRY_STARTED_NO_NATIVE
} wl_columnar_session_step_reset_origin_t;

/* This owner lives outside the descriptor whose metadata it clears. No
 * Native resource, financial grant or synchronous Snapshot address is copied. */
typedef struct {
    const void *identity;
    struct wl_col_session_t *session;
    wl_columnar_controlled_step_t *target;
    wl_evaluation_control_t *control;
    uint64_t control_identity, operation_id, operation_identity;
    col_rel_t *append_source;
    uint64_t append_identity;
    uint32_t append_begin;
    size_t byte;
    unsigned restore;
    wl_columnar_session_step_reset_phase_t phase;
    wl_columnar_session_step_reset_origin_t origin;
    bool operation_active, observed, general, append_proven, busy;
    bool old_observed, old_published, ended_valid;
    int ended_result;
    wl_backend_controlled_completion_t completion;
    bool thread_valid;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD thread;
#else
    pthread_t thread;
#endif
} wl_columnar_session_step_reset_t;

typedef struct wl_col_session_t {
    wl_session_t base;         /* MUST be first field (vtable dispatch)  */
    /* base.extension_snapshot is borrowed from the coordinator in workers;
     * col_worker_session_destroy must never release that reference. */
    const col_frontier_ops_t *frontier_ops; /* frontier vtable (#261)   */
    const col_rotation_ops_t *rotation_ops; /* rotation vtable (#600)   */
    const wl_plan_t *plan;     /* borrowed, lifetime: caller             */
    wl_intern_t *intern;       /* borrowed, lifetime: caller (prog)      */
    col_rel_t **rels;          /* owned array of owned col_rel_t*        */
    uint32_t nrels;            /* current number of registered relations */
    uint32_t rel_cap;          /* allocated capacity of rels[]           */
    wl_columnar_memory_reservation_t rels_reservation;
    /* Relation name hash table (Issue #281): O(1) lookup for session_find_rel.
     * Uses FNV-1a hash (arrangement.c pattern) with chaining. Built lazily on
     * first lookup, rebuilt when load factor exceeds 50%.  */
    uint32_t *rel_hash_head;      /* owned bucket heads array (UINT32_MAX = empty) */
    uint32_t *rel_hash_next;      /* owned collision chain pointers           */
    uint32_t rel_hash_nbuckets;   /* current bucket count (power of 2)       */
    uint32_t rel_hash_chain_cap;  /* allocated capacity of rel_hash_next[]  */
    wl_columnar_memory_reservation_t rel_hash_reservation;
    wirelog_on_delta_fn delta_cb;   /* delta callback (NULL = disabled)       */
    void *delta_data;          /* opaque user context for delta_cb       */
    wl_col_delta_event_t *delta_events; /* staged observer events */
    size_t delta_event_count;
    size_t delta_event_capacity;
    wl_columnar_memory_reservation_t delta_event_reservation;
    uint64_t delta_event_reserved_bytes;
    bool delta_event_transaction;
    wl_arena_t *eval_arena;    /* arena for per-iteration temporaries    */
    col_mat_cache_t mat_cache; /* materialization cache (US-006)        */
    uint32_t total_iterations; /* fixed-point iterations in last eval   */
    /* True after at least one evaluation pass has completed successfully.
     * Unlike total_iterations, this remains true when a pass converges
     * without performing a fixpoint iteration. */
    bool has_evaluated;
    bool plain_step_completion_pending;
    bool plain_step_completion_active;
    bool plain_step_completion_step_context;
    uint64_t plain_step_completion_mask;
    uint32_t plain_step_completion_stratum;
    uint32_t plain_step_completion_phase;
    uint32_t plain_step_completion_relation;
    bool plain_step_completion_workers_retired;
    uint32_t plain_step_completion_final_iteration;
    uint32_t plain_step_completion_rule_base;
    bool plain_step_completion_iteration_capped;
    /* Framed controlled initial STEP continuation; opaque to the session
     * layout so its host protocol types remain declared below. */
    wl_columnar_controlled_step_t *controlled_step;
    wl_columnar_session_step_reset_t controlled_step_reset;
    bool destroy_prepared;
    bool destroy_controlled_prepared;
    /* Issue #2092, #2348: how many leading strata a plain step or a snapshot
     * that has not committed evaluated, including one that failed (saturating).
     * Their heads may hold rows no commit accounts for, so the next plain step,
     * snapshot or delta baseline that does not resume clears them before
     * re-deriving, even before has_evaluated is set.  Zero at commit.
     */
    uint16_t uncommitted_strata_extent;
    /* Issue #176: Per-iteration cache eviction for recursive strata.
     * cache_evict_threshold: target cache size (bytes) for LRU eviction
     * in recursive stratum iteration loop. When cache exceeds this threshold,
     * LRU entries are evicted until size drops below it.
     * Configurable via WL_MAT_CACHE_EVICT_THRESHOLD_PERCENT env var [1,100],
     * default = 90% of limit */
    size_t cache_evict_threshold;
    wl_work_queue_t *wq; /* lazily sized reusable worker pool     */
    uint32_t wq_workers; /* current thread count in wq            */
    /* Profiling counters (3B-003): accumulated across all strata/iters  */
    uint64_t
        consolidation_ns; /* time in col_op_consolidate_incremental_delta */
    uint64_t kfusion_ns;  /* time in col_op_k_fusion                */
    /* Fast-path hit/miss counters for incremental consolidation (Issue #278).
    * consolidate_fast_hits: calls where all delta > all old (sub-cases a/b).
    * consolidate_slow_hits: calls requiring O(N) merge walk (interleaved). */
    uint64_t consolidate_fast_hits;
    uint64_t consolidate_slow_hits;
    /* Arrangement registry (Phase 3C): persistent hash indices           */
    col_arr_entry_t *arr_entries; /* owned flat array of arrangements     */
    uint32_t arr_count;           /* number of active arrangements        */
    uint32_t arr_cap;             /* allocated capacity                   */
    /* LRU eviction tracking for arrangement cache (Issue #216) */
    uint64_t arr_clock;           /* monotonically increasing access counter */
    size_t arr_total_bytes;       /* total bytes in ht_head + ht_next arrays */
    size_t arr_cache_limit_bytes; /* eviction threshold (default 256 MB)     */
    /* Delta arrangement cache (Phase 3C-001-Ext): per-iteration hash
     * indices for delta-substituted right relations.  Unlike arr_entries
     * (cross-iteration, session-global), these are:
     *   - Per-worker: zeroed in each K-fusion worker's session copy
     *   - Per-iteration: freed at start of each col_eval_stratum iter
     * This avoids races: workers write to their own copy, never shared. */
    col_arr_entry_t *darr_entries; /* owned flat array of delta arrs      */
    uint32_t darr_count;           /* number of active delta arrangements */
    uint32_t darr_cap;             /* allocated capacity                  */
    /* Filtered arrangement cache (Issue #433): persistent hash indices for
     * filtered right-side relations from filt_cache.  Unlike darr_entries
     * (cleared per sub-pass), these persist across sub-passes and are only
     * reset when col_session_invalidate_arrangements is called.
     * Workers start with empty filt_arr (like darr) for isolation safety. */
    col_filt_arr_entry_t *filt_arr_entries;
    uint32_t filt_arr_count;
    uint32_t filt_arr_cap;
    /* 2D Frontier Epoch Tracking (Issue #103): Incremental insertion epoch counter.
     * Incremented before each EDB insertion and stratum evaluation to distinguish
     * between different insertion epochs. Used with frontiers[] to track
     * (outer_epoch, iteration) pairs: an iteration is skipped only if it was
     * already processed in the SAME outer_epoch. This prevents incorrect skipping
     * when comparing across different insertion epochs. */
    uint32_t outer_epoch;
    /* Frontier tracking (Phase 4 / Issue #104): per-stratum 2D frontier array
     * for epoch-aware incremental re-evaluation. Each frontiers[i] tracks the
     * (outer_epoch, iteration) pair at which stratum i last converged.
     * An iteration is skipped only when it was already processed in the SAME
     * outer_epoch, preventing incorrect skipping across insertion epochs.
     * This enables skipping redundant iterations when frontier persists across
     * session_step calls (incremental evaluation). */
    col_frontier_2d_t
        frontiers[MAX_STRATA]; /* per-stratum 2D frontier tracking */
    /* Frontier tracking (Phase 4, US-4-002): per-rule frontier array for
     * rule-level incremental re-evaluation. Each rule_frontiers[i] tracks the
     * minimum (iteration, stratum) boundary fully processed for rule i.
     * Initialized to (0, 0) via calloc. Reset to UINT32_MAX for affected
     * rules on incremental insert (enables selective rule skipping in
     * US-4-004). MAX_RULES=64 matches uint64_t bitmask width. */
    col_frontier_2d_t
        rule_frontiers[MAX_RULES]; /* per-rule frontier tracking with
                                                     (outer_epoch, iteration) pairs */
    /* Per-phase K-fusion profiling (Phase 3A): breakdown of kfusion_ns into
    * four sub-phases accumulated across all col_op_k_fusion calls per eval.
    *   alloc_ns:    calloc of results/workers/worker_sess arrays
    *   dispatch_ns: submit loop + wl_workqueue_wait_all barrier
    *   merge_ns:    col_rel_merge_k + eval_stack_push
    *   cleanup_ns:  result/worker mat_cache/arr/darr free loops + free() */
    uint64_t kfusion_alloc_ns;
    uint64_t kfusion_dispatch_ns;
    uint64_t kfusion_merge_ns;
    uint64_t kfusion_cleanup_ns;
    /* Coordinator-owned adaptive policy for K=2/K=3 K-fusion. Worker
    * session copies set this to NULL and never mutate or free it. */
    wl_kfusion_adaptive_ctx_t *kfusion_adaptive;
    /* Exchange path timing (Issue #413): accumulated wall time spent in
     * tdd_exchange_deltas / tdd_bdx_exchange_deltas across all sub-pass
     * barriers.  Used to compute serial_fraction = exchange_time_ns / total_ns
     * for Amdahl's Law validation at varying worker counts W.
     * Coordinator-only; reset at the start of each wl_session_snapshot(). */
    uint64_t exchange_time_ns;
    /* TDD recursive evaluator profiling (#650, #1373).  These counters
     * split each sub-pass round into phases that can be compared across
     * W=4/W=8/W=16.  tdd_submit_loop_ns is the submit loop.
     * tdd_wait_barrier_ns runs from the dispatch until the workers are
     * joined and the batches taken in discard mode are disposed, so it
     * includes the coordinator's channel pump and the held-cap spills it
     * makes while the workers run; tdd_dispatch_wait_ns is the sum of the
     * two.  tdd_idle_estimate_ns adds how far each round's wait exceeded
     * its slowest worker's runtime, so it includes pump and spill time
     * too.  tdd_queue_drain_ns covers the staging of the collected
     * batches after the join (each relation's spill-down and coalesce),
     * which the exchanges run; the driver takes that time out of
     * exchange_time_ns and tdd_exchange_ns, though the exchanges' own
     * tdd_exchange_*_ns breakdowns can still include it.  Coordinator-only;
     * reset at the start of each wl_session_snapshot(). */
    uint64_t tdd_total_ns;
    uint64_t tdd_dispatch_wait_ns;
    uint64_t tdd_submit_loop_ns;
    uint64_t tdd_wait_barrier_ns;
    uint64_t tdd_worker_sum_ns;
    uint64_t tdd_worker_max_ns;
    uint64_t tdd_idle_estimate_ns;
    uint64_t tdd_queue_drain_ns;
    uint64_t tdd_convergence_ns;
    uint64_t tdd_exchange_ns;
    uint64_t tdd_exchange_matrix_ns;
    uint64_t tdd_exchange_coordinator_ns;
    uint64_t tdd_exchange_scatter_ns;
    uint64_t tdd_exchange_gather_ns;
    uint64_t tdd_exchange_broadcast_ns;
    uint64_t tdd_final_merge_ns;
    uint32_t tdd_recursive_strata;
    uint32_t tdd_executed_strata;
    uint32_t tdd_fallback_strata;
    uint32_t tdd_fallback_reason_counts[
        WL_COLUMNAR_INTERNAL_TDD_FALLBACK_REASON_COUNT];
    wl_columnar_internal_tdd_fallback_reason_t tdd_last_fallback_reason;
    bool tdd_decision_tracking_active;
    /* Opt-in snapshot diagnostics; reset at snapshot entry and before each
     * stratum. Only the coordinator writes this, never worker tasks.
     * A completed round means all W submissions reached the barrier, not
     * successful exchange or distinct OS-thread execution. Runtime extrema
     * are individual worker sub-pass extrema, not per-worker lifetime sums. */
    struct {
        bool enabled;
        const char *strategy;
        uint32_t selected_workers;
        uint64_t submitted_tasks;
        uint64_t completed_rounds;
        uint64_t worker_min_ns;
        uint64_t worker_max_ns;
        uint64_t worker_sum_ns;
        uint64_t worker_delta_rows;
        const char *replay;
        int replay_rc;
        /* The stratum's TDD channel (#1373): rounds whose channel was
         * cancelled, the first error it recorded (kept when a worker's
         * error outranks it as the round's rc), descriptors reclaimed
         * from closed lanes, and reservations refused because their
         * descriptor belonged to another round. */
        uint64_t channel_cancelled;
        int channel_rc;
        uint64_t orphan_reclaims;
        uint64_t rejected;
        /* The stratum's consumer counts (see wl_tdd_consumer_stats_t):
         * batches spilled, cap passes that ended over the held cap,
         * stagings that ended over it, and the stratum's
         * stage_peak_bytes. */
        uint64_t consumer_spills;
        uint64_t held_over_cap;
        uint64_t stage_over_cap;
        uint64_t stage_peak_bytes;
        /* The reason the worker whose error failed a round gave, when it
         * gave one: "outbound_growth" for an outbound frame's head growth
         * (EPROTO). */
        const char *refusal;
    } tdd_audit;
    /* Phase 4: tracks which relation was just inserted via
     * col_session_insert_incremental, so a step with a delta callback can
     * evaluate only the strata it affects and a snapshot can bring them up
     * to date from its appended rows (#2114).  Session-owned canonical
     * relation name; base and
     * compound-side relations remain registered while input work is pending,
     * so the pointer stays valid until a successful step/snapshot clears it.
     * NULL when no incremental insert preceded the current step (all strata
     * evaluated normally via affected_mask = UINT64_MAX). */
    const char *last_inserted_relation;
    /* True when an input relation changed since the last successful step.
     * This includes hidden side-compound storage writes, which are EDB-like
     * dependencies for plans that scan __compound_* relations. */
    bool pending_input_change;
    /* True when more than one inserted input relation is pending, so affected
     * stratum selection must conservatively evaluate every stratum while
     * preserving last_inserted_relation as the most recent input name. */
    bool pending_full_input_eval;
    /* True after a successful step/snapshot has materialized stable IDB rows.
     * A clean snapshot may enumerate those rows directly instead of running
     * another evaluation pass. */
    bool snapshot_stable_valid;
    /* Current fixed-point iteration counter within col_eval_stratum.
     * Set at the start of each iteration; operators use this to distinguish
     * iteration 0 (base case: FORCE_DELTA falls back to full relation) from
     * iteration > 0 (FORCE_DELTA with absent delta -> empty short-circuit).
     * Only valid during col_eval_stratum execution. */
    uint32_t current_iteration;
    /* Last scalar-extension evaluator status.  Written by the coordinator
     * after worker barriers, never by a worker into caller TLS. */
    int extension_expr_status;
    /* Set by evaluator admission sites when a governor denial caused the
     * current operation to stop.  Kept separate from ENOSPC because cache
     * refusal and compound saturation use that status too. */
    bool memory_budget_denied;
    /* Governor denial count when a controlled STEP's first public call began,
     * and the attempt it belongs to; held until a return leaves no debt. */
    bool controlled_denial_open;
    uint64_t controlled_denial_baseline;
    uint64_t controlled_denial_attempt;
    /* Operation-local denial while privately staging an advanced incremental
     * bulk removal.  The temporary delta is discarded before generic session
     * budget inspection can see it. */
    bool remove_staging_budget_denied;
    /* Delta-seeded evaluation (issue #83).
     * When true, FORCE_DELTA at iteration 0 pushes empty (not full) for
     * relations without a delta, so evaluation propagates deltas only.
     * tdd_worker_subpass_fn sets it on a worker clone for an outbound-only
     * differential sub-pass and restores it afterwards.  The snapshot
     * pre-seed of `$d$` EDB deltas that set it on the coordinator was
     * replaced in #2114 by wl_columnar_eval_tdd_insert_stratum, which clears
     * it on its own worker clone. */
    bool delta_seeded;
    /* Multi-worker support (issue #99).
     * Stored from col_session_create num_workers parameter as a maximum worker
     * width. Adaptive TDD and K-fusion may dispatch fewer active workers for a
     * stratum/operator. Workqueue threads and TDD worker slots are allocated
     * lazily for the selected active width, so workers=N means "use up to N". */
    uint32_t num_workers;
    uint32_t callback_configured_workers;
    uint32_t callback_active_workers;
    bool callback_parallel_execution;
    const void *callback_session_key;
    /* Optional legacy maximum output rows per single join, configured through
     * WIRELOG_JOIN_OUTPUT_LIMIT. Zero disables the row cap; memory admission
     * is enforced separately. */
    uint64_t join_output_limit;
    /* Bounded keyed-join sub-batches (Issue #1446).  join_batch_bytes is
     * the per-producer batch payload budget from WIRELOG_JOIN_BATCH_BYTES;
     * zero keeps the one-shot join.  join_batch_strict makes an excluded
     * shape fail with ENOTSUP instead of falling back; the fallback counter
     * and last reason record every silent fallback for diagnostics. */
    uint64_t join_batch_bytes;
    bool join_batch_strict;
    uint32_t join_batch_fallback_count;
    uint8_t join_batch_last_reason;
    /* Published, authorized controlled materializing fallback count. */
    uint64_t controlled_materialized_batch_published_count;
    uint16_t join_batch_warned_reasons; /* one WL_LOG warning per reason */
    /* Bounded producer runs that completed, per route, indexed by
     * col_join_batch_run_route_t (columnar/join_batch.h) (#2201):
     * join_batch_runs counts this session's own runs, and
     * join_batch_worker_runs the runs its workers' teardowns folded in. */
    uint32_t join_batch_runs[3];
    uint32_t join_batch_worker_runs[3];
    /* Issue #959: high-water mark of a single join's output, per session.
     * Workers are separate sessions, so each carries its own -- which is the
     * number needed to decide whether dividing the row cap by W is right:
     * compare a worker's peak against single_threaded_peak / W. */
    uint64_t join_output_peak;
    /* Shared join-output counter for K-fusion and relation-level TDD workers.
     * Borrowed from the coordinator while the worker cohort is running;
     * NULL uses the session-local join_output_limit semantics. */
    atomic_uint_fast64_t *join_output_shared_count;
    uint64_t join_output_shared_limit;
    /* Monotone property tracking (issue #105).
     * stratum_is_monotone[si] = true if stratum si only derives facts
     * (no deletion via negation/antijoin/subtraction). Used for DRedL-style
     * deletion phase skip optimization. Populated from plan->strata[si].is_monotone
     * during session_create. Conservative default: all false (no optimization). */
    bool stratum_is_monotone[MAX_STRATA];
    /* Retraction delta tracking (Issue #158): tracks which relation was just
     * removed via col_session_remove_incremental, enables delta retraction path.
     * Session-owned canonical relation name; the base relation remains
     * registered while retraction work is pending, so the pointer stays valid
     * until a successful step clears it.
     * NULL when no incremental remove preceded the current step. */
    const char *last_removed_relation;
    /* Retraction-seeded incremental evaluation (Issue #158).
     * When true, EDB retraction delta relations have been pre-seeded into
     * the session before re-evaluation. Similar to delta_seeded but for
     * $r$<name> relations. Cleared after eval completes. */
    bool retraction_seeded;
    /* Issue #472: Second-pass flag for self-join retraction.
     * When true, VARIABLE ops load the full relation (not $r$) and
     * JOIN/SEMIJOIN ops substitute $r$ on the right side instead. */
    bool retraction_right_pass;
    delta_pool_t *delta_pool; /* Pool allocator for operator temporaries */
    /* Sorted arrangement cache (Issue #195): per-key-column sorted copies of
     * EDB relations for leapfrog triejoin (WL_PLAN_OP_LFTJ).  Unlike hash
     * arrangements, these are sorted by a single key column and reused across
     * semi-naive iterations (EDB relations are stable between iterations).
     * Freed only on session destroy. */
    col_sorted_arr_entry_t
    *sarr_entries;     /* flat array of sorted arrangements */
    uint32_t sarr_count;
    uint32_t sarr_cap;
    uint32_t sarr_active_pins;
#ifdef WL_PROFILE
    wl_profile_stats_t profile; /* operator profiling counters */
#endif
    /* Coordinator-owned immutable descriptor arena. Never execution authority
    * and never copied to worker wrappers, including its noncopyable token. */
    wl_plan_scalar_view_t *controlled_scalar_view;
    wl_columnar_memory_reservation_t controlled_scalar_view_reservation;
    /* Memory accounting ledger (Issue #224): thread-safe per-subsystem tracking.
     * Embedded (not a pointer) so that the session owns the ledger lifetime.
     * Initialized in col_session_create via wl_mem_ledger_init().
     * Accessible to all columnar code via &COL_SESSION(sess)->mem_ledger. */
    wl_mem_ledger_t mem_ledger;
    /* Shared coordinator-owned governor. Workers retain this reference and
     * never copy or destroy the embedded governor value. */
    wl_columnar_memory_governor_ref_t *memory_governor;
    /* Numeric spill: coordinator owns, workers borrow. Lifecycle operations
     * require external serialization even when sharing this pointer. */
    wl_columnar_spill_store_t *spill_store;
    bool owns_spill_store;
    /* Internal opt-in; coordinator serial ordinary JOIN only. Final output
     * stays resident; eligible sources can transfer into immutable payloads.
     * Count selections, including failed ones. */
    uint64_t spill_join_batch_bytes;
    uint64_t spill_join_index_bytes;
    uint64_t spill_join_selected_count;
    wl_columnar_session_cold_relation_t *cold_relation; /* Owned binding list. */
    bool cold_seal_closed; /* First evaluation attempt permanently closes seal. */
    /* Issue #1380: memory instrumentation state that is not part of the
     * ledger proper.
     *   mem_channel_side_bytes: bytes charged to CHANNEL for the TDD
     *       channel object, its lanes and the consumer list heads of the
     *       stratum currently being evaluated (0 otherwise).
     *   mem_worker_reports / mem_worker_peak_max / mem_worker_peak_sum:
     *       aggregates of TDD worker ledger peaks folded in at
     *       col_worker_session_destroy() so one coordinator report can
     *       stand in for the per-worker lines.
     *   mem_report_level: cached WL_MEM_REPORT level (0 = off, 1 =
     *       coordinator summary, 2 = also every worker teardown). */
    uint64_t mem_channel_side_bytes;
    /* Coordinator-owned TDD channel side buffers (the channel, its lanes and
     * the consumer list heads); workers never inherit this token. */
    wl_columnar_memory_reservation_t tdd_channel_reservation;
    uint64_t mem_worker_reports;
    uint64_t mem_worker_peak_max;
    uint64_t mem_worker_peak_sum;
    int mem_report_level;
    /* Differential arrangement registry (Issue #263): persistent hash indices
     * for arrangement reuse in differential join. Unlike darr_entries (per-iteration
     * delta arrangements), these persist across iterations within an epoch.
     * Only active when diff_operators_active is true. Freed on session destroy
     * or when switching back to epoch-based evaluation. */
    col_diff_arr_entry_t *diff_arr_entries;
    uint32_t diff_arr_count;
    uint32_t diff_arr_cap;
    wl_columnar_memory_reservation_t diff_arr_registry_reservation;
    uint64_t diff_arr_registry_reserved_bytes;
    uint64_t diff_arr_registry_metadata_reserved_bytes;
    uint32_t diff_txn_count;      /* active differential replacement txns */
    /* Session-level differential path master switch (Issue #264).
     * When true, differential operators may be activated based on guard logic.
     * When false, always use epoch-based operators regardless of affected_strata.
     * Default: true. Overridable via WIRELOG_DIFF_ENABLED=0 env var. */
    bool diff_enabled;
    /* Guard flag for differential operator activation (Issue #263).
     * Set to true when diff_enabled is true AND affected_strata < full_mask
     * (partial insertion), enabling col_op_join_diff / col_op_consolidate_diff
     * in eval dispatch.
     * When false (bulk insert, full evaluation, or diff_enabled=false),
     * epoch-based operators used. */
    bool diff_operators_active;
    /* Issue #277: Cache debug/log env vars at session init to avoid repeated
     * getenv() calls in hot paths. */
    bool debug_join;         /* WL_DEBUG_JOIN=1 enables DEBUG[JOIN] output  */
    bool consolidation_log;  /* WL_CONSOLIDATION_LOG=1 enables CONS output  */
    /* Per-worker session state (Issue #315): data-partitioned worker isolation.
     * worker_id:    0-based worker index.  Only meaningful when coordinator
     *               is non-NULL (i.e., this session is a worker, not the
     *               coordinator).
     * coordinator:  borrowed pointer to parent session.  NULL means this
     *               IS the coordinator session.  Non-NULL is the canonical
     *               "is this a worker?" test and prevents freeing borrowed
     *               resources (plan, frontier_ops) in worker destroy. */
    uint32_t worker_id;
    struct wl_col_session_t *coordinator;
    /* Worker/session-owned registry for persistent shared-view source
     * readers.  Membership is confined to the coordinator thread between
     * worker barriers; worker tasks only read the published relations. */
    wl_columnar_session_source_lease_t *source_leases;
    col_rel_t *deferred_relations;
    uint32_t deferred_relation_count;
    /* Persistent cleanup for all col_eval_stratum callers, including worker
     * sessions, recursive delta steps, direct TDD recursive subpasses and
     * the specialized nonrecursive parallel rule evaluators. K-Fusion is the
     * one evaluator that still drains an unframed stack; see #1648. */
    wl_columnar_eval_stack_cleanup_frame_t *cleanup_active;
    /* Caller-owned bound-slice handle; blocks reuse until finish succeeds. */
    wl_columnar_eval_tdd_run_t *tdd_input_run;
    wl_columnar_eval_stack_cleanup_frame_t *cleanup_pending;
    uint32_t cleanup_active_count;
    uint32_t cleanup_pending_count;
    uint64_t cleanup_reserved_bytes;
    /* Receipts for framed relation attempts; every access is serialized by
     * the framed host/session owner and stores scalar identity only. */
    uint64_t cleanup_receipt_session_generation;
    uint64_t cleanup_receipt_next_id;
    uint64_t cleanup_receipt_next_plan_epoch;
    wl_columnar_eval_cleanup_receipt_t cleanup_receipts[
        WL_COLUMNAR_EVAL_STACK_CLEANUP_MAX_FRAMES];
    /* Session-owned transferred frames, indexed only by a fresh full key. */
    wl_columnar_eval_stack_cleanup_frame_t *cleanup_pending_owners[
        WL_COLUMNAR_EVAL_STACK_CLEANUP_MAX_FRAMES];
    /* Set false on entry to col_eval_stratum, and true only at each of its
     * two completion points.  col_stratum_step_with_delta clears it again on
     * its own entry, which is the load-bearing clear: its detach loop can
     * reach cleanup without calling col_eval_stratum at all, and a stale true
     * would then skip a restore those heads need.
     *
     * It answers the one question no later observer can: whether a head that
     * is empty was emptied by a stratum that ran to the end, or was never
     * reached.  Those are otherwise identical -- delta detach leaves every
     * head at the same generation pair and the paths that produce nothing
     * never touch one.
     *
     * Read only by col_stratum_step_with_delta, once, for the call it just
     * made; it is neither a gate nor a predicate, and nothing may consult it
     * later.  False is the safe default: it makes the caller restore. */
    bool eval_stratum_heads_final;
    /* Last evaluator outcome; consume before calling another stratum. Legacy
     * cap exhaustion returns zero but cannot commit stable-model bookkeeping. */
    bool eval_stratum_iteration_capped;
    wl_columnar_eval_delta_rollback_t *delta_rollback;
    uint64_t delta_rollback_reserved_bytes;
    wl_columnar_eval_delta_observer_t *delta_observer;
    wl_columnar_eval_delta_observer_build_t *delta_observer_build;
    wl_columnar_eval_delta_observer_prepare_t *delta_observer_prepare;
    uint64_t delta_observer_reserved_bytes;
    /* Keep metadata credit alive after the observer allocation is freed if
     * its checked retirement refuses. A later serialized cleanup retries it. */
    wl_columnar_memory_reservation_t delta_observer_retirement_metadata;
    wl_columnar_memory_governor_ref_t *delta_observer_retirement_governor;
    wl_columnar_eval_delta_observer_retire_t delta_observer_retirement;
    bool delta_observer_retirement_gc;
    bool delta_publish_active;
    bool delta_publish_cancelled;
    /* Serial K-Fusion retains refused evaluator entries here until the
     * parent allocator and any operation-scoped readers are quiescent. */
    struct wl_columnar_retained_eval_entry *retained_eval_entries;
    uint32_t retained_eval_entry_count;
    /* Parallel K-Fusion invocation retained across refused worker cleanup. */
    struct wl_columnar_kfusion_cohort *kfusion_pending_cohort;
    /* Exchange operator state (Issue #316): W x W partition buffer matrix.
     * Allocated by coordinator before exchange scatter dispatch.
     * exchange_bufs[src_worker][dst_worker] holds rows src sends to dst.
     * NULL when no exchange is in progress.  Owned by coordinator only;
     * worker sessions inherit a borrowed pointer (not freed on worker destroy). */
    col_rel_t ***exchange_bufs;
    uint32_t exchange_num_workers; /* W dimension of the matrix */
    /* Per-worker frontier progress tracker (Issue #317): coordinator-owned.
     * Collects each worker's convergence report (outer_epoch, iteration)
     * after parallel stratum evaluation.  Workers write to their own slot
     * (thread-safe during scatter); coordinator reads after the workqueue
     * barrier to compute the global minimum frontier.
     * Embedded (not a pointer) so the coordinator session owns the lifetime.
     * Worker sessions must zero progress.entries in col_worker_session_create
     * to prevent double-free of the coordinator's entries array. */
    wl_frontier_progress_t progress;
    /* Distributed stratum evaluator state (Issue #318).
     * Worker session slots allocated lazily for the selected active width.
     * NULL when no TDD stratum has used workers yet. Owned by coordinator;
     * worker sessions set tdd_workers = NULL. */
    struct wl_col_session_t *tdd_workers; /* owned array [tdd_workers_cap] */
    uint32_t tdd_workers_cap;           /* allocated slots in tdd_workers */
    uint32_t tdd_workers_count;         /* number of initialized workers */
    /* Retains owner-mode TDD delta slots and channel batches when checked
     * cleanup refuses.
     * This record owns no plan or execution context and is cleanup-only. */
    wl_columnar_eval_tdd_owner_lifetime_t *tdd_owner_lifetime;
    uint32_t tdd_active_workers;        /* current adaptive TDD width */
    uint32_t tdd_last_active_workers;   /* last selected TDD width */
    uint32_t tdd_max_active_workers;    /* max selected width this eval */
    /* Number of base-case VARIABLEs this session replaced by an empty
     * relation after the first iteration (Issue #2127).  Each session
     * counts its own; a test reads it on a one-worker session. */
    uint64_t base_case_skips;
    /* TDD batch channel carrying worker deltas to the coordinator (Issue
     * #1373).  Created per recursive stratum evaluation in
     * col_eval_stratum_tdd_recursive() and destroyed when it ends, or by
     * the owner lifetime record that retains it.  Coordinator only; worker
     * sessions are created with tdd_channel=NULL. */
    wl_tdd_channel_t *tdd_channel;
    /* Consumer list heads for tdd_channel, one per (relation, worker) and
     * indexed rel_idx * workers + worker; tdd_channel_list_count entries.
     * They hold batches only between a round's collect and its coalesce,
     * or until the driver's cleanup disposes of them. */
    wl_tdd_batch_t **tdd_channel_lists;
    size_t tdd_channel_list_count;
    /* One flag per list, set by staging when the (worker, relation) slot
     * it built is private to the coordinator rather than an adopted batch.
     * Allocated with tdd_channel_lists, after its list heads. */
    bool *tdd_channel_private;
    /* Batches taken from tdd_channel in discard mode, once its round
     * cannot succeed, linked through batch->next.  They are disposed after
     * the round's producers are joined, or by the driver's cleanup. */
    wl_tdd_batch_t *tdd_channel_discard;
    /* Consumer-side accounting of the channel: the held cap and consumer
     * spill (#1373).  Coordinator only; reset at the start of each
     * wl_session_snapshot(). */
    wl_tdd_consumer_stats_t tdd_consumer;
    /* Set true inside tdd_worker_subpass_fn so col_op_variable AUTO heuristic
     * always uses the broadcast delta (which may be >= local partition size).
     * False everywhere else, including retraction paths. */
    bool tdd_subpass_active;
    bool tdd_outbound_only_active;
    /* Side-relation compound arena (Issue #559): heap-allocated session-local
     * compound-term arena.  Owned by the coordinator; created in
     * col_session_create and freed in col_session_destroy.  Worker sessions
     * NULL this pointer in col_worker_session_create so the bitwise copy of
     * the coordinator never participates in worker cleanup; the arena is
     * single-threaded and frozen across K-Fusion (see compound_arena.h).
     * The session_seed passed at create time is a placeholder constant; the
     * remap-aware seed will land in the rotation work tracked by #586+. */
    wl_compound_arena_t *compound_arena;
    /* Worker-owned read lease for the coordinator arena. */
    wl_compound_arena_borrow_t compound_borrow;
    /* Filtered relation cache (Issue #386): caches apply_right_filter results
     * keyed by (relation_name, filter_expr hash + full content). Prevents
     * redundant O(N) filter scans on each fixpoint iteration when
     * right_filter_expr is present.  Each entry owns rel_name (strdup),
     * filter_data (malloc copy of expression bytes), and filtered
     * (col_rel_new_like).  Entries are invalidated when source_nrows changes
     * (relation grew) or filter content differs (hash collision guard).
     * Freed on session destroy. Workers get NULL cache (zeroed at create). */
    col_filt_cache_entry_t *filt_cache;
    uint32_t filt_cache_count;
    uint32_t filt_cache_cap;
    /* Stable token for the cache entry-array allocation. */
    wl_columnar_memory_reservation_t *filt_cache_array_reservation;
    /* Issue #1435: active filtered-cache leases.  While non-zero the entry
     * array is neither grown nor compacted, so lease pointers stay valid;
     * asserted zero at session and worker teardown in debug builds. */
    uint32_t filt_cache_active_pins;
    /* A refused worker teardown is resumable but the worker must not be
     * reused. The report flag prevents retry from double-counting metrics. */
    bool teardown_started;
    bool teardown_reported;
    /* Issue #1994: identities of relations a host insert found to be no
     * rule head, direct-mapped by identity, so inserts into input relations
     * skip the seed-shadow lookup.  Rule-head membership is fixed by the
     * plan, and relation identities are never reused, so an entry cannot go
     * stale; a collision only costs a lookup. */
    uint64_t seed_none_identity[16];
} wl_col_session_t;

/* Distinct unpublished destination, immutable non-owning source fields.
 * Never byte-copy the scalar-view token or live ledger atomics, even
 * transiently. Caller initializes the excluded ledger before publication. */
static inline void
wl_columnar_session_copy_without_ledger(wl_col_session_t *destination,
    const wl_col_session_t *source)
{
    const size_t begin = offsetof(wl_col_session_t, controlled_scalar_view);
    const size_t end = offsetof(wl_col_session_t, mem_ledger)
        + sizeof(source->mem_ledger);
    memcpy(destination, source, begin);
    memcpy((unsigned char *)destination + end,
        (const unsigned char *)source + end, sizeof(*source) - end);
    destination->controlled_scalar_view = NULL;
    destination->controlled_step = NULL;
    destination->base.source_financial_head = NULL;
    destination->controlled_step_reset.identity = NULL;
    destination->controlled_step_reset.phase =
        WL_COLUMNAR_SESSION_STEP_RESET_NONE;
    destination->controlled_step_reset.busy = false;
    destination->controlled_step_reset.thread_valid = false;
    destination->controlled_step_reset.completion.selected = false;
    destination->destroy_prepared = false;
    destination->destroy_controlled_prepared = false;
    wl_columnar_memory_reservation_init(
        &destination->controlled_scalar_view_reservation);
    /* Worker wrappers never inherit the coordinator's pending owners. */
    memset((void *)destination->cleanup_pending_owners, 0,
        sizeof(destination->cleanup_pending_owners));
}

bool
wl_columnar_session_budget_denied(const void *session);
void
wl_columnar_session_budget_denial_clear(wl_col_session_t *sess);
/* Issue #1994: append the input rows a rule-head relation holds in its
 * `$in$<name>` seed shadow back into @r after @r was reset for a full
 * re-evaluation.  Returns 0 when @r has no shadow. */
int
wl_columnar_session_restore_seed(wl_col_session_t *sess, col_rel_t *r);
/* Issue #2091: the rows host removals have taken out of rule head
 * @relation's committed model since the last commit.  NULL until the first
 * such removal registers the relation; empty after a commit. */
col_rel_t *
wl_columnar_session_retired_rows(wl_col_session_t *sess,
    const char *relation);
/* Issue #2091: rule head @relation's `$in$<name>` seed shadow, or NULL.
 * Its rows [base_nrows, nrows) were inserted since the last commit. */
col_rel_t *
wl_columnar_session_seed_rows(wl_col_session_t *sess, const char *relation);
/* Issue #2100: sort and deduplicate each head of @sp that also holds input.
 * Defined in eval_serial.c. */
int
wl_columnar_eval_consolidate_input_heads(const wl_plan_stratum_t *sp,
    wl_col_session_t *sess);

typedef struct wl_columnar_session_hash_registry_image
    wl_columnar_session_hash_registry_image_t;

/* Standalone owner-publication transaction.  Candidates are owned by the
 * transaction after a successful add; on an add failure the caller retains
 * candidate ownership.  Published sessions and input relations are never
 * mutated until register/commit. */
typedef struct wl_columnar_eval_owner_publication_entry {
    wl_col_session_t *session;
    const char *name;
    col_rel_t *target;
    col_rel_t *owner;
    col_rel_t *candidate;
    col_rel_replacement_t replacement;
    bool replacement_prepared;
} wl_columnar_eval_owner_publication_entry_t;

typedef struct wl_columnar_eval_owner_publication_txn {
    wl_columnar_eval_owner_publication_entry_t *entries;
    uint32_t count;
    uint32_t capacity;
    wl_columnar_session_hash_registry_image_t *registry_images;
    uint32_t registry_image_count;
    bool registry_images_prepared;
    bool prepared;
} wl_columnar_eval_owner_publication_txn_t;

void
wl_columnar_eval_owner_publication_init(
    wl_columnar_eval_owner_publication_txn_t *txn);
int
wl_columnar_eval_owner_publication_add(
    wl_columnar_eval_owner_publication_txn_t *txn, wl_col_session_t *session,
    const char *name, col_rel_t *target, col_rel_t *candidate);
int
wl_columnar_eval_owner_publication_prepare(
    wl_columnar_eval_owner_publication_txn_t *txn);
int
wl_columnar_eval_owner_publication_register(
    wl_columnar_eval_owner_publication_txn_t *txn);
/* The caller must provide exclusive, quiescent access to every participating
 * session, target, and candidate from the first add through commit or
 * discard. Successful add transfers candidate ownership to the transaction;
 * prepare may consume candidates for existing targets. Registration prepares
 * private registry/hash images without changing sessions; commit swaps those
 * images and publishes replacements with no fallible work remaining. The TDD
 * owner exchange uses this builder for its multi-session publication. */
int
wl_columnar_eval_owner_publication_commit(
    wl_columnar_eval_owner_publication_txn_t *txn);
/* Discard is idempotent and leaves published sessions unchanged. */
int
wl_columnar_eval_owner_publication_discard(
    wl_columnar_eval_owner_publication_txn_t *txn);
#ifdef WL_TEST_OWNER_PUBLICATION
typedef struct col_eval_tdd_worker_ctx col_eval_tdd_worker_ctx_t;
int
wl_columnar_eval_test_owner_exchange(const wl_plan_stratum_t *sp,
    wl_col_session_t *coord, col_eval_tdd_worker_ctx_t *ctxs, uint32_t workers);
int
wl_columnar_eval_test_owner_build_candidate(col_rel_t *target,
    const char *name, col_rel_t *const *inputs, uint32_t input_count,
    bool preserve_target_rows, col_rel_t **out);
void
wl_columnar_eval_test_owner_publication_fail_registration(
    wl_col_session_t *session, const char *name);
void
wl_columnar_eval_test_owner_publication_fail_prepare(
    wl_col_session_t *session, const char *name);
bool
wl_columnar_eval_test_owner_publication_prepare_failure_hit(void);
bool
wl_columnar_eval_test_owner_publication_prepare_failure_followed_prepared(
    void);
bool
wl_columnar_eval_test_owner_publication_registration_failure_hit(void);
bool
wl_columnar_eval_test_owner_publication_registration_failure_followed_image(
    void);
#endif

/*
 * COL_SESSION: Cast wl_session_t* to wl_col_session_t*
 *
 * Safe because wl_session_t base is the first member of wl_col_session_t
 * (C11 6.7.2.1 P15 guarantees address equality of struct and first member).
 */
#define COL_SESSION(s) ((wl_col_session_t *)(s))

/* ======================================================================== */
/* Evaluation Stack                                                         */
/* ======================================================================== */

/*
 * eval_entry_t: one entry on the operator evaluation stack.
 *
 * @rel:   heap-allocated result relation (owned; freed on pop)
 * @owned: true if this entry owns @rel (must free on pop)
 */
typedef enum {
    WL_COLUMNAR_EVAL_ENTRY_RELATION = 0,
    WL_COLUMNAR_EVAL_ENTRY_CONTINUATION = 1,
} wl_columnar_eval_entry_kind_t;

typedef struct {
    col_rel_t *rel;
    bool owned;
    bool is_delta; /* true when rel is a delta (DR) relation, not the full */
    uint32_t
    *seg_boundaries;     /* Array of K+1 boundary row indices (K-way merge) */
    uint32_t seg_count;  /* Number of segments (0 = no segmentation) */
    wl_columnar_eval_entry_kind_t kind;
    wl_columnar_continuation_t *continuation;
} eval_entry_t;

typedef struct {
    eval_entry_t items[COL_STACK_MAX];
    uint32_t top;
} eval_stack_t;

/* Whole-public-step observer ownership is independent of storage rollback. */
/* Internal opt-in baseline construction, not whole controlled STEP. The host
 * keeps plan, registry and source contents stable and serializes every call,
 * including cross-thread discard. Each advance performs one charged unit;
 * EAGAIN is progress/retry. A stop retains the cursor and original readers.
 * A fresh attempt may resume with its own current ID. Only READY publishes.
 * Discard is one unmetered mandatory cleanup unit, EAGAIN until drained. */
/* Caller-owned immutable bindings remain at stable addresses until build or
 * prepare drains. NULL relation denotes an absent initial head of width. */
typedef struct {
    const char *name;
    col_rel_t *relation;
    uint32_t width;
} wl_columnar_eval_delta_binding_t;
int wl_columnar_eval_delta_observer_build_start_missing_heads(
    wl_col_session_t *, uint64_t, const wl_columnar_eval_delta_binding_t *,
    uint32_t);
int wl_columnar_eval_delta_observer_prepare_start_with_bindings(
    wl_col_session_t *, const wl_columnar_eval_delta_binding_t *, uint32_t);
int wl_columnar_eval_delta_observer_build_start(wl_col_session_t *, uint64_t);
int wl_columnar_eval_delta_observer_build_start_missing_head(
    wl_col_session_t *, uint64_t, const char *);
int wl_columnar_eval_delta_observer_build_advance(wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, bool *ready);
int wl_columnar_eval_delta_observer_build_discard(wl_col_session_t *);
int wl_columnar_eval_delta_observer_prepare_start(wl_col_session_t *);
int wl_columnar_eval_delta_observer_prepare_start_with_override(
    wl_col_session_t *, const char *, col_rel_t *);
int wl_columnar_eval_delta_observer_prepare_advance(wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, bool *ready);
int wl_columnar_eval_delta_observer_prepare_discard(wl_col_session_t *);
int
wl_columnar_eval_delta_observer_begin(wl_col_session_t *sess,
    uint64_t mask);
bool
wl_columnar_eval_delta_observer_active(const wl_col_session_t *sess);
bool
wl_columnar_eval_delta_observer_evaluated(const wl_col_session_t *sess);
uint64_t
wl_columnar_eval_delta_observer_mask(const wl_col_session_t *sess);
void
wl_columnar_eval_delta_observer_set_active(wl_col_session_t *sess,
    bool active);
void
wl_columnar_eval_delta_observer_set_evaluated(wl_col_session_t *sess);
void
wl_columnar_eval_delta_observer_cancel(wl_col_session_t *sess);
int
wl_columnar_eval_delta_observer_prepare(wl_col_session_t *sess);
void
wl_columnar_eval_delta_observer_publish(wl_col_session_t *sess);
size_t
wl_columnar_eval_delta_observer_event_count(const wl_col_session_t *sess);
int
wl_columnar_eval_delta_observer_finish(wl_col_session_t *sess);
int
wl_columnar_eval_delta_observer_discard(wl_col_session_t *sess);

/* Allocate/admit before evaluating. Pending cleanup blocks begin. ENOSPC
 * denotes governor denial, ENOMEM allocation failure, ENOBUFS the frame cap.
 * Session access must be serialized. All col_eval_stratum callers, including
 * workers and recursive delta steps, use this boundary. */
int
wl_columnar_eval_stack_cleanup_begin(wl_col_session_t *sess,
    wl_columnar_eval_stack_cleanup_frame_t **out);
/* Opt-in original-attempt admission, not operator activation. NULL control
 * delegates raw begin. Otherwise require a live matching nonzero ID, empty
 * exclusive out, serialized session and stable governor binding. Storage is
 * disjoint and stays live through the call; peer governor credits may change.
 * Failures preserve lists/counters/out; actual DENIED may set budget_denied.
 * Success transfers ownership to the session, independent of control lifetime.
 * Private frames have no supported ownership escape through test callbacks.
 * Both external-cutoff hooks share one funded region; mandatory physical-freed
 * hook receives NULL control and never polls or debits another attempt. */
int
wl_columnar_eval_stack_cleanup_begin_attempt_controlled(wl_col_session_t *sess,
    wl_columnar_eval_stack_cleanup_frame_t **out,
    wl_evaluation_control_t *control, uint64_t attempt_id);
/* Tracked frames reserve before allocation/activation. Receipt queue access is
 * serialized by the framed host/session owner, not by admission counters. */
int wl_columnar_eval_stack_cleanup_receipt_reserve(wl_col_session_t *,
    uint64_t operation_attempt_id, uint64_t operation_id,
    wl_columnar_eval_cleanup_receipt_key_t *);
int wl_columnar_eval_stack_cleanup_receipt_session_generation_new(uint64_t *);
int wl_columnar_eval_stack_cleanup_begin_receipted_attempt_controlled(
    wl_col_session_t *, wl_columnar_eval_stack_cleanup_frame_t **,
    wl_evaluation_control_t *, uint64_t, uint64_t,
    wl_columnar_eval_cleanup_receipt_key_t *);
int wl_columnar_eval_stack_cleanup_receipt_cancel_begin(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *);
bool wl_columnar_eval_stack_cleanup_receipt_key_protected(
    wl_columnar_eval_stack_cleanup_frame_t *);
int wl_columnar_eval_stack_cleanup_receipt_key_for_frame(
    wl_columnar_eval_stack_cleanup_frame_t *,
    wl_columnar_eval_cleanup_receipt_key_t *);
int wl_columnar_eval_stack_cleanup_receipt_release(wl_col_session_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *);
int wl_columnar_eval_stack_cleanup_receipt_read(wl_col_session_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *,
    wl_columnar_eval_cleanup_receipt_t *);
int wl_columnar_eval_stack_cleanup_receipt_ack(wl_col_session_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *);
typedef struct {
    int protocol;
    int execution_result;
} wl_columnar_eval_cleanup_receipt_ack_result_t;
wl_columnar_eval_cleanup_receipt_ack_result_t
    wl_columnar_eval_stack_cleanup_receipt_ack_funded(wl_col_session_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_stack_cleanup_receipt_retry(wl_col_session_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *);
int wl_columnar_eval_stack_cleanup_receipt_prepare(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *, int, bool);
enum {
    WL_COLUMNAR_EVAL_STACK_ENTRY_PHASE = 1,
    WL_COLUMNAR_EVAL_STACK_RESERVE_PHASE = 2,
    WL_COLUMNAR_EVAL_STACK_ALLOCATION_PHASE = 3,
    WL_COLUMNAR_EVAL_STACK_ZERO_PHASE = 4,
    WL_COLUMNAR_EVAL_STACK_TOKEN_PHASE = 5,
    WL_COLUMNAR_EVAL_STACK_MOVED_PHASE = 6,
    WL_COLUMNAR_EVAL_STACK_COMMITTED_PHASE = 7,
    WL_COLUMNAR_EVAL_STACK_EXTERNAL_PHASE = 8,
    WL_COLUMNAR_EVAL_STACK_PHYSICAL_FREED_PHASE = 9,
    WL_COLUMNAR_EVAL_STACK_UNARY_BEGIN_VALID_PHASE = 10,
    WL_COLUMNAR_EVAL_STACK_UNARY_BEGIN_PREPARED_PHASE = 11,
    WL_COLUMNAR_EVAL_STACK_UNARY_ACTIVE_CUTOFF_PHASE = 12,
    WL_COLUMNAR_EVAL_STACK_UNARY_COMMIT_VALID_PHASE = 13,
    WL_COLUMNAR_EVAL_STACK_UNARY_COLLISION_PHASE = 14,
    WL_COLUMNAR_EVAL_STACK_UNARY_COMMIT_CUTOFF_PHASE = 15,
};
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_stack_test_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint64_t);
extern int wl_columnar_eval_stack_test_fail_allocation;
/* Refuse the next N frame disposals with EBUSY, as a still-borrowed result
 * would.  Plain counter: single-threaded (W=1) tests only. */
extern unsigned wl_columnar_eval_stack_test_fail_cleanup_dispose;
/* Physical layout only, never an observed work total. */
size_t wl_columnar_eval_stack_test_frame_size(void);
size_t wl_columnar_eval_stack_test_allocation_size(void);
void wl_columnar_eval_stack_test_receipt_next_session_generation(uint64_t);
#endif
/* Persistent unary replacement, opt-in only. Begin binds nonNULL control and
 * supplied active ID to an original LIFO frame with a valid relation top.
 * Exclusive frame/session access; no raw stack/result mutation, reentrancy or
 * input destruction until first finish. Native owner thread governs forward
 * access and first finish. The original frame and its allocator stay live.
 * Accessors have no callback/debit; caller funds their complete finite paths.
 * Failure preserves accessor outputs. Input is borrowed; output exposes only
 * an exclusive provisional rel slot, whose borrow expires on commit/finish.
 * Same-frame aliases are detached without destruction on commit refusal AND
 * abort before commit; cross-frame duplicate authority is unsupported.
 * Output is independent private heap storage, with no supported reader escape
 * until publication. Slot/output/control and caller outputs do not overlap.
 * Commit's bool is normalized false even on refusal, true only on publication;
 * later retirement cannot undo the internal committed outcome. */
int wl_columnar_eval_stack_unary_begin_attempt_controlled(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_unary_input(
    wl_columnar_eval_stack_cleanup_frame_t *, const col_rel_t **);
int wl_columnar_eval_stack_unary_output(
    wl_columnar_eval_stack_cleanup_frame_t *, col_rel_t ***);
int wl_columnar_eval_stack_unary_commit_attempt_controlled(
    wl_columnar_eval_stack_cleanup_frame_t *, bool *);
/* Mandatory first finish latches initiating result including0, sanitizes
 * provisional aliases, and retires output on abort or old input on commit.
 * No old-control access; caller first drains all child source/batch authority.
 * Real EBUSY retains the original owning slot. Later serialized finish/reset
 * may run on another host thread after old control destruction. Return the
 * latched first initiating result when nonzero (later arguments never replace
 * the first zero), else persistent alias EINVAL, else latest
 * cleanup result. Repeated DONE does not dispose again; reset requires DONE
 * and inert owning slots. Generic frame finish rejects an active transaction
 * before consuming the handle. No handle survives consumed frame cleanup.
 * All new ordinary cleanup work needs explicit inventory; physical/token/ref
 * retirement is the narrow mandatory boundary, not a blanket scan exemption. */
int wl_columnar_eval_stack_unary_finish(
    wl_columnar_eval_stack_cleanup_frame_t *, int);
int wl_columnar_eval_stack_unary_reset(
    wl_columnar_eval_stack_cleanup_frame_t *);
/* Callback-free original/session/LIFO/IDLE validator. Borrowed stack is
 * written only on success; failed validation changes no authority. Caller
 * serializes frame/session use; IDLE has no stored creator-thread identity. */
int wl_columnar_eval_stack_operator_stack(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    eval_stack_t **);

eval_stack_t *
wl_columnar_eval_stack_cleanup_stack(
    wl_columnar_eval_stack_cleanup_frame_t *frame);
/* Move a popped entry only into an empty result slot; clear it on transfer. */
eval_entry_t *
wl_columnar_eval_stack_cleanup_result(
    wl_columnar_eval_stack_cleanup_frame_t *frame);
/* Valid LIFO finish consumes the handle, including on cleanup refusal.
 * Non-LIFO rejection preserves it. Retained frames pin no allocator by
 * themselves: callers must keep every owner/allocator alive until retry. */
int
wl_columnar_eval_stack_cleanup_finish(
    wl_columnar_eval_stack_cleanup_frame_t **frame);
int wl_columnar_eval_stack_cleanup_finish_receipted(
    wl_columnar_eval_stack_cleanup_frame_t **,
    const wl_columnar_eval_cleanup_receipt_key_t *,
    wl_columnar_eval_cleanup_outcome_t *);
/* Refuses while any active frame remains. A finite continuation-first sweep
 * precedes disposal across all pending frames; no promotion or allocation. */
int
wl_columnar_eval_stack_cleanup_retry(wl_col_session_t *sess);
typedef struct wl_columnar_retained_eval_entry {
    eval_entry_t entry;
    struct wl_columnar_retained_eval_entry *next;
} wl_columnar_retained_eval_entry_t;

/* ======================================================================== */
/* Relation Storage (columnar/relation.c)                                   */
/* ======================================================================== */

int
wl_columnar_relation_rename_checked(col_rel_t *rel, const char *name);
void
col_rel_free_contents(col_rel_t *r);
/* Both receipts are address- and creator-thread-bound. Initialize each with
 * { 0 } before begin; keep it at one stable address through READY/DONE. */
int
wl_columnar_relation_managed_binary_build_begin(
    wl_columnar_relation_managed_binary_build_t *build, uint32_t capacity,
    wl_columnar_memory_governor_ref_t *governor_ref);
int
wl_columnar_relation_managed_binary_build_step(
    wl_columnar_relation_managed_binary_build_t *build,
    wl_evaluation_control_t *control, uint64_t expected_attempt_id);
int
wl_columnar_relation_managed_binary_build_step_budgeted(
    wl_columnar_relation_managed_binary_build_t *build,
    wl_evaluation_control_t *control, uint64_t expected_attempt_id,
    uint64_t *remaining);
int
wl_columnar_relation_managed_binary_build_abandon(
    wl_columnar_relation_managed_binary_build_t *build);
int
wl_columnar_relation_managed_binary_build_adopt_schema(
    wl_columnar_relation_managed_binary_build_t *build,
    const char *const *column_names);
/* Caller must transfer exclusive relation lifetime before begin: stop new
 * raw-pointer operations and drain/join existing ones. Keep the descriptor at
 * a stable address until FREE_DESCRIPTOR runs, never dereference it afterward,
 * and keep the receipt stable through DONE. Do not use another relation
 * pointer or reuse the descriptor after retirement begins. */
int
wl_columnar_relation_managed_retirement_begin(
    wl_columnar_relation_managed_retirement_t *retirement, col_rel_t *relation);
int
wl_columnar_relation_managed_retirement_step(
    wl_columnar_relation_managed_retirement_t *retirement,
    wl_evaluation_control_t *control, uint64_t expected_attempt_id);
/* source must be canonical and globally sorted; candidate may be unsorted.
 * Begin acquires descriptor and storage reader gates for both inputs as one
 * all-or-release round. Advance charges each comparison cell, copy cell,
 * builder action, and phase action against the original attempt and executes
 * at most 64 actions per call. EAGAIN retains progress; terminal stops require
 * abort or cleanup. take_result transfers both outputs exactly once; cleanup
 * retires all remaining private builders and releases input gates under fresh
 * maintenance control, then ACK clears completed receipts. take_result
 * requires distinct output slots whose values are both NULL on entry. */
int
wl_columnar_managed_candidate_merge_begin(
    wl_columnar_managed_candidate_merge_t *attempt, col_rel_t *source,
    const col_rel_t *candidate, wl_evaluation_control_t *control,
    uint64_t expected_attempt_id);
int
wl_columnar_managed_candidate_merge_advance(
    wl_columnar_managed_candidate_merge_t *attempt, uint64_t quantum);
int
wl_columnar_managed_candidate_merge_take_result(
    wl_columnar_managed_candidate_merge_t *attempt,
    col_rel_t **replacement_out, col_rel_t **delta_out);
int
wl_columnar_managed_candidate_merge_abort(
    wl_columnar_managed_candidate_merge_t *attempt);
int
wl_columnar_managed_candidate_merge_cleanup_step(
    wl_columnar_managed_candidate_merge_t *attempt,
    wl_evaluation_control_t *maintenance_control,
    uint64_t maintenance_attempt_id);
int
wl_columnar_managed_candidate_merge_status(
    const wl_columnar_managed_candidate_merge_t *attempt,
    wl_columnar_managed_candidate_phase_t *phase, int *terminal_status);
int
wl_columnar_managed_candidate_merge_ack(
    wl_columnar_managed_candidate_merge_t *attempt);
/* Genuine finite support owns proof/body/footer AND the one-use delayed
* financial ACK suffix. Caller proves full current private parent/target/
* controller allocation lineage and disjointness before every invocation.
* No output is published on an unselected/protocol/refused admission. */
int wl_columnar_managed_candidate_merge_ack_begin_owned(
    wl_columnar_managed_candidate_merge_ack_progress_t *, const void *,
    wl_columnar_managed_candidate_merge_t *, wl_evaluation_control_t *,
    uint64_t, bool *);
int wl_columnar_managed_candidate_merge_ack_step_owned(
    wl_columnar_managed_candidate_merge_ack_progress_t *, const void *,
    wl_columnar_managed_candidate_merge_t *, wl_evaluation_control_t *,
    uint64_t, bool *);
int wl_columnar_managed_candidate_merge_ack_action_ack_owned(
    wl_columnar_managed_candidate_merge_ack_progress_t *, const void *,
    wl_evaluation_control_t *, uint64_t);
bool wl_columnar_managed_candidate_merge_ack_pending(
    const wl_columnar_managed_candidate_merge_ack_progress_t *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_managed_candidate_merge_test_ack_checkpoint)(
    wl_columnar_managed_candidate_merge_ack_progress_t *,
    wl_evaluation_control_t *, uint64_t);
#endif

uint64_t
col_rel_owned_ledger_bytes(const col_rel_t *r);
/* Checked flat-grid size for ncols pointer slots and owned INT64 lanes. */
bool
wl_columnar_relation_payload_grid_bytes(uint32_t ncols,
    uint32_t owned_columns, uint32_t capacity, bool table, uint64_t *out);
/*
 * col_rel_timestamp_ledger_bytes: bytes held by r->timestamps (timestamp_capacity
 * entries of col_delta_timestamp_t), or 0 when timestamps are disabled.
 */
uint64_t
col_rel_timestamp_ledger_bytes(const col_rel_t *r);
/*
 * col_rel_transport_bytes: heap bytes a relation carries when it changes
 * hands whole (TDD delta transport, cache insertion): owned column buffers
 * plus the timestamps array.  Arena-owned columns contribute 0.
 */
uint64_t
col_rel_transport_bytes(const col_rel_t *r);
void
col_rel_ledger_reconcile(col_rel_t *r, uint64_t before_bytes);
void
col_rel_ledger_release(col_rel_t *r);
void
col_rel_destroy(col_rel_t *r);
/* The caller must keep the raw descriptor alive and prevent new operations
 * from starting until this synchronous call returns. Already-admitted source
 * readers are counted by the access gates; a reader of this alias blocks its
 * retirement, but a peer descriptor's reader does not. */
int
col_rel_destroy_checked(col_rel_t *r);
/* Prepare/cancel/commit an allocation-free retirement. Preparation rejects
 * pool, arena, shared-column, and alias-backed relations without mutation.
 * Commit consumes and frees an independent heap relation and cannot fail. */
void
wl_columnar_relation_retirement_init(
    wl_columnar_relation_retirement_token_t *token);
int
wl_columnar_relation_retirement_prepare(col_rel_t *relation,
    wl_columnar_relation_retirement_token_t *token);
/* Owner-evaluator delta slots may use pool or arena backing.  This variant
 * holds the same terminal writers but permits those transient descriptors;
 * commit leaves pool slots as inert tombstones and never frees arena data. */
int
wl_columnar_relation_retirement_prepare_transient(col_rel_t *relation,
    wl_columnar_relation_retirement_token_t *token);
int
wl_columnar_relation_retirement_cancel(
    wl_columnar_relation_retirement_token_t *token);
void
wl_columnar_relation_retirement_commit(
    wl_columnar_relation_retirement_token_t *token);
/* Prepare a private replacement without changing @dst.  The canonical writer
 * remains held in @replacement until commit or discard. */
int
col_rel_prepare_replacement(col_rel_t *dst, const col_rel_t *candidate,
    col_rel_replacement_t *replacement);
/* Prepare a replacement after the caller has already admitted the
 * destination's canonical writer into replacement->writer.  This is used by
 * multi-relation transactions so all writers can be acquired before any
 * candidate is prepared or published. */
int
col_rel_prepare_replacement_locked(col_rel_t *dst,
    const col_rel_t *candidate, col_rel_replacement_t *replacement);
/* Publish a prepared replacement while its canonical writer is held.  The
 * preparation contract makes this path no-fail: it performs no allocation,
 * schema construction, or memory admission, and writer release is diagnostic
 * only because publication has already completed. */
void
col_rel_commit_replacement_locked(col_rel_t *dst,
    col_rel_replacement_t *replacement);
/* Publish identically, moving the still-held writer into a caller-owned
 * zeroed token. The caller releases that token after its larger transaction. */
void
col_rel_commit_replacement_retain_writer_locked(col_rel_t *dst,
    col_rel_replacement_t *replacement,
    wl_columnar_source_access_writer_t *retained_writer);
/* Release a prepared replacement and its writer; safe after any prepare error
 * and idempotent after commit. */
void
col_rel_discard_replacement(col_rel_replacement_t *replacement);
int
col_rel_pool_destroy_aliases_checked(delta_pool_t *pool,
    uint32_t first_slot, uint32_t slot_limit);
int
col_rel_pool_destroy_roots_checked(delta_pool_t *pool,
    uint32_t first_slot, uint32_t slot_limit);
int
col_rel_set_schema(col_rel_t *r, uint32_t ncols, const char *const *col_names);
int
col_rel_set_column_types(col_rel_t *r,
    const wirelog_column_type_t *types, uint32_t ncols);
uint32_t
col_arrangement_find_first_typed(const col_arrangement_t *arr,
    const col_rel_t *rel, const int64_t *key_row);
/* Return only the first row in the typed hash bucket. Unlike find_first,
 * this does not walk collision chains and is suitable for bounded cursors. */
uint32_t
col_arrangement_bucket_head_typed(const col_arrangement_t *arr,
    const col_rel_t *rel, const int64_t *key_row);

/* join.c helpers shared with join_batch.c (Issue #1446) and
 * join_pipeline.c.  Internal only: hidden visibility keeps them out of the
 * library's export map. */
uint32_t
col_join_output_width(const col_rel_t *left, const col_rel_t *right,
    const wl_plan_op_t *op);
int
col_join_set_output_types(col_rel_t *out, const col_rel_t *left,
    const col_rel_t *right, const wl_plan_op_t *op);
/* Writes one joined row at @out_row with col_rel_set_raw and publishes
 * neither nrows nor a view generation; its callers arrange that.  The
 * batch producers publish nrows after every written row (#1909); the keyed
 * fill workers leave a single publication to their coordinator. */
int
col_join_write_pair_at(col_rel_t *out, uint64_t out_row,
    const col_rel_t *left, uint32_t lr, const col_rel_t *right, uint32_t rr,
    const uint32_t *project_indices, uint32_t project_count);
/* Legacy row cap (WIRELOG_JOIN_OUTPUT_LIMIT): account @added_rows newly
 * committed output rows in a shared K-fusion/TDD counter, saturating at
 * UINT64_MAX. Without a shared counter, compare @out's total row count.
 * A disabled cap records the local high-water mark without charging rows.
 * Zero added rows still checks an enabled cap. */
bool
wl_columnar_join_output_limit_reached(wl_col_session_t *sess,
    const col_rel_t *out, uint64_t added_rows);
/* Scalar callers have just committed one row. */
bool
col_join_output_limit_reached(wl_col_session_t *sess, const col_rel_t *out);
/* The right operand a JOIN reads: the named relation, its $d$ or $r$
 * delta when the delta mode, iteration and retraction pass select one
 * (used_right_delta), or nothing at all (force_empty). */
typedef struct {
    col_rel_t *right;
    bool used_right_delta;
    bool force_empty;
} wl_columnar_join_selection_t;
wl_columnar_join_selection_t
wl_columnar_join_select_right(const wl_plan_op_t *op,
    wl_col_session_t *sess, col_rel_t *right, bool left_is_delta);
/* False when a FLOAT key column is paired with a non-FLOAT one.  Reads
 * column_types[lk[k]] and column_types[rk[k]] when a relation has column
 * types, so those keys must be in range for it. */
bool
col_join_key_types_compatible(const col_rel_t *left, const uint32_t *lk,
    const col_rel_t *right, const uint32_t *rk, uint32_t key_count);
/* Issue #2185: a step of a bounded JOIN path that failed with a budget
 * denial -- ENOSPC, or ENOMEM while @rel (which may be NULL) holds a pending
 * denial -- is reported as ENOSPC and recorded on @sess, so
 * wl_columnar_session_budget_denied() still sees it after the path destroys
 * the relation that carried the evidence.  Any other @rc is returned
 * unchanged. */
int
wl_columnar_join_budget_denial(wl_col_session_t *sess, const col_rel_t *rel,
    int rc);
/* The governor a JOIN-family operator charges for its output and scratch:
 * the session's, else @left's, else @right's. */
wl_columnar_memory_governor_ref_t *
wl_columnar_join_output_governor(const wl_col_session_t *sess,
    const col_rel_t *left, const col_rel_t *right);
/* Hash probe set over a right relation's key columns, shared by SEMIJOIN,
 * ANTIJOIN and the join pipeline.  The two operators size the next links
 * differently, and both sizes are part of their admitted footprint. */
typedef enum {
    WL_COLUMNAR_JOIN_PROBE_NEXT_ROWS = 0,      /* max(nrows, 1): SEMIJOIN */
    WL_COLUMNAR_JOIN_PROBE_NEXT_ROWS_PLUS_ONE, /* nrows + 1: ANTIJOIN */
} wl_columnar_join_probe_next_t;
typedef struct {
    const col_rel_t *right;
    const uint32_t *rk;
    uint32_t kc;
    uint32_t nbuckets;
    uint32_t *head;
    uint32_t *next;
    wl_columnar_memory_reservation_t reservation;
    wl_columnar_join_probe_next_t next_mode; /* as built */
    bool admitted;
    bool built;
} wl_columnar_join_probe_set_t;
int
wl_columnar_join_probe_set_bytes(uint32_t nrows,
    wl_columnar_join_probe_next_t next_mode, uint64_t *bytes);
int
wl_columnar_join_probe_set_build(wl_col_session_t *sess,
    wl_columnar_memory_governor_ref_t *governor, const col_rel_t *right,
    const uint32_t *rk, uint32_t kc, wl_columnar_join_probe_next_t next_mode,
    wl_columnar_join_probe_set_t *set);
bool
wl_columnar_join_probe_set_contains(const wl_columnar_join_probe_set_t *set,
    const col_rel_t *left, uint32_t lr, const uint32_t *lk);
/* Frees the arrays and rolls the admission back; a second call does
 * nothing. */
void
wl_columnar_join_probe_set_release(wl_columnar_join_probe_set_t *set);
/* The operator's output relation for @left: SEMIJOIN projects
 * op->project_indices with left output types; ANTIJOIN is like @left with
 * no timestamps.  Errors are the operator's own at that step. */
int
wl_columnar_semijoin_new_output(const wl_plan_op_t *op,
    wl_col_session_t *sess, const col_rel_t *left, const col_rel_t *right,
    col_rel_t **out);
int
wl_columnar_antijoin_new_output(const wl_plan_op_t *op,
    wl_col_session_t *sess, const col_rel_t *left, const col_rel_t *right,
    col_rel_t **out);
/* Probe @left against @right into a new output in *@out.  @set is either
 * unbuilt (zeroed, or left by a failed wl_columnar_join_probe_set_build)
 * or built over @right and @rk in the operator's next-link mode; a built
 * set for another relation, key list or mode is EINVAL.  A built @set is
 * used and left built; otherwise the emit builds one at the operator's
 * hash step and releases it before returning. */
int
wl_columnar_semijoin_emit(const wl_plan_op_t *op, wl_col_session_t *sess,
    const col_rel_t *left, const col_rel_t *right, const uint32_t *lk,
    const uint32_t *rk, wl_columnar_join_probe_set_t *set, col_rel_t **out);
int
wl_columnar_antijoin_emit(const wl_plan_op_t *op, wl_col_session_t *sess,
    const col_rel_t *left, const col_rel_t *right, const uint32_t *lk,
    const uint32_t *rk, wl_columnar_join_probe_set_t *set, col_rel_t **out);
/* Type-aware key equality for a candidate pair; arrangement chains may
 * return collision rows, so every probe verifies the keys. */
static inline bool
col_join_keys_match_rel(const col_rel_t *left, uint32_t lr,
    const uint32_t *lk, const col_rel_t *right, uint32_t rr,
    const uint32_t *rk, uint32_t kc)
{
    for (uint32_t k = 0; k < kc; k++) {
        if (!wl_columnar_value_equal(left, lk[k], left->columns[lk[k]][lr],
            right, rk[k], right->columns[rk[k]][rr]))
            return false;
    }
    return true;
}

/* A hash index a caller owns over an explicit relation (#2201).
 * col_arrangement_owned_bytes gives the bytes a build over @nrows rows
 * allocates (EOVERFLOW for a count the builder refuses), so the caller can
 * admit them first.  col_arrangement_build_owned builds a zeroed @arr with
 * no ledger or governor over all of @rel's rows, keyed by @key_cols (which
 * it borrows, not owns), and checks that the build allocated exactly
 * that; col_arrangement_owned_release frees the tables. */
int
col_arrangement_owned_bytes(uint32_t nrows, uint64_t *bytes);
int
col_arrangement_build_owned(col_arrangement_t *arr, const col_rel_t *rel,
    uint32_t *key_cols, uint32_t key_count);
void
col_arrangement_owned_release(col_arrangement_t *arr);
/* True when the first relation named @name in @session's relation array --
 * the one a pin by name finds -- is @source. */
bool
col_session_has_exact_relation(const wl_col_session_t *session,
    const col_rel_t *source, const char *name);
/* Acquire only a fresh index. Stale pinned entries defer rebuild and reject
 * new leases. Protects index storage, not source mutation or destruction;
 * release every lease before session teardown. Final release invalidates
 * deferred indexes; rebuilding is lazy on the next lookup. */
int
col_session_pin_arrangement(wl_session_t *sess, const char *rel_name,
    const uint32_t *key_cols, uint32_t key_count,
    col_arrangement_pin_t *pin);
/* Acquire the exact source reader and pin an already-built current primary
 * arrangement. This function never builds/rebuilds an arrangement. */
int
col_session_pin_existing_arrangement(wl_session_t *sess,
    const col_rel_t *source, const uint32_t *key_cols, uint32_t key_count,
    col_arrangement_pin_t *pin,
    wl_columnar_source_access_reader_t *source_reader);
void
col_arrangement_pin_release(col_arrangement_pin_t *pin);
/* Bind an already-built primary arrangement to its exact current source.
 * EBUSY means the source is write-locked, replaced, or generation-stale;
 * callers may retry after the conflicting operation finishes. */
int
col_session_acquire_arrangement_probe(wl_session_t *sess,
    col_arrangement_t *arr, const col_rel_t *source,
    col_arrangement_probe_t *probe);
int
col_session_acquire_primary_arrangement_probe(wl_session_t *sess,
    const col_rel_t *source, const uint32_t *key_cols, uint32_t key_count,
    col_arrangement_probe_t *probe);
int
col_arrangement_probe_release(col_arrangement_probe_t *probe);
void
col_arrangement_probe_bundle_init(col_arrangement_probe_bundle_t *bundle);
int
col_arrangement_probe_bundle_acquire_primary(
    col_arrangement_probe_bundle_t *bundle, wl_session_t *sess,
    const col_rel_t *source, const uint32_t *key_cols, uint32_t key_count,
    col_arrangement_probe_t **out_probe);
int
col_arrangement_probe_bundle_acquire(col_arrangement_probe_bundle_t *bundle,
    wl_session_t *sess, col_arrangement_t *arr, const col_rel_t *source,
    col_arrangement_probe_t **out_probe);
int
col_arrangement_probe_bundle_acquire_dependency(
    col_arrangement_probe_bundle_t *bundle, const col_rel_t *relation);
int
col_arrangement_probe_bundle_release(col_arrangement_probe_bundle_t *bundle);
#ifdef WL_COLUMNAR_ARRANGEMENT_PROBE_TEST_HOOKS
void
wl_columnar_arrangement_probe_test_fail_next_acquire(int rc);
void
wl_columnar_arrangement_probe_test_clear(void);
void
wl_columnar_arrangement_test_force_stale(wl_col_session_t *sess,
    const char *rel_name);
#endif
int
col_rel_alloc(col_rel_t **out, const char *name);
int
col_rel_attach_memory_governor(col_rel_t *rel,
    wl_columnar_memory_governor_ref_t *memory_governor);
/* Projected footprint at @capacity rows: columns and enabled timestamps
 * both use that requested width. Batch planners use this for one-row costs
 * and prospective payloads, not live reservation checks. */
bool
col_rel_retained_bytes_for(const col_rel_t *r, uint32_t capacity,
    uint64_t *out);
/* Exact currently owned heap footprint, including physical timestamp width;
 * false for inconsistent timestamp pointer/capacity or size overflow. */
bool
col_rel_retained_live_bytes(const col_rel_t *r, uint64_t *out);
/* Replace a persistent merge grid under the aggregate payload reservation.
 * On admission/allocation failure the relation and old grid are unchanged. */
int col_rel_reserve_merge_grid(col_rel_t *r, uint32_t capacity);
int col_rel_reserve_merge_grid_with_lease(col_rel_t *r, uint32_t capacity,
    wl_columnar_relation_mutation_lease_t *lease);
int col_rel_cow_unshare_with_lease(col_rel_t *r,
    wl_columnar_relation_mutation_lease_t *lease);
WL_MUST_CHECK int
wl_columnar_relation_privatize_shared_view_with_lease(col_rel_t *r,
    wl_columnar_relation_mutation_lease_t *lease);
/* Append many rows to one relation under a held mutation lease instead of
 * one per row (col_rel_append_row acquires and finishes a mutation set for
 * every row).  begin acquires the lease; row appends exactly as
 * col_rel_append_row would, starting a fresh lease only before a row that
 * replaces storage once this lease has already published a transition; end
 * finishes it and is a no-op on an inactive batch.
 *
 * While a batch is active this thread holds the relation's descriptor and
 * source writer gates, and for a shared view also its storage owner's
 * source writer gate: readers of either get EBUSY, and destroying the
 * relation fails, so end the batch before destroying, publishing or
 * returning it.
 * The struct holds address- and thread-bound tokens: keep it in the frame
 * that runs the loop, pass it by pointer, never copy it.  A failed row leaves
 * the relation as that append's own contract says and the batch active; a
 * lease renewal that cannot finish the old lease leaves the batch active,
 * and one that cannot acquire the new lease leaves it inactive.
 *
 * set writes one cell of a row the relation already holds (row < nrows,
 * where col_rel_set accepts row < capacity) under the held lease, with
 * col_rel_set's column and float checks and storage contract: on a shared
 * view it validates first and then copies the view, after which the batch
 * keeps the former owner's source writer gate until its next renewal or
 * its end.  A failed set writes no cell. */
typedef struct {
    wl_columnar_relation_mutation_single_t single;
    col_rel_t *relation;
    /* Relation generation at which the lease was last fully validated, or 0;
     * rows at that generation take a cheaper check (#2072). */
    uint64_t verified_generation;
    bool active;
} col_rel_append_batch_t;

int col_rel_append_batch_begin(col_rel_append_batch_t *batch, col_rel_t *r);
int col_rel_append_batch_row(col_rel_append_batch_t *batch,
    const int64_t *row);
int col_rel_append_batch_set(col_rel_append_batch_t *batch, uint32_t row,
    uint32_t col, int64_t val);
int col_rel_append_batch_end(col_rel_append_batch_t *batch, bool commit);

int col_rel_append_row_with_lease(col_rel_t *r, const int64_t *row,
    wl_columnar_relation_mutation_lease_t *lease);
int col_rel_reserve_rows_with_lease(col_rel_t *r, uint32_t additional,
    wl_columnar_relation_mutation_lease_t *lease);
/* Retire aggregate credit after a payload allocation has been freed. */
void col_rel_retire_payload_credit(col_rel_t *r);
/* Admit and grow @r to at least @new_cap rows as one transaction; with
 * @new_cap <= capacity it admits the buffers the relation already owns.
 * ENOMEM with *@denied set is a governor verdict, clear is an allocation
 * failure (Issue #1446). EOVERFLOW reports size/accounting overflow; EINVAL
 * reports invalid shape/state. Caller owns an unpublished/self-owned
 * relation exclusively or holds its writer; the raw writer never authorizes
 * alias detach through the mutation-set API. This operation resets transient
 * denial evidence. */
int
col_rel_reserve_capacity_admitted(col_rel_t *r, uint32_t new_cap,
    bool *denied);
int
col_rel_enable_timestamps(col_rel_t *rel);
/* Enable timestamp storage while the canonical owner writer is held.
* Nested preparation preserves earlier denial evidence. Admission errors
* retain ENOMEM+pending (budget), EOVERFLOW, or EINVAL provenance. */
int
col_rel_enable_timestamps_locked(col_rel_t *rel);
/* Promote arena-backed relation columns to private heap storage.  Admission
 * and copying are transactional; failure leaves the relation unchanged.
 * Caller owns the private/self-owned relation exclusively; this helper
 * acquires no live mutation authority. ENOMEM+pending denotes budget
 * refusal; ENOMEM alone is allocation failure, EOVERFLOW/EINVAL stay typed. */
int
col_rel_promote_arena_admitted(col_rel_t *rel);

/* ------------------------------------------------------------------------ */
/* Compound-column layout (Issue #532 Task 2).                              */
/*                                                                          */
/* Inline-tier invariants: compounds wider than MAX_ARITY or deeper than    */
/* MAX_DEPTH must be lowered to the SIDE tier. Physical-layout inference    */
/* rejects violations with EINVAL.                                          */
/* ------------------------------------------------------------------------ */

#define WL_COMPOUND_INLINE_MAX_ARITY 4u
#define WL_COMPOUND_INLINE_MAX_DEPTH 1u

/* Logical column descriptor consumed by col_rel_compute_physical_layout.
 * kind  -- NONE for scalar columns, INLINE or SIDE for compound columns.
 * arity -- functor arity when kind != NONE (ignored for NONE).
 * depth -- compound nesting depth; 0 for scalar, 1 for flat compound.
 *          INLINE columns with depth > WL_COMPOUND_INLINE_MAX_DEPTH are
 *          rejected. */
typedef struct {
    wirelog_compound_kind_t kind;
    uint32_t arity;
    uint32_t depth;
} col_rel_logical_col_t;

/* Compute the physical column layout implied by `logical_cols`.
 *
 *   *out_physical_ncols       -- sum of per-column slot widths, where
 *                                NONE/SIDE columns contribute 1 slot each
 *                                and INLINE columns contribute `arity`
 *                                slots each.
 *   out_offset_map[i]         -- physical index at which logical column
 *                                i's first slot begins (prefix sum of
 *                                widths). Caller provides the buffer; it
 *                                must hold >= logical_ncols entries.
 *   *out_inline_physical_offset -- physical index of the first INLINE
 *                                  column, or 0 if none.
 *   *out_compound_count       -- number of INLINE logical columns.
 *
 * Any out_* pointer may be NULL to skip that output. On EINVAL the outputs
 * are left unmodified.
 *
 * Returns 0 on success, EINVAL on bad inputs (NULL logical_cols,
 * logical_ncols == 0, or any INLINE column with arity == 0,
 * arity > WL_COMPOUND_INLINE_MAX_ARITY, or depth > WL_COMPOUND_INLINE_MAX_DEPTH). */
int
col_rel_compute_physical_layout(const col_rel_logical_col_t *logical_cols,
    uint32_t logical_ncols,
    uint32_t *out_physical_ncols,
    uint32_t *out_offset_map,
    uint32_t *out_inline_physical_offset,
    uint32_t *out_compound_count);

/* Populate the relation's compound_kind / compound_count /
 * compound_arity_map / inline_physical_offset fields from `logical_cols`.
 *
 * Relation-level compound_kind is chosen as:
 *   INLINE   if any logical column is INLINE;
 *   SIDE     if all compound columns are SIDE and no INLINE is present;
 *   NONE     if every logical column is scalar.
 *
 * Allocates compound_arity_map via malloc (size logical_ncols entries);
 * ownership transfers to the relation and is released by
 * col_rel_destroy. Any pre-existing compound_arity_map is freed first.
 *
 * This function does NOT resize r->columns -- callers that want the
 * physical schema materialised must pass the physical_ncols returned by
 * col_rel_compute_physical_layout to col_rel_set_schema separately.
 *
 * Returns 0 on success, EINVAL on bad inputs, ENOMEM on allocation
 * failure. On error the relation's compound fields are unchanged. */
int
col_rel_apply_compound_schema(col_rel_t *r,
    const col_rel_logical_col_t *logical_cols,
    uint32_t logical_ncols);

/* ------------------------------------------------------------------------ */
/* Inline-tier storage ops (Issue #532 Task 3).                             */
/*                                                                          */
/* Inline compounds occupy `compound_arity_map[logical_col]` contiguous     */
/* physical slots starting at the prefix-sum of preceding widths. The       */
/* functor identity is schema-level (see col_rel_apply_compound_schema),    */
/* so only the arguments are materialised per row -- no handle slot.        */
/* All three ops are O(logical_col) for offset resolution and preserve      */
/* physical slot contents outside the addressed range.                      */
/* ------------------------------------------------------------------------ */

/* Write `arity` argument values into the inline compound at
 * (row_idx, logical_col). Returns 0 on success; EINVAL when the relation
 * is not INLINE, row_idx is out of range, logical_col is beyond the
 * schema, or `arity` does not match compound_arity_map[logical_col]. */
int
wl_col_rel_store_inline_compound(col_rel_t *rel, uint32_t row_idx,
    uint32_t logical_col, const int64_t *args, uint32_t arity);

/* Copy the inline compound at (row_idx, logical_col) into out_args
 * (must hold at least `arity` int64s). Returns 0 on success; EINVAL on
 * the same precondition violations as store_inline_compound. */
int
wl_col_rel_retrieve_inline_compound(const col_rel_t *rel, uint32_t row_idx,
    uint32_t logical_col, int64_t *out_args, uint32_t arity);

/* Signal retraction of the inline compound at (row_idx, logical_col) with
 * the given non-zero Z-set multiplicity. Physical slots are intentionally
 * left intact: Z-set multiplicity lives in the delta/timestamps layer,
 * and join matching during retraction-seeded semi-naive evaluation still
 * needs to see the original tuple. Returns 0 on success; EINVAL for the
 * usual precondition violations or when multiplicity is zero. */
int
wl_col_rel_retract_inline_compound(col_rel_t *rel, uint32_t row_idx,
    uint32_t logical_col, int64_t multiplicity);

/* ------------------------------------------------------------------------ */
/* Inline-tier FILTER/PROJECT/LFTJ wiring helpers (Issue #534 Task #1).     */
/*                                                                          */
/* Pure, read-only resolvers that bridge the `logical` column identity used */
/* by IR lowering (#531) to the `physical` column offsets used by the       */
/* FILTER/PROJECT/LFTJ hot paths. K-Fusion isolation is preserved: each     */
/* helper touches only the passed relation's own arity map / buffers, so a  */
/* fused worker's per-worker snapshot stays isolated from sibling workers.  */
/*                                                                          */
/* Z-set semantics (Invariant #1): none of these helpers mutate multiplicity*/
/* or timestamps; they are pure resolvers/comparators. Mutation is the      */
/* responsibility of the store/retract ops + delta/timestamp layer.         */
/* ------------------------------------------------------------------------ */

/* Resolve the physical offset and slot width of a logical column in an
 * INLINE-kind relation. On success writes *out_offset and *out_width and
 * returns 0. Returns EINVAL when the relation is not INLINE, the arity
 * map is absent, logical_col is out of range, or the prefix sum becomes
 * inconsistent with the physical schema.
 *
 * K-Fusion C2 (§5): pure/read-only; safe to call from any worker thread on
 * a per-worker-owned relation without synchronization. */
int
wl_col_rel_inline_locate(const col_rel_t *rel, uint32_t logical_col,
    uint32_t *out_offset, uint32_t *out_width);

/* Resolve the physical column index of the i-th argument of an inline
 * compound at logical_col. Returns 0 and writes *out_physical_col on
 * success; EINVAL if arg_idx >= compound width or locate fails. Intended
 * for LFTJ callers that use a single inline argument as the join key. */
int
wl_col_rel_inline_arg_physical_col(const col_rel_t *rel, uint32_t logical_col,
    uint32_t arg_idx, uint32_t *out_physical_col);

/* FILTER helper: return non-zero if the inline compound at (row_idx,
 * logical_col) equals the `expect` tuple element-for-element. Matches
 * iff the locate succeeds, widths agree, and all arity args compare
 * equal. Returns 0 on any mismatch or precondition failure. This is the
 * hot-path equality predicate for authorization-style matches like
 * `p(_, f(1,2), _)`.
 *
 * Multiplicity (Invariant #1): this helper only INSPECTS row content; the
 * caller is responsible for preserving the source row's Z-set multiplicity
 * when copying into the output relation. */
int
wl_col_rel_inline_compound_equals(const col_rel_t *rel, uint32_t row_idx,
    uint32_t logical_col, const int64_t *expect, uint32_t expect_arity);

/* PROJECT helper: copy the `width` physical slots of an inline compound
 * from src[src_row] to dst[dst_row] starting at the logical_col offset.
 * Both relations must be INLINE and the compound's arity must match; on
 * any precondition failure returns EINVAL without mutating dst.
 *
 * Multiplicity (Invariant #1): this helper copies payload only. The
 * caller is responsible for extending dst->nrows (via col_rel_append_row
 * semantics) and preserving the source row's Z-set multiplicity so that
 * consolidation can later collapse duplicates correctly. */
int
wl_col_rel_inline_project_column(col_rel_t *dst, uint32_t dst_row,
    const col_rel_t *src, uint32_t src_row, uint32_t logical_col);

/* Public append acquires exact descriptor and canonical-owner authority.
 * The lease form is used by wider transactions that already hold a mutation
 * set. Both stage overlapping tuples before replacement and preserve the
 * distinction between quota denial, allocator ENOMEM, EOVERFLOW and EINVAL. */
int
col_rel_append_row(col_rel_t *r, const int64_t *row);

/* Controlled private single-row append; NULL control delegates directly to raw.
 * Initialized canonical scalar self-owner only: no destination alias/COW,
 * arena/pool/compound/lazy-owner expansion. Positive width needs allocated
 * positive capacity; timestamps must genuinely occupy aligned capacity.
 * Valid deferred ledger timestamp tracking is supported. Nullary non-TS
 * capacity0 grows to64 without zero-byte allocation or governor growth.
 * Caller keeps relation/control/input storage live, serializes control
 * lifecycle and keeps input values stable during capture. Input may alias
 * protected destination columns/row_scratch. Input must not overlap control
 * or mutate protected descriptors, original stack frames/tokens in callbacks.
 * Saves one original attempt ID before callbacks; stale continuation returns
 * EINVAL without debiting a successor. Every admitted forward region fits the
 * source quantum; allocator runtimes/callbacks/mandatory cleanup are excluded.
 * Always captures input: inline16 or governed heap scratch for width>16.
 * This may require additional credit versus raw disjoint wide input. Scratch
 * credit is committed before malloc, and physical free precedes its release.
 * Authoritative S/P budget denial returns ENOMEM with pending=true; allocator
 * ENOMEM has no new denial. Positive execution errors precede typed status;
 * typed denial precedes negative cancellation. Prior pending is cleared only
 * after successful single acquisition. Stops preserve old rows/storage;
 * unpublished spare cells may change. Ledger CAS is the final publication
 * cutoff; no negative return follows it. Original authority/resource cleanup
 * is mandatory; impossible retirement failure aborts rather than discarding
 * stack-local authority. This private API does not activate operators. */
int wl_columnar_relation_append_row_controlled(col_rel_t *r,
    const int64_t *row, wl_evaluation_control_t *control);
/* Controlled original held batch, zero-initialized before begin. Never copy or
 * move a live wrapper. Keep relation/control alive and serialize lifecycle.
 * The private domain matches controlled single-row append; NULL begin binds
 * raw delegation with its broader domain. Every exit must call end, including
 * failed begin that leaves DRAINING authority. End is mandatory after attempt
 * cancellation/restart; it never polls or debits a successor and preserves the
 * initiating result across a failed cleanup retry. Published earlier rows are
 * retained. Reset only a completely ENDED wrapper to zero for reuse.
 * Every row captures raw input under its old lease before a renewal releases
 * backing. A new width mismatch is ENOTSUP; types belong to the reacquired
 * destination. Wide capture pins its original governor until physical free
 * and S refund. Later ungoverned-to-governed attachment does not retroactively
 * admit old S; new P uses the current destination governor. */
typedef enum {
    WL_COLUMNAR_RELATION_BATCH_EMPTY = 0,
    WL_COLUMNAR_RELATION_BATCH_HELD,
    WL_COLUMNAR_RELATION_BATCH_RENEWING,
    WL_COLUMNAR_RELATION_BATCH_DRAINING,
    WL_COLUMNAR_RELATION_BATCH_ENDED
} wl_columnar_relation_batch_phase_t;

typedef struct wl_columnar_relation_append_batch {
    struct wl_columnar_relation_append_batch *identity;
    col_rel_append_batch_t raw;
    wl_evaluation_control_t *control;
    uint64_t attempt_id;
    wl_columnar_relation_batch_phase_t phase;
    bool raw_mode;
    bool result_saved;
    int saved_result;
} wl_columnar_relation_append_batch_t;

/* Caller-owned generation; a stale ID cannot acquire a writer or debit its successor. */
int wl_columnar_relation_append_batch_begin_attempt_controlled(
    wl_columnar_relation_append_batch_t *batch, col_rel_t *r,
    wl_evaluation_control_t *control, uint64_t attempt_id);
int wl_columnar_relation_append_batch_begin_controlled(
    wl_columnar_relation_append_batch_t *batch, col_rel_t *r,
    wl_evaluation_control_t *control);
int wl_columnar_relation_append_batch_row_controlled(
    wl_columnar_relation_append_batch_t *batch, const int64_t *row);
int wl_columnar_relation_append_batch_set_controlled(
    wl_columnar_relation_append_batch_t *batch, uint32_t row, uint32_t col,
    int64_t value);
int wl_columnar_relation_append_batch_end_controlled(
    wl_columnar_relation_append_batch_t *batch, int result);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_relation_test_batch_renewed)(
    wl_columnar_relation_append_batch_t *batch);
#endif

/* Append a complete input batch under one relation writer.  All row/type
 * validation and governor admission complete before the first row publishes.
 * On ENOMEM, *@denied distinguishes governor refusal from allocator failure. */
int
col_rel_append_rows_atomic(col_rel_t *r, const int64_t *rows,
    uint32_t num_rows, uint32_t num_cols, bool *denied);
int
col_rel_reset_rows_locked(col_rel_t *r,
    wl_columnar_source_access_writer_t *writer);
/* Detach only row storage under descriptor/owner exclusion. The caller must
 * already own a rollback copy. Shared/arena payloads are not individually
 * freed. On success a former alias is self-owned; retire its session lease
 * after this function returns. Failure does not mutate the relation. */
int
wl_columnar_relation_delta_detach(col_rel_t *rel, uint64_t expected_identity);
/* Restore only a matching self-owned empty descriptor. Existing columns are
 * preserved; allocation/admission and reader refusal leave it unchanged. */
int
wl_columnar_relation_delta_restore_flat(col_rel_t *rel,
    uint64_t expected_identity, const int64_t *rows,
    uint32_t nrows, uint32_t ncols);

/* Restore a captured snapshot over a populated self-owned head.  The
 * conservative restore_flat variant intentionally preserves populated heads;
 * rollback uses this form only when evaluation failed before completion. */
int
wl_columnar_relation_delta_restore_flat_overwrite(col_rel_t *rel,
    uint64_t expected_identity, const int64_t *rows,
    uint32_t nrows, uint32_t ncols);
int
col_rel_append_all(col_rel_t *dst, const col_rel_t *src, wl_arena_t *arena);
/* One unit admits a bounded gate check and at most one strong CAS. Reader
 * contention retries are separately charged. A stopped acquired token is
 * released before return; mandatory release retries are not metered.
 * NULL control delegates to raw acquisition. Tokens must start inert. */
int
wl_columnar_relation_reader_acquire_controlled(
    wl_columnar_source_access_gate_t *gate,
    wl_columnar_source_access_reader_t *token,
    wl_evaluation_control_t *control);
int
wl_columnar_relation_writer_acquire_controlled(
    wl_columnar_source_access_gate_t *gate,
    wl_columnar_source_access_writer_t *token,
    wl_evaluation_control_t *control);
/* Metered private scalar append. Forward gate rounds, width/type validation,
* doubling, allocation attempts, scalar and timestamp copies are charged.
* Established positive-width allocated heap grids may grow transactionally.
* Timestamped growth requires both sides tracked and destination timestamp
* capacity equal to its old column capacity. Other growth shapes, aliases,
* COW, arena and compound data remain unsupported. Preallocated nonempty
* appends may install integer-family types and matching flat scalar Arrow
* schema together into an untyped destination; growth installation is unsupported.
* Existing destination schema must be normal descriptor-owned scalar metadata.
* For W columns and N name characters including each NUL (unnamed counts1),
* installation adds6+7W+2N units plus34 for two governed fresh reservations
* and final commit, plus actual extra total-CAS attempts. This includes name
* scans/copies and explicit allocation regions, excluding fixed Arrow/token
* initialization and mandatory publication/destruction. Retained destination
* names are conservatively covered by both old/new metadata policy credit.
* Failed installation preserves canonical metadata and original credit; spare
* cells may be written. Shared ledger totals are never snapshot-restored.
* Governed growth requires positive committed retained credit. Its bounded
* reservation preparation/admission/commit adds75 units plus one per extra
* total-CAS round; interrupted begin restores its own credit, while interrupted
* commit retains credit through staged-buffer disposal before rollback.
* Raw owner resolution, ledger operations, allocation runtime and mandatory
* credit/gate cleanup are excluded; this is not a whole-call work bound.
* A stop leaves logical rows and generations unchanged. Preallocated spare
* cells may be written; failed growth preserves the original physical image.
* Descriptors must remain alive and externally serialized during the call. */
int
wl_columnar_relation_append_all_controlled(col_rel_t *dst,
    const col_rel_t *src, wl_arena_t *arena,
    wl_evaluation_control_t *control);

/* Resumable private INT64 append growth. The zero-initialized attempt and both
 * descriptors remain at stable addresses, alive, and on the creating thread
 * through DONE. The caller keeps the operation control active while forwarding
 * and committing. Once abort or commit enters cleanup, the operation control
 * may be released; cleanup uses its captured process-unique identity only.
 * The caller does not mutate either relation outside its gates. Before
 * publication, stop or abort preserves the destination image. After
 * publication, cleanup_step must continue until DONE so old storage is retired
 * and governed credit is reduced; `published` distinguishes this committed
 * cleanup interval from prepublication failure. EAGAIN means retry the
 * forward attempt or fund one cleanup step, according to the current phase. */
typedef enum wl_columnar_relation_append_growth_phase {
    WL_COLUMNAR_RELATION_APPEND_GROWTH_INERT = 0,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_ACQUIRE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_VALIDATE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_CAPACITY,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_TYPES,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_ADMIT,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_ALLOC_TABLE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_ALLOC_LANES,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_COPY_DESTINATION,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_COPY_SOURCE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_READY,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_COMMIT_PUBLISH,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_RETIRE_OLD,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_RETIRE_OLD_TABLE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_RETIRE_OLD_LEDGER,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_DOWNSIZE_BEGIN,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_DOWNSIZE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_RELEASE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_ABORT_FREE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_ABORT_COMMIT,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_ABORT_REFUND,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_ABORT_RELEASE,
    WL_COLUMNAR_RELATION_APPEND_GROWTH_DONE
} wl_columnar_relation_append_growth_phase_t;

typedef struct wl_columnar_relation_append_growth_attempt {
    struct wl_columnar_relation_append_growth_attempt *identity;
    col_rel_t *destination;
    const col_rel_t *source;
    wl_evaluation_control_t *control; /* Forward/commit only; may then expire. */
    uint64_t active_attempt_id;
    uint64_t control_identity; /* Stable identity, safe after release. */
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid;
    bool published;
    bool growth_active;
    wl_columnar_relation_append_growth_phase_t phase;
    wl_columnar_source_access_gate_set_attempt_t gates;
    wl_columnar_memory_downsize_attempt_t downsize;
    wl_columnar_memory_growth_refund_attempt_t refund;
    wl_columnar_memory_governor_growth_commit_prepared_t commit;
    uint32_t source_first;
    uint32_t source_count;
    uint32_t source_rows;
    uint32_t source_capacity;
    uint32_t destination_rows;
    uint32_t destination_capacity;
    uint32_t ncols;
    uint32_t required_rows;
    uint32_t new_capacity;
    uint64_t destination_relation_identity;
    uint64_t destination_view_generation;
    uint64_t destination_storage_generation;
    uint64_t source_relation_identity;
    uint64_t source_view_generation;
    uint64_t source_storage_generation;
    uint64_t source_owner_generation;
    uint64_t destination_owner_generation;
    uint64_t incoming_bytes;
    uint64_t target_bytes;
    uint64_t destination_ledger_before;
    uint64_t destination_ledger_after;
    uint64_t old_reserved_bytes;
    int64_t **replacement_columns;
    uint32_t allocated_lanes;
    uint32_t lane_cursor;
    uint32_t row_cursor;
    int64_t **retired_columns;
    int result;
    int cleanup_result;
    int terminal_result;
} wl_columnar_relation_append_growth_attempt_t;

/* Internal opt-in transaction for bounded relation growth. It supports only
 * distinct self-owned heap relations with the same positive INT64 column
 * count, no auxiliary/compound payload, and a positive append that exceeds
 * destination capacity. Initialize the receipt to zero and keep it at one
 * address on its creating thread. The original operation control must remain
 * live through forward advance and commit, or until abort has entered cleanup.
 * READY is private staging; only commit publishes. Keep both relations and
 * their storage alive until cleanup reaches DONE. */
int wl_columnar_relation_append_growth_attempt_begin(
    wl_columnar_relation_append_growth_attempt_t *, col_rel_t *,
    const col_rel_t *, uint32_t, uint32_t, wl_evaluation_control_t *);
int wl_columnar_relation_append_growth_attempt_advance(
    wl_columnar_relation_append_growth_attempt_t *);
/* Cleanup requires a distinct live control and its currently active matching
 * attempt ID on each nonterminal call. Each successful call pays for one
 * bounded cleanup action and retains no funding-control state. Funding refusal
 * preserves the pending action. The owner keeps the receipt, descriptors,
 * reservation and storage alive at stable addresses on the creating thread
 * until DONE. `cleanup_result` records cleanup diagnostics; successful DONE
 * returns the latched primary operation result. DONE acknowledgment is
 * receipt-local and needs no funding. */
int wl_columnar_relation_append_growth_attempt_cleanup_step(
    wl_columnar_relation_append_growth_attempt_t *,
    wl_evaluation_control_t *, uint64_t);
/* Advance returns 0 at READY without publishing. Commit crosses the
 * irreversible boundary; afterward call cleanup_step until DONE. */
int wl_columnar_relation_append_growth_attempt_commit(
    wl_columnar_relation_append_growth_attempt_t *);
bool wl_columnar_relation_append_growth_attempt_ready(
    const wl_columnar_relation_append_growth_attempt_t *);
int wl_columnar_relation_append_growth_attempt_abort(
    wl_columnar_relation_append_growth_attempt_t *, int);
bool wl_columnar_relation_append_growth_attempt_published(
    const wl_columnar_relation_append_growth_attempt_t *);
#ifdef WL_SESSION_TEST_HOOKS
extern uint32_t wl_columnar_relation_test_metadata_fail_allocation;
extern bool wl_columnar_relation_test_metadata_fail_commit;
extern uint32_t wl_columnar_relation_test_constructor_fail_allocation;
extern void (*wl_columnar_relation_test_before_identity_cas)(
    wl_evaluation_control_t *, uint64_t);
extern void (*wl_columnar_relation_test_constructor_committed)(
    wl_evaluation_control_t *, unsigned);
extern void (*wl_columnar_relation_test_constructor_retired)(void);
extern void (*wl_columnar_relation_test_new_like_before_release)(
    const col_rel_t *);
extern void (*wl_columnar_relation_test_before_reader_cas)(
    wl_evaluation_control_t *, wl_columnar_source_access_gate_t *, uint64_t);
/* Called on each step of a binary builder with the phase it is in, before
 * that step is funded. */
extern void (*wl_columnar_relation_test_builder_phase)(
    wl_evaluation_control_t *, unsigned);
extern void (*wl_columnar_relation_test_after_reader_cas)(
    wl_evaluation_control_t *, wl_columnar_source_access_gate_t *, bool);
extern void (*wl_columnar_relation_test_before_writer_cas)(
    wl_evaluation_control_t *, wl_columnar_source_access_gate_t *);
extern void (*wl_columnar_relation_test_work_checkpoint)(
    wl_evaluation_control_t *control, uint64_t work);
#endif
/* Exact-capacity reserve for an exclusively owned unpublished relation or a
 * caller-held canonical writer, with descriptor lifetime/metadata serialized.
 * Does not acquire gates, advance a live mutation lease or publish a mutation
 * set: do not use behind a lease whose generations cannot legally be refreshed.
 * NULL control delegates raw before these restrictions. Controlled mode supports
 * initialized self-owned, positive-width allocated scalar heap storage only;
 * independent timestamp capacity >= nrows is supported. Malformed shape/token
 * is EINVAL, unsupported compound/shared/arena/alias/nullary/detached storage
 * ENOTSUP, and borrowers EBUSY. Growing an exhausted generation is EOVERFLOW.
 * Valid but missing/insufficient retained credit is ENOTSUP, even on no-growth;
 * no token repair is attempted. Status outputs are cleared before polling and
 * indicate only actual budget denial, not allocator ENOMEM or cancellation.
 * A supported requested <= capacity call validates W lanes and otherwise leaves
 * storage, timestamp spare fields, generations, credit and ledger unchanged.
 * Growth installs exactly requested capacity, preserving rows/view and live
 * cells/timestamp fields; every spare timestamp field is zero (padding is
 * unspecified). Storage generation advances once. Failure preserves the old
 * image and disposes staging before returning its credit. Success finishes
 * publication/retirement without another cancellation point after commit.
 * For W columns, L live rows, C requested rows and T timestamp presence, work
 * is 2W+W*L+5+T*(1+5C), plus75 for governed growth and1 per extra total-CAS
 * attempt. No-growth costs W. Fixed preflight/helper reads/arithmetic, caller
 * gates, allocator runtime, shared ledger atomics and mandatory cleanup are
 * excluded; this is not a whole-call bound. Scalar spare cells are unspecified.
 */
int
wl_columnar_relation_reserve_capacity_admitted_controlled(col_rel_t *r,
    uint32_t requested, bool *denied, wl_evaluation_control_t *control);

/* Append only while dst is still empty after canonical storage admission.
 * EBUSY means another writer populated it before this operation acquired
 * the destination gate.  The source and destination descriptors must remain
 * alive for the call, as with col_rel_append_all. */
int
wl_columnar_relation_append_all_if_empty(col_rel_t *dst,
    const col_rel_t *src);
int
col_rel_col_idx(const col_rel_t *r, const char *name);
col_rel_t *
col_rel_new_auto(const char *name, uint32_t ncols);
int
wl_columnar_relation_new_auto_governed(const char *name, uint32_t ncols,
    uint32_t initial_capacity, bool timestamps,
    wl_columnar_memory_governor_ref_t *governor, col_rel_t **out);
/* Caller-attempt-bound untyped auto construction without timestamps.
 * The supplied nonzero ID is immutable; name/control/governor remain live
 * and the output slot is exclusive, disjoint, and holds no live owned result.
 * One fixed output-normalization store may occur on inactive/stale/first
 * admission refusal. All recipe/local initialization requires paid work.
 * Governed mode is strict (non-NULL governor) and preserves explicit capacity;
 * plain mode uses the raw default capacity and private heap storage, without
 * a pool/arena or equivalent allocator/peak-threshold promise.
 * NULL control delegates each raw counterpart. Raw plain pointer failure maps
 * to ENOMEM, including NULL name; controlled NULL name reports EINVAL.
 * No types or timestamp buffers are installed; FLOAT lanes remain raw bits.
 * Until actual publication, only the private lexical local owns the output.
 * A stop checked-destroys it or fails stop on impossible destruction refusal;
 * a still-NULL caller/frame slot cannot retain private failed authority.
 * No supported private reader/ownership escape is allowed before publication.
 * This is not pointer secrecy: privileged instrumentation can recover committed
 * owner_bits, but must not read unfinished storage or acquire private readers.
 * After publication the original caller slot owns normal cleanup and may use
 * the persistent unary protocol. No recipe pointer survives this call. */
int
wl_columnar_relation_new_auto_governed_attempt_controlled(
    const char *name, uint32_t ncols, uint32_t initial_capacity,
    wl_columnar_memory_governor_ref_t *governor, col_rel_t **out,
    wl_evaluation_control_t *control, uint64_t attempt_id);
int
wl_columnar_relation_new_auto_attempt_controlled(
    const char *name, uint32_t ncols, col_rel_t **out,
    wl_evaluation_control_t *control, uint64_t attempt_id);
/* Private operator constructor: non-NULL original control only, untyped and
 * without timestamps; explicit initial capacity, private heap ownership. */
int wl_columnar_relation_new_auto_operator_attempt_controlled(
    const char *, uint32_t, uint32_t, wl_columnar_memory_governor_ref_t *,
    col_rel_t **, wl_evaluation_control_t *, uint64_t);
/* Private typed noTS operator construction. types contains exactly ncols
* immutable initialized scalar lanes (NULL allowed only at width0). Keep
* name/types/governor/control live through return; no recipe escapes. The
* exclusive output slot owns no live result on entry. Fixed outNULL bootstrap
* precedes admission; publication follows the final original-ID check. */
int wl_columnar_relation_new_typed_operator_attempt_controlled(
    const char *, uint32_t, const wirelog_column_type_t *,
    wl_columnar_memory_governor_ref_t *, col_rel_t **,
    wl_evaluation_control_t *, uint64_t);
/* Same original-attempt/private ownership contract, explicit capacity. Codes
 * are immutable int64 scalar type enums (including valid INT32=0), checked
 * before native conversion. Borrowed only until synchronous return; output
 * owns independent native types/Arrow metadata. NULL codes allowed at width0.
 * No int64 scratch is aliased through an enum pointer. */
int wl_columnar_relation_new_typed_codes_operator_attempt_controlled(
    const char *, uint32_t, uint32_t, const int64_t *,
    wl_columnar_memory_governor_ref_t *, col_rel_t **,
    wl_evaluation_control_t *, uint64_t);
/* Same private original-attempt contract with explicit timestamp storage.
 * Stamps start zero, including spare rows. Synchronous construction polls
 * and charges the original target throughout; this is not a per-call work
 * quantum. A host imposing a hard turn allowance must use a resumable owner
 * rather than count this nested constructor as one unit of that allowance. */
int wl_columnar_relation_new_typed_codes_stamped_operator_attempt_controlled(
    const char *, uint32_t, uint32_t, const int64_t *, bool,
    wl_columnar_memory_governor_ref_t *, col_rel_t **,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_relation_append_batch_numeric_row_operator_controlled(
    wl_columnar_relation_append_batch_t *, const int64_t *,
    wl_evaluation_control_t *, uint64_t);
/* Authentic unspecialized empty descriptor, distinct from a scalar HELD
 * source. Stable zero or proven-drained record, disjoint from descriptor and
 * borrowed metadata. Actual descriptor and canonical-owner readers precede
 * empty-shape inspection; no declared lane is synthesized and no row gather
 * is authorized. Original descriptor/control/ID/native thread remain fixed.
 * END drains one real reader-release action under distinct actual funding,
 * using captured gate pointers without polling the stopped original target
 * or reading descriptor payload/schema. Descriptor storage stays alive until END completes. Serialize calls;
 * callbacks may request a stop but must not reenter this owner. */
typedef enum {
    WL_COLUMNAR_RELATION_EMPTY_SOURCE_INERT,
    WL_COLUMNAR_RELATION_EMPTY_SOURCE_ACQUIRE,
    WL_COLUMNAR_RELATION_EMPTY_SOURCE_VALIDATE,
    WL_COLUMNAR_RELATION_EMPTY_SOURCE_HELD,
    WL_COLUMNAR_RELATION_EMPTY_SOURCE_DRAINED
} wl_columnar_relation_empty_source_phase_t;
typedef struct wl_columnar_relation_empty_source {
    struct wl_columnar_relation_empty_source *identity;
    const col_rel_t *descriptor;
    wl_evaluation_control_t *control;
    uint64_t attempt_id, control_identity;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid, control_retained, ending;
    wl_columnar_source_access_reader_t reader;
    col_relation_snapshot_t snapshot;
    uint32_t declared_ncols, graph_col_idx;
    bool has_graph_column;
    wl_columnar_relation_empty_source_phase_t phase;
    int result;
} wl_columnar_relation_empty_source_t;
int wl_columnar_relation_empty_source_begin(
    wl_columnar_relation_empty_source_t *, const col_rel_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_relation_empty_source_step(
    wl_columnar_relation_empty_source_t *, bool *);
int wl_columnar_relation_empty_source_end(
    wl_columnar_relation_empty_source_t *, wl_evaluation_control_t *, uint64_t,
    bool *);
/* Begin, then step to HELD on the original attempt. *initialized is set from
 * the record right after begin, also when begin fails, so the caller can end
 * a record that needs it. Returns the first nonzero result of begin or step;
 * otherwise EINVAL unless the record is HELD, not ending, and bound to
 * control/id. Charges are those of begin and step. */
int wl_columnar_relation_empty_source_hold_attempt_controlled(
    wl_columnar_relation_empty_source_t *, const col_rel_t *,
    wl_evaluation_control_t *, uint64_t, bool *initialized);
/* Private forced-empty clone from real HELD original metadata, live through
 * return. Output slot is exclusive/disjoint and initially NULL. Fresh owned
 * initialized physical width0; declared metadata supplies no lanes. Future
 * graph declarations reject with raw new-like EINVAL. Construction polls the
 * original attempt; retained source END uses separate actual funding. */
int wl_columnar_relation_empty_source_new_like_operator_attempt_controlled(
    wl_columnar_relation_empty_source_t *, const char *,
    wl_columnar_memory_governor_ref_t *, col_rel_t **);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_relation_test_empty_source_checkpoint)(
    const wl_columnar_relation_empty_source_t *);
#endif

/* Original protected scalar source, opt-in nonNULL-control only. Never copy
 * or move an initialized live record; serialize all access and do not invoke
 * begin/end/init reentrantly from child callbacks. Caller keeps descriptor,
 * canonical owner, metadata and pool/arena lifetimes through end: readers
 * prevent mutation but do not pin those allocations. Forward calls require
 * the original native thread and live original control/immutable attempt ID.
 * End drains actual original reader tokens independent of outer phase and
 * does not access control. DRAINED repeat returns the first result, including
 * zero, without accessing old control or source. Wrong live thread/copy is
 * rejected without changing original authority; release corruption aborts. */
typedef enum {
    WL_COLUMNAR_RELATION_SCALAR_SOURCE_INERT,
    WL_COLUMNAR_RELATION_SCALAR_SOURCE_DESCRIPTOR,
    WL_COLUMNAR_RELATION_SCALAR_SOURCE_HELD,
    WL_COLUMNAR_RELATION_SCALAR_SOURCE_ENDING,
    WL_COLUMNAR_RELATION_SCALAR_SOURCE_DRAINED
} wl_columnar_relation_scalar_source_phase_t;

typedef struct wl_columnar_relation_scalar_source {
    struct wl_columnar_relation_scalar_source *identity;
    wl_evaluation_control_t *control;
    uint64_t attempt_id, control_identity, end_attempt_id;
    unsigned end_cursor;
    wl_columnar_relation_scalar_source_phase_t phase;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid;
    wl_columnar_source_access_reader_t descriptor_reader;
    wl_columnar_source_access_reader_t owner_reader;
    const col_rel_t *descriptor;
    col_rel_t *owner;
    const int64_t *const *columns;
    const col_delta_timestamp_t *timestamps;
    const char *const *names;
    const wirelog_column_type_t *types;
    uint32_t width, nrows, capacity, timestamp_capacity;
    uint64_t descriptor_identity, descriptor_view_generation;
    uint64_t descriptor_storage_generation, owner_identity;
    uint64_t owner_storage_generation;
    bool has_graph_column;
    uint32_t graph_col_idx, declared_ncols;
    bool preserve_timestamps;
    bool first_result_saved;
    int first_result;
} wl_columnar_relation_scalar_source_t;

/* Init requires new or proven DRAINED original storage and a disjoint live
 * flag. Only *initialized=false is permitted before admission. Never inspect
 * or end a refused uninitialized record. Once initialized is true, even an
 * interrupted init has complete cleanup-safe inert fields and can be ended.
 * INIT admission prepays the ordinary bookkeeping of one first live End;
 * End adds no control debit and does not inspect a freed/stopped control. */
int wl_columnar_relation_scalar_source_init_attempt_controlled(
    wl_columnar_relation_scalar_source_t *source, bool *initialized,
    wl_evaluation_control_t *control, uint64_t attempt_id);
int wl_columnar_relation_scalar_source_begin_attempt_controlled(
    wl_columnar_relation_scalar_source_t *source, const col_rel_t *relation,
    bool preserve_timestamps);
/* Begin with opt-in representation admission. admit 0 is exactly the begin
 * above. WL_COLUMNAR_RELATION_SOURCE_ADMIT_INLINE also admits a descriptor
 * of compound_kind INLINE after a metered arity-map check (EINVAL when
 * malformed); its physical lanes are then read as ordinary scalar columns
 * with their lane types. compound_kind SIDE stays ENOTSUP. */
#define WL_COLUMNAR_RELATION_SOURCE_ADMIT_INLINE 1u
int wl_columnar_relation_scalar_source_admit_attempt_controlled(
    wl_columnar_relation_scalar_source_t *source, const col_rel_t *relation,
    bool preserve_timestamps, uint32_t admit);
/* Retained failures keep actual acquired claims and enter ENDING. Only the
 * genuine initialized source may then be driven through finite funded END. */
int wl_columnar_relation_scalar_source_begin_retained_attempt_controlled(
    wl_columnar_relation_scalar_source_t *, const col_rel_t *, bool);
/* The same opt-in representation check, retaining acquired readers on error. */
int wl_columnar_relation_scalar_source_admit_retained_attempt_controlled(
    wl_columnar_relation_scalar_source_t *, const col_rel_t *, bool, uint32_t);
int wl_columnar_relation_scalar_source_validate_attempt_controlled(
    const wl_columnar_relation_scalar_source_t *, wl_evaluation_control_t *,
    uint64_t);
/* Disjoint exclusive scalar outputs publish only after a successful tail. */
int wl_columnar_relation_scalar_source_shape_attempt_controlled(
    wl_columnar_relation_scalar_source_t *source, uint32_t *width,
    uint32_t *nrows, bool *timestamped);
/* Exact snapshot width, bounded row and nonNULL exclusive nonoverlapping
 * values even for nullary input. Stop may leave a private gathered prefix;
 * it must not be published. Reads descriptor columns, never source scratch. */
int wl_columnar_relation_scalar_source_gather_attempt_controlled(
    wl_columnar_relation_scalar_source_t *source, uint32_t row,
    int64_t *values, uint32_t width);
/* Exclusive empty out; single outNULL bootstrap. Already-held readers protect
 * recipe pointers; no reacquisition. Failed private local is checked-destroyed
 * or fail-stopped, not retained by a stillNULL external/frame slot. */
int wl_columnar_relation_scalar_source_new_like_attempt_controlled(
    wl_columnar_relation_scalar_source_t *source, const char *name,
    wl_columnar_memory_governor_ref_t *governor, col_rel_t **out);
/* Operator-only pinned constructor uses eight-byte byte admissions. Original
 * source/control storage lifetimes and publication contracts are unchanged;
 * legacy constructor keeps its own sixteen-byte budget/event protocol. */
int wl_columnar_relation_scalar_source_new_like_operator_attempt_controlled(
    wl_columnar_relation_scalar_source_t *source, const char *name,
    wl_columnar_memory_governor_ref_t *governor, col_rel_t **out);
/* Both original held sources stay protected through synchronous construction.
 * selected_types is NULL or original immutable native lanes from held left or
 * right of identical width. Names/graph/declared width always come from left. */
int
wl_columnar_relation_scalar_source_new_like_typed_operator_attempt_controlled(
    wl_columnar_relation_scalar_source_t *, const char *,
    wl_columnar_memory_governor_ref_t *, const wirelog_column_type_t *,
    col_rel_t **);
/* Empty JOIN/probe schema preparation only: no rows or probe index. Sources
* and immutable operator/name metadata remain held at original addresses
* through forward completion. ANTI requires a no-TS held source and clones
* its names/graph/declared width; JOIN/SEMI use generated projected names.
* The exclusive output slot is disjoint from the owner/source records and
* all borrowed metadata. It owns any constructed result, including a stop
* after construction. END never destroys that result or dereferences sources;
* the caller ends source leases before retiring an old template. Stable zero
* or proven-drained record only; no token/reader may move with a live record.
* Constructors are internally metered synchronous regions, not a total-call
* max_work promise. END uses distinct actual funding after original stop. */
typedef enum {
    WL_COLUMNAR_JOIN_SCHEMA_ALLOCATE,
    WL_COLUMNAR_JOIN_SCHEMA_COLUMNS,
    WL_COLUMNAR_JOIN_SCHEMA_CONSTRUCT,
    WL_COLUMNAR_JOIN_SCHEMA_READY
} wl_columnar_join_schema_phase_t;
typedef struct wl_columnar_join_schema_attempt {
    struct wl_columnar_join_schema_attempt *identity;
    const wl_plan_op_t *op;
    wl_columnar_relation_scalar_source_t *left, *right;
    const char *name;
    col_rel_t **output_slot;
    wl_evaluation_control_t *control;
    uint64_t attempt_id, control_identity;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid, control_retained;
    wl_columnar_memory_governor_ref_t *governor;
    wl_columnar_memory_reservation_t codes_credit;
    int64_t *codes;
    uint64_t bytes;
    uint32_t width, column;
    wl_columnar_join_schema_phase_t phase;
    bool codes_admitted, codes_committed, governor_retained;
    bool ready, ending, drained, output_transferred;
    int result;
} wl_columnar_join_schema_attempt_t;
int wl_columnar_join_schema_attempt_begin(wl_columnar_join_schema_attempt_t *,
    const wl_plan_op_t *, wl_columnar_relation_scalar_source_t *,
    wl_columnar_relation_scalar_source_t *, const char *,
    wl_columnar_memory_governor_ref_t *, col_rel_t **,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_join_schema_attempt_step(wl_columnar_join_schema_attempt_t *,
    uint32_t max_work, bool *);
int wl_columnar_join_schema_attempt_end(wl_columnar_join_schema_attempt_t *,
    wl_evaluation_control_t *, uint64_t, bool *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_join_test_schema_checkpoint)(
    const wl_columnar_join_schema_attempt_t *);
#endif
/* Original controlled HELD batch, same original control/ID, private self-owned
 * destination distinct from descriptor/owner, matching width, stable values.
 * Preserve selected TS fields and signed multiplicity exactly; noTS performs
 * no source/destination timestamp element accesses in this wrapper. A later failure can leave an
 * appended private row: drain batch and source and discard the whole output.
 * Save local control/ID before child; first successful return action guards
 * those locals before any record/lease/row/TS read. Reload current pointers
 * after renewal. Caller must inspect actual ENDED authority on batch drain. */
int wl_columnar_relation_append_batch_selected_source_row_controlled(
    wl_columnar_relation_append_batch_t *batch,
    wl_columnar_relation_scalar_source_t *source, uint32_t source_row,
    const int64_t *values, uint32_t width);
/* Operator-specific selection adds two separately admitted pure-validation
 * cutpoints before destination reads and hooks. Original control storage is
 * caller-pinned and lifecycle serialized. Legacy selected API is unchanged. */
int wl_columnar_relation_append_batch_selected_source_row_operator_controlled(
    wl_columnar_relation_append_batch_t *batch,
    wl_columnar_relation_scalar_source_t *source, uint32_t source_row,
    const int64_t *values, uint32_t width);
/* Stamp derived sorted caches on an already sorted-and-unique private scalar
 * output. The caller completes dedup and any timestamp transport first.
 * Requires original native-thread HELD fixed-one writer, current control/ID,
 * and exclusively serialized output lifetime. No later append is permitted.
 * Does not scan/verify ordering or uniqueness, or change rows/generations.
 * Caller separately funds its <=64-slot continuation to the next real poll
 * or host return. Metadata survives
 * the ordinary batch drain. NULL control is invalid. Caller pins control. */
int wl_columnar_relation_append_batch_mark_sorted_operator_controlled(
    wl_columnar_relation_append_batch_t *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_relation_scalar_source_end(
    wl_columnar_relation_scalar_source_t *source, int initiating_result);
/* One finite reader/metadata action. Protocol is separate from first_result;
 * ENDING blocks forward access. Progress survives a stopped financier footer.
 * The caller owns source storage until done and keeps its cleanup grants live. */
int wl_columnar_relation_scalar_source_end_step(
    wl_columnar_relation_scalar_source_t *, int,
    wl_evaluation_control_t *, uint64_t, bool *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_relation_test_scalar_end_checkpoint)(
    const wl_columnar_relation_scalar_source_t *, wl_evaluation_control_t *,
    uint64_t, unsigned);
#endif

/* Fresh private scalar construction. Same strict non-NULL name/governor/out
* domain as raw; NULL control delegates raw. The name remains immutable for
* this call. Logical work counts byte scans/copies/zeroing, generated digits,
* table slots, allocation attempts, fixed header/token initialization, real
* identity CAS rounds and controlled governor primitives. Fixed entry/size
* arithmetic and mandatory retirement are excluded, as are allocator internals.
* Three original local credit tokens survive all unpublished failure paths;
* physical retirement precedes own-credit refunds. A final prepaid cutoff
* installs canonical tokens and output without subsequent callbacks. Identity
* gaps after cancellation are intentional; identities are never refunded. */
int
wl_columnar_relation_new_auto_governed_controlled(const char *name,
    uint32_t ncols, uint32_t initial_capacity, bool timestamps,
    wl_columnar_memory_governor_ref_t *governor, col_rel_t **out,
    wl_evaluation_control_t *control);
/* Allocate a heap descriptor and optional name under a known governor. */
int
wl_columnar_relation_alloc_governed(col_rel_t **out, const char *name,
    wl_columnar_memory_governor_ref_t *governor);
/* Admit metadata moved from an ungoverned pool descriptor to a heap owner. */
int
wl_columnar_relation_admit_existing_metadata(col_rel_t *dst,
    const col_rel_t *src);
int wl_columnar_relation_admit_existing_payload(col_rel_t *r);
bool
wl_columnar_relation_compound_map_valid(const col_rel_t *r);
col_rel_t *
col_rel_new_like(const char *name, const col_rel_t *src);
/* Checked construction admits the heap descriptor/name first, then each
 * schema, type, map, and retained image before allocation. Pointer wrappers
 * preserve their historical NULL-on-error behavior. */
col_rel_t *
wl_columnar_relation_new_like_governed(const char *name, const col_rel_t *src,
    wl_columnar_memory_governor_ref_t *governor);
int
wl_columnar_relation_new_like_governed_checked(col_rel_t **out,
    const char *name, const col_rel_t *src,
    wl_columnar_memory_governor_ref_t *governor);
int
wl_columnar_relation_new_like_governed_checked_mode(const char *name,
    const col_rel_t *src, wl_columnar_memory_governor_ref_t *governor,
    bool preserve_timestamps, col_rel_t **out);
/* Empty private scalar schema clone, with optional output governor (never
 * inherited from src). NULL control delegates its exact raw counterpart.
 * Initialized scalar owners, shared-view aliases and pool/arena metadata
 * sources are admitted; compound metadata and lazy owners are unsupported.
 * Caller keeps descriptors, metadata and name live/immutable through the call
 * and does not reset a source pool. Original descriptor/owner reader tokens
 * pin source reads, including all three measured name passes, then drain
 * before the final output store. Unexpected mandatory release failure aborts.
 * Source admission adds55 uncontended units, recipe selection3W, explicit
 * names3N scans+2N copies (generated names retain constructor digit work),
 * type allocation/copyW and format-selectionW when typed, recipe install18,
 * and final external store1. No length cache; no credit is inherited/restored.
 * Fixed entry bookkeeping, allocator internals and mandatory cleanup excluded.
 * FLOAT selects Arrow g; other enum metadata retains the raw l representation.
 * Names/types/graph/declared width and optional timestamp presence are copied;
 * rows are empty, capacity is the raw default, timestamp values are zero. */
int
wl_columnar_relation_new_like_governed_checked_mode_controlled(const char *name,
    const col_rel_t *src, wl_columnar_memory_governor_ref_t *governor,
    bool preserve_timestamps, col_rel_t **out,
    wl_evaluation_control_t *control);

/* Caller-attempt-bound empty scalar schema clone. NULL control delegates the
 * exact raw mode API and ignores attempt_id. A controlled caller supplies its
 * active nonzero ID and keeps source/canonical storage alive and immutable
 * under admitted readers, including an external no-reset arena/pool lifetime.
 * The exclusive writable, nonoverlapping out slot must own no live result.
 * One fixed bootstrap exception clears *out before ID/first-charge checks;
 * stale/inactive/first refusal may therefore write NULL with consumed0.
 * All other forward resource work is admitted; cleanup drains original tokens.
 * Source names/types/graph and optional zero timestamps are owned by the clone.
 * Output uses the explicit governor, without inheriting the source governor.
 */
int
wl_columnar_relation_new_like_governed_checked_mode_attempt_controlled(
    const char *name, const col_rel_t *src,
    wl_columnar_memory_governor_ref_t *governor, bool preserve_timestamps,
    col_rel_t **out, wl_evaluation_control_t *control, uint64_t attempt_id);
int
wl_columnar_relation_new_like_governed_checked_controlled(col_rel_t **out,
    const char *name, const col_rel_t *src,
    wl_columnar_memory_governor_ref_t *governor,
    wl_evaluation_control_t *control);
/* Rows [@begin, @end) of @src as a new private relation named @name with
 * @src's schema and without delta timestamps, appended under one batch
 * lease per storage epoch (#2072).  Requires @begin <= @end <= @src->nrows.
 * On failure *@out is left unchanged and no copy remains. */
WL_MUST_CHECK int
wl_columnar_relation_copy_rows(const char *name, const col_rel_t *src,
    uint32_t begin, uint32_t end, wl_columnar_memory_governor_ref_t *governor,
    col_rel_t **out);
/* Controlled scalar physical-row projection with one captured caller attempt.
 * NULL control delegates raw before output normalization. Controlled mode
 * clears the exclusive, writable, nonoverlapping output slot before the first
 * admission; it must contain no live owned result. This single fixed bootstrap
 * store is retrospective. Source/owner lifetime and pool/arena no-reset are
 * caller obligations; original readers protect metadata and row lanes.
 * Order/duplicates are preserved; timestamps and signed multiplicities are
 * deliberately omitted, matching raw physical-row projection. Source scratch
 * is untouched. Wide rows use a reusable gather S plus independent batch
 * capture S, so their peak budget can exceed raw copy. Constructor denial is
 * ENOSPC; gather/row denial is ENOMEM. Every failed controlled call leaves
 * output NULL and retires its private destination and original authority. */
WL_MUST_CHECK int
wl_columnar_relation_copy_rows_controlled(const char *name,
    const col_rel_t *src,
    uint32_t begin, uint32_t end, wl_columnar_memory_governor_ref_t *governor,
    col_rel_t **out, wl_evaluation_control_t *control);
#ifdef WL_TEST_BDX_SEED
int
wl_columnar_eval_test_bdx_seed(col_rel_t *cidb,
    col_rel_t *const *worker_idbs, uint32_t worker_count);
void
wl_columnar_eval_test_bdx_seed_fail_worker(uint32_t worker_index);
void
wl_columnar_eval_test_bdx_seed_fail_sort_once(void);
#endif
#ifdef WL_TEST_TDD_MERGE
int
wl_columnar_eval_test_tdd_merge(col_rel_t **target,
    col_rel_t *const *worker_rels, uint32_t worker_count);
int
wl_columnar_eval_test_tdd_merge_with_coord(wl_col_session_t *coord,
    col_rel_t **target, col_rel_t *const *worker_rels, uint32_t worker_count);
void
wl_columnar_eval_test_tdd_merge_fail_worker(uint32_t worker_index);
void
wl_columnar_eval_test_tdd_merge_fail_sort_once(void);
void
wl_columnar_eval_test_tdd_merge_fail_overflow_once(void);
#endif
#ifdef WL_TEST_TDD_RESET_RESTORE
int
wl_columnar_eval_test_tdd_reset(col_rel_t *relation);
int
wl_columnar_eval_test_tdd_save(const wl_plan_stratum_t *sp,
    wl_col_session_t *coord, col_rel_t ***out_saved);
int
wl_columnar_eval_test_tdd_restore(const wl_plan_stratum_t *sp,
    wl_col_session_t *coord, col_rel_t **saved);
void
wl_columnar_eval_test_tdd_free_saved(const wl_plan_stratum_t *sp,
    col_rel_t **saved);
#endif
col_rel_t *
col_rel_pool_new_like(delta_pool_t *pool, const char *name,
    const col_rel_t *like);

/* A pool slot admits its own heap name separately from metadata. Setup
 * failures restore the slot; only absent, exhausted, or missed slots fall
 * back to governed heap construction. Pool clones do not enable timestamps. */
col_rel_t *wl_columnar_relation_pool_new_like_governed(delta_pool_t *pool,
    const char *name, const col_rel_t *like,
    wl_columnar_memory_governor_ref_t *governor);
int wl_columnar_relation_pool_new_like_governed_checked(col_rel_t **out,
    delta_pool_t *pool, const char *name, const col_rel_t *like,
    wl_columnar_memory_governor_ref_t *governor);

/*
 * col_rel_deep_copy (Issue #553):
 * Produce a fully independent deep copy of `src`.  Unlike col_rel_new_like
 * (which clones schema only), col_rel_deep_copy clones every owned buffer
 * and metadata field of the source relation so that subsequent mutations
 * on either relation are completely isolated.
 *
 * On success, *out is set to a heap-allocated col_rel_t whose fields are
 * deep copies or fresh zero state per the field-group taxonomy in #553.
 * Pool/arena ownership is reset (always heap-owned), memory_governor and
 * retained_reserved_bytes are reset, col_shared/dedup_* caches are cleared,
 * and the schema is rebuilt via manual reinit (the
 * Arrow release callback cannot be aliased across copies).
 *
 * Returns 0 on success, EINVAL when src or out is NULL, ENOMEM on
 * allocation failure.  On failure *out is set to NULL.
 *
 * The `arena` parameter is currently reserved (always heap-allocated);
 * it is accepted to mirror the FROZEN signature in the issue body so that
 * future arena-aware optimizations are ABI-compatible.
 */
int
col_rel_deep_copy(const col_rel_t *src, col_rel_t **out, wl_arena_t *arena);
/* Create an independent logical relation copy whose column and timestamp
* buffers are admitted to @governor (or src->memory_governor when NULL).
* Execution scratch and rollback backups are intentionally not copied. */
int
wl_columnar_relation_deep_copy_governed(const col_rel_t *src, col_rel_t **out,
    wl_columnar_memory_governor_ref_t *governor);
col_rel_t *
col_rel_pool_new_auto(delta_pool_t *pool, wl_arena_t *arena,
    const char *name, uint32_t ncols);
int
col_rel_compact(col_rel_t *r);
int
col_rel_compact_many(col_rel_t *const *rels, uint32_t nrels);
int
col_rel_install_shared_view(col_rel_t *dst, const col_rel_t *src);
/* Externally serialized session publication may temporarily upgrade its own
 * transferable destination-owner lease.  Additional readers still deny it;
 * the lease is restored on both success and failure before returning. */
int
wl_columnar_relation_install_shared_view_with_lease(col_rel_t *dst,
    const col_rel_t *src,
    wl_columnar_source_access_reader_t *destination_lease);

/* Source-storage ownership helpers (Issue #1493).  These are internal
 * bookkeeping operations; caller exclusion and public teardown remain the
 * responsibility of the follow-up lifecycle units. */
int col_rel_storage_owner_resolve(const col_rel_t *src,
    col_rel_t **out_owner);
int col_rel_storage_owner_ensure_initialized(col_rel_t *rel);
int col_rel_storage_alias_release(col_rel_t *alias);
uint64_t col_rel_storage_alias_borrow_count(const col_rel_t *owner);
int col_rel_storage_alias_borrow_acquire(col_rel_t *owner);
int col_rel_storage_alias_borrow_release(col_rel_t *owner);
/* Read-only snapshot check while the caller owns the exchanged cohort and
 * keeps its arrays and relation descriptors stable through restoration.
 * Borrowers correspond to reader_refs by index; every live alias must occur. */
int col_rel_replacement_cohort_validate(
    const col_rel_t *destination,
    const wl_columnar_source_access_cohort_t *cohort,
    col_rel_t *const *borrower_refs, size_t borrower_count);
int col_rel_storage_owner_destroy_status(const col_rel_t *owner);
int col_rel_source_reader_acquire(const col_rel_t *,
    wl_columnar_source_access_reader_t *);
int col_rel_source_reader_acquire_step(const col_rel_t *,
    wl_columnar_source_access_reader_t *, bool *);
int col_rel_source_reader_acquire_transferable(const col_rel_t *,
    wl_columnar_source_access_reader_t *);
/* One transferable reader transition per call. Original token storage and
 * canonical relation remain live and externally serialized until both gates
 * are released. EAGAIN means retry, including a successful descriptor-only
 * acquisition. A stopped call retains every acquired gate. NULL control is
 * permitted only for mandatory, externally serialized release. */
typedef struct {
    uintptr_t identity;
    const col_rel_t *relation;
    bool descriptor_held;
    wl_columnar_source_access_reader_t token;
} wl_columnar_relation_reader_step_t;
int wl_columnar_relation_reader_step(const col_rel_t *relation,
    wl_columnar_relation_reader_step_t *record, bool release,
    wl_evaluation_control_t *control, uint64_t attempt_id);
/* Read-only shape proof shared with finite CLOSE validation. The caller
 * supplies real relation lifetime and Native permission; no gate action. */
int wl_columnar_relation_reader_step_validate(const col_rel_t *,
    const wl_columnar_relation_reader_step_t *);
int col_rel_source_reader_release(wl_columnar_source_access_reader_t *);
int col_rel_source_writer_acquire(const col_rel_t *,
    wl_columnar_source_access_writer_t *);
/* Checked single-cell mutation.  The implementation lives in relation.c so
 * it holds descriptor and canonical-owner writers across COW/publication. */
int col_rel_set(col_rel_t *, uint32_t row, uint32_t col, int64_t val);

/* Test seam for the non-wrapping relation identity allocator. */
int
col_rel_test_set_next_identity(uint64_t next);
/* Sorts all rows.  Returns 0, or the status col_rel_radix_sort() refused
 * with -- EBUSY when the relation is a canonical owner with live alias
 * borrows or the source gate is contended, ENOMEM on allocation failure.
 * sorted_nrows is advanced only on success, so a caller that depends on the
 * ordering must check the result rather than assume it. */
WL_MUST_CHECK int
col_rel_radix_sort_int64(col_rel_t *r);

typedef struct {
    uint32_t *perm_a;
    uint32_t *perm_b;
    void *bucket_values;
    uint8_t *byte_values;
    uint16_t *short_values;
    uint32_t *count16;
    int64_t *temp_column;
    int64_t *insertion_rows;
    col_delta_timestamp_t *timestamps;
    uint32_t timestamp_capacity;
    uint32_t k8_capacity;
    uint32_t k16_capacity;
    uint32_t insertion_capacity;
    size_t insertion_bytes; /* Actual capacity, including the saved row. */
    const col_rel_t *prepared_relation;
    uint64_t prepared_identity;
    uint64_t prepared_view_generation;
    uint64_t prepared_storage_generation;
    uint64_t prepared_type_fingerprint;
    uint32_t prepared_start;
    uint32_t prepared_count;
    uint32_t prepared_nrows;
    uint32_t prepared_ncols;
    uint32_t prepared_capacity;
    uint32_t prepared_timestamp_capacity;
    bool prepared_has_timestamps;
    bool prepared_has_types;
    wl_columnar_memory_reservation_t admission;
    bool admission_active;
} wl_columnar_radix_workspace_t;

/* Owning prepared token for one whole multi-segment radix sequence. Initialize
 * to zero, prepare once, execute once, then destroy even after failures. */
typedef struct wl_columnar_relation_radix_sequence {
    uintptr_t identity;
    uint64_t acquisition_nonce;
    wl_columnar_relation_mutation_set_t *set;
    wl_columnar_relation_mutation_lease_t *lease;
    col_rel_t *relation;
    col_rel_t *owner;
    uint64_t relation_identity;
    uint64_t relation_generation;
    uint64_t owner_identity;
    uint64_t owner_generation;
    uint64_t view_generation;
    uint64_t type_fingerprint;
    const int64_t *const *columns;
    const uint32_t *column_types;
    const col_delta_timestamp_t *timestamps;
    uint32_t nrows, ncols, capacity, timestamp_capacity;
    uint32_t *boundaries;
    uint8_t *needs_sort;
    uint32_t seg_count, needs_sort_count;
    wl_columnar_memory_reservation_t metadata_admission;
    bool metadata_admission_active;
    wl_columnar_radix_workspace_t workspace;
    bool prepared;
    bool consumed;
} wl_columnar_relation_radix_sequence_t;

/* Prepare a zero-initialized or fully destroyed workspace. Live workspaces
 * are refused unchanged; destroy releases their buffers and admission once.
 * Partial, empty and sorted ranges are supported. All boundaries are checked
 * before row reads. ENOMEM denotes allocator failure or real budget denial;
 * only the latter adds memory_budget_denial_pending. This nested helper never
 * clears earlier denial evidence: the owning operation controls that boundary.
 * Arithmetic/accounting overflow returns EOVERFLOW; invalid input/state EINVAL. */
int
wl_columnar_radix_workspace_prepare(const col_rel_t *rel,
    const uint32_t *seg_boundaries, uint32_t seg_count,
    uint64_t additional_scratch_bytes,
    wl_columnar_radix_workspace_t *workspace);
void
wl_columnar_radix_workspace_destroy(wl_columnar_radix_workspace_t *workspace);
/* Lease-scoped preparation allocates the complete scratch even for sorted
 * ranges, and preflights authority, shape and epoch headroom before allocation. */
WL_MUST_CHECK int
wl_columnar_relation_radix_workspace_prepare_with_lease(col_rel_t *rel,
    uint32_t start_row, uint32_t nrows,
    wl_columnar_radix_workspace_t *workspace,
    wl_columnar_relation_mutation_lease_t *lease);

/* Exact prepared single-range snapshot, validated before any COW. Every call
 * requires a workspace; mutations consume its generation provenance. The
 * caller holds a PAYLOAD_MUTATION lease. Shared detach retires its borrow here. */
WL_MUST_CHECK int
wl_columnar_relation_radix_sort_with_lease(col_rel_t *rel, uint32_t start_row,
    uint32_t nrows, const wl_columnar_radix_workspace_t *workspace,
    wl_columnar_relation_mutation_lease_t *lease);
WL_MUST_CHECK int
wl_columnar_relation_radix_sort_consolidation_with_lease(col_rel_t *rel,
    uint32_t start_row, uint32_t nrows,
    const wl_columnar_radix_workspace_t *workspace,
    wl_columnar_relation_mutation_lease_t *lease);
WL_MUST_CHECK int wl_columnar_relation_radix_sequence_prepare_with_lease(
    col_rel_t *rel, const uint32_t *seg_boundaries, uint32_t seg_count,
    wl_columnar_relation_radix_sequence_t *sequence,
    wl_columnar_relation_mutation_lease_t *lease);
WL_MUST_CHECK int wl_columnar_relation_radix_sequence_execute_with_lease(
    wl_columnar_relation_radix_sequence_t *sequence,
    wl_columnar_relation_mutation_lease_t *lease);
void wl_columnar_relation_radix_sequence_destroy(
    wl_columnar_relation_radix_sequence_t *sequence);

/** Stable LSD radix sort of a row-major int64_t buffer by a single key
 *  column.  Used by arrangement.c (sarr_build) and lftj.c
 *  (lftj_iter_init) to replace the platform-specific qsort_r path --
 *  the call site only needs a sort by one column, which radix can do
 *  in one pass over 8 key bytes without any comparator callback.
 *  Returns 0 on success, -1 on allocation failure (data is unchanged).
 *  No-op when key_col >= ncols or nrows < 2.  (#465). */
int
col_radix_sort_rows_by_key(int64_t *data, uint32_t nrows, uint32_t ncols,
    uint32_t key_col);
int
wl_columnar_relation_radix_sort_rows_by_key_typed(int64_t *data,
    uint32_t nrows,
    uint32_t ncols, uint32_t key_col, wirelog_column_type_t key_type);

/** Index-permutation radix sort on sub-range [start_row, start_row+nrows).
 *  Uses col_rel_get() for key extraction -- layout independent.
 *  Phase C: permutation-apply uses col_rel_row_copy_out/in. */
int
col_rel_radix_sort(col_rel_t *r, uint32_t start_row, uint32_t nrows);
/* ======================================================================== */
/* Cache & Materialized Join (columnar/cache.c)                             */
/* ======================================================================== */

col_materialized_join_t *
col_materialized_join_create(uint32_t ncols, uint32_t memory_limit);
int
col_materialized_join_append(col_materialized_join_t *mj, const int64_t *row);
void
col_materialized_join_free(col_materialized_join_t *mj);
void
col_materialized_join_invalidate(col_materialized_join_t *mj);
uint64_t
col_mat_cache_key_content(const col_rel_t *rel);
void
col_mat_cache_clear(col_mat_cache_t *cache);
void
col_mat_cache_evict_until(col_mat_cache_t *cache, size_t target_bytes);
col_rel_t *
col_mat_cache_lookup(col_mat_cache_t *cache, const col_rel_t *left,
    const col_rel_t *right);
/* Legacy diagnostic lookup.  The returned relation is borrowed.  For an
 * eligible live entry, the first hit in the current pin epoch takes one
 * implicit epoch pin (subsequent hits in that epoch are idempotent).  The
 * pin is released by col_mat_cache_release_pins(); until then clear,
 * eviction, and reclaim defer destruction and keep cache-ledger and
 * governor reservations charged.  Production callers that need a stable
 * result must use lookup_pin(), deep-copy while pinned, and release the
 * explicit pin before retaining the copy. */
int
col_mat_cache_insert(col_mat_cache_t *cache, const col_rel_t *left,
    const col_rel_t *right, col_rel_t *result);
void
col_mat_cache_remove_result(col_mat_cache_t *cache, const col_rel_t *result);
/* Insert takes ownership of result only on success.  On failure, the caller
 * retains ownership and must destroy result or push it as owned. */
int
col_mat_cache_insert_pin(col_mat_cache_t *cache, const col_rel_t *left,
    const col_rel_t *right, col_rel_t *result, col_mat_cache_pin_t *pin);
col_rel_t *
col_mat_cache_lookup_pin(col_mat_cache_t *cache, const col_rel_t *left,
    const col_rel_t *right, col_mat_cache_pin_t *pin);
void
col_mat_cache_pin_release(col_mat_cache_pin_t *pin);
/* Source and destination are valid, separately backed writable objects.
 * Initialize destination to all-zero at its final address before moving.
 * Failure changes neither object; success transfers the one actual pin
 * without callbacks or cache access and leaves source inert. Issuer output
 * storage must likewise be nonaliasing and must not overwrite a live pin. */
int
wl_columnar_cache_pin_move(col_mat_cache_pin_t *destination,
    col_mat_cache_pin_t *source);
/* Keyed entry points (Issue #2127).  Two joins over the same left and right
 * inputs can produce different results when their kind, path, keys or right
 * filter differ, so a lookup hits only an entry inserted with the same
 * signature.  The unkeyed functions above use signature 0. */
uint64_t
col_mat_cache_join_signature(const wl_plan_op_t *op, bool diff_path);
int
col_mat_cache_insert_keyed(col_mat_cache_t *cache, const col_rel_t *left,
    const col_rel_t *right, uint64_t op_signature, col_rel_t *result);
int
col_mat_cache_insert_pin_keyed(col_mat_cache_t *cache, const col_rel_t *left,
    const col_rel_t *right, uint64_t op_signature, col_rel_t *result,
    col_mat_cache_pin_t *pin);
col_rel_t *
col_mat_cache_lookup_pin_keyed(col_mat_cache_t *cache, const col_rel_t *left,
    const col_rel_t *right, uint64_t op_signature, col_mat_cache_pin_t *pin);
/* Release only implicit epoch pins from the legacy lookup path and advance
 * the epoch.  Deferred entries whose final implicit pin is released are
 * removed here.  Explicit col_mat_cache_pin_t handles remain owned by their
 * callers. */
void
col_mat_cache_release_pins(col_mat_cache_t *cache);
/*
 * col_mat_cache_truncate: keep_count is the visible-prefix target.  Destroy
 * entries [keep_count, count) when they are unpinned and keep total_bytes and
 * the ledger in step.  Pinned suffix entries may keep the physical count above
 * keep_count; they are deferred, remain charged and hidden from lookup, and
 * are removed only when their final pin is released.  Used to roll back
 * branch-added entries after serial K-fusion.
 */
void
col_mat_cache_truncate(col_mat_cache_t *cache, uint32_t keep_count);

/* Internal pin/generation-safe cache reclaim contract. */
int
col_mat_cache_attach_reclaimer(col_mat_cache_t *cache);
void
col_mat_cache_detach_reclaimer(col_mat_cache_t *cache);
wl_mem_reclaim_result_t
col_mat_cache_reclaim_entry(col_mat_cache_t *cache, uint32_t index,
    uint64_t expected_generation);

/* ======================================================================== */
/* Memory instrumentation (Issue #1380, columnar/session.c)                 */
/* ======================================================================== */

/*
 * col_session_mem_sample:
 * Re-measure the enumerable allocation classes of @sess and publish them
 * as gauges: STORED (sess->rels[] column buffers and timestamps) and
 * TEMPORARY (heap-backed delta_pool temporaries).  Called at iteration
 * boundaries, before delta_pool_reset(), and at the end of a snapshot.
 * O(nrels + pool slots); no allocation.
 */
void
col_session_mem_sample(wl_col_session_t *sess);

/*
 * col_session_mem_note_worker:
 * Fold a TDD worker's ledger peak into the coordinator aggregates before
 * the worker is torn down.  Coordinator-thread only.
 */
void
col_session_mem_note_worker(wl_col_session_t *coordinator,
    const wl_col_session_t *worker);

/*
 * col_session_mem_report_level:
 * Parsed WL_MEM_REPORT (0 = off, 1 = summary, 2 = verbose).
 */
int
col_session_mem_report_level(void);

/*
 * col_session_peak_rss_bytes:
 * Process-wide peak resident set size (ru_maxrss), 0 when unavailable.
 */
uint64_t
col_session_peak_rss_bytes(void);

/* ======================================================================== */
/* Session Helpers (backend/columnar_nanoarrow.c)                           */
/* ======================================================================== */

col_rel_t *
session_find_rel(wl_col_session_t *sess, const char *name);

/*
 * The entry of @sess's plan->idb_schemas for the IDB @name, or NULL when
 * the plan has none (Issue #2334).
 */
const wl_plan_idb_schema_t *
wl_columnar_session_idb_schema(const wl_col_session_t *sess, const char *name);

/*
 * The empty relation an IDB @name of @sess's stratum starts as before any
 * rule has produced rows for it (Issue #2334).  When the session's plan
 * lists @name in plan->idb_schemas, it has that width and, for a declared
 * relation, those lane types; an undeclared one has no lane types until
 * rows are published into it (see tdd_idb_adopts_first_rows() in eval.c).
 * Otherwise, and for a NULL @sess or a session without a plan, it is
 * zero-width and untyped, and the first rows published into it define its
 * schema.  The caller registers it.  Returns 0, EINVAL for a NULL @name or
 * @out, or the error col_rel_alloc(), col_rel_set_schema() or
 * col_rel_set_column_types() returned (ENOMEM, EOVERFLOW, EINVAL).
 */
int
wl_columnar_session_idb_placeholder_new(const wl_col_session_t *sess,
    const char *name, col_rel_t **out);
int
session_add_rel(wl_col_session_t *sess, col_rel_t *r);
int
session_remove_rel(wl_col_session_t *sess, const char *name);
/* Explicit internal pre-evaluation opt-in, under external session lifecycle
 * serialization. Caller keeps the plan immutable through session destruction.
 * Supported scalar or declared flat INLINE EDBs used only by audited JOINs
 * or complete direct/filtered projections may be sealed individually. Success
 * removes its resident registry owner and makes ALL fact and
 * compound mutation unsupported, including zero-row requests. Failed sealing
 * preserves the source/registry and refunds private work.
 * No readers may escape synchronous operations; callbacks must not reenter
 * source/session/store/governor lifecycle. STEP/SNAPSHOT recheck mode guards.
 * Original logical identity/view/ordinals survive in source_snapshot; storage
 * generation advances once. Old resident caches are not reusable. */
wl_columnar_spill_status_t wl_columnar_session_seal_input(
    wl_session_t *session, const char *name, wl_columnar_spill_cancel_fn cancel,
    void *context);
wl_columnar_spill_status_t wl_columnar_session_seal_join_input(
    wl_session_t *session, const char *name, wl_columnar_spill_cancel_fn cancel,
    void *context);
wl_columnar_session_cold_relation_t *wl_columnar_session_cold_find(
    const wl_col_session_t *session, const char *name);
int wl_columnar_session_cold_execution_check(const wl_col_session_t *session);
const wirelog_column_type_t *wl_columnar_session_cold_types(
    const wl_columnar_session_cold_relation_t *cold);
bool wl_columnar_session_cold_uses_intern(
    const wl_columnar_session_cold_relation_t *cold, const wl_intern_t *intern);
const wirelog_column_t *wl_columnar_session_cold_inline_schema(
    const wl_columnar_session_cold_relation_t *cold, uint32_t *count);
const wirelog_column_type_t *wl_columnar_session_cold_declared_types(
    const wl_col_session_t *session, const char *name, uint32_t *width);
wl_columnar_spill_status_t wl_columnar_session_begin_cold_input(
    wl_session_t *session, const char *name);
wl_columnar_spill_status_t wl_columnar_session_append_cold_input(
    wl_session_t *session, const char *name, const int64_t *rows,
    uint32_t count, uint32_t width);
wl_columnar_spill_status_t wl_columnar_session_finish_cold_input(
    wl_session_t *session, const char *name);

/* Read-only source/declaration provenance; returns NULL schema for scalars. */
bool wl_columnar_session_cold_source_schema(const wl_col_session_t *session,
    const char *name, const col_rel_t *resident,
    const struct wl_columnar_batch_payload *payload,
    const wl_plan_edb_schema_t **schema);
/* Valid only after the complete cold scan body/prefix has been audited. */
typedef struct {
    const wl_plan_op_t *map; /* Last MAP, or NULL for a FILTER-only JOIN prefix. */
    uint32_t filter_count;
} wl_columnar_eval_plan_cold_projection_t;
typedef struct {
    uint32_t column;
    int64_t literal;
    uint8_t comparison;
} wl_columnar_eval_plan_cold_predicate_t;
bool wl_columnar_eval_plan_cold_predicate_decode(const wl_plan_op_t *filter,
    uint32_t ncols, const wirelog_column_type_t *types,
    wl_columnar_eval_plan_cold_predicate_t *out);
bool wl_columnar_eval_plan_cold_column(const wl_plan_relation_t *plan,
    uint32_t end, uint32_t column, uint32_t ncols, uint32_t *source);
bool wl_columnar_eval_plan_cold_map_lane(const wl_plan_op_t *map,
    uint32_t column, uint32_t width, wirelog_column_type_t type);
bool wl_columnar_eval_plan_cold_scan_decode(const wl_plan_relation_t *plan,
    const char *name, uint32_t ncols, const wirelog_column_type_t *types,
    uint32_t end, wl_columnar_eval_plan_cold_projection_t *out);
bool wl_columnar_join_cold_scan_prefix(const wl_col_session_t *session,
    const wl_plan_relation_t *plan, uint32_t *join_index);
int wl_columnar_ops_cold_scan(const wl_plan_relation_t *plan,
    eval_stack_t *stack, wl_col_session_t *session, uint32_t end);
int wl_columnar_relation_new_named_governed(const char *name, uint32_t ncols,
    const char *const *names, uint32_t capacity, bool timestamps,
    wl_columnar_memory_governor_ref_t *governor, col_rel_t **out);
bool wl_columnar_eval_plan_cold_projection_decode(
    const wl_plan_relation_t *plan, const char *name, uint32_t ncols,
    const wirelog_column_type_t *types,
    wl_columnar_eval_plan_cold_projection_t *out);
bool wl_columnar_eval_plan_cold_projection(const wl_plan_relation_t *plan,
    const char *name, uint32_t ncols, const wirelog_column_type_t *types);
int wl_columnar_ops_cold_projection(const wl_plan_relation_t *plan,
    eval_stack_t *stack, wl_col_session_t *session);

typedef struct {
    uint32_t reduce_index, filter_count, operand;
} wl_columnar_eval_plan_cold_aggregate_t;
bool wl_columnar_eval_plan_cold_aggregate_decode(
    const wl_plan_relation_t *plan, const char *name, uint32_t ncols,
    const wirelog_column_type_t *types,
    wl_columnar_eval_plan_cold_aggregate_t *out);
int wl_columnar_ops_cold_aggregate(const wl_plan_relation_t *plan,
    eval_stack_t *stack, wl_col_session_t *session);
/* A complete one-JOIN reduction audit, shared by retirement and execution. */
bool wl_columnar_join_aggregate_decode(const wl_col_session_t *session,
    const wl_plan_relation_t *plan, uint32_t *join_index);
int wl_columnar_join_aggregate(wl_col_session_t *session,
    const wl_plan_relation_t *plan, eval_stack_t *stack, uint32_t join_index,
    const char *cold_left);
int wl_columnar_ops_join_aggregate(const wl_plan_relation_t *plan,
    uint32_t join_index, wl_columnar_continuation_t *continuation,
    wl_col_session_t *session, uint32_t width,
    const wirelog_column_type_t *types, col_rel_t **out);
bool wl_columnar_eval_plan_aggregate_column(const wl_plan_expr_buffer_t *expr,
    uint32_t width, uint32_t *column);
bool wl_columnar_join_output_count_limit(wl_col_session_t *session,
    uint64_t total, uint64_t added);

/* Shared schema lookup semantics, including the resident col<N> fallback. */
int wl_columnar_relation_schema_column_index(uint32_t ncols,
    const char *const *names, const char *name);

#ifdef WL_SESSION_TEST_HOOKS
int wl_columnar_session_test_register_retraction(wl_col_session_t *sess,
    col_rel_t *relation, bool publish);
int wl_columnar_session_test_register_expected_head(wl_col_session_t *sess,
    col_rel_t *relation, col_rel_t *expected_old, uint64_t identity,
    uint64_t view_generation, uint64_t storage_generation, bool publish);
/* Calls of session_snapshot_insert() that returned 0 (Issue #2119). */
extern uint32_t wl_columnar_session_test_insert_route_taken;
#endif

/* ======================================================================== */
/* Session Hash Table Helpers (columnar/session_hash.c - Issue #281)       */
/* ======================================================================== */

int
session_rel_build_hash(wl_col_session_t *sess);
col_rel_t *
session_rel_hash_lookup(wl_col_session_t *sess, const char *name);
int
session_rel_hash_insert(wl_col_session_t *sess, uint32_t idx);
int
session_rel_hash_remove(wl_col_session_t *sess, uint32_t idx);
void
session_rel_free_hash(wl_col_session_t *sess);

/* Private relation-registry image used by owner publication.  Preparation
 * copies the current registry and builds its complete hash off to the side;
 * publication validates the original identities and then swaps pointers
 * without allocation. */
struct wl_columnar_session_hash_registry_image {
    wl_col_session_t *session;
    col_rel_t **expected_rels;
    uint32_t expected_nrels;
    uint32_t expected_rel_cap;
    uint32_t *expected_hash_head;
    uint32_t *expected_hash_next;
    uint32_t expected_hash_nbuckets;
    uint32_t expected_hash_chain_cap;
    col_rel_t **expected_rel_contents;
    col_rel_t **rels;
    uint32_t nrels;
    uint32_t rel_cap;
    uint32_t *hash_head;
    uint32_t *hash_next;
    uint32_t hash_nbuckets;
    uint32_t hash_chain_cap;
    wl_columnar_memory_reservation_t hash_reservation;
    wl_columnar_memory_reservation_t rels_reservation;
    wl_columnar_memory_reservation_t expected_rels_reservation;
};

int
wl_columnar_session_hash_registry_image_prepare(wl_col_session_t *session,
    col_rel_t *const *additions, uint32_t addition_count,
    wl_columnar_session_hash_registry_image_t *image);
int
wl_columnar_session_hash_registry_image_validate(
    const wl_columnar_session_hash_registry_image_t *image);
void
wl_columnar_session_hash_registry_image_publish(
    wl_columnar_session_hash_registry_image_t *image);
void
wl_columnar_session_hash_registry_image_discard(
    wl_columnar_session_hash_registry_image_t *image);
#ifdef WL_TEST_OWNER_PUBLICATION
void
wl_columnar_session_hash_test_fail_registry_image_prepare(
    wl_col_session_t *session);
bool
wl_columnar_session_hash_test_registry_image_prepare_failure_hit(void);
#endif

/* ======================================================================== */
/* Arrangement Layer (columnar/arrangement.c)                               */
/* ======================================================================== */

void
arr_free_contents(col_arrangement_t *arr);
/*
 * col_arr_attach_ledger: start charging @arr's hash-table bytes to @ledger
 * under WL_MEM_SUBSYS_ARRANGEMENT (Issue #1380).  Charges the current
 * footprint immediately; no-op when already attached.  Used for cloned
 * worker registries, whose entries are copied outside the build path.
 */
void
col_arr_attach_ledger(col_arrangement_t *arr, wl_mem_ledger_t *ledger);

#ifdef WL_SESSION_TEST_HOOKS
/* Set/reset only with no concurrent arrangement users. Observer must not
 * allocate or reenter the governor; false reserve is not itself proof of
 * budget denial, so tests must also compare request with remaining budget. */
extern void (*wl_columnar_arrangement_test_reserve_denied)(
    wl_columnar_memory_governor_t *, uint64_t, uint64_t);
#endif

void
col_arr_attach_memory_governor(col_arrangement_t *arr,
    wl_columnar_memory_governor_ref_t *memory_governor);

void
col_arr_detach_memory_governor(col_arrangement_t *arr);
col_arrangement_t *
col_session_get_delta_arrangement(wl_col_session_t *cs, const char *rel_name,
    const col_rel_t *delta_rel,
    const uint32_t *key_cols, uint32_t key_count);
void
col_session_free_delta_arrangements(wl_col_session_t *cs);

/* Filtered arrangement cache (Issue #433) */
col_arrangement_t *
col_session_get_filt_arrangement(wl_col_session_t *cs, const char *rel_name,
    uint64_t filter_hash, const col_rel_t *filtered_rel,
    const uint32_t *key_cols, uint32_t key_count);
void
col_session_free_filt_arrangements(wl_col_session_t *cs);

/* Differential arrangement registry (Issue #263) */
typedef struct wl_columnar_arrangement_diff_txn {
    wl_col_session_t *session;
    col_diff_arr_entry_t *entry;
    col_diff_arrangement_t **slot;
    col_diff_arrangement_t *persistent;
    col_diff_arrangement_t *working;
    uint32_t entry_index;
    uint64_t entry_generation;
    bool pending_entry;
} wl_columnar_arrangement_diff_txn_t;

col_diff_arrangement_t *
col_session_get_diff_arrangement(wl_col_session_t *cs, const char *rel_name,
    const col_rel_t *source_rel,
    const uint32_t *key_cols, uint32_t key_count, int *status_out);
void
wl_columnar_arrangement_diff_reset_state(col_diff_arrangement_t *arr);
int
col_session_pin_diff_arrangement(wl_col_session_t *cs, const char *rel_name,
    const col_rel_t *source_rel, const uint32_t *key_cols, uint32_t key_count,
    col_diff_arrangement_pin_t *pin);
void
col_diff_arrangement_pin_release(col_diff_arrangement_pin_t *pin);
int
wl_columnar_arrangement_diff_txn_begin(wl_col_session_t *cs,
    const char *rel_name, const col_rel_t *source_rel,
    const uint32_t *key_cols, uint32_t key_count,
    wl_columnar_arrangement_diff_txn_t *txn);
int
wl_columnar_arrangement_diff_txn_commit(
    wl_columnar_arrangement_diff_txn_t *txn);
void
wl_columnar_arrangement_diff_txn_abort(
    wl_columnar_arrangement_diff_txn_t *txn);
/* Returns EBUSY while a pin or replacement transaction is active. */
int
col_session_free_diff_arrangements(wl_col_session_t *cs);
/* Issue #260: Deep-copy arrangement entries for K-fusion worker isolation. */
int
col_arr_entries_clone(const col_arr_entry_t *src, uint32_t count,
    col_arr_entry_t **out_entries, uint32_t *out_cap,
    wl_columnar_memory_governor_ref_t *memory_governor);
/* Issue #274: Deep-copy differential arrangement entries for K-fusion worker isolation. */
int
col_diff_arr_entries_clone(const col_diff_arr_entry_t *src, uint32_t count,
    col_diff_arr_entry_t **out_entries, uint32_t *out_cap,
    wl_columnar_memory_governor_ref_t *memory_governor);
int
col_diff_arr_entries_registry_size(const col_diff_arr_entry_t *src,
    uint32_t count, uint64_t *array_bytes, uint64_t *metadata_bytes);
col_sorted_arr_t *
col_session_get_sorted_arrangement(wl_col_session_t *cs, const char *rel_name,
    uint32_t key_col);
int
col_session_acquire_sorted_arrangement_probe(wl_session_t *session,
    const col_rel_t *source, uint32_t key_col,
    col_sorted_arrangement_probe_t *probe);
int
col_session_acquire_sorted_arrangement_probe_with_source_reader(
    wl_session_t *session, const col_rel_t *source, uint32_t key_col,
    col_sorted_arrangement_probe_t *probe,
    wl_columnar_source_access_reader_t *source_reader);
int
col_sorted_arrangement_probe_release(col_sorted_arrangement_probe_t *probe);
void
col_session_free_sorted_arrangements(wl_col_session_t *cs);

/* ======================================================================== */
/* Mobius / Z-set (columnar/mobius.c)                                        */
/* ======================================================================== */

int
col_compute_delta_mobius(const col_rel_t *prev_collection,
    const col_rel_t *curr_collection,
    col_rel_t *out_delta);

/* ======================================================================== */
/* Eval Stack (columnar/eval_stack.c) and operators (columnar/ops.c)         */
/* ======================================================================== */

/* Checked expression arithmetic (columnar/arithmetic.c). */
typedef struct wl_columnar_expr_compiled wl_columnar_expr_compiled_t;

typedef struct {
    wl_intern_t *intern;
    const wirelog_extension_snapshot_t *extensions; /* borrowed */
    bool allow_extension_scalar_result;
    uint32_t configured_worker_count;
    uint32_t active_worker_count;
    bool parallel_execution;
    const void *session_key;
} wl_columnar_expr_context_t;

typedef enum {
    WL_COLUMNAR_EXPR_OK = 0,
    WL_COLUMNAR_EXPR_MALFORMED = 1,
    WL_COLUMNAR_EXPR_EXTENSION_MALFORMED,
    WL_COLUMNAR_EXPR_MISSING_EXTENSION,
    WL_COLUMNAR_EXPR_ARITY_MISMATCH,
    WL_COLUMNAR_EXPR_TYPE_MISMATCH,
    WL_COLUMNAR_EXPR_CALLBACK_FAILURE,
    WL_COLUMNAR_EXPR_INVALID_RESULT,
    WL_COLUMNAR_EXPR_ALLOCATION_FAILURE,
    WL_COLUMNAR_EXPR_EXTENSION_ABI_MISMATCH,
    WL_COLUMNAR_EXPR_CALLBACK_POLICY,
    WL_COLUMNAR_EXPR_CALLBACK_REENTRANT
} wl_columnar_expr_status_t;

/* #2299 immutable bytes: saved active attempt required, no allocation or
 * intern ownership. Caller pins/keeps sources immutable and outputs disjoint.
 * NULL spans are valid only at length0; C strings must remain terminated.
 * Scalars are unchanged on error. Copy uses private disjoint scratch and
 * reports completed stores after accepted entry, including on interruption;
 * rejected entry leaves copied unchanged. Compare returns -1/0/1 unsigned;
 * find returns position0/found=false on absence, 0/true for an empty needle.
 * FNV1a wraps uint32_t and preserves initial for an empty span.
 * Tariff224 per entry/final and action: length includes NUL, compare each
 * inspected pair; copy/hash separate load+store/update; search each admitted
 * candidate and inspected pair. Phases40entry,41length,42compare,43load,
 * 44store,45hash,46candidate,47searchpair,48final. Hooks revalidate attempt.
 * Final guarded poll precedes scalar publication. Invalid calls/stale IDs
 * neither debit a successor attempt nor invoke a later checkpoint. */
int wl_columnar_expr_cstr_length_attempt_controlled(const char *, size_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_expr_bytes_compare_attempt_controlled(const uint8_t *,
    const uint8_t *, size_t, int *, wl_evaluation_control_t *, uint64_t);
/* Compare real intern rank/lexical values without normalizing invalid IDs.
 * Outputs publish only after the last actual saved-generation observation. */
int wl_columnar_expr_intern_rank_compare_attempt_controlled(const wl_intern_t *,
    int64_t, int64_t, int *, bool *, bool *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_expr_bytes_copy_attempt_controlled(uint8_t *, const uint8_t *,
    size_t, size_t *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_expr_bytes_hash_attempt_controlled(const uint8_t *, size_t,
    uint32_t, uint32_t *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_expr_bytes_find_attempt_controlled(const uint8_t *, size_t,
    const uint8_t *, size_t, size_t *, bool *, wl_evaluation_control_t *,
    uint64_t);

/* Permissive UTF-8 step: empty => advance0/codepoint-1; invalid lead =>
 * advance1/codepoint-1; invalid continuation at i => advance i/codepoint-1.
 * Each actual inspected byte costs224, entry/final224 each. Outputs unchanged
 * on nonzero; immutable NUL-terminated input borrowed from a live owner/pin. */
int wl_columnar_expr_utf8_next_attempt_controlled(const char *, size_t *,
    int64_t *, wl_evaluation_control_t *, uint64_t);

/* Base10 prefix with locale isspace, optional sign and checked int64 range.
 * Tariff224 per entry/final, inspected byte and digit accumulation. Traverses
 * the entire digit prefix even after overflow; suffix is ignored. ERANGE and
 * control/identity errors leave output unchanged. Input borrowed/immutable. */
int wl_columnar_expr_decimal_attempt_controlled(const char *, int64_t *,
    wl_evaluation_control_t *, uint64_t);

/* Borrowed spans, NULL only for length0; saved active attempt required.
 * No allocations/intern changes. Nonzero leaves output unchanged.
 * XXH3: 224*(4+ceil(length/64)) engine work, narrow vendor reset/update/digest
 * cooperation boundaries, each update<=64. CRC: 224*(2*length+2), distinct
 * byte LOAD and immutable-table update, zero-extended complemented CRC. */
/* Original PSA compute compatibility: value/failed remain unchanged on rc.
 * Success costs9*224; init failure3*224, compute/length failure4*224,
 * disabled2*224. Engine operand scans are separate; provider bodies cooperate
 * only at their synchronous return and may have input-sized latency. */
int wl_columnar_expr_crypto_digest_attempt_controlled(uint8_t,
    const uint8_t *, size_t, int64_t *, bool *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_expr_crypto_hmac_attempt_controlled(const uint8_t *message,
    size_t message_length, const uint8_t *key, size_t key_length,
    int64_t *value, bool *failed, wl_evaluation_control_t *control,
    uint64_t id);
int wl_columnar_expr_crypto_uuid4_attempt_controlled(int64_t *value,
    bool *failed,
    wl_evaluation_control_t *control, uint64_t id);
int wl_columnar_expr_crypto_uuid_pair_attempt_controlled(bool framed,
    uint8_t first_tag, const uint8_t *first, size_t first_length,
    uint8_t second_tag, const uint8_t *second, size_t second_length,
    uint8_t *output, bool *failed, wl_evaluation_control_t *control,
    uint64_t id);
int wl_columnar_expr_crypto_uuid_parse_attempt_controlled(const char *text,
    uint8_t *output, bool *valid, wl_evaluation_control_t *control,
    uint64_t id);
int wl_columnar_expr_crypto_uuid_format_attempt_controlled(const uint8_t *bytes,
    char *output, wl_evaluation_control_t *control, uint64_t id);

int wl_columnar_expr_hash_bytes_attempt_controlled(const uint8_t *, size_t,
    int64_t *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_expr_crc_bytes_attempt_controlled(const uint8_t *, size_t,
    bool, uint32_t *, wl_evaluation_control_t *, uint64_t);

/* Private disjoint case-copy destination, immutable source span. Like byte
 * copy, copied reports completed stores after accepted entry, even on stop;
 * rejected entry leaves it unchanged. Tariff224*(3*length+2): LOAD, ASCII-only
 * transform, STORE separately funded. NUL/high bytes are ordinary span bytes. */
int wl_columnar_expr_ascii_case_attempt_controlled(uint8_t *, const uint8_t *,
    size_t, bool, size_t *, wl_evaluation_control_t *, uint64_t);
/* Caller supplies private24-byte buffer. Fixed snprintf boundary; buffer may
 * be modified before a later stop, length unchanged on nonzero. Two224 caller
 * regions, independent of fixed-width int64 magnitude. No heap admission. */
int wl_columnar_expr_format_i64_attempt_controlled(int64_t, char *, size_t *,
    wl_evaluation_control_t *, uint64_t);

/* Immutable C-string span selectors. Nonzero leaves all outputs unchanged.
* Trim uses locale isspace on unsigned bytes, metered front/back inspections
* plus the full bounded length scan. Slice preserves permissive UTF8 next;
* negative/beyond-end indices publish valid=false without changing span,
* start==end is valid, and no signed start+length addition is performed. */
int wl_columnar_expr_trim_span_attempt_controlled(const char *, size_t *,
    size_t *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_expr_utf8_slice_attempt_controlled(const char *, int64_t,
    int64_t, size_t *, size_t *, bool *, wl_evaluation_control_t *, uint64_t);

/* Checked nonoverlapping replacement metadata, excluding trailing NUL.
 * old_length must be positive; count*old_length cannot exceed source_length.
 * Normal exact work448, errors leave result unchanged. No allocation/input
 * traversal; capacity includes a representable terminating NUL. */
int wl_columnar_expr_replace_size_attempt_controlled(size_t, size_t, size_t,
    size_t, size_t *, wl_evaluation_control_t *, uint64_t);

/* Context-bearing scalar owner (#2299). Immutable bytecode copy, no intern
 * mutation during compile. Numeric-only hosts keep the numeric owner path.
 * Evaluation borrows the actual session/plan context (or caller-held pin),
 * never rebinds the intern to the bytecode owner's governor. Temporary literal
 * buffers use that owner governor; retained strings use their intern governor.
 * Caller keeps context, row and owner live/immutable throughout evaluation.
 * Compile initializes out=NULL/supported=false; unsupported grammar returns0.
 * Nonzero eval leaves scalar outputs unchanged. Semantic failure publishes
 * value0/failed=true/MALFORMED. Literal legacy interning failures map ENOMEM;
 * temporary governed allocation keeps its own ENOSPC/admission dispositions.
 * No raw expression fallback. Disposal is mandatory/noncancellable. */
typedef struct wl_columnar_expr_attempt_scalar wl_columnar_expr_attempt_scalar_t;
int wl_columnar_expr_compile_scalar_attempt_controlled(const uint8_t *,
    uint32_t,
    wl_columnar_memory_governor_ref_t *, wl_columnar_expr_attempt_scalar_t **,
    bool *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_expr_eval_scalar_attempt_controlled(
    const wl_columnar_expr_attempt_scalar_t *, const int64_t *, uint32_t,
    const wl_columnar_expr_context_t *, int64_t *, bool *,
    wl_columnar_expr_status_t *, wl_evaluation_control_t *, uint64_t);
bool wl_columnar_expr_scalar_schema_unknown(
    const wl_columnar_expr_attempt_scalar_t *owner);
int wl_columnar_expr_scalar_result_type_attempt_controlled(
    const wl_columnar_expr_attempt_scalar_t *, const wirelog_column_type_t *,
    uint32_t, wirelog_column_type_t *, bool *, wl_evaluation_control_t *,
    uint64_t);
void wl_columnar_expr_attempt_scalar_free(wl_columnar_expr_attempt_scalar_t *);
#ifdef WL_SESSION_TEST_HOOKS
size_t wl_columnar_expr_test_scalar_owner_size(void);
#endif

/* #1821 numeric preparation/execution foundation; no engine activation.
 * Bytecode is immutable through both passes. Governor is borrowed until free;
 * owner/row must remain alive and immutable during evaluation. NULL control
 * uses the same owner representation and destructor without metering.
 * Compile initializes out=NULL/supported=false. Empty, malformed or unsupported
 * bytecode returns0 unsupported; NULL buf with nonzero size returns EINVAL.
 * Numeric VAR/VAR_FLOAT accepts col plus1..9 digits; FLOAT variables are an
 * additional capability relative to today's raw compiler. Allocation ENOMEM,
 * admission ENOSPC/EOVERFLOW/EINVAL and negative control stops stay distinct.
 * Eval only accepts this compiler's owner, never raw compiled objects. Invalid
 * args/control errors leave value/failed unchanged. Semantic failures publish
 * failed=true,value0; successful semantics match raw numeric stack behavior
 * (underflow yields0, full-stack pushes ignored). Results publish after a tail.
 * Free consumes a live owner once, accepts NULL, and is noncancellable.
 * No string/intern/crypto/extension fallback. Tariff table lives in expr.c. */
typedef struct wl_columnar_expr_controlled wl_columnar_expr_controlled_t;
int wl_columnar_expr_compile_controlled(const uint8_t *, uint32_t,
    wl_columnar_memory_governor_ref_t *, wl_columnar_expr_controlled_t **,
    bool *, wl_evaluation_control_t *);
int wl_columnar_expr_eval_controlled(const wl_columnar_expr_controlled_t *,
    const int64_t *, uint32_t, int64_t *, bool *, wl_evaluation_control_t *);
void wl_columnar_expr_controlled_free(wl_columnar_expr_controlled_t *);

/* Caller-attempt numeric owner: distinct from legacy representations. The
 * immutable bytecode and output slots remain live/nonoverlapping through the
 * call; an output slot must not hold a live owned result (free it first).
 * Caller serializes control lifecycle and keeps the shared governor alive
 * with stable configuration through admission; owner pins its own reference
 * thereafter. Original token/owner use is exclusive; immutable evaluation
 * may borrow only while destruction is externally excluded.
 * NonNULL control and a nonzero current supplied ID are required;
 * missing/inactive/stale IDs return EINVAL without successor callbacks/debit.
 * Compile initializes out=NULL/supported=false as fixed bootstrap, then
 * returns supported=false for nonnumeric/malformed programs without fallback.
 * Genuine NULL governor is supported; a governed owner pins its own reference.
 * Owner and its embedded token are noncopyable, externally synchronized for
 * destruction, and may survive attempt finish/reset. Free is mandatory and
 * retires physical storage before its own credit and saved reference.
 * The separate evaluator below borrows this prepared owner without mutation. */
typedef struct wl_columnar_expr_attempt_numeric
    wl_columnar_expr_attempt_numeric_t;
int wl_columnar_expr_compile_attempt_controlled(const uint8_t *, uint32_t,
    wl_columnar_memory_governor_ref_t *, wl_columnar_expr_attempt_numeric_t **,
    bool *, wl_evaluation_control_t *, uint64_t);
/* Zero-row FILTER setup: raw compiler opcode domain (including string
 * comparisons, excluding HASH/CRC). The owner is cleanup-only: NEVER evaluate
 * it through the numeric evaluator. Actual source owner must prove zero rows.
 * SIMPLE classification shares bounded decoding; no schema/lane validation. */
int wl_columnar_expr_compile_empty_filter_attempt_controlled(const uint8_t *,
    uint32_t, wl_columnar_memory_governor_ref_t *,
    wl_columnar_expr_attempt_numeric_t **, bool *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_expr_simple_filter_attempt_controlled(const uint8_t *,
    uint32_t, bool *, wl_evaluation_control_t *, uint64_t);
void wl_columnar_expr_attempt_numeric_free(
    wl_columnar_expr_attempt_numeric_t *);

/* Constant-time result schema, without evaluation or callbacks. The immutable
 * program caches the actual returned producer during compilation, including
 * legacy capped pushes, zero-filled underflow and aggregate no-ops. Plain VAR
 * preserves an in-range source physical type; absent/out-of-range is INT64.
 * Explicit VAR_FLOAT is FLOAT. source_types, when nonNULL, has ncols entries.
 * Outputs are exclusive/disjoint from borrowed inputs/control and each other.
 * Original-ID admission/cutoff precedes publication; nonzero rc changes no
 * output. On success supported=false leaves type untouched. Phase23 is the
 * final schema cutoff. No allocation, ownership or governor operation occurs. */
int wl_columnar_expr_result_type_attempt_controlled(
    const wl_columnar_expr_attempt_numeric_t *program,
    const wirelog_column_type_t *source_types, uint32_t ncols,
    wirelog_column_type_t *type, bool *supported,
    wl_evaluation_control_t *control, uint64_t attempt_id);

/* Caller-attempt evaluator for genuine immutable numeric owners above.
 * Program and row stay live/immutable; outputs are exclusive, disjoint from
 * each other, program/instructions, row and control. NULL control, inactive
 * or stale caller ID return EINVAL without changing either output.
 * Nonzero return leaves value/failed untouched. Success publishes value and
 * failed=false, or semantic failure value=0/failed=true after final cutoff.
 * No allocation, governor debit/ref operation, or ownership transfer occurs.
 * Immutable readers may use separate controls/outputs concurrently; exclude
 * destruction until every reader joins. Phases20/21/22: step/row/final;
 * row21 precedes finite-FLOAT validation and reports failed=false, while
 * step20/final22 report detected semantic failure. Logical forward bound224
 * excludes control internals/instrumentation; no allocation/retirement occurs.
 */
int
wl_columnar_expr_eval_attempt_controlled(
    const wl_columnar_expr_attempt_numeric_t *program,
    const int64_t *row, uint32_t ncols, int64_t *value, bool *failed,
    wl_evaluation_control_t *control, uint64_t attempt_id);
#ifdef WL_SESSION_TEST_HOOKS
/* Configured ABI dimensions for independent attempt-owner resource oracles. */
size_t wl_columnar_expr_test_attempt_numeric_owner_size(void);
size_t wl_columnar_expr_test_attempt_numeric_instruction_size(void);
/* phases:1/2 consumed byte in first/second pass;3 evaluated instruction;
 * 4 reserved;5 moved;6 committed before publication;7 evaluation publication;
 * 8 physical storage freed but credit still held (mandatory cleanup, NULL ctl).
 * Attempt compiler additionally uses10 entry,11 first-pass caller,12 setup,
 * 13 reserve caller,14/15 allocations,16 second-pass caller,17 store,
 * 18 commit caller,19 digit. Legacy phase numbers remain unchanged.
 * Progress is byte offset/instruction count; failed is pending semantic result. */
extern void (*wl_columnar_expr_test_checkpoint)(wl_evaluation_control_t *,
    unsigned, uint64_t, bool);
extern int wl_columnar_expr_test_fail_allocation;
#endif

wl_columnar_expr_compiled_t *
wl_columnar_expr_compile(const uint8_t *buf, uint32_t size,
    const wl_intern_t *intern);
wl_columnar_expr_compiled_t *
wl_columnar_expr_compile_governed(const uint8_t *buf, uint32_t size,
    const wl_intern_t *intern, wl_columnar_memory_governor_ref_t *governor,
    wl_col_session_t *sess, int *error_out);
void
wl_columnar_expr_compiled_free(wl_columnar_expr_compiled_t *c);
/* Same schema rules as the attempt query; false leaves type untouched.
 * Interpreter-only expression families have no compiled owner to query. */
bool wl_columnar_expr_compiled_result_type(
    const wl_columnar_expr_compiled_t *c,
    const wirelog_column_type_t *source_types, uint32_t ncols,
    wirelog_column_type_t *type);
/* Pure static result query for complete canonical fixed-result scalar builtin
 * expressions. No execution, operand/ID validation, intern mutation or callbacks.
 * Unknown/extension/aggregate/malformed input leaves type untouched. */
bool wl_columnar_expr_interpreted_result_type(const uint8_t *buf, uint32_t size,
    const wirelog_column_type_t *source_types, uint32_t ncols,
    wirelog_column_type_t *type);
int
wl_columnar_expr_eval_compiled(const wl_columnar_expr_compiled_t *c,
    const int64_t *row, uint32_t ncols, int64_t *out_val);
int
wl_columnar_expr_eval_run(const uint8_t *buf, uint32_t size,
    const int64_t *row, uint32_t ncols, int64_t *out_val,
    wl_intern_t *intern);
int
wl_columnar_expr_eval_run_ctx(const uint8_t *buf, uint32_t size,
    const int64_t *row, uint32_t ncols, int64_t *out_val,
    const wl_columnar_expr_context_t *ctx,
    wl_columnar_expr_status_t *status);
int
wl_columnar_expr_filter_row(const uint8_t *buf, uint32_t size,
    const int64_t *row, uint32_t ncols, wl_intern_t *intern);
int
wl_columnar_expr_eval_i64(const uint8_t *buf, uint32_t size,
    const int64_t *row, uint32_t ncols, int64_t *out_val,
    wl_intern_t *intern);
bool
wl_columnar_expr_parse_var_col(const uint8_t *buf, uint32_t size,
    uint32_t *pos, uint32_t *col_out);

int
wl_columnar_arithmetic_checked_add_int64(int64_t a, int64_t b, int64_t *out);
int
wl_columnar_arithmetic_checked_sub_int64(int64_t a, int64_t b, int64_t *out);
int
wl_columnar_arithmetic_checked_mul_int64(int64_t a, int64_t b, int64_t *out);
int
wl_columnar_arithmetic_checked_div_int64(int64_t a, int64_t b, int64_t *out);
int
wl_columnar_arithmetic_checked_mod_int64(int64_t a, int64_t b, int64_t *out);
int
wl_columnar_arithmetic_checked_shl_int64(int64_t a, int64_t b, int64_t *out);
int
wl_columnar_arithmetic_checked_shr_int64(int64_t a, int64_t b, int64_t *out);
uint32_t
wl_columnar_filter_next_pow2(uint32_t n);
col_rel_t *
wl_columnar_filter_apply_right_filter(const wl_plan_expr_buffer_t *fexpr,
    col_rel_t *rel, delta_pool_t *pool, wl_intern_t *intern);
/* Explicit governor is preserved through pool exhaustion and heap fallback. */
col_rel_t *
wl_columnar_filter_apply_right_filter_governed(
    const wl_plan_expr_buffer_t *fexpr,
    col_rel_t *rel, delta_pool_t *pool, wl_intern_t *intern,
    wl_columnar_memory_governor_ref_t *governor);
int
wl_columnar_filter_apply_right_filter_governed_checked(
    const wl_plan_expr_buffer_t *fexpr, col_rel_t *rel, delta_pool_t *pool,
    wl_intern_t *intern, wl_columnar_memory_governor_ref_t *governor,
    wl_col_session_t *sess, col_rel_t **out);
uint64_t
wl_columnar_filter_fnv1a_hash(const uint8_t *buf, uint32_t len);
col_rel_t *
wl_columnar_filter_apply_right_filter_cached(wl_col_session_t *sess,
    const wl_plan_expr_buffer_t *fexpr, const char *rel_name, col_rel_t *rel);
/* Lease-taking variant (Issue #1435): on success *pin is active and the
 * returned relation stays valid until col_filt_cache_pin_release(); NULL
 * when the entry is leased and stale (replacement deferred), hidden by a
 * deferred invalidation, or when the cache cannot grow while leases are
 * active, as well as on allocation failure.  Callers fall back to the
 * owned wl_columnar_filter_apply_right_filter path on NULL. */
col_rel_t *
wl_columnar_filter_apply_right_filter_cached_pin(wl_col_session_t *sess,
    const wl_plan_expr_buffer_t *fexpr, const char *rel_name, col_rel_t *rel,
    col_filt_cache_pin_t *pin);
/* Checked cache lookup returns zero with *cache_unavailable=true when a
 * lease/deferred invalidation prevents cache use; allocation and admission
 * failures are returned as errors so callers do not hide them as fallback. */
int
wl_columnar_filter_apply_right_filter_cached_pin_checked(
    wl_col_session_t *sess, const wl_plan_expr_buffer_t *fexpr,
    const char *rel_name, col_rel_t *rel, col_filt_cache_pin_t *pin,
    col_rel_t **out, bool *cache_unavailable);
void
col_filt_cache_pin_release(col_filt_cache_pin_t *pin);

void
eval_stack_init(eval_stack_t *s);
int
eval_stack_push(eval_stack_t *s, col_rel_t *r, bool owned);
int
eval_stack_push_delta(eval_stack_t *s, col_rel_t *r, bool owned, bool is_delta);
int
eval_stack_push_continuation(eval_stack_t *s,
    wl_columnar_continuation_t *continuation);
eval_entry_t
eval_stack_pop(eval_stack_t *s);
int
eval_entry_dispose(eval_entry_t *entry);
/* Dispose a relation entry removed from @s, putting it back on the stack if
 * checked destruction is refused.  The caller retains responsibility for
 * deciding whether a cleanup error supersedes its primary error. */
int
eval_stack_dispose_entry(eval_stack_t *s, eval_entry_t *entry);
int
eval_stack_repush_entry(eval_stack_t *s, eval_entry_t *entry);
int
eval_stack_pop_relation(eval_stack_t *s, eval_entry_t *out);
int
eval_stack_drain(eval_stack_t *s);
int
eval_stack_drain_to_session(eval_stack_t *s, wl_col_session_t *sess);
int
wl_columnar_session_retain_eval_entry(wl_col_session_t *sess,
    eval_entry_t *entry);
int
wl_columnar_session_retain_eval_stack(wl_col_session_t *sess,
    eval_stack_t *stack);
int
wl_columnar_session_retry_retained_eval_entries(wl_col_session_t *sess);
int
wl_columnar_kfusion_retry_pending(wl_col_session_t *sess);
bool
wl_columnar_deferred_relation_eligible(const col_rel_t *rel);
int
wl_columnar_session_defer_relation(wl_col_session_t *sess, col_rel_t *rel);
/* Local, serialized evaluator/worker entry. Active-only nesting is allowed;
 * existing pending cleanup must finish before any owner/allocator mutation. */
int
wl_columnar_session_cleanup_ready(wl_col_session_t *sess);
/* Backend-operation boundary only: drain coordinator work before inspecting
 * worker frames, retry workers before the coordinator, and retain unresolved
 * owners. Worker contexts use only local readiness, never coordinator lists.
 * These guards do not activate evaluator frames or protect newly pending
 * cleanup from later rollback/reset paths; caller integration remains pending. */
int
wl_columnar_session_cleanup_ready_quiescent(wl_col_session_t *sess);

int
wl_columnar_session_retry_deferred(wl_col_session_t *sess);
int
wl_columnar_session_transfer_deferred(wl_col_session_t *from,
    wl_col_session_t *to);
int
col_op_consolidate(eval_stack_t *stack, wl_col_session_t *sess);
int
row_cmp_dispatch(const int64_t *a, const int64_t *b, uint32_t ncols);
int
col_op_consolidate_kway_merge(col_rel_t *rel, const uint32_t *seg_boundaries,
    uint32_t seg_count);
#ifdef WL_TEST_CONSOLIDATE_ALLOC_HOOK
typedef bool (*wl_columnar_consolidate_alloc_hook_t)(const char *site);
extern wl_columnar_consolidate_alloc_hook_t
    wl_columnar_consolidate_alloc_hook;
#endif
int
col_op_consolidate_incremental_delta(col_rel_t *rel, uint32_t old_nrows,
    col_rel_t *delta_out, int *out_fast_path);
int
col_op_reduce_weighted(const col_rel_t *src, col_rel_t *dst);
int
col_op_join_weighted(const col_rel_t *lhs, const col_rel_t *rhs,
    uint32_t key_col, col_rel_t *dst);

/* Individual operator functions (columnar/ops.c, called by eval.c) */
int
col_op_variable(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_map(const wl_plan_op_t *op, eval_stack_t *stack, wl_col_session_t *sess);
/* Install on the empty @out the column types col_op_map would give @op's
 * output over @input's schema, without evaluating an expression.  Scratch
 * is admitted under @governor; @out stays untyped where col_op_map's would. */
int
col_op_map_output_types(const wl_plan_op_t *op, const col_rel_t *input,
    wl_col_session_t *sess, wl_columnar_memory_governor_ref_t *governor,
    col_rel_t *out);
int
wl_columnar_filter_op(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
uint32_t wl_columnar_join_cold_source_key(const wl_col_session_t *s,
    const char *relation, const char *key);
bool wl_columnar_join_cold_prefix(const wl_col_session_t *s,
    const wl_plan_relation_t *rp);
int wl_columnar_join_cold_left(wl_col_session_t *s,
    const wl_plan_relation_t *rp,
    eval_stack_t *stack);

int
wl_columnar_join_op(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
#ifdef WL_TEST_RELATION_RESIZE_HOOK
extern void (*wl_columnar_relation_test_after_governed_copy_admission)(
    const col_rel_t *);
#endif
#ifdef WL_TEST_JOIN_CACHE_HOOK
extern void (*wl_columnar_join_test_before_diff_commit)(
    wl_columnar_arrangement_diff_txn_t *);
#endif
int
wl_columnar_antijoin_op(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_concat(eval_stack_t *stack, wl_col_session_t *sess);
int
wl_columnar_semijoin_op(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_reduce(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_k_fusion(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_lftj(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_exchange(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);

/* Differential operator variants (Issue #263) */
int
wl_columnar_join_diff_op(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_join(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_antijoin(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_semijoin(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_join_diff(const wl_plan_op_t *op, eval_stack_t *stack,
    wl_col_session_t *sess);
int
col_op_consolidate_diff(eval_stack_t *stack, wl_col_session_t *sess);

/* ======================================================================== */
/* Evaluator deduplication (columnar/eval_dedup.c)                           */
/* ======================================================================== */

uint64_t
wl_columnar_eval_dedup_row_hash(const col_rel_t *r, uint32_t row);
int wl_columnar_eval_dedup_set_clone_exact(col_rel_t *dst,
    const col_rel_t *src);
int wl_columnar_eval_dedup_set_clone_begin(col_rel_t *dst,
    const col_rel_t *src);
int wl_columnar_eval_dedup_set_clone_slot(col_rel_t *dst,
    const col_rel_t *src, uint32_t slot);
bool
wl_columnar_eval_dedup_set_insert(col_rel_t *r, uint64_t h);
/* Worker transaction path: a duplicate needs no growth.  On error neither
 * the table nor *inserted changes; memory-budget denial may be recorded on
 * the private relation image. */
int wl_columnar_eval_dedup_set_insert_checked(col_rel_t *r, uint64_t h,
    bool *inserted);
#ifdef WL_SESSION_TEST_HOOKS
void wl_columnar_eval_dedup_test_fail_next_growth_alloc(void);
void wl_columnar_eval_dedup_test_fail_next_worker_growth_alloc(void);
bool wl_columnar_eval_dedup_test_worker_growth_alloc_pending(void);
#endif
bool
wl_columnar_eval_dedup_set_contains(const col_rel_t *r, uint64_t h);
int
wl_columnar_eval_dedup_set_init_from_rel(col_rel_t *r);
#ifdef WL_TEST_MUTATION_SET_HOOK
int wl_columnar_eval_test_copy_relation_slice(wl_col_session_t *coord,
    const col_rel_t *src, const char *name, uint32_t begin, uint32_t end,
    wl_columnar_memory_governor_ref_t *governor, col_rel_t **out);
int wl_columnar_eval_test_dedup_append(col_rel_t *image, uint32_t start,
    wl_columnar_memory_governor_ref_t *governor, col_rel_t **delta_out,
    uint32_t *keep);
int wl_columnar_session_test_snapshot_insert(wl_session_t *session,
    const wl_plan_t *plan);
#endif
/* Validate a persistent hash table and clear it after physical free. */
int wl_columnar_eval_dedup_set_bytes(const col_rel_t *r, uint64_t *bytes);
int wl_columnar_eval_dedup_set_metadata_bytes(const col_rel_t *r,
    uint64_t *bytes);
void wl_columnar_eval_dedup_set_clear(col_rel_t *r);

/* ======================================================================== */
/* Evaluator (columnar/eval.c)                                              */
/* ======================================================================== */

int
col_eval_relation_plan(const wl_plan_relation_t *rplan, eval_stack_t *stack,
    wl_col_session_t *sess);
int
retraction_rel_name(const char *rel, char *buf, size_t sz);
bool
has_empty_forced_delta(const wl_plan_relation_t *rp, wl_col_session_t *sess,
    uint32_t iteration);
/* Reports whether @relation_name has new rows in this sub-pass. */
typedef bool (*wl_columnar_eval_plan_delta_probe_fn)(void *ctx,
    const char *relation_name);
bool
wl_columnar_eval_plan_var_skip_scan(const wl_plan_relation_t *rplan,
    uint32_t var_idx, wl_columnar_eval_plan_delta_probe_fn has_delta,
    void *ctx);
typedef struct wl_columnar_eval_serial_framed_host_request
    wl_columnar_eval_serial_framed_host_request_t;
/* Raw synchronous calls pass NULL request. Controlled calls require the aware
 * one-action host contract defined after the framed parent below. */
int
wl_columnar_eval_serial_framed_relation_source(const wl_plan_relation_t *,
    wl_col_session_t *, bool,
    const wl_columnar_eval_serial_framed_host_request_t *,
    wl_session_source_finance_t *);
int
wl_columnar_eval_serial_framed_relation(const wl_plan_relation_t *rp,
    wl_col_session_t *sess, bool recursive,
    const wl_columnar_eval_serial_framed_host_request_t *request);
int
col_eval_stratum(const wl_plan_stratum_t *sp, wl_col_session_t *sess,
    uint32_t stratum_idx);
int
col_eval_stratum_multiworker(const wl_plan_stratum_t *sp,
    wl_col_session_t *coord, uint32_t stratum_idx,
    wl_col_session_t *workers, uint32_t num_workers);
int
col_eval_stratum_tdd(const wl_plan_stratum_t *sp,
    wl_col_session_t *coord, uint32_t stratum_idx);
/* Cleanup-only retry for a coordinator-owned owner-mode delta lifetime. */
int
wl_columnar_eval_tdd_owner_lifetime_retry(wl_col_session_t *coord);
int
wl_columnar_eval_tdd_owner_lifetime_quiesce(wl_col_session_t *coord);
int
wl_columnar_eval_resume_stratum_completion(wl_col_session_t *coord);
int
wl_columnar_session_ensure_workqueue(wl_col_session_t *sess,
    uint32_t active_workers);
int
wl_columnar_session_ensure_tdd_worker_slots(wl_col_session_t *sess,
    uint32_t active_workers);
bool
tdd_stratum_has_idb_self_join(const wl_plan_stratum_t *sp);
bool
tdd_stratum_has_unsupported_lftj(const wl_plan_stratum_t *sp);
uint32_t
stratum_max_idb_body_atoms(const wl_plan_stratum_t *sp);
bool
tdd_stratum_idb_self_join_exchange_aligned(const wl_plan_stratum_t *sp,
    wl_col_session_t *coord);
bool
tdd_stratum_single_idb_join_keys_exchange_aligned(
    const wl_plan_stratum_t *sp);
bool
tdd_stratum_global_read_candidate(const wl_plan_stratum_t *sp);
/* Occurrence bindings for explicit unfused multiway alternatives (#1984).
 * This describes input requirements only, NEVER execution eligibility.
 * Names and ops are borrowed: the unchanged plan must outlive the manifest.
 * Every read in an active slice requires one immutable epoch; only DELTA
 * reads may be partitioned. Unexpanded/K=1 relations return ENOTSUP except
 * the verified CSPA memoryAlias recursive body; its seeds remain excluded.
 */
typedef enum {
    WL_COLUMNAR_EVAL_TDD_PLAN_FULL,
    WL_COLUMNAR_EVAL_TDD_PLAN_DELTA,
    WL_COLUMNAR_EVAL_TDD_PLAN_PREFILTER
} wl_columnar_eval_tdd_plan_read_kind_t;

typedef struct {
    uint32_t op_index; /* absolute index in the owning relation */
    uint32_t source_index; /* same slot across expansion alternatives */
    const char *relation_name;
    bool right_operand;
    wl_columnar_eval_tdd_plan_read_kind_t kind;
} wl_columnar_eval_tdd_plan_read_t;

typedef struct {
    uint32_t alternative;
    uint32_t ordinal; /* rule slice within this alternative */
    uint32_t start;
    uint32_t count;
    uint32_t driver; /* absolute op index; UINT32_MAX for seed/inactive */
    uint32_t read_start;
    uint32_t read_count;
    bool seed;
    bool inactive;
} wl_columnar_eval_tdd_plan_slice_t;

typedef enum {
    WL_COLUMNAR_EVAL_TDD_PLAN_EXPANDED = 0,
    /* Only the verified CSPA memoryAlias positive recursive body. */
    WL_COLUMNAR_EVAL_TDD_PLAN_CSPA_K1,
    /* Issue #2114: insertion instances over wl_plan_stratum_t.bodies. */
    WL_COLUMNAR_EVAL_TDD_PLAN_INSERT,
} wl_columnar_eval_tdd_plan_form_t;

typedef struct {
    wl_columnar_eval_tdd_plan_form_t form;
    uint32_t relation_index;
    uint32_t alternative_count;
    uint32_t block_size;
    uint32_t slice_count;
    uint32_t read_count;
    wl_columnar_eval_tdd_plan_slice_t *slices;
    wl_columnar_eval_tdd_plan_read_t *reads;
    const wl_plan_stratum_t *owner_stratum;
    const wl_plan_relation_t *owner_relation;
    const wl_plan_op_t *owner_ops;
    uint32_t owner_op_count;
} wl_columnar_eval_tdd_plan_manifest_t;

/* Explicit caller snapshot, schema and partition attestations. The caller
 * holds an epoch barrier or pinned views before capture; matching tokens alone
 * do not establish a coherent epoch or global partition coverage. Borrowed
 * names/arrays, plan, manifest and source contents remain immutable. Keep all
 * borrowed data, sources and worker alive through successful finish.
 * Inputs are ordered exactly as the selected manifest slice's reads. */
typedef struct {
    const wl_columnar_eval_tdd_plan_read_t *read;
    col_rel_t *relation;
    const char *name;
    const void *snapshot;
    const void *partition;
    uint64_t view_generation, storage_generation;
    uint32_t worker_index, worker_count;
    uint32_t ncols, declared_ncols;
    bool schema_ok;
    const char *const *column_names;
    const wirelog_column_type_t *column_types;
    wirelog_compound_kind_t compound_kind;
    uint32_t compound_count, compound_arity_len, inline_physical_offset;
    const uint32_t *compound_arity_map;
    bool has_graph_column;
    uint32_t graph_col_idx;
} wl_columnar_eval_tdd_input_t;

typedef struct {
    wl_columnar_eval_tdd_input_t input;
    wl_columnar_source_access_reader_t reader;
} wl_columnar_eval_tdd_input_slot_t;

/* Zero-initialize and keep at a stable address. Never move/copy a live handle.
 * begin evaluates once; finish only cleans up and transfers independent output.
 * Passing NULL for owned_result discards the output during finish.
 * A non-NULL worker after any error means ownership remains here: retain all
 * dependencies and retry finish. A primary evaluation error wins over cleanup
 * refusal. Successful cleanup clears worker even when returning that error. */
struct wl_columnar_eval_tdd_run {
    wl_col_session_t *worker;
    const wl_columnar_eval_tdd_plan_manifest_t *manifest;
    const wl_columnar_eval_tdd_plan_slice_t *slice;
    wl_columnar_eval_tdd_input_slot_t *slots;
    uint32_t input_count;
    wl_columnar_memory_reservation_t reservation;
    wl_columnar_memory_governor_ref_t *governor;
    wl_columnar_eval_stack_cleanup_frame_t *cleanup;
    col_rel_t *output;
    const wl_plan_op_t *current_op;
    bool evaluating;
    int primary_rc;
};

/* Also accepts only the generated valueFlow unary assign seed bodies in
 * alternative zero, with one full two-column input, iteration zero, positive
 * state, worker 0/1 and NULL partition. Other seed shapes/topologies/phases
 * are refused before acquiring resources. The caller enumerates each seed
 * once; this handle does not provide scheduler-wide exactly-once execution.
 * Outputs remain independent raw bags with the existing operator metadata;
 * no UNION consolidation, coordinator publication or signed mode is added. */
int wl_columnar_eval_tdd_run_bound_slice_begin(wl_col_session_t *worker,
    const wl_plan_stratum_t *stratum,
    const wl_columnar_eval_tdd_plan_manifest_t *manifest, uint32_t slice_index,
    const void *snapshot, const void *partition,
    uint32_t worker_index, uint32_t worker_count,
    const wl_columnar_eval_tdd_input_t *inputs, uint32_t input_count,
    wl_columnar_eval_tdd_run_t *run);
int wl_columnar_eval_tdd_run_bound_slice_finish(wl_columnar_eval_tdd_run_t *run,
    col_rel_t **owned_result);
int wl_columnar_eval_tdd_plan_prepare_inputs(wl_col_session_t *worker,
    const wl_plan_stratum_t *stratum,
    const wl_columnar_eval_tdd_plan_manifest_t *manifest, uint32_t slice_index,
    const void *snapshot, const void *partition,
    uint32_t worker_index, uint32_t worker_count,
    const wl_columnar_eval_tdd_input_t *inputs, uint32_t input_count,
    wl_columnar_eval_tdd_run_t *run);
int wl_columnar_eval_tdd_plan_resolve_input(wl_col_session_t *worker,
    const wl_plan_op_t *op, bool right, col_rel_t **relation, bool *delta);

/* out must not own a previous manifest. Every failure leaves it empty.
 * EINVAL: malformed/inconsistent expansion; ENOTSUP: unsupported plan form;
 * ENOMEM/EOVERFLOW: storage failure. No plan or session mutation. */
int wl_columnar_eval_tdd_plan_bindings(const wl_plan_stratum_t *sp,
    uint32_t relation_index, wl_columnar_eval_tdd_plan_manifest_t *out);
/* Validate and count without allocating occurrence arrays. Counts are
 * alternatives, slices and reads; failures leave them zero. */
int wl_columnar_eval_tdd_plan_binding_summary(const wl_plan_stratum_t *sp,
    uint32_t relation_index, uint32_t counts[3]);
void wl_columnar_eval_tdd_plan_bindings_free(
    wl_columnar_eval_tdd_plan_manifest_t *manifest);
/* Issue #2114: the instances that find the derivations an insert adds to the
 * relation @relation_index of @sp, over its lowered body (sp->bodies).  One
 * instance per (rule slice, driving occurrence): the driver reads DELTA,
 * a recognised SEMIJOIN prefilter reads PREFILTER, every other read FULL.
 * With @round0 the drivers are the occurrences of the @changed relations,
 * none of which may be a head of @sp (EINVAL); otherwise they are the
 * occurrences of the heads of @sp.  A rule slice with no driver yields no
 * instance.  FULL means the relation as it stands after the insert, new
 * rows included: that is what lets an instance driven by one changed
 * occurrence also pair new rows with new rows at another.  The manifest
 * has form WL_COLUMNAR_EVAL_TDD_PLAN_INSERT and borrows the body as
 * owner_ops, so op_index and driver index the body, not the relation's
 * rewritten ops, and source_index is relative to the rule slice.
 * ENOTSUP: no recorded bodies, or a body operator outside VARIABLE, JOIN,
 * SEMIJOIN (prefilter only), MAP, FILTER, CONCAT and CONSOLIDATE --
 * negation and aggregation among them.  Every failure leaves @out empty. */
int wl_columnar_eval_tdd_plan_insert_bindings(const wl_plan_stratum_t *sp,
    uint32_t relation_index, const char *const *changed,
    uint32_t changed_count, bool round0,
    wl_columnar_eval_tdd_plan_manifest_t *out);
/* Issue #2114: bring the heads of @sp up to date after rows were appended to
 * the @changed relations, without re-deriving what the heads hold.
 * @changed_delta[c] holds exactly the rows appended to @changed[c], without
 * delta timestamps; @changed[c] itself must already hold them.  Round 0 runs
 * the instances driven by the changed relations; a recursive stratum then
 * runs those driven by its own heads, bound to the rows the previous round
 * added, until a round adds nothing.  Each head ends sorted and unique, and
 * may end without the delta timestamps it had.  On success @head_delta[ri]
 * (sp->relation_count entries) owns the rows head ri gained, without
 * timestamps, or is NULL when it gained none.  Every manifest is built
 * before anything is mutated, so ENOTSUP from the binder leaves the session
 * unchanged; any later failure may leave heads partly updated, and the
 * caller must then re-evaluate in full.
 * Issue #2122: with sess->num_workers > 1 a round's instances run on up to
 * that many worker clones at once, each instance possibly split into ranges
 * of its leading input; the round's outputs are merged after every clone
 * is done, in an unspecified order.  A session whose extension snapshot
 * holds a callback not declared thread-safe runs every round on one clone.
 * The first failure of a round, in clone order, is returned. */
int wl_columnar_eval_tdd_insert_stratum(wl_col_session_t *sess,
    const wl_plan_stratum_t *sp, const char *const *changed,
    col_rel_t *const *changed_delta, uint32_t nchanged,
    col_rel_t **head_delta);
#ifdef WL_SESSION_TEST_HOOKS
/* Called after each round's merge, with the heads already updated; a
 * non-zero return fails the stratum there. */
extern int (*wl_columnar_eval_tdd_insert_test_after_merge)(
    const wl_plan_stratum_t *sp);
/* Issue #2122: called on the coordinator after each round's barrier, before
 * its merge, with the round's instances, the runs they were split into and
 * the tasks that ran them. */
extern void (*wl_columnar_eval_tdd_insert_test_round)(
    const wl_plan_stratum_t *sp, uint32_t units, uint32_t pieces,
    uint32_t tasks);
/* Issue #2122: called by a task before each run it takes, on the thread
 * running it; @first_piece is set for the task's first run of the round. */
extern void (*wl_columnar_eval_tdd_insert_test_piece_start)(uint32_t task,
    uint32_t tasks, bool first_piece);
#endif

typedef struct {
    uint32_t total_segments;
    uint32_t seed_only_segments;
    uint32_t global_read_segments;
    uint32_t unsafe_segments;
    uint32_t max_segment_idb_atoms;
    uint32_t max_segment_join_like;
} wl_tdd_segment_stats_t;
void
tdd_stratum_segment_stats(const wl_plan_stratum_t *sp,
    wl_tdd_segment_stats_t *stats);
bool
tdd_stratum_mixed_slice_candidate(const wl_plan_stratum_t *sp);
int
col_stratum_step_with_delta(const wl_plan_stratum_t *sp, wl_col_session_t *sess,
    uint32_t stratum_idx);
/* Retry after evaluator frames drain. Active evaluation permits nested entry.
 * Pending snapshots survive any refusal; discard is teardown-only while an
 * error remains and never allocates replacement columns. */
int wl_columnar_eval_delta_rollback_retry(wl_col_session_t *sess);
int wl_columnar_eval_delta_rollback_discard(wl_col_session_t *sess);
bool wl_columnar_eval_delta_rollback_active(const wl_col_session_t *sess);
/* Rotation strategies defer frontier GC while snapshots own compound IDs.
 * Only successful evaluation replays one coalesced request after release. */
bool wl_columnar_eval_delta_defer_gc(wl_col_session_t *sess);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_delta_test_after_eval)(wl_col_session_t *sess);
extern void (*wl_columnar_eval_delta_test_before_direct_event)(
    wl_col_session_t *, uint32_t);
extern int (*wl_columnar_eval_delta_test_retraction_eval)(
    const wl_plan_stratum_t *, wl_col_session_t *, uint32_t);
int wl_columnar_eval_delta_test_retraction_step(const wl_plan_stratum_t *,
    wl_col_session_t *, uint32_t);
extern void (*wl_columnar_kfusion_test_clone)(wl_col_session_t *parent,
    wl_col_session_t *child, bool before);
extern void (*wl_columnar_kfusion_test_before_cleanup)(
    wl_col_session_t *sess, eval_stack_t *stack, col_rel_t **results,
    uint32_t result_count);
extern int (*wl_columnar_kfusion_test_submit)(wl_work_queue_t *wq,
    void (*work_fn)(void *ctx), void *ctx);
#endif
void
wl_columnar_delta_events_clear(wl_col_session_t *sess);
void
wl_columnar_delta_events_publish(wl_col_session_t *sess);
/* Normalize a relation through an admitted private candidate.
 * Refusal retains the original target and any pending candidate cleanup. */
int
wl_columnar_eval_delta_consolidate(col_rel_t *target, wl_col_session_t *sess);
/* Defined in columnar/eval_serial.c; also called from the TDD final-merge
 * path in columnar/eval.c. */
int
wl_columnar_eval_serial_canonicalize_aggregates(const wl_plan_stratum_t *sp,
    wl_col_session_t *sess);
/* Defined in columnar/eval.c; called from the serial stratum evaluator in
 * columnar/eval_serial.c. */
int
wl_columnar_eval_nonrec_relation_parallel(const wl_plan_relation_t *rp,
    wl_col_session_t *coord);
/* The bytes of a TDD channel's side buffers for @workers lanes and @nrels
 * relations: the channel object, its lanes, and the consumer list heads
 * with one staging flag each.  Returns 0, EINVAL for zero workers, or
 * EOVERFLOW. */
int
wl_columnar_eval_tdd_channel_side_bytes(uint32_t workers, uint32_t nrels,
    uint64_t *bytes);
#ifdef WL_TEST_ALLOC_WRAP
int wl_columnar_eval_test_reserve_channel(wl_col_session_t *coord,
    uint32_t workers, uint32_t nrels, uint64_t *bytes);
int wl_columnar_eval_test_create_channel(wl_col_session_t *coord,
    uint32_t workers, uint32_t nrels);
#endif
int
wl_columnar_eval_tdd_matrix_size(uint32_t W, uint32_t nrels,
    size_t element_size, size_t *out);
int
wl_columnar_eval_checked_size_mul(size_t count, size_t element_size,
    size_t *out);
int
wl_columnar_eval_checked_count_inc(uint32_t count, size_t *out);
int
wl_columnar_eval_checked_row_add(uint32_t total, uint32_t addend,
    uint32_t *out);
int
wl_columnar_eval_checked_hash_capacity(uint32_t nrows, uint32_t *out);
int
tdd_sorted_merge_append(col_rel_t *dst, col_rel_t *src);

/* ======================================================================== */
/* Relation Partitioning (columnar/partition.c)                             */
/* ======================================================================== */

/*
 * col_rel_partition_by_key:
 * Partition src into num_workers disjoint sub-relations by hashing
 * the specified key columns with XXH3_64bits.
 *
 * Two-pass algorithm: count rows per bucket, allocate exact-sized
 * partitions, then scatter.  out_parts must point to an array of
 * num_workers col_rel_t* slots (caller-provided).  On success each
 * slot holds a newly allocated relation; caller owns all.
 *
 * Returns 0 on success, EINVAL for bad arguments, ENOMEM on failure.
 */
int
col_rel_partition_by_key(const col_rel_t *src,
    const uint32_t *key_cols, uint32_t key_count,
    uint32_t num_workers, col_rel_t **out_parts);

/*
 * col_rel_merge_partitions:
 * Concatenate num_workers partition relations into a single output.
 * Rows are appended in partition order.  Schema copied from parts[0].
 * Input partitions are NOT destroyed (caller retains ownership).
 *
 * Returns 0 on success, EINVAL for bad arguments, ENOMEM on failure.
 */
int
col_rel_merge_partitions(col_rel_t **parts, uint32_t num_workers,
    col_rel_t **out);

/*
 * col_rel_exchange_partition:
 * Graph-aware EXCHANGE partitioning wrapper for col_rel_partition_by_key.
 *
 * When src->has_graph_column == true AND num_workers > 1, this function
 * partitions by src->graph_col_idx (a single-column key), ignoring
 * fallback_key_cols entirely.  This ensures that all rows belonging to
 * the same named graph land on the same worker, which is required for
 * correct graph-scoped join and aggregation semantics.
 *
 * When src->has_graph_column == false OR num_workers == 1, the call
 * forwards unchanged to col_rel_partition_by_key with fallback_key_cols.
 *
 * Co-partitioning correctness: each relation is routed based on its OWN
 * has_graph_column flag.  If both sides of a join carry the flag, both
 * route by graph_id and co-partitioning is preserved.  If only one side
 * carries the flag the fallback key is used for that side, matching the
 * existing join-key co-partitioning contract.
 *
 * Returns 0 on success, EINVAL for bad arguments, ENOMEM on failure.
 */
int
col_rel_exchange_partition(const col_rel_t *src,
    const uint32_t *fallback_key_cols, uint32_t fallback_key_count,
    uint32_t num_workers, col_rel_t **out_parts);

/* ======================================================================== */
/* Per-Worker Session State (columnar/session.c, Issue #315)                */
/* ======================================================================== */

/*
 * col_worker_session_create:
 * Create an isolated worker session from a coordinator session.
 * The worker owns independent rels[] (populated with partitions),
 * eval_arena, delta_pool, arrangement clones, and mat_cache.
 * Borrowed fields (plan, frontier_ops) are shared read-only.
 *
 * out_worker must be caller-allocated (e.g., from calloc'd array).
 * It must be distinct from coordinator; self-cloning returns EINVAL.
 * partitions[] ownership transfers to the worker on success;
 * on failure, partitions[] are NOT consumed (caller must free).
 * Precondition (#1661): no non-NULL partition may itself be pool_owned or
 * arena_owned; such a partition is refused with EINVAL before any transfer,
 * because this path bypasses session_add_rel and therefore its pool/arena
 * promotion, and that storage cannot safely outlive its allocator in the
 * worker registry.  This checks the partition's OWN flags only -- a
 * shared-view alias whose storage owner is pool/arena-backed carries clear
 * flags and is refused separately, by the lease prepare inside
 * wl_columnar_session_adopt_shared_view.  NULL slots are permitted and
 * skipped.
 *
 * Returns 0 on success, EINVAL for bad arguments, ENOMEM on failure.
 */
int
col_worker_session_create(wl_col_session_t *coordinator,
    uint32_t worker_id, col_rel_t **partitions,
    uint32_t num_partitions, wl_col_session_t *out_worker);

/*
 * col_worker_session_destroy:
 * Free all resources owned by a worker session.  Does NOT free borrowed
 * resources (plan, frontier_ops) or the out_worker struct itself.
 * Safe to call on a partially-initialized worker (all owned pointers
 * are pre-NULLed during create).  Zeroes the struct on completion.
 */
int
col_worker_session_destroy(wl_col_session_t *worker);

/* Publish a shared view owned by sess and retain its source for exactly the
 * borrower's registered lifetime.  Repeated publication from the same source
 * reuses the stable lease; changing source replaces it transactionally. */
int
wl_columnar_session_install_shared_view(wl_col_session_t *sess,
    col_rel_t *dst, const col_rel_t *src);
int
wl_columnar_session_adopt_shared_view(wl_col_session_t *sess,
    col_rel_t *borrower);
int
wl_columnar_session_retire_source_lease(wl_col_session_t *sess,
    col_rel_t *borrower);

/*
 * col_detect_physical_memory: Detect total physical RAM in bytes (Issue #221).
 * Returns 0 if the platform is not supported or detection fails.
 */
uint64_t
col_detect_physical_memory(void);

/*
 * col_compute_worker_cap: RAM-aware worker cap formula (Issue #409).
 *
 * Returns the maximum safe number of workers for a system with ram_bytes of
 * physical RAM, using the formula:
 *
 *   cap = min((uint32_t)sqrt(ram_bytes / 8), ram_bytes / 40MB, 4096)
 *
 * Rationale:
 *   - sqrt(RAM/8): keeps W^2 * 8B exchange matrix below RAM/8.
 *   - RAM/40MB:    keeps per-worker linear cost (20MB arena + overhead) below
 *                  half of RAM, leaving headroom for data.
 *   - 4096:        absolute ceiling (W^2 * 8B = 128MB at W=4096; manageable).
 *
 * Returns 1 when ram_bytes == 0 (undetected RAM; caller falls back to env or
 * default).
 *
 * This function is pure (no side effects) and intended for unit testing.
 * col_session_create calls it internally via col_detect_physical_memory().
 */
uint32_t
col_compute_worker_cap(uint64_t ram_bytes);

/* ======================================================================== */
/* TDD Distributed Evaluator (Issue #410)                                   */
/* ======================================================================== */

/*
 * col_eval_tdd_worker_ctx_t:
 * Per-worker context for one sub-pass of distributed stratum evaluation.
 *
 * For non-recursive workers (tdd_worker_nonrecursive_fn): only sp,
 * worker_sess, stratum_idx, and rc are used.
 *
 * For recursive sub-pass workers (tdd_worker_subpass_fn): all fields.
 * The coordinator allocates delta_rels[nrels] before dispatch; the worker
 * fills in entries for each relation that produced new tuples.  Ownership
 * of each delta_rels[ri] (heap-allocated via col_rel_new_like) transfers
 * to the coordinator after the workqueue barrier.
 */
typedef struct {
    uint32_t relation_index;       /* target relation in stratum      */
    const wl_plan_op_t *ops;       /* borrowed executable rule slice  */
    uint32_t op_count;
    bool tdd_safe;                 /* true: worker TDD, false: fallback */
} wl_tdd_rule_slice_t;

typedef struct col_eval_tdd_worker_ctx {
    const wl_plan_stratum_t *sp;   /* borrowed: stratum plan          */
    wl_col_session_t *worker_sess; /* borrowed: isolated worker       */
    const wl_tdd_rule_slice_t *rule_slices; /* optional mixed TDD slices */
    uint32_t rule_slice_count;
    uint32_t stratum_idx;
    uint32_t eff_iter;             /* effective sub-pass index (set by coord) */
    bool any_new;                  /* OUT: produced >=1 new tuple     */
    bool all_empty_delta;          /* OUT: all FORCE_DELTA empty, skipped */
    bool force_diff;               /* IN: enable diff from eff_iter 0 (BDX) */
    bool outbound_only;            /* IN: emit deltas without local IDB append */
    col_rel_t **delta_rels;        /* OUT: produced deltas [nrels], coord frees */
    uint64_t runtime_ns;           /* OUT: worker sub-pass wall runtime */
    int rc;                        /* OUT: return code                */
    const char *refusal;           /* OUT: why rc was set, or NULL     */
} col_eval_tdd_worker_ctx_t;

/* Release the coordinator's TDD channel and its side buffers.  Every batch
 * still queued, on a consumer list or on the discard list is disposed, and
 * each queued batch's CHANNEL charge is freed (a taken batch's was freed at
 * its take).  A no-op while an owner lifetime record holds the channel; the
 * record releases it instead.  Also a no-op while a lane is open, because a
 * running producer may still touch the channel. */
void wl_columnar_eval_tdd_dispose_channel(wl_col_session_t *coord);

/* Teardown: cancel the coordinator's TDD channel, and the one its owner
 * lifetime record holds, if a round is open, so a producer waiting for
 * space returns and a following drain of the workqueue completes.  Call it
 * before any teardown wait on the workqueue. */
void wl_columnar_eval_tdd_channel_cancel_for_teardown(wl_col_session_t *sess);

/*
 * COL_FILTER_SEL_SLACK:
 * Spare uint32_t slots the caller must add to a col_filter_select_rows()
 * selection buffer.  The AVX2 left-pack writes a full 8-lane vector even
 * when fewer lanes are selected, so the buffer needs room for one whole
 * vector past the largest possible selection count.
 */
#define COL_FILTER_SEL_SLACK 8u

/*
 * COL_FILTER_TILE:
 * Rows scanned per selection pass before the passing ones are materialized.
 *
 * Tiling exists because scanning the whole column first and materializing
 * afterwards measured slower than the fused loop on wide relations: by the
 * time materialization reached a row it had been evicted.
 *
 * The exact value matters far less than having one.  Sweeping 256 / 1024 /
 * 4096 / 16384 over 100k- and 1M-row relations barely moved scan throughput,
 * so the win comes from separating the vectorizable scan from the
 * materialize, not from fitting any particular cache level.  1024 is chosen
 * because larger tiles cost more on 8-column relations at moderate
 * selectivity: measured at 1M rows and 25% selectivity, 0.94x of the fused
 * loop at 4096 and 0.92x at 16384, against ~0.96x here.  It halves that
 * regression rather than removing it; smaller tiles recover no more of it
 * and give up throughput on narrow relations.
 */
#define COL_FILTER_TILE 1024u

/*
 * col_filter_select_rows:
 * Scan a contiguous int64_t column and record the indices of passing rows.
 *
 * @col_a    left operand column, @nrows entries (required)
 * @col_b    right operand column when comparing two columns, else NULL
 * @const_b  right operand value when @col_b is NULL
 * @nrows    number of rows to scan
 * @cmp_op   WL_PLAN_EXPR_CMP_* opcode; an unrecognized opcode selects nothing
 * @out_sel  receives the passing row indices in ascending order; must have
 *           capacity @nrows + COL_FILTER_SEL_SLACK
 *
 * Returns the number of indices written to @out_sel.
 *
 * Exposed (rather than static) so tests and benchmarks can drive the kernel
 * directly.  It is not part of the public API and is not exported: the
 * project builds with hidden symbol visibility.
 */
uint32_t
col_filter_select_rows(const int64_t *col_a, const int64_t *col_b,
    int64_t const_b, uint32_t nrows, wl_plan_expr_tag_t cmp_op,
    uint32_t *out_sel);

/*
 * ARR_HASH_TILE:
 * Rows hashed per arr_hash_rows_batch() call when a caller tiles a large
 * range.  Bounds the scratch buffer an arrangement build needs.
 */
#define ARR_HASH_TILE 1024u

/*
 * arr_hash_rows_batch:
 * Hash rows [@row_begin, @row_end) of @rel over @key_count key columns,
 * writing @row_end - @row_begin results to @out_hashes, indexed RELATIVE to
 * @row_begin.
 *
 * Returns the low 32 bits of the arrangement's FNV-1a chain, UNMASKED.  A
 * caller reproduces the arrangement bucket with `out_hashes[j] & (nbuckets -
 * 1)`, which must equal what arr_hash_key() computes on the probe side for
 * the same key values.
 *
 * Only the low 32 bits are needed because nbuckets is a uint32_t, so the
 * mask can never expose more; and those low bits are exactly reproducible in
 * 32-bit arithmetic, since multiplication modulo 2^32 depends only on its
 * operands modulo 2^32.  See the definition for the full argument.
 *
 * Bucket equality is load-bearing, not incidental: arr_update_incremental()
 * extends a cached arrangement in place, so rows indexed by one code path are
 * probed against rows indexed by another.  A divergence would leave earlier
 * rows in buckets the probe never visits and silently drop join matches.
 *
 * @row_end must not exceed rel->nrows; row_begin >= row_end is a no-op.  No
 * slack is required in @out_hashes: the vector loop runs only while eight
 * whole rows remain and writes exactly eight lanes for them.
 *
 * Exposed (not static) so tests and benchmarks can drive it directly.  Not
 * public API and not exported: the library builds with hidden visibility.
 */
void
arr_hash_rows_batch(const col_rel_t *rel, uint32_t row_begin, uint32_t row_end,
    const uint32_t *key_cols, uint32_t key_count, uint32_t *out_hashes);

#ifdef WL_SESSION_TEST_HOOKS
/* Test-only seam for exercising MAP input cleanup refusal. */
extern void (*wl_columnar_ops_test_before_map_dispose)(eval_stack_t *,
    eval_entry_t *);
extern bool wl_columnar_ops_test_map_fail_output_alloc;
extern void (*wl_columnar_ops_test_before_reduce_dispose)(eval_stack_t *,
    eval_entry_t *);
extern void (*wl_columnar_filter_test_before_filter_dispose)(eval_stack_t *,
    eval_entry_t *);
/* Probe-set and SEMIJOIN/ANTIJOIN emit observation points; they also count
 * the calls the standalone operators make. */
extern atomic_uint_fast64_t wl_columnar_join_test_probe_set_build_calls;
extern atomic_uint_fast64_t wl_columnar_join_test_probe_set_build_denials;
extern atomic_uint_fast64_t wl_columnar_join_test_probe_set_reserved_at_entry;
extern atomic_uint_fast64_t wl_columnar_join_test_probe_set_admitted_bytes;
extern atomic_uint_fast64_t wl_columnar_join_test_probe_emits;
extern void (*wl_columnar_join_test_before_probe_emit)(const col_rel_t *left);
extern bool wl_columnar_ops_test_reduce_fail_output_alloc;
extern bool wl_columnar_diff_test_fail_copy_alloc;
extern bool wl_columnar_diff_test_fail_copy_append;
extern bool wl_columnar_merge_test_fail_copy_alloc;
extern bool wl_columnar_merge_test_fail_copy_append;
#endif

/* Opt-in numeric FILTER with original frame-owned cooperative cleanup.
 * Each YIELD resumes on a later host dispatch on the same native thread.
 * Keep session/source/backing alive until DONE acknowledgement. A synchronous
 * pump cannot claim the per-dispatch bound. NULL control delegates raw FILTER.
 * Status contains no authority; protocol errno never consumes a live context. */
typedef enum {
    WL_COLUMNAR_FILTER_PROGRESS_NOT_STARTED = 0,
    WL_COLUMNAR_FILTER_PROGRESS_YIELD,
    WL_COLUMNAR_FILTER_PROGRESS_RETAINED,
    WL_COLUMNAR_FILTER_PROGRESS_DONE
} wl_columnar_filter_progress_t;

typedef struct {
    wl_columnar_filter_progress_t progress;
    int execution_result;
    int cleanup_result;
    int semantic_result;
    bool committed;
} wl_columnar_filter_status_t;

typedef enum {
    WL_COLUMNAR_RELATION_PRIVATE_BATCH_NEW = 0,
    WL_COLUMNAR_RELATION_PRIVATE_BATCH_OWNER,
    WL_COLUMNAR_RELATION_PRIVATE_BATCH_DESCRIPTOR,
    WL_COLUMNAR_RELATION_PRIVATE_BATCH_CLEAR,
    WL_COLUMNAR_RELATION_PRIVATE_BATCH_FINAL,
    WL_COLUMNAR_RELATION_PRIVATE_BATCH_DONE
} wl_columnar_relation_private_batch_phase_t;

typedef struct wl_columnar_relation_private_batch_drain {
    struct wl_columnar_relation_private_batch_drain *identity;
    wl_columnar_relation_append_batch_t *batch;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid;
    uint64_t bound_nonce;
    col_rel_t *bound_relation;
    wl_columnar_relation_private_batch_phase_t phase;
    uint32_t cursor;
    int release_error;
    bool result_saved;
} wl_columnar_relation_private_batch_drain_t;

/* Original initialized private self-owned scalar B2 output only. This API
 * drains genuine partial acquisition/renewal states, including owner_count0
 * with descriptor authority. Each invocation retires at most one writer or
 * clears at most eight meaningful fields. No control access or debit. Caller
 * keeps original storage/relation alive and serializes the native owner.
 * Nonzero protocol/release status preserves remaining original authority.
 * done means authority drained, not semantic success; first result is latched
 * independently. Existing raw and B2 end entrypoints retain their contracts. */
void wl_columnar_relation_private_batch_drain_init(
    wl_columnar_relation_private_batch_drain_t *);
int wl_columnar_relation_private_batch_drain_step(
    wl_columnar_relation_private_batch_drain_t *,
    wl_columnar_relation_append_batch_t *, int, bool *);
/* LFTJ cleanup funding is distinct from Original. Physical release failures
 * remain on release_error with done=false for retry; protocol errors return. */
int wl_columnar_relation_private_batch_drain_step_funded(
    wl_columnar_relation_private_batch_drain_t *,
    wl_columnar_relation_append_batch_t *, int, bool *,
    wl_evaluation_control_t *, uint64_t);

typedef enum {
    WL_COLUMNAR_FILTER_STAGE_INERT = 0,
    WL_COLUMNAR_FILTER_STAGE_RUNNING,
    WL_COLUMNAR_FILTER_STAGE_JOIN_BATCH,
    WL_COLUMNAR_FILTER_STAGE_JOIN_RIGHT_SOURCE,
    WL_COLUMNAR_FILTER_STAGE_JOIN_PHYSICAL,
    WL_COLUMNAR_FILTER_STAGE_JOIN_CREDIT,
    WL_COLUMNAR_FILTER_STAGE_JOIN_REFERENCE,
    WL_COLUMNAR_FILTER_STAGE_JOIN_CLEAR,
    WL_COLUMNAR_FILTER_STAGE_TABLE_PROGRAM,
    WL_COLUMNAR_FILTER_STAGE_TABLE_PHYSICAL,
    WL_COLUMNAR_FILTER_STAGE_TABLE_CREDIT,
    WL_COLUMNAR_FILTER_STAGE_TABLE_REFERENCE,
    WL_COLUMNAR_FILTER_STAGE_TABLE_CLEAR,
    WL_COLUMNAR_FILTER_STAGE_BATCH,
    WL_COLUMNAR_FILTER_STAGE_PROGRAM,
    WL_COLUMNAR_FILTER_STAGE_PHYSICAL,
    WL_COLUMNAR_FILTER_STAGE_CREDIT,
    WL_COLUMNAR_FILTER_STAGE_REFERENCE,
    WL_COLUMNAR_FILTER_STAGE_SOURCE,
    WL_COLUMNAR_FILTER_STAGE_DECIDE,
    WL_COLUMNAR_FILTER_STAGE_JOIN_DECIDE,
    WL_COLUMNAR_FILTER_STAGE_CONTROL,
    WL_COLUMNAR_FILTER_STAGE_FINISH,
    WL_COLUMNAR_FILTER_STAGE_RESET,
    WL_COLUMNAR_FILTER_STAGE_SCALAR_TABLE_PHYSICAL,
    WL_COLUMNAR_FILTER_STAGE_SCALAR_TABLE_CREDIT,
    WL_COLUMNAR_FILTER_STAGE_DONE
} wl_columnar_filter_stage_t;

/* Original, nonmovable owner of a compiled MAP table. Only initialized_slots
* are discoverable. Each slot's first retirement is admitted before it enters
* that prefix; fixed physical/credit/reference retirement precedes allocation.
* The table reference keeps the governor alive independently of source input.
* A cleared table has no resources; dormant credit bits are not authority. */
typedef struct {
    wl_columnar_expr_attempt_numeric_t **programs;
    wl_columnar_expr_attempt_scalar_t **scalars;
    wl_columnar_memory_reservation_t scalar_credit;
    uint32_t scalar_initialized_slots;
    bool scalar_allocated, scalar_admitted, scalar_committed;
    uint32_t initialized_slots;
    uint32_t retirement_cursor;
    wl_columnar_memory_reservation_t credit;
    wl_columnar_memory_governor_ref_t *governor;
    bool initialized;
    bool allocated;
    bool admitted;
    bool committed;
    bool ref_held;
} wl_columnar_filter_program_table_t;

/* Original fixed JOIN scratch owner. Only initialized records may own
 * credits; each record retains its own governor until physical-before-credit
 * retirement completes. Never copy a live reservation or original record. */
typedef struct {
    void *physical;
    wl_columnar_memory_reservation_t credit;
    wl_columnar_memory_governor_ref_t *governor;
    bool initialized, allocated, admitted, committed, ref_held;
} wl_columnar_join_scratch_t;

#define WL_COLUMNAR_JOIN_SCRATCH_COUNT 3u

/* Dedicated two-input CONCAT continuation. Original storage never moves;
 * A binary transaction owns candidate/retired entries and the control pin. */
typedef struct wl_columnar_merge_concat_context {
    struct wl_columnar_merge_concat_context *identity;
    wl_columnar_eval_stack_cleanup_frame_t *frame;
    wl_col_session_t *session;
    wl_evaluation_control_t *control;
    uint64_t attempt_id;
    const void *numeric_owner;
    unsigned phase;
    int execution_result, cleanup_result;
    col_rel_t *private_output; /* Borrow only; erased before binary disposal. */
    bool committed, busy;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid;
    bool source_initialized[2], batch_initialized;
    wl_columnar_relation_scalar_source_t sources[2];
    wl_columnar_relation_append_batch_t batch;
    wl_columnar_relation_private_batch_drain_t drain;
    wl_columnar_join_scratch_t scratch;
} wl_columnar_merge_concat_context_t;

int wl_columnar_eval_stack_concat_context_owned(
    wl_columnar_eval_stack_cleanup_frame_t *,
    wl_columnar_merge_concat_context_t **, const void *);
/* All start/step/retry/ACK actions use a fresh independent HOST768 allowance.
 * The wrapper admits384; binary finish/ACK separately admits384 when used.
 * Inputs and plan/session/governors remain immutable/live until ACK. Scalar,
 * equal-width, noTS, ordinary serial materialization only. NULL control/raw
 * compatibility requires NULL numeric owner. Output is flat/non-delta; input
 * segment arrays remain owned by the binary transaction through disposal. */
int wl_columnar_merge_concat_attempt_start(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_merge_concat_attempt_start_owned(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *,
    wl_evaluation_control_t *, uint64_t, const void *);
int wl_columnar_merge_concat_attempt_step_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_status_t *,
    wl_evaluation_control_t *, uint64_t, const void *);
int wl_columnar_merge_concat_attempt_ack_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_evaluation_control_t *,
    uint64_t, const void *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_merge_test_concat_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint64_t);
extern int wl_columnar_merge_test_concat_fail_allocation;
#endif

typedef enum {
    WL_COLUMNAR_JOIN_DISPOSITION_REPLACE,
    WL_COLUMNAR_JOIN_DISPOSITION_MISSING_EXACT,
    WL_COLUMNAR_JOIN_DISPOSITION_ANTI_KEEP_ALL
} wl_columnar_join_disposition_t;

typedef struct wl_columnar_filter_context {
    struct wl_columnar_filter_context *identity;
    wl_columnar_eval_stack_cleanup_frame_t *frame;
    wl_col_session_t *session;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid;
    bool busy;
    wl_columnar_filter_stage_t stage;
    wl_evaluation_control_t *control;
    uint64_t attempt_id;
    bool pin_owned;
    int execution_result, cleanup_result, semantic_result;
    uint32_t row, width, nrows;
    bool committed, unary_started;
    bool source_initialized, batch_initialized, drain_initialized;
    bool heap, admitted, credit_committed, ref_held;
    wl_columnar_relation_scalar_source_t source;
    wl_columnar_relation_append_batch_t batch;
    wl_columnar_relation_private_batch_drain_t batch_drain;
    wl_columnar_expr_attempt_numeric_t *program;
    wl_columnar_expr_attempt_scalar_t *scalar_program;
    wl_columnar_memory_reservation_t credit;
    wl_columnar_memory_governor_ref_t *governor;
    col_rel_t *output;
    /* Constructor provenance, erased before any output disposal. */
    col_rel_t *private_output;
    int64_t inline_values[16];
    int64_t *values;
    wl_columnar_filter_program_table_t table;
    /* Fixed original JOIN ownership, inactive for FILTER/MAP. join_initialized
     * remains true until B2/right/readers and all scratch records are drained. */
    bool join_initialized, join_right_initialized;
    bool join_decision_pending, join_result_is_delta, join_metadata_busy;
    wl_columnar_join_disposition_t join_disposition;
    const wl_plan_op_t *join_operation;
    col_relation_snapshot_t join_input_snapshot;
    uint32_t join_retirement_cursor;
    wl_columnar_relation_scalar_source_t join_right;
    /* Only owned ordinary JOIN admits authentic unspecialized descriptors.
     * The tag never grants scalar gather authority. Cleared after real END. */
    bool source_bare, join_right_bare;
    wl_columnar_relation_empty_source_t source_empty_reader, join_empty_reader;
    wl_columnar_join_scratch_t join_scratch[WL_COLUMNAR_JOIN_SCRATCH_COUNT];
} wl_columnar_filter_context_t;

/* Address-bound ROW resources. Local legacy records and the selected
 * persistent capsule use the same forward algorithm. Never move live records. */
typedef struct {
    wl_columnar_memory_reservation_t scratch_credit;
    wl_columnar_memory_governor_growth_commit_prepared_t governor;
    wl_columnar_mem_ledger_publication_prepared_t ledger;
    wl_columnar_mem_ledger_publication_request_t requests[2];
    int64_t inline_row[16];
    int64_t *captured;
    int64_t **columns;
    col_delta_timestamp_t *timestamps;
    uint32_t allocated_columns;
    bool scratch_held;
    bool scratch_owned;
    bool growth_held;
    bool published;
    uint32_t capacity;
    uint32_t timestamp_capacity;
    uint32_t rows;
    uint64_t storage_generation;
    uint64_t view_generation;
    uint64_t row_bytes;
    uint64_t lane_bytes;
    uint64_t table_bytes;
    uint64_t old_lanes;
    uint64_t new_lanes;
    uint64_t old_ts;
    uint64_t new_ts;
    uint64_t incoming;
    uint64_t old_payload;
    uint64_t final_payload;
    uint64_t covered;
    unsigned request_count;
} wl_columnar_relation_row_t;

typedef struct {
    wl_columnar_memory_reservation_t credit;
    wl_columnar_memory_governor_ref_t *governor;
    int64_t inline_row[16];
    int64_t *values;
    uint64_t bytes;
    uint32_t width;
    bool ref_held;
    bool credit_held;
    bool allocated;
} wl_columnar_relation_batch_capture_t;

/* Existing numeric prefix prices, shared by the selected component entry. */
enum {
    WL_COLUMNAR_RELATION_SCALAR_SOURCE_SELECTED_WORK = 192,
    WL_COLUMNAR_RELATION_SCALAR_SOURCE_ROW_CALL_WORK = 128,
    WL_COLUMNAR_RELATION_ROW_RETIRE_ACTION_WORK = 1
};

typedef enum {
    WL_COLUMNAR_RELATION_ROW_DEBT_IDLE,
    WL_COLUMNAR_RELATION_ROW_DEBT_FORWARD,
    WL_COLUMNAR_RELATION_ROW_DEBT_CANCEL_LEDGER,
    WL_COLUMNAR_RELATION_ROW_DEBT_CANCEL_GOVERNOR,
    WL_COLUMNAR_RELATION_ROW_DEBT_IMAGE_LANE,
    WL_COLUMNAR_RELATION_ROW_DEBT_IMAGE_TABLE,
    WL_COLUMNAR_RELATION_ROW_DEBT_IMAGE_TIMESTAMPS,
    WL_COLUMNAR_RELATION_ROW_DEBT_REFUND_BEGIN,
    WL_COLUMNAR_RELATION_ROW_DEBT_REFUND_STEP,
    WL_COLUMNAR_RELATION_ROW_DEBT_DOWNSIZE_BEGIN,
    WL_COLUMNAR_RELATION_ROW_DEBT_DOWNSIZE_STEP,
    WL_COLUMNAR_RELATION_ROW_DEBT_CAPTURE_BUFFER,
    WL_COLUMNAR_RELATION_ROW_DEBT_CAPTURE_CREDIT,
    WL_COLUMNAR_RELATION_ROW_DEBT_CAPTURE_REF,
    WL_COLUMNAR_RELATION_ROW_DEBT_UNBIND,
    WL_COLUMNAR_RELATION_ROW_DEBT_DONE
} wl_columnar_relation_row_debt_phase_t;

typedef enum {
    WL_COLUMNAR_RELATION_ROW_DEBT_PREPUBLICATION_STAGED,
    WL_COLUMNAR_RELATION_ROW_DEBT_POSTPUBLICATION_DISPLACED
} wl_columnar_relation_row_debt_mode_t;

typedef enum {
    WL_COLUMNAR_RELATION_ROW_DEBT_NO_RESOURCE,
    WL_COLUMNAR_RELATION_ROW_DEBT_CAPTURE_ONLY,
    WL_COLUMNAR_RELATION_ROW_DEBT_ROW_RESOURCES
} wl_columnar_relation_row_debt_progress_t;

typedef struct {
    int execution_result, cleanup_result;
    bool row_published, cleanup_pending, complete;
} wl_columnar_relation_row_debt_status_t;

/* Caller-owned final address, from init through terminal unbind. Header only
 * is readable before each corresponding payload-ready marker. The frame
 * anchor is nonowning; the caller must retain this storage until DONE. */
typedef struct wl_columnar_relation_row_debt {
    struct wl_columnar_relation_row_debt *identity;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid;
    wl_columnar_relation_row_debt_phase_t phase;
    wl_columnar_relation_row_debt_mode_t mode;
    wl_columnar_relation_row_debt_progress_t progress;
    wl_columnar_eval_stack_cleanup_frame_t *frame;
    const void *numeric_owner;
    wl_columnar_filter_context_t *context;
    col_rel_t *target;
    wl_evaluation_control_t *original_control;
    uint64_t original_id, original_control_identity, batch_nonce;
    wl_columnar_filter_stage_t origin_stage;
    int execution_result, cleanup_result;
    bool row_published, growth_published;
    bool capture_ready, row_ready, refund_ready, downsize_ready, intent_valid;
    /* Same-call reentry exclusion; never a resource permit. */
    bool active_call;
    int64_t **image_columns;
    col_delta_timestamp_t *image_timestamps;
    uint32_t image_extent, image_cursor;
    wl_columnar_relation_row_debt_phase_t selected_phase;
    uint32_t selected_cursor;
    /* Retirement attempt observation (wrap allowed), never permission. */
    unsigned action;
    wl_columnar_relation_row_t row;
    wl_columnar_relation_batch_capture_t capture;
    wl_columnar_memory_growth_refund_attempt_t refund;
    wl_columnar_memory_downsize_attempt_t downsize;
} wl_columnar_relation_row_debt_t;

void wl_columnar_relation_row_debt_init(wl_columnar_relation_row_debt_t *);
int wl_columnar_relation_row_debt_reset(wl_columnar_relation_row_debt_t *);
int wl_columnar_filter_row_component_append_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_columnar_relation_row_debt_t *, const int64_t *,
    wl_columnar_relation_row_debt_status_t *);
/* One fresh dedicated financier generation per invocation; no incoming
 * assigned SOURCE promise. This caller precondition is not a native permit. */
int wl_columnar_filter_row_debt_step_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_columnar_relation_row_debt_t *, wl_evaluation_control_t *, uint64_t,
    wl_columnar_relation_row_debt_status_t *);
/* DONE accepts NULL frame/owner and reads only fixed self/thread/status. */
int wl_columnar_filter_row_debt_status_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    const wl_columnar_relation_row_debt_t *,
    wl_columnar_relation_row_debt_status_t *);
int wl_columnar_eval_stack_row_debt_bind_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_columnar_relation_row_debt_t *, uint64_t,
    wl_columnar_filter_context_t **);
int wl_columnar_eval_stack_row_debt_context_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    const wl_columnar_relation_row_debt_t *, wl_columnar_filter_context_t **);
int wl_columnar_eval_stack_row_debt_unbind_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_columnar_relation_row_debt_t *);
int wl_columnar_eval_stack_row_debt_geometry_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    const wl_columnar_relation_row_debt_t *, const int64_t *, uint32_t,
    const wl_columnar_relation_row_debt_status_t *, wl_evaluation_control_t *,
    uint64_t, bool);
int wl_columnar_relation_row_debt_prove_batch(
    const wl_columnar_relation_append_batch_t *, wl_evaluation_control_t *,
    uint64_t, bool *);
int wl_columnar_relation_row_debt_append_private(
    wl_columnar_relation_row_debt_t *, const int64_t *);
int wl_columnar_relation_row_debt_retire_one(
    wl_columnar_relation_row_debt_t *, wl_evaluation_control_t *, uint64_t,
    bool *);
bool wl_columnar_relation_row_debt_thread(
    const wl_columnar_relation_row_debt_t *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_filter_row_debt_test_checkpoint)(
    wl_columnar_relation_row_debt_t *, wl_evaluation_control_t *, unsigned);
enum {
    WL_COLUMNAR_FILTER_ROW_DEBT_TEST_FORWARD = 1,
    WL_COLUMNAR_FILTER_ROW_DEBT_TEST_RETIRE,
    WL_COLUMNAR_FILTER_ROW_DEBT_TEST_CLEANUP,
    WL_COLUMNAR_FILTER_ROW_DEBT_TEST_CLEANUP_RETIRED
};
#endif

/* Borrow embedded original context after original frame validation. No owner
 * transfer or old-control access; callers never copy the returned record. */
int wl_columnar_eval_stack_filter_context(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_context_t **);
/* Serialized owning start only: the exact original RUNNING/busy context
 * authorizes admission; standalone unary begin refuses an active context.
 * Neither callers nor callbacks may reenter this private authorized route. */
int wl_columnar_eval_stack_unary_begin_attempt_context_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_context_t *,
    wl_evaluation_control_t *, uint64_t, const void *);
/* JOIN decision belongs to the exact original busy JOIN_DECIDE context.
 * Publication flag is captured before the existing callback-free cutoff;
 * private output delta remains false. Generic unary commit stays false. */
int wl_columnar_eval_stack_unary_commit_join_attempt_context_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_context_t *,
    bool *, const void *);
/* Exact ordinary ANTI identity cutoff: moves only CONCAT segment ownership
 * into the frame retirement slot, clears live segments/delta and preserves
 * the relation/owned flag. All readers/temporary owners must have drained. */
int wl_columnar_eval_stack_unary_commit_anti_keep_all_context_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_context_t *,
    bool *, const void *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_stack_test_anti_metadata_committed)(
    const eval_entry_t *, const eval_entry_t *);
#endif
/* Meaningful-field initializer: new or proven ENDED/inert storage only,
 * never a live/retained/DRAINING batch. No live authority may be erased. */
void wl_columnar_filter_attempt_batch_init(
    wl_columnar_relation_append_batch_t *);

/* Initial scalar numeric REDUCE. COUNT accepts all valid operand domains;
 * SUM/MIN/MAX accept integer/FLOAT and AVG requires FLOAT. No STRING ordering,
 * interpreter fallback, timestamps, recursion/diff/TDD/batch/parallel. Reuses
 * original source/program/scratch3/B2/unary owners and shared filter step/ACK.
 * Hosts keep descriptors/backing/governors immutable/live through ACK, with
 * a distinct fresh HOST384 grant for each start/step/retry/ACK. NULL control
 * delegates raw REDUCE only with NULL owner. Owned control/ID must match the
 * genuine original numeric record; no authority transfers through copies. */
int wl_columnar_ops_reduce_attempt_start(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *);
int wl_columnar_ops_reduce_attempt_start_owned(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *,
    const void *owner);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_ops_test_reduce_attempt_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint64_t);
extern int wl_columnar_ops_test_reduce_attempt_fail_allocation;
#endif

/* Controlled initial nonrecursive ordinary JOIN. Hosts keep op/session,
 * registry, descriptors, backing and governor bindings immutable/live until
 * ACK, serialize the native owner and forbid same-context reentry. Each
 * start/step/ACK/retry requires a fresh distinct live HOST384 grant from the
 * canonical caller; operation control pays forward/first-retirement work.
 * NULL control delegates raw JOIN. Step/ACK use the shared filter protocol.
 * Generic frame/pending cleanup remains a separate external host action. */
/* Bounded scalar SEMIJOIN/ANTIJOIN. Existing named right is required;
 * missing right is ENOTSUP (unlike raw repush). NoTS/compound/right-filter,
 * differential/TDD/batch/parallel paths are outside this private domain.
 * SEMI projects only left lanes with canonical typed colN output; ANTI keeps
 * left names/type presence/graph. Results are materialized, non-delta and
 * ignore ordinary JOIN output limit/delta selection. Same original owned
 * frame/source/three-scratch/batch cleanup and separate HOST funding apply. */
int wl_columnar_join_probe_op_attempt_start(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *);
int wl_columnar_join_probe_op_attempt_start_owned(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *,
    const void *owner);
int wl_columnar_join_op_attempt_start(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *);
/* Original numeric-record authority through all frame getters. A live owner
 * requires its original operation control and saved ID; only the NULL owner may
 * delegate to raw JOIN. Shared step/ACK retain the same original owner. */
int wl_columnar_join_op_attempt_start_owned(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *,
    const void *);
/* Charged source/key preparation shared by ordinary and prepared JOIN hosts. */
struct wl_columnar_eval_private_bindings;
void *wl_columnar_join_attempt_allocate(size_t);
int wl_columnar_join_attempt_lookup(wl_col_session_t *, const char *, bool,
    col_rel_t **, wl_evaluation_control_t *, uint64_t,
    const struct wl_columnar_eval_private_bindings *);
int wl_columnar_join_attempt_key(const wl_columnar_relation_scalar_source_t *,
    const char *, uint32_t *, wl_evaluation_control_t *, uint64_t);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_join_test_attempt_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint64_t);
extern int wl_columnar_join_test_attempt_fail_allocation;
#endif

/* Private finish-status bridge, validated original live FILTER context only.
 * semantic is the designated context semantic_result slot or a disjoint live
 * external int; retained is a live bool disjoint from frame/context/semantic.
 * Protocol refusal leaves both outputs untouched. No other context aliasing. */
int wl_columnar_eval_stack_filter_finish(
    wl_columnar_eval_stack_cleanup_frame_t *, int, int *, bool *);
/* Serial nonrecursive scalar sorted distinct preserves the first incoming
* representative's complete timestamp when present. No delta or active
* differential/retraction/TDD/parallel context. Caller pins immutable plan,
* session, source and governor through ACK. Always private materialization,
* including zero/one row; logical parity does not imply allocation parity.
* NULL control delegates raw CONSOLIDATE. Reuse common FILTER step/ACK. */
int wl_columnar_filter_consolidate_attempt_start(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *);
/* Original numeric owner, operation control and saved active attempt ID are
 * required together. Protocol rejection preserves status and frame state.
 * NULL owner retains the standalone raw/controlled compatibility route. */
int wl_columnar_filter_consolidate_attempt_start_owned(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *,
    const void *);

int wl_columnar_filter_op_attempt_start(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *);
int wl_columnar_filter_op_attempt_step(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_status_t *);
int wl_columnar_filter_op_attempt_ack(wl_columnar_eval_stack_cleanup_frame_t *);

/* MAP uses the same original numeric continuation and the same step/ack
 * functions above. NULL control delegates col_op_map. Numeric-only controlled
 * execution refuses unsupported expressions without interpreter fallback. */
int wl_columnar_filter_map_attempt_start(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *);

#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_filter_test_attempt_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint64_t);
extern int wl_columnar_filter_test_attempt_fail_allocation;
#endif

/* Original-address JOIN/probe/FILTER/MAP/REDUCE/CONSOLIDATE numeric plan segments. This internal
 * host-driven interface does not activate public session evaluation controls.
 * The host binds one
 * private input entry and keeps plan/frame/session storage live until ACK.
 * Every action needs a distinct live host funding control. Never spin on a
 * child return: consume its protocol result on a later host dispatch. */
typedef enum {
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_INERT = 0,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_PREFLIGHT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_READY,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_CHILD,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_ACK_CHILD,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_ADVANCE,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_PREFLIGHT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_FULL,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_DELTA,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_SELECT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_INIT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_HOLD,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_SLOT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_NEW,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_END,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_SOURCE_INSTALL,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_PENDING,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_RELEASE,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_INPUTS,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_PREFLIGHT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_PREFLIGHT_LFTJ,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_READY,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_LFTJ_BEGIN,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_LFTJ_CHILD,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_UNARY_CHILD,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_UNARY_ACK,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_UNARY_ADVANCE,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_CONCAT_START,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_CONCAT_CHILD,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_CONCAT_ACK,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_CONCAT_ADVANCE,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_FULL,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_DELTA,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_SELECT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_INIT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_HOLD,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_SLOT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_NEW,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_END,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_INSTALL,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_SOURCE_ABORT,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_PENDING,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_JOIN_BATCH,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_RELEASE,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_COMPOSE_DONE,
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_DONE
} wl_columnar_eval_plan_numeric_phase_t;

/* Resumable ordinary LFTJ child owned by a composed numeric attempt.  The
 * input and merge cursors are explicit so no framed host action copies or
 * sorts an entire relation.  LFTJ reads named relations and pushes one result;
 * it does not consume runtime stack entries. */
typedef enum {
    WL_COLUMNAR_LFTJ_ATTEMPT_INERT,
    WL_COLUMNAR_LFTJ_ATTEMPT_RESOLVE,
    WL_COLUMNAR_LFTJ_ATTEMPT_ACQUIRE,
    WL_COLUMNAR_LFTJ_ATTEMPT_SIZE,
    WL_COLUMNAR_LFTJ_ATTEMPT_ALLOC_PRECHARGE,
    WL_COLUMNAR_LFTJ_ATTEMPT_ALLOC,
    WL_COLUMNAR_LFTJ_ATTEMPT_SCHEMA,
    WL_COLUMNAR_LFTJ_ATTEMPT_COPY,
    WL_COLUMNAR_LFTJ_ATTEMPT_SORT,
    WL_COLUMNAR_LFTJ_ATTEMPT_JOIN,
    WL_COLUMNAR_LFTJ_ATTEMPT_OUTPUT_CREATE,
    WL_COLUMNAR_LFTJ_ATTEMPT_OUTPUT_BEGIN,
    WL_COLUMNAR_LFTJ_ATTEMPT_OUTPUT_FILL,
    WL_COLUMNAR_LFTJ_ATTEMPT_OUTPUT_END,
    WL_COLUMNAR_LFTJ_ATTEMPT_RELEASE,
    WL_COLUMNAR_LFTJ_ATTEMPT_DONE
} wl_columnar_lftj_attempt_phase_t;

typedef enum {
    WL_COLUMNAR_LFTJ_JOIN_INPUT_CHECK,
    WL_COLUMNAR_LFTJ_JOIN_INITIAL_MAX,
    WL_COLUMNAR_LFTJ_JOIN_SEEK_START,
    WL_COLUMNAR_LFTJ_JOIN_SEEK_SEARCH,
    WL_COLUMNAR_LFTJ_JOIN_RANGE_START,
    WL_COLUMNAR_LFTJ_JOIN_RANGE_SEARCH,
    WL_COLUMNAR_LFTJ_JOIN_PRODUCT_START,
    WL_COLUMNAR_LFTJ_JOIN_PRODUCT_COUNT,
    WL_COLUMNAR_LFTJ_JOIN_PRODUCT_EMIT,
    WL_COLUMNAR_LFTJ_JOIN_PRODUCT_ADVANCE,
    WL_COLUMNAR_LFTJ_JOIN_ADVANCE_KEY
} wl_columnar_lftj_join_phase_t;

typedef enum {
    WL_COLUMNAR_LFTJ_SOURCE_LOOKUP,
    WL_COLUMNAR_LFTJ_SOURCE_READER,
    WL_COLUMNAR_LFTJ_SOURCE_KEY,
    WL_COLUMNAR_LFTJ_SOURCE_CELLS,
    WL_COLUMNAR_LFTJ_SOURCE_ROW_BYTES,
    WL_COLUMNAR_LFTJ_SOURCE_ADD_ROWS,
    WL_COLUMNAR_LFTJ_SOURCE_COLUMN_BYTES,
    WL_COLUMNAR_LFTJ_SOURCE_ADD_COLUMNS,
    WL_COLUMNAR_LFTJ_SOURCE_COMPLETE
} wl_columnar_lftj_source_phase_t;

typedef struct {
    col_rel_t *relation;
    wl_columnar_source_access_reader_t reader;
    col_relation_snapshot_t snapshot;
    wl_columnar_lftj_source_phase_t source_phase;
    bool reader_held;
    uint64_t raw_bytes;
    uint32_t nrows, ncols, key_col;
    wirelog_column_type_t key_type;
    /* Bounded, side-effect-free registry discovery.  A candidate slot is
    * only an index until the complete registry scan proves it unique. */
    uint32_t lookup_slot, lookup_match_slot, lookup_matches;
    size_t lookup_name_byte;
    int64_t *rows, *scratch;
    uint64_t copy_cell;
    uint32_t position, range_lo, range_hi, product_index;
    uint32_t sort_width, sort_run, sort_mid, sort_end;
    uint32_t sort_left, sort_right, sort_dest;
    uint32_t sort_source_row, sort_source_col;
    bool sort_copying, sort_take_left;
} wl_columnar_lftj_input_attempt_t;

typedef struct wl_columnar_lftj_attempt {
    struct wl_columnar_lftj_attempt *identity;
    const wl_plan_op_lftj_t *metadata;
    wl_columnar_eval_stack_cleanup_frame_t *frame;
    const void *numeric_owner;
    wl_col_session_t *session;
    col_rel_t **registry;
    uint32_t registry_count;
    const struct wl_columnar_eval_private_bindings *private_bindings;
    uint32_t cleanup_cursor;
    uint8_t cleanup_input_stage;
    wl_evaluation_control_t *control;
    uint64_t attempt_id;
    wl_columnar_lftj_attempt_phase_t phase;
    int semantic_result;
    wl_columnar_lftj_input_attempt_t *inputs;
    uint32_t input_count, cursor, total_columns;
    uint32_t scratch_size_cursor;
    uint64_t row_bytes;
    bool scratch_size_initialized;
    uint64_t raw_preflight_scratch_bytes;
    bool raw_preflight_initialized;
    uint64_t allocation_work_total, allocation_work_charged;
    uint32_t binary_offset[WL_LFTJ_MAX_K];
    int64_t *output_types;
    int64_t *row;
    uint64_t scratch_bytes, output_rows, output_written;
    wl_columnar_memory_reservation_t scratch_reservation;
    bool scratch_reserved, scratch_committed, output_pass;
    col_rel_t *output;
    wl_columnar_relation_append_batch_t writer;
    int64_t key, max_key;
    wl_columnar_lftj_join_phase_t join_phase;
    uint32_t join_index, seek_lo, seek_hi, seek_mid;
    uint32_t range_index, product_depth, fill_input, fill_col;
    int64_t fill_key;
    bool writer_active, output_owned, registered;
    wl_columnar_relation_scalar_retirement_t retirement;
    wl_columnar_relation_scalar_retirement_initializer_t retirement_initializer;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid, busy;
    bool retirement_started, retirement_committed, retirement_drained;
    wl_columnar_relation_private_batch_drain_t writer_drain;
} wl_columnar_lftj_attempt_t;

/* Actual owned LFTJ row and protected exact-capacity output; no generic
 * alias capture, growth or renewal is selected by this internal producer. */
int wl_columnar_relation_append_lftj_owned_row_operator_controlled(
    wl_columnar_lftj_attempt_t *);

#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_lftj_test_attempt_checkpoint)(
    wl_evaluation_control_t *, const wl_columnar_lftj_attempt_t *);
#endif

/* Actual composed parent owns this proof through ACK; plan/header/arrays and
 * private bindings remain immutable. It supplies no source-reader authority. */
typedef enum {
    WL_COLUMNAR_LFTJ_METADATA_INERT,
    WL_COLUMNAR_LFTJ_METADATA_HEADER,
    WL_COLUMNAR_LFTJ_METADATA_NAMES,
    WL_COLUMNAR_LFTJ_METADATA_VALIDATED,
    WL_COLUMNAR_LFTJ_METADATA_BIND_HEADER,
    WL_COLUMNAR_LFTJ_METADATA_BIND_ENTRY,
    WL_COLUMNAR_LFTJ_METADATA_BIND_PAIR,
    WL_COLUMNAR_LFTJ_METADATA_BIND_DYNAMIC,
    WL_COLUMNAR_LFTJ_METADATA_BIND_FINAL,
    WL_COLUMNAR_LFTJ_METADATA_PREFIX,
    WL_COLUMNAR_LFTJ_METADATA_INSTALL,
    WL_COLUMNAR_LFTJ_METADATA_CONSUMED
} wl_columnar_lftj_metadata_phase_t;

typedef struct {
    wl_columnar_lftj_metadata_phase_t phase;
    const wl_plan_op_t *operation;
    const wl_plan_op_lftj_t *metadata;
    char **names;
    uint32_t *keys;
    uint32_t op_index, k, name_index;
    const struct wl_columnar_eval_private_bindings *bindings;
    const void *dynamic_entries;
    uint64_t binding_generation;
    uint32_t binding_count, entry, pair;
    col_rel_t **registry;
    uint32_t registry_count;
    bool prefix_cleared;
} wl_columnar_lftj_metadata_proof_t;

typedef struct wl_columnar_eval_plan_numeric_attempt {
    struct wl_columnar_eval_plan_numeric_attempt *identity;
    wl_columnar_eval_stack_cleanup_frame_t *frame;
    wl_col_session_t *session;
    const wl_plan_relation_t *plan;
    wl_evaluation_control_t *control;
    uint64_t attempt_id;
    uint32_t begin, end, cursor, completed;
    wl_columnar_eval_plan_numeric_phase_t phase, pending_action;
    wl_columnar_filter_status_t child_status;
    int semantic_result, protocol_result;
    /* Source mode borrows an immutable registry; no lookup hash is built. */
    col_rel_t **source_registry;
    uint32_t source_count, source_slot, source_begin;
    size_t source_byte;
    col_rel_t *source_full, *source_delta, *source_selected;
    col_rel_t **source_output;
    wl_columnar_relation_scalar_source_t source;
    bool source_mode, source_installed, source_empty, source_is_delta;
    bool source_initialized, source_slot_borrowed;
    bool source_bare;
    wl_columnar_relation_empty_source_t source_empty_reader;
    /* ABORT is available only for the audited operator closure. Ordinary
    * composed execution retains its wider existing admission surface. */
    bool abort_supported, abort_requested;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid;
    /* Appended composition state; original record address and prefix retained. */
    uint32_t preflight_depth, runtime_depth;
    bool composed_mode;
    /* Set only by the exact framed controlled STEP fallback preflight. */
    bool controlled_materialized_batch_fallback;
    const struct wl_columnar_eval_private_bindings *private_bindings;
    bool lftj_metadata_ended, lftj_metadata_dispatch;
    wl_columnar_lftj_metadata_proof_t lftj_metadata;
    wl_columnar_lftj_attempt_t lftj;
    bool composed_busy, lftj_cleanup_authorized;
    void *join_host;
    uint64_t join_host_initialized_bytes;
    uint32_t join_host_tail_count;
    wl_columnar_memory_reservation_t join_host_credit;
    wl_columnar_memory_governor_ref_t *join_host_governor;
    bool join_host_admitted, join_host_committed;
    bool join_host_terminal, join_host_declined;
    bool join_host_busy;
} wl_columnar_eval_plan_numeric_attempt_t;

typedef struct {
    wl_columnar_eval_plan_numeric_phase_t phase;
    uint32_t completed;
    int semantic_result, protocol_result;
    bool retained;
} wl_columnar_eval_plan_numeric_status_t;
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_plan_test_after_terminal_exchange)(
    wl_evaluation_control_t *, uint64_t);
#endif

/* Authenticated name-to-owner overlay for one serialized evaluator attempt.
 * Keys are copied into this address-bound record; relation descriptors stay
 * private and may be unnamed. The caller borrows these descriptors and must
 * keep them alive and immutable until the child attempt is acknowledged.
 * Keep this record stable and immutable for the same interval. */
#define WL_COLUMNAR_EVAL_PRIVATE_BINDING_MAX 4u
typedef struct {
    char name[256];
    col_rel_t *relation;
    col_relation_snapshot_t snapshot;
} wl_columnar_eval_private_binding_t;

/* Session transaction owns this stable, charged, unbounded name table.
 * NULL relations reserve not-yet-computed heads and prohibit public fallback. */
typedef struct {
    const char *name;
    col_rel_t *relation;
    col_rel_t *public_relation;
    col_relation_snapshot_t snapshot;
} wl_columnar_eval_private_dynamic_binding_t;

typedef struct wl_columnar_eval_private_bindings {
    uintptr_t identity;
    wl_col_session_t *session;
    const wl_plan_relation_t *plan;
    wl_evaluation_control_t *control;
    uint64_t attempt_id;
    uint32_t count;
    wl_columnar_eval_private_binding_t entries[
        WL_COLUMNAR_EVAL_PRIVATE_BINDING_MAX];
    const wl_columnar_eval_private_dynamic_binding_t *dynamic_entries;
    uint64_t generation;

} wl_columnar_eval_private_bindings_t;

bool wl_columnar_session_observed_bindings_authorized(
    const wl_col_session_t *, const wl_columnar_eval_private_bindings_t *);
bool wl_columnar_session_observed_bindings_cleanup_authorized(
    const wl_col_session_t *, const wl_columnar_eval_private_bindings_t *,
    const wl_plan_relation_t *, wl_evaluation_control_t *, uint64_t, uint64_t);
/* Iteration-zero scalar selectors admitted by the materialized batch host.
 * JOIN-right has no VARIABLE FORCE_EMPTY semantics. */
bool wl_columnar_eval_plan_scalar_selector_supported(const wl_plan_op_t *);
/* Exact host-owned occurrence override for acyclic appends or qualified SCC
 * row frontiers. NULL means full evaluation; an empty delta remains a nonNULL
 * immutable source through child ACK and never a public full-source index key. */
int wl_columnar_session_delta_source(wl_col_session_t *,
    const wl_columnar_eval_private_bindings_t *, const wl_plan_op_t *,
    col_rel_t **);
int wl_columnar_session_diff_index(
    wl_col_session_t *, const wl_columnar_eval_private_bindings_t *,
    const col_rel_t *, const char *, const uint32_t *, uint32_t,
    col_diff_arrangement_t **, bool *);
int wl_columnar_arrangement_diff_attempt_index(
    wl_columnar_arrangement_diff_attempt_t *, wl_col_session_t *,
    const wl_plan_op_t *, uint32_t, const col_rel_t *, const char *,
    const uint32_t *, uint32_t, wl_evaluation_control_t *, uint64_t,
    col_diff_arrangement_t **, bool *);
int wl_columnar_arrangement_diff_attempt_prepare(
    wl_columnar_arrangement_diff_attempt_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t);
void wl_columnar_arrangement_diff_attempt_commit(
    wl_columnar_arrangement_diff_attempt_t *, wl_col_session_t *);
int wl_columnar_arrangement_diff_attempt_drain(
    wl_columnar_arrangement_diff_attempt_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t);
/* One actual finite parent action, without the generic128 prefix on ledger
 * DESCRIBE109/COMMIT194. The real parent pins the same control allocation and
 * this record until every action's actual FINISH/report/Source receipt/ACK.
 * Capture a consumed COMMIT report before starting another generation. The
 * next drain uses its existing metadata128 action for the prepaid fixed ACK;
 * applied=false retries fresh DESCRIBE only after that ACK. Legacy raw drain
 * is unchanged and cannot be interleaved while this journal is live. */
int wl_columnar_arrangement_diff_attempt_drain_finite(
    wl_columnar_arrangement_diff_attempt_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_arrangement_diff_attempt_ledger_capture_owned(
    wl_columnar_arrangement_diff_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_arrangement_test_diff_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint64_t);
#endif
int wl_columnar_eval_private_binding_get(
    const wl_columnar_eval_private_bindings_t *, uint32_t,
    const char **, col_rel_t **);

void wl_columnar_eval_plan_numeric_attempt_init(
    wl_columnar_eval_plan_numeric_attempt_t *);
bool wl_columnar_eval_plan_numeric_owner_valid(const void *,
    const wl_columnar_eval_stack_cleanup_frame_t *);
bool wl_columnar_eval_plan_numeric_batch_fallback_authorized(const void *,
    const wl_columnar_eval_stack_cleanup_frame_t *, const wl_col_session_t *,
    const wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_plan_numeric_attempt_begin(
    wl_columnar_eval_plan_numeric_attempt_t *, const wl_plan_relation_t *,
    uint32_t, uint32_t, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, wl_evaluation_control_t *, uint64_t,
    wl_evaluation_control_t *, uint64_t);
/* Initial VARIABLE + JOIN/probe/FILTER/MAP/REDUCE/CONSOLIDATE fragment. Keep registry, names,
 * descriptors and source contents immutable and live through ACK. Unknown
 * delta modes use AUTO as in the raw VARIABLE operator. The containing
 * stratum must be nonrecursive (a caller precondition; relation plans do not
 * carry that fact). No TDD, retraction,
 * iterative or differential evaluation; NULL control is invalid. */
int wl_columnar_eval_plan_numeric_source_attempt_begin(
    wl_columnar_eval_plan_numeric_attempt_t *, const wl_plan_relation_t *,
    uint32_t, uint32_t, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, wl_evaluation_control_t *, uint64_t,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_plan_numeric_attempt_step(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_numeric_consume_result(
    wl_columnar_eval_plan_numeric_attempt_t *, int,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_plan_numeric_attempt_status(
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_columnar_eval_plan_numeric_status_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_numeric_attempt_ack(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t);

int wl_columnar_eval_stack_numeric_source_claim(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_numeric_source_output(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_numeric_source_install(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_numeric_source_release(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);

/* Exact segment authority routes; NULL denotes an unbound standalone frame.
 * Owner arguments are original stable records, not transferable capabilities. */
int wl_columnar_eval_stack_numeric_owner(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *);
/* Fixed status-only shape observation AFTER the caller's actual native/frame
 * owner proof. No pointer loan or independent ownership capability. */
bool wl_columnar_eval_stack_metadata_result_disjoint(
    const wl_columnar_eval_stack_cleanup_frame_t *, const int *);
int wl_columnar_eval_stack_numeric_metadata_empty(
    const wl_columnar_eval_stack_cleanup_frame_t *, const void *, const int *);
int wl_columnar_eval_stack_numeric_claim(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *, const void *);
int wl_columnar_eval_stack_numeric_unbind(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *, const void *);
int wl_columnar_eval_stack_operator_stack_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    eval_stack_t **, const void *);
int wl_columnar_eval_stack_unary_begin_attempt_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_evaluation_control_t *,
    uint64_t, const void *);
int wl_columnar_eval_stack_unary_reset_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *);
int wl_columnar_eval_stack_filter_finish_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, int, int *, bool *, const void *);
int wl_columnar_filter_op_attempt_start_owned(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *,
    const void *);
int wl_columnar_filter_map_attempt_start_owned(const wl_plan_op_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_columnar_filter_status_t *,
    const void *);
int wl_columnar_filter_op_attempt_step_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_status_t *,
    const void *);
/* Nonstream BATCH/JOIN_BATCH only; other lifecycle stages return EBUSY.
 * One invocation per fresh dedicated financier generation, no incoming SOURCE
 * promise. The caller owns this precondition; the helper does not inspect the
 * remaining budget or infer resource authority from financial admission. */
int wl_columnar_filter_batch_end_step_owned_funded(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_status_t *,
    const void *, wl_evaluation_control_t *, uint64_t);
/* Exact owned ordinary JOIN cleanup only. Queries refuse all stream hosts;
 * actual END uses distinct supplied funding after the parent dispatch1. */
typedef enum {
    WL_COLUMNAR_FILTER_SOURCE_END_NONE,
    WL_COLUMNAR_FILTER_SOURCE_END_EMPTY_LEFT,
    WL_COLUMNAR_FILTER_SOURCE_END_EMPTY_RIGHT,
    WL_COLUMNAR_FILTER_SOURCE_END_SCALAR_LEFT,
    WL_COLUMNAR_FILTER_SOURCE_END_SCALAR_RIGHT
} wl_columnar_filter_source_end_kind_t;
int wl_columnar_filter_source_end_pending_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_evaluation_control_t *, uint64_t,
    wl_columnar_filter_source_end_kind_t *);
int wl_columnar_filter_source_end_step_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_status_t *,
    const void *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_filter_empty_end_pending_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *, bool *);
int wl_columnar_filter_empty_end_step_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_status_t *,
    const void *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_stack_scalar_source_begin_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    const wl_plan_op_t *,
    wl_columnar_relation_scalar_source_t *, const col_rel_t *, bool);
int wl_columnar_eval_stack_scalar_source_admit_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    const wl_plan_op_t *,
    wl_columnar_relation_scalar_source_t *, const col_rel_t *, bool, uint32_t);
int wl_columnar_eval_stack_filter_context_nonstream_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_context_t **,
    const void *);
int wl_columnar_filter_op_attempt_ack_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *);

int wl_columnar_eval_stack_unary_input_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const col_rel_t **, const void *);
int wl_columnar_eval_stack_unary_output_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, col_rel_t ***, const void *);
int wl_columnar_eval_stack_unary_commit_attempt_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, bool *, const void *);
int wl_columnar_eval_stack_unary_commit_numeric_join_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, bool *, const void *);
/* Private stream exchange moves only an eval entry, never address-bound
 * tokens. The parked original remains frame-owned until exact restore.
 * Consumer scope is serialized and accepts only the host's current tail op;
 * it grants no raw stack or parent publication access. */
int wl_columnar_eval_stack_stream_enter_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *, const void *,
    const col_rel_t *, uint64_t, bool, bool);
int wl_columnar_eval_stack_stream_dispatch_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *, const void *,
    const wl_plan_op_t *, unsigned, bool);
int wl_columnar_eval_stack_consumer_stack_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    eval_stack_t **, const void *, const wl_plan_op_t *);
int wl_columnar_eval_stack_stream_restore_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *, const void *,
    eval_entry_t *);
int wl_columnar_eval_stack_stream_consumer_state_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *, const void *,
    bool *, bool *);
/* Numeric-owned scalar retirement. Prepare validates the old owned entry
 * reversibly on the original target before commit, retaining writer claims.
 * Funded finish cancels those claims on abort or retires the old entry after
 * commit, using only a distinct supplied cleanup attempt. Never copy a live
 * frame/receipt. done=false retains exact authority; funding refusal or a
 * foreign reader may be retried. Generic finish/reset cannot bypass it.
 * Provisional output and any owned old input must be private scalar heap
 * relations without segment metadata. Borrowed input is never destroyed. */
int wl_columnar_eval_stack_unary_prepare_scalar_retirement_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *, bool *done);
int wl_columnar_eval_stack_unary_finish_scalar_funded_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, int initiating_result,
    const void *, wl_evaluation_control_t *, uint64_t funding_id,
    int *semantic_result, bool *done);
int wl_columnar_eval_stack_filter_context_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_columnar_filter_context_t **,
    const void *);

/* Original two-entry replacement. The frame and original plan/record stay
* live and serialized through ACK. Finish and ACK each admit fresh384 from
* independent host funding; old operation cancellation never pays cleanup.
* Inputs and output borrows are setup/forward calls, not cleanup authority.
* A NULL owner denotes a standalone unbound frame. No raw-pointer mutation
* is permitted during the exclusive gate. Output is flat and non-delta. */
int wl_columnar_eval_stack_binary_begin_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, const void *);
int wl_columnar_eval_stack_binary_input_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, unsigned, const eval_entry_t **,
    const void *);
int wl_columnar_eval_stack_binary_output_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, col_rel_t ***, const void *);
int wl_columnar_eval_stack_binary_commit_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, bool *, const void *);
int wl_columnar_eval_stack_binary_finish_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, int,
    wl_columnar_filter_status_t *,
    wl_evaluation_control_t *, uint64_t, const void *);
int wl_columnar_eval_stack_binary_ack_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_evaluation_control_t *,
    uint64_t, const void *);
int wl_columnar_eval_stack_numeric_stack_claim(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *, const void *,
    uint32_t, wl_evaluation_control_t *, uint64_t);
/* Exact nonempty stack authority, not UNION grammar admission. The complete
 * configured stack/plan must precede begin; old top1/empty APIs retain scope. */
int wl_columnar_eval_plan_numeric_stack_attempt_begin(
    wl_columnar_eval_plan_numeric_attempt_t *, const wl_plan_relation_t *,
    uint32_t, uint32_t, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, uint32_t, wl_evaluation_control_t *, uint64_t,
    wl_evaluation_control_t *, uint64_t);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_stack_test_binary_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint64_t);
#endif

/* Complete initial, acyclic scalar bodies. initial_depth0 claims an empty
 * source frame;1..32 claims that exact configured original stack via A.
 * Immutable plan/registry/borrowed source storage, noTS/compound/recursive modes.
 * Prebound owned entries retire through the controlled child transactions.
 * Every action uses fresh independent, exclusively host-owned funding. Its
 * control/active generation/lifetime cannot finish/reset/begin/transfer until
 * the complete host action returns; cancellation may latch normally. Own384,
 * nested CONCAT maximum1152 (parent+B+A); each LFTJ cleanup action costs one
 * additional unit. A deeper funding refusal may leave
 * genuine PENDING; consume its protocol on a later grant without promotion.
 * Successful completed counts every opcode, including each VARIABLE.
 * Old step/consume/ACK cannot operate these distinct lifecycle phases. */
int wl_columnar_eval_plan_numeric_composed_attempt_begin(
    wl_columnar_eval_plan_numeric_attempt_t *, const wl_plan_relation_t *,
    uint32_t, uint32_t, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, uint32_t, wl_evaluation_control_t *, uint64_t,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_private_bindings_begin(
    wl_columnar_eval_private_bindings_t *, wl_col_session_t *,
    const wl_plan_relation_t *, wl_evaluation_control_t *, uint64_t,
    const char *const *, col_rel_t *const *, uint32_t);
int wl_columnar_eval_plan_numeric_composed_attempt_begin_bound(
    wl_columnar_eval_plan_numeric_attempt_t *, const wl_plan_relation_t *,
    uint32_t, uint32_t, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, uint32_t, wl_evaluation_control_t *, uint64_t,
    wl_evaluation_control_t *, uint64_t,
    const wl_columnar_eval_private_bindings_t *);
int wl_columnar_eval_plan_numeric_composed_attempt_begin_bound_batch(
    wl_columnar_eval_plan_numeric_attempt_t *, const wl_plan_relation_t *,
    uint32_t, uint32_t, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, uint32_t, wl_evaluation_control_t *, uint64_t,
    wl_evaluation_control_t *, uint64_t,
    const wl_columnar_eval_private_bindings_t *);
/* Synchronous setup results carry no owning receipt or pointer authority. */
typedef enum {
    WL_COLUMNAR_JOIN_SETUP_FUNDING_REFUSED,
    WL_COLUMNAR_JOIN_SETUP_ORIGINAL_STOPPED,
    WL_COLUMNAR_JOIN_SETUP_INVALID,
    WL_COLUMNAR_JOIN_SETUP_CHILD_DISPATCHED
} wl_columnar_join_setup_outcome_t;
typedef struct {
    int protocol;
    wl_columnar_join_setup_outcome_t outcome;
} wl_columnar_join_setup_result_t;
enum {
    WL_COLUMNAR_EVAL_PLAN_NUMERIC_HOST_WORK = 384,
    WL_COLUMNAR_JOIN_SETUP_DISPATCH_WORK = 128,
    WL_COLUMNAR_JOIN_SETUP_STACK_WORK = 192,
    WL_COLUMNAR_JOIN_SETUP_HEADER_WORK = 128,
    WL_COLUMNAR_JOIN_SETUP_ENTRY_WORK = 64,
    WL_COLUMNAR_JOIN_SETUP_PAIR_WORK = 32,
    WL_COLUMNAR_JOIN_SETUP_DYNAMIC_WORK = 64,
    WL_COLUMNAR_JOIN_SETUP_FINISH_WORK = 64,
    WL_COLUMNAR_JOIN_SETUP_PRECHILD_WORK = 128,
    WL_COLUMNAR_JOIN_SETUP_MAX_WORK = WL_COLUMNAR_EVAL_PLAN_NUMERIC_HOST_WORK
        + WL_COLUMNAR_JOIN_SETUP_DISPATCH_WORK +
        WL_COLUMNAR_JOIN_SETUP_STACK_WORK
        + WL_COLUMNAR_JOIN_SETUP_HEADER_WORK
        + WL_COLUMNAR_EVAL_PRIVATE_BINDING_MAX *
        WL_COLUMNAR_JOIN_SETUP_ENTRY_WORK
        + WL_COLUMNAR_EVAL_PRIVATE_BINDING_MAX
        * (WL_COLUMNAR_EVAL_PRIVATE_BINDING_MAX - 1) / 2
        * WL_COLUMNAR_JOIN_SETUP_PAIR_WORK
        + WL_COLUMNAR_JOIN_SETUP_FINISH_WORK +
        WL_COLUMNAR_JOIN_SETUP_PRECHILD_WORK
};
/* Portable constant-expression checks, including the MSVC C frontend. */
typedef char wl_columnar_join_setup_supported_max_t[
        (WL_COLUMNAR_EVAL_PRIVATE_BINDING_MAX == 4u
        && WL_COLUMNAR_JOIN_SETUP_MAX_WORK == 1472) ? 1 : -1];
typedef char wl_columnar_join_setup_quantum_t[
        (WL_COLUMNAR_JOIN_SETUP_DISPATCH_WORK <= 256
        && WL_COLUMNAR_JOIN_SETUP_STACK_WORK <= 256
        && WL_COLUMNAR_JOIN_SETUP_HEADER_WORK <= 256
        && WL_COLUMNAR_JOIN_SETUP_ENTRY_WORK <= 256
        && WL_COLUMNAR_JOIN_SETUP_PAIR_WORK <= 256
        && WL_COLUMNAR_JOIN_SETUP_DYNAMIC_WORK <= 256
        && WL_COLUMNAR_JOIN_SETUP_FINISH_WORK <= 256
        && WL_COLUMNAR_JOIN_SETUP_PRECHILD_WORK <= 256) ? 1 : -1];
/* Separate pipeline setup actions; the maximum sizes grant capacity only. */
enum {
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_STACK_WORK = 192,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_LOOKUP_WORK = 128,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_SELECT_WORK = 128,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_RESERVE_WORK = 256,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_ALLOC_WORK = 128,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_COMMIT_WORK = 192,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_ZERO_WORK = 128,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_HEADER_WORK = 192,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_CLASSIFY_WORK = 192,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_PUBLISH_WORK = 192,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_CREDIT_WORK = 192,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_REF_WORK = 128,
    WL_COLUMNAR_JOIN_PIPELINE_SETUP_MAX_WORK =
        WL_COLUMNAR_EVAL_PLAN_NUMERIC_HOST_WORK
        + WL_COLUMNAR_JOIN_PIPELINE_SETUP_STACK_WORK
        + WL_COLUMNAR_JOIN_SETUP_HEADER_WORK +
        WL_COLUMNAR_JOIN_SETUP_FINISH_WORK
        + 2 * WL_COLUMNAR_JOIN_PIPELINE_SETUP_LOOKUP_WORK
        + WL_COLUMNAR_JOIN_PIPELINE_SETUP_SELECT_WORK
        + WL_COLUMNAR_JOIN_PIPELINE_SETUP_RESERVE_WORK
        + WL_COLUMNAR_JOIN_PIPELINE_SETUP_ALLOC_WORK
        + WL_COLUMNAR_JOIN_PIPELINE_SETUP_COMMIT_WORK
};
typedef char wl_columnar_join_pipeline_setup_max_t[
        WL_COLUMNAR_JOIN_PIPELINE_SETUP_MAX_WORK == 1728 ? 1 : -1];
typedef char wl_columnar_join_pipeline_setup_quantum_t[
        (WL_COLUMNAR_JOIN_PIPELINE_SETUP_STACK_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_LOOKUP_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_SELECT_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_RESERVE_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_ALLOC_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_COMMIT_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_ZERO_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_HEADER_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_CLASSIFY_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_PUBLISH_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_CREDIT_WORK <= 256
        && WL_COLUMNAR_JOIN_PIPELINE_SETUP_REF_WORK <= 256) ? 1 : -1];

wl_columnar_join_setup_result_t wl_columnar_join_setup_head(
    wl_evaluation_control_t *, uint64_t, wl_evaluation_control_t *, uint64_t,
    uint64_t);
wl_columnar_join_setup_result_t wl_columnar_join_setup_tail(
    wl_evaluation_control_t *, uint64_t, wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_stack_numeric_setup_nonstream(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *);
wl_columnar_join_setup_result_t
    wl_columnar_eval_plan_numeric_composed_join_setup_handoff(
    wl_columnar_eval_plan_numeric_attempt_t *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, const wl_plan_op_t *);
wl_columnar_join_setup_result_t
    wl_columnar_eval_plan_numeric_private_bindings_get_funded(const void *,
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t, wl_evaluation_control_t *, uint64_t,
    const wl_columnar_eval_private_bindings_t **);
wl_columnar_join_setup_result_t wl_columnar_join_op_attempt_start_funded(
    const wl_plan_op_t *, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, wl_evaluation_control_t *, uint64_t,
    wl_columnar_filter_status_t *, wl_columnar_eval_plan_numeric_attempt_t *,
    wl_evaluation_control_t *, uint64_t);

int wl_columnar_eval_plan_numeric_private_bindings_get(const void *,
    const wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_evaluation_control_t *, uint64_t,
    const wl_columnar_eval_private_bindings_t **);
bool wl_columnar_eval_plan_numeric_recursive_path_supported(
    const wl_plan_relation_t *);
int wl_columnar_eval_plan_numeric_composed_attempt_begin_batch_fallback(
    wl_columnar_eval_plan_numeric_attempt_t *, const wl_plan_relation_t *,
    uint32_t, uint32_t, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, uint32_t, wl_evaluation_control_t *, uint64_t,
    wl_evaluation_control_t *, uint64_t);
/* Fixed header only; the compatibility preflight below also scans names.
 * Controlled hosts instead use their actual parent-owned ordered cursor. */
int wl_columnar_lftj_metadata_header(const wl_plan_op_t *, wl_col_session_t *);
typedef struct {
    wl_columnar_eval_stack_cleanup_frame_t *frame;
    wl_col_session_t *session;
    wl_evaluation_control_t *control;
    uint64_t attempt_id;
    const wl_plan_op_lftj_t *metadata;
    const wl_columnar_eval_private_bindings_t *bindings;
    col_rel_t **registry;
    uint32_t registry_count;
    wl_columnar_lftj_metadata_phase_t phase;
} wl_columnar_lftj_begin_context_t;
int wl_columnar_eval_plan_numeric_lftj_begin_context_get(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_columnar_lftj_attempt_t *,
    wl_columnar_lftj_begin_context_t *);
/* Stop-only, no-child cleanup after the actual original finished. Result
 * must be disjoint from the whole parent and frame; caller owns all output/control
 * lifetimes. Independent cleanup192 and ACK384; normal validators stay strict. */
int wl_columnar_eval_plan_numeric_lftj_metadata_cleanup_ended(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t, int *);
int wl_columnar_eval_plan_numeric_lftj_metadata_ack_ended(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t, int *);
int wl_columnar_lftj_attempt_begin_prevalidated(
    wl_columnar_lftj_attempt_t *, wl_columnar_eval_plan_numeric_attempt_t *,
    bool *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_plan_test_lftj_metadata_checkpoint)(
    wl_columnar_eval_plan_numeric_attempt_t *);
extern void (*wl_columnar_eval_plan_test_lftj_metadata_cleanup_checkpoint)(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *);
extern void (*wl_columnar_eval_plan_test_static_validation_checkpoint)(
    wl_evaluation_control_t *, uint64_t, uint32_t, uint32_t);
extern void (*wl_columnar_eval_plan_test_lftj_ack_checkpoint)(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t, size_t);
#endif
int wl_columnar_ops_lftj_attempt_preflight(const wl_plan_op_t *,
    wl_col_session_t *);
int wl_columnar_ops_lftj_attempt_begin(wl_columnar_lftj_attempt_t *,
    const wl_plan_op_t *, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_col_session_t *, wl_evaluation_control_t *, uint64_t, const void *);
int wl_columnar_ops_lftj_attempt_step(wl_columnar_lftj_attempt_t *, bool *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_ops_lftj_attempt_abort(wl_columnar_lftj_attempt_t *, bool *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_plan_numeric_composed_attempt_step(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
/* Drain an owned LFTJ child after the original operation has latched a
 * cancellation or work-limit stop. Each call performs at most one child
 * cleanup action under fresh host funding; it never resumes evaluation. */
int wl_columnar_eval_plan_numeric_composed_cleanup_lftj(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
/* Cooperatively stop a composed source owner without starting pending child
 * work, publishing output, or consuming an outstanding child receipt. */
int wl_columnar_eval_plan_numeric_composed_cleanup_source(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
/* Latch a funded abort request without advancing an owner. The next step
* observes cancellation through each operator's existing cleanup path. */
int wl_columnar_eval_plan_numeric_composed_abort_request(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
/* Pure generated-closure check used before the framed host consumes any
 * progress receipt; unsupported requests must be completely inert. */
enum {
    WL_COLUMNAR_EVAL_PLAN_ABORT_SCAN_ENTRY_WORK = 33,
    WL_COLUMNAR_EVAL_PLAN_ABORT_SCAN_OP_WORK = 64,
    WL_COLUMNAR_EVAL_PLAN_ABORT_SCAN_FINAL_WORK = 17
};
int wl_columnar_eval_plan_numeric_composed_abort_supported_attempt_controlled(
    const wl_plan_relation_t *, uint32_t, uint32_t, bool *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_plan_numeric_composed_abort_supported(
    const wl_plan_relation_t *, uint32_t, uint32_t, bool *);
int wl_columnar_eval_plan_numeric_composed_consume_result(
    wl_columnar_eval_plan_numeric_attempt_t *, int, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_numeric_composed_attempt_status(
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_columnar_eval_plan_numeric_status_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_plan_numeric_composed_attempt_ack(
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_composed_source_claim(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_composed_source_output(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_composed_source_install(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_composed_source_abort(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
/* Validate or perform the result-slot abort after the caller has already
 * charged one 384-unit host action. Both share the charged wrapper's checks
 * and preserve the borrowed slot when disposal is refused. */
int wl_columnar_eval_stack_composed_source_abort_validate(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_composed_source_abort_funded(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_composed_source_release(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);
int wl_columnar_eval_stack_composed_source_release_validate(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_plan_numeric_attempt_t *);

/* Durable fresh-head evaluation. The parent and its embedded child live at
 * their original addresses in the cleanup frame, starting before child begin.
 * Only an initially empty frame and a terminal CONSOLIDATE body are admitted.
 * This internal protocol does not activate public STEP/SNAPSHOT. */
typedef enum {
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_INERT = 0,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_LOOKUP,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_CHILD_BEGIN,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_CHILD,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_CLAIM,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SOURCE_INIT,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SOURCE_HOLD,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_VALIDATE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_NEW,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SCRATCH,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_BATCH_PREPARE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_BATCH_BEGIN,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_GATHER,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_APPEND,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SORTED,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_BATCH_END,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SOURCE_END,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_ENTRY_DRAIN,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SCRATCH_PHYSICAL,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SCRATCH_CREDIT,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SCRATCH_REFERENCE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_READY,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_IMAGE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_CANDIDATE_ABORT,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_GATE_RELEASE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_CHILD_ACK,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_SPARE_PROOF,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_NORMALIZE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_CLOSE_PROOF,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_DONE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_PENDING
} wl_columnar_eval_serial_framed_phase_t;

/* Original-address journal for a single fresh registry head. Array images
 * borrow descriptors until the fixed publication cutoff; they never own them. */
typedef enum {
    WL_COLUMNAR_SESSION_HASH_REGISTRY_INERT = 0,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_HOLE,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_SIZE,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ADMIT_R,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ALLOC_R,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ADMIT_E,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ALLOC_E,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ADMIT_H,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ALLOC_HEAD,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ALLOC_NEXT,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ZERO_R,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ZERO_HEAD,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_ZERO_NEXT,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_COPY,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_COMPARE,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_INSERT,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_HASH_SLOT,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_HASH_BYTE,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_HASH_LINK,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_VALIDATE,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_MOVE,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_CHECK_R,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_CHECK_H,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_CUTOFF,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_REVERSE,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_REVERSE_MOVE,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_FREE_R,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_FREE_HEAD,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_FREE_NEXT,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_CREDIT_R,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_CREDIT_H,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_FREE_E,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_CREDIT_E,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_WAIT_ACK,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_OLD_R,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_OLD_HEAD,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_OLD_NEXT,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_OLD_CREDIT_R,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_OLD_CREDIT_H,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_PROOF,
    WL_COLUMNAR_SESSION_HASH_REGISTRY_DRAINED
} wl_columnar_session_hash_registry_phase_t;

typedef struct wl_columnar_session_hash_registry_attempt {
    struct wl_columnar_session_hash_registry_attempt *identity;
    struct wl_columnar_eval_serial_framed_attempt *parent;
    wl_columnar_session_hash_registry_image_t image;
    wl_columnar_memory_reservation_t retired_rels, retired_hash;
    /* Nonowning original-address pair, authenticated in the preceding cell.
     * Exclusive serialized parent authority keeps it stable through retry. */
    wl_columnar_memory_reservation_t *reverse_source, *reverse_destination;
    uint64_t rel_bytes, expected_bytes, hash_bytes;
    uint64_t old_rel_bytes, old_hash_bytes, name_hash;
    uint32_t slot, byte, first_hole, cursor, move;
    wl_columnar_session_hash_registry_phase_t phase;
    /* 0=not moved, 1=explicit no-credit skip, 2=real original-address move. */
    uint8_t journal[4];
    bool credit_rels, credit_expected, credit_hash;
    bool old_credit_rels, old_credit_hash;
    bool committed, drained;
} wl_columnar_session_hash_registry_attempt_t;

typedef struct wl_columnar_eval_serial_framed_attempt {
    struct wl_columnar_eval_serial_framed_attempt *identity;
    wl_columnar_eval_stack_cleanup_frame_t *frame;
    wl_col_session_t *session;
    const wl_plan_relation_t *plan;
    wl_evaluation_control_t *control;
    uint64_t attempt_id, operation_identity;
    wl_columnar_eval_cleanup_receipt_key_t cleanup_receipt_key;
    wl_columnar_eval_plan_numeric_attempt_t child;
    wl_columnar_relation_scalar_source_t source;
    wl_columnar_relation_append_batch_t batch;
    wl_columnar_relation_private_batch_drain_t drain;
    wl_columnar_join_scratch_t scratch;
    col_rel_t *candidate;
    /* Nonowning snapshot; only the original stack entry owns this relation. */
    eval_entry_t input;
    /* The host keeps this completed grant alive and unchanged until consume.
     * It finishes with execution_status/cleanup_status0 so its report denotes
     * host disposition, independently of the child's returned protocol. */
    wl_evaluation_control_t *pending_funding;
    uint64_t pending_funding_id;
    wl_columnar_eval_serial_framed_phase_t phase, pending_action;
    uint32_t registry_slot, name_byte, row, cursor;
    int primary_result, cleanup_result, inner_protocol;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    bool thread_valid, pin_owned, child_bound, gate_owned;
    bool source_initialized, batch_initialized, batch_done;
    bool candidate_owned, materialized, committed, pending_inner_consume;
    bool close_proven, abort_supported, abort_requested;
    bool native_cleanup;
    bool unary_native_cleanup, observed_native_cleanup;
    bool controlled_materialized_batch_fallback;
    const wl_columnar_eval_private_bindings_t *private_bindings;
    col_rel_t **capture_out;
    bool capture_only;
    bool capture_done;
    wl_columnar_session_hash_registry_attempt_t publication;
} wl_columnar_eval_serial_framed_attempt_t;

typedef struct {
    wl_columnar_eval_serial_framed_phase_t phase;
    int execution_result, cleanup_result;
    bool ready, retained, committed;
} wl_columnar_eval_serial_framed_status_t;

/* A prepared receipt owns only leases, exclusion and one control reference.
 * Prior mutable loans are surrendered through ACK. Owned original inputs
 * in ModeA require genuine preexisting scalar READY; callers consume ABORT
 * history into numeric-owned funded finish. ModeB authenticates the actual
 * ordinary JOIN context and uses its normal context-owned finish after ACK;
 * bounded scalar cleanup/automatic driver selection are separate adapters. */
typedef enum {
    WL_COLUMNAR_EVAL_STACK_PREPARED_INERT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_HEAD,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_HEAD,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_STATE,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_SCRATCH0,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_SCRATCH1,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_SCRATCH2,
    WL_COLUMNAR_EVAL_STACK_PREPARED_ALIAS_FIXED,
    WL_COLUMNAR_EVAL_STACK_PREPARED_ALIAS_ROWS,
    WL_COLUMNAR_EVAL_STACK_PREPARED_ACQUIRE_OLD,
    WL_COLUMNAR_EVAL_STACK_PREPARED_ACQUIRE_OUTPUT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_VALIDATE_OLD,
    WL_COLUMNAR_EVAL_STACK_PREPARED_VALIDATE_OUTPUT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_READY,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_SEAL_HEAD,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_SEAL_STATE,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_SEAL_SCRATCH0,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_SEAL_SCRATCH1,
    WL_COLUMNAR_EVAL_STACK_PREPARED_JOIN_SEAL_SCRATCH2,
    WL_COLUMNAR_EVAL_STACK_PREPARED_SEAL_OLD,
    WL_COLUMNAR_EVAL_STACK_PREPARED_SEAL_OUTPUT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_SEAL_LATCH,
    WL_COLUMNAR_EVAL_STACK_PREPARED_SEALED,
    WL_COLUMNAR_EVAL_STACK_PREPARED_COMMITTED_DRAIN,
    WL_COLUMNAR_EVAL_STACK_PREPARED_CANCEL_SANITIZE,
    WL_COLUMNAR_EVAL_STACK_PREPARED_DRAIN_OUTPUT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_DRAIN_OLD,
    WL_COLUMNAR_EVAL_STACK_PREPARED_CLEAR_WORK,
    WL_COLUMNAR_EVAL_STACK_PREPARED_ACK_READY,
    WL_COLUMNAR_EVAL_STACK_PREPARED_ACKED,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_HEAD,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_SEGMENTS,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_SELECT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_INIT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_PREPARE,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_COMMIT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_DISPOSE,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_CLEAR_SCALAR,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_CLEAR_WORK,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_DECLINE_INIT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_DECLINE_CLAIMS,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_DECLINE_CLEAR,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_DECLINE_RESTORE
} wl_columnar_eval_stack_unary_prepared_phase_t;

typedef enum {
    WL_COLUMNAR_EVAL_STACK_PREPARED_NONE,
    WL_COLUMNAR_EVAL_STACK_PREPARED_ABORT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_RESUME,
    WL_COLUMNAR_EVAL_STACK_PREPARED_FINISH_DECLINED
} wl_columnar_eval_stack_unary_prepared_disposition_t;

typedef struct {
    eval_entry_t original, output;
    col_relation_snapshot_t old_snapshot, output_snapshot;
    const col_rel_t *old_canonical, *output_canonical;
    uint64_t old_identity, old_generation, output_identity, output_generation;
    wl_columnar_source_access_reader_t old_reader, output_reader;
} wl_columnar_eval_stack_unary_prepared_work_t;

typedef struct wl_columnar_eval_stack_unary_prepared {
    struct wl_columnar_eval_stack_unary_prepared *identity;
    wl_columnar_eval_stack_cleanup_frame_t *frame;
    wl_col_session_t *session;
    const wl_columnar_eval_plan_numeric_attempt_t *numeric_owner;
    const wl_plan_relation_t *plan;
    const wl_plan_op_t *operation;
    wl_evaluation_control_t *control;
    uint64_t control_identity, attempt_id;
    wl_columnar_eval_stack_unary_prepared_work_t work;
    /* alias_cursor is a byte offset only in the two CLEAR_WORK phases. */
    uint32_t numeric_cursor, top, index, alias_cursor;
    wl_columnar_eval_plan_numeric_phase_t numeric_phase;
    wl_columnar_eval_stack_unary_prepared_phase_t phase;
    wl_columnar_eval_stack_unary_prepared_disposition_t disposition;
#if defined(WL_HAVE_C11_THREADS)
    thrd_t owner_thread;
#elif defined(_WIN32) || defined(_WIN64)
    DWORD owner_thread;
#else
    pthread_t owner_thread;
#endif
    int first_result, cleanup_result;
    bool thread_valid, busy, control_ref, scalar_ready;
    bool old_held, output_held, alias_complete, needs_sanitize;
    bool commit_prepaid, committed, result_saved;
    /* Confirmation is earned by the paid ordinary JOIN context proof. */
    bool join_mode, publication_is_delta;
} wl_columnar_eval_stack_unary_prepared_t;
/* Structural bounds for actual staged byte writes. These are not packet
 * certificates: complete Native caller/body/return/ACK qualification is
 * separately required before this isolated candidate may be integrated. */
#define WL_COLUMNAR_EVAL_STACK_PREPARED_CLEAR_CAP 64u
#define WL_COLUMNAR_EVAL_STACK_PREPARED_WORK_CLEAR_CAP 32
#if WL_COLUMNAR_EVAL_STACK_PREPARED_WORK_CLEAR_CAP <= 0 \
    || WL_COLUMNAR_EVAL_STACK_PREPARED_WORK_CLEAR_CAP \
    > WL_COLUMNAR_EVAL_STACK_PREPARED_CLEAR_CAP
#error \
    Prepared work clear quantum must be positive and within constructor capacity
#endif
typedef char wl_columnar_eval_stack_prepared_clear_cap_fits_t[
        WL_COLUMNAR_EVAL_STACK_PREPARED_CLEAR_CAP > 0
        && WL_COLUMNAR_EVAL_STACK_PREPARED_CLEAR_CAP <= 64 ? 1 : -1];
typedef char wl_columnar_eval_stack_prepared_cursor_fits_t[
        (size_t)(uint32_t)sizeof(wl_columnar_eval_stack_unary_prepared_t) ==
        sizeof(wl_columnar_eval_stack_unary_prepared_t) ? 1 : -1];
typedef char wl_columnar_eval_stack_prepared_work_cursor_fits_t[
        (size_t)(uint32_t)sizeof(wl_columnar_eval_stack_unary_prepared_work_t)
        == sizeof(wl_columnar_eval_stack_unary_prepared_work_t) ? 1 : -1];

typedef struct {
    wl_columnar_eval_stack_unary_prepared_phase_t phase;
    wl_columnar_eval_stack_unary_prepared_disposition_t disposition;
    uint32_t alias_cursor;
    int first_result, cleanup_result;
    bool committed, result_saved, alias_complete, old_held, output_held;
} wl_columnar_eval_stack_unary_prepared_status_t;

int wl_columnar_eval_stack_unary_prepared_begin(
    wl_columnar_eval_stack_unary_prepared_t *,
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *, bool *);
/* Normal ordinary JOIN context at its real JOIN_DECIDE boundary. This
 * primitive does not itself select or own an automatic session driver. */
int wl_columnar_eval_stack_unary_prepared_join_begin(
    wl_columnar_eval_stack_unary_prepared_t *,
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *, bool *);
typedef enum {
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_INERT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_CAPTURE,
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_ADMIT,
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_CLEAR,
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_RESTORE,
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_PUBLISH,
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_CANCEL,
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_PUBLISHED,
    WL_COLUMNAR_EVAL_STACK_PREPARED_INIT_CANCELLED
} wl_columnar_eval_stack_prepared_init_phase_t;
typedef struct {
    wl_columnar_eval_stack_prepared_init_phase_t phase, action;
    const void *target, *numeric, *operation;
    uint64_t original_identity, original_id, support_identity, support_id;
    uint32_t cursor;
    wl_columnar_eval_cleanup_receipt_key_t key;
    int semantic_cause;
    bool action_pending, performed, physical_published, physical_cancelled,
        launch_consumed;
} wl_columnar_eval_stack_prepared_init_view_t;
typedef struct {
    int semantic_cause;
    bool selected, performed, published, cancelled, needs_ack, launch_consumed;
} wl_columnar_eval_stack_prepared_init_action_outcome_t;
int wl_columnar_eval_stack_unary_prepared_init_step_owned(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_evaluation_control_t *, uint64_t, bool *);
int wl_columnar_eval_stack_unary_prepared_init_cancel_owned(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_evaluation_control_t *, uint64_t, bool *);
int wl_columnar_eval_stack_unary_prepared_init_action_ack_owned(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_evaluation_control_t *, uint64_t);
/* Rebind a genuine ACKED receipt at actual quiescent ordinary JOIN FINISH.
 * Only distinct cleanup funding is charged. These typed steps may make multiple
 * genuine subadmissions; no whole-call256 bound is implied. Decline is legal
 * only before relation retirement commit/borrowed clear and preserves the
 * remaining owner, never already freed segment metadata. ACK uses the existing
 * terminal API; automatic driver selection is a separate integration. */
int wl_columnar_eval_stack_unary_prepared_join_finish_begin(
    wl_columnar_eval_stack_unary_prepared_t *,
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_stack_unary_prepared_join_finish_step(
    wl_columnar_eval_stack_unary_prepared_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_unary_prepared_join_finish_decline(
    wl_columnar_eval_stack_unary_prepared_t *, wl_evaluation_control_t *,
    uint64_t);
/* Quiet FINISH of an independent direct/composed numeric owner. All embedded
 * framed/native child owners are excluded before funding. Fresh zero setup or
 * genuine ACKED storage stays at its final address through existing ACK.
 * One actual distinct fresh financier per call; no Original polling. This
 * component does not automatically select a production parent/stream route. */
int wl_columnar_eval_stack_unary_prepared_operator_finish_begin(
    wl_columnar_eval_stack_unary_prepared_t *,
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_stack_unary_prepared_operator_finish_step(
    wl_columnar_eval_stack_unary_prepared_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_unary_prepared_operator_finish_decline(
    wl_columnar_eval_stack_unary_prepared_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_unary_prepared_step(
    wl_columnar_eval_stack_unary_prepared_t *);
int wl_columnar_eval_stack_unary_prepared_cancel(
    wl_columnar_eval_stack_unary_prepared_t *, int, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_unary_prepared_drain(
    wl_columnar_eval_stack_unary_prepared_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_unary_prepared_ack(
    wl_columnar_eval_stack_unary_prepared_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_unary_prepared_query(
    const wl_columnar_eval_stack_unary_prepared_t *,
    wl_columnar_eval_stack_unary_prepared_status_t *);
/* Original SEALED capability, prepaid COMMIT128, external serialization and
 * immediate callback-free publisher admission are mandatory preconditions. */
void wl_columnar_eval_stack_unary_commit_prepared_nofail(
    wl_columnar_eval_stack_unary_prepared_t *);
/* Copied exclusion observation only; never independent mutation authority. */
bool wl_columnar_eval_stack_frame_mutation_blocked(
    const wl_columnar_eval_stack_cleanup_frame_t *);
int wl_columnar_eval_stack_numeric_writable(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *);
int wl_columnar_eval_stack_framed_writable(
    const wl_columnar_eval_stack_cleanup_frame_t *, const wl_col_session_t *,
    const wl_columnar_eval_serial_framed_attempt_t *);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_stack_test_unary_prepared_checkpoint)(
    wl_columnar_eval_stack_unary_prepared_t *);
typedef struct {
    wl_columnar_eval_stack_prepared_init_phase_t phase;
    int cause, action_result;
    bool original_paid, admitted, acquired_ref, original_frozen, action_pending;
} wl_columnar_eval_stack_test_initializer_observation_t;
int wl_columnar_eval_stack_test_initializer_observe(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_columnar_eval_stack_test_initializer_observation_t *);
/* Test-only corruption of an authentic, idle selected initializer cursor.
 * No phase/owner can be fabricated; caller must settle admitted refusals. */
int wl_columnar_eval_stack_test_initializer_cursor(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_plan_numeric_attempt_t *,
    wl_columnar_eval_stack_prepared_init_phase_t, uint32_t, uint32_t *);
typedef struct {
    const void *receipt, *launch, *saved_binding, *operation;
    uint64_t launch_id, saved_binding_generation;
    unsigned phase, receipt_phase, parent_phase, numeric_phase, cursor;
    int launch_protocol, first_result;
    bool busy, committed, finish, abort_requested;
    bool initializer_pending;
    wl_columnar_eval_stack_prepared_init_phase_t initializer_phase;
} wl_columnar_eval_stack_test_auto_observation_t;
int wl_columnar_eval_stack_test_auto_observe(
    const wl_columnar_eval_stack_cleanup_frame_t *, const wl_col_session_t *,
    wl_columnar_eval_stack_test_auto_observation_t *);
/* Test-only copied observation; addresses are comparison tokens, never loans. */
typedef struct {
    const void *relation, *segments, *continuation;
    const void *snapshot_relation, *snapshot_segments;
    uint32_t segment_count, snapshot_segment_count;
    unsigned kind, phase, scalar_phase, scalar_init_phase, managed_phase;
    int first_result;
    bool owned, is_delta, committed, result_saved, scalar_started, scalar_ready;
    bool scalar_ledger_pending, credit_started[4], credit_empty[4];
} wl_columnar_eval_stack_test_unary_observation_t;
int wl_columnar_eval_stack_test_unary_observe(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_columnar_eval_stack_test_unary_observation_t *);
/* Test fixture transfers one genuine malloc-owned segment array on success.
 * Only authentic quiescent uncommitted FINISH; no phase/owner flags are seeded. */
int wl_columnar_eval_stack_test_unary_output_segments_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *, uint32_t *,
    uint32_t);
#endif

enum { WL_COLUMNAR_EVAL_SERIAL_FRAMED_HOST_WORK = 384 };

/* Copied observations only. Opaque addresses are comparison tokens, never
 * mutable frame/context/output loans or transferable ownership. */
typedef struct {
    const void *plan, *session, *control, *private_bindings, *capture_out;
    uint64_t attempt_id, operation_identity;
    bool capture_only, controlled_materialized_batch_fallback, abort_supported;
    bool prepared_unary_present, prepared_initializer_pending;
    wl_columnar_eval_cleanup_receipt_key_t cleanup_receipt_key;
    wl_columnar_eval_serial_framed_status_t status;
} wl_columnar_eval_serial_framed_view_t;

typedef enum {
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_ADVANCE = 0,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_STATUS,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_ABORT,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_RECEIPT_RETRY,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_RECEIPT_ACK,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_NATIVE_CLEANUP
} wl_columnar_eval_serial_framed_host_action_t;

typedef enum {
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_REPLY_REJECTED = 0,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_REPLY_MORE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_REPLY_BOOTSTRAP_RECEIPT,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_REPLY_STATUS,
    /* Native maintenance: preserve the completed launch tuple through ACK
     * and the following successful checked parent consumption. */
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_REPLY_PREPARED_MORE,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_REPLY_TERMINAL,
    WL_COLUMNAR_EVAL_SERIAL_FRAMED_REPLY_TERMINAL_CLEANUP_PENDING
} wl_columnar_eval_serial_framed_host_reply_kind_t;

typedef struct {
    wl_columnar_eval_serial_framed_host_reply_kind_t kind;
    int execution_result;
    int cleanup_result;
    bool committed;
    wl_columnar_eval_cleanup_receipt_key_t cleanup_receipt_key;
    wl_columnar_eval_serial_framed_status_t status;
} wl_columnar_eval_serial_framed_host_reply_t;

/* Exclusive serialized/native internal host only. Session, actual immutable
 * plan, original operation and all inputs remain live through true TERMINAL.
 * Request/reply are disjoint external objects; neither address is retained.
 * Each call performs ONE action, then returns before host finish(funding,0,0).
 * The host owns two or more stable grants/owner keys; never reset a pending
 * grant. Keep the latest nonSTATUS tuple across STATUS. A refused CONSUME
 * retains its old tuple; only successful consume releases that borrowed grant.
 * int is protocol only. Semantic fields are valid for TERMINAL and
 * TERMINAL_CLEANUP_PENDING; status only for STATUS and rc0.
 * TERMINAL_CLEANUP_PENDING means evaluation is terminal while its keyed frame
 * still needs cleanup retry; it is never logical success. Receipt-only STATUS,
 * ABORT/RECEIPT_RETRY and RECEIPT_ACK require copying the full key from reply.
 * MORE/BOOTSTRAP_RECEIPT rc0 is never logical success.
 * A bootstrap receipt with no durable parent proves only its completed grant:
 * exact association to this rp/session/original generation/native owner and
 * no synthesis/replay is a trusted caller precondition, not runtime authority.
 * The host begins original once using base.operation_admission, keeps it live
 * across progress, and finishes it only after TERMINAL if savedID still owns
 * that generation. A stopped/old parent may clean up without touching successor.
 * Public and whole-stratum STEP/SNAPSHOT are separately gated. */
struct wl_columnar_eval_serial_framed_host_request {
    wl_evaluation_control_t *funding;
    uint64_t funding_id;
    wl_evaluation_control_t *operation;
    uint64_t operation_id;
    /* Stable host operation identity, distinct from the control attempt ID. */
    uint64_t operation_identity;
    /* Frozen authorization from the controlled initial-STEP classifier. */
    bool controlled_materialized_batch_fallback;
    /* Private body evaluation is authenticated by the address-bound binding
     * record and captures its materialized result without registry publish. */
    const wl_columnar_eval_private_bindings_t *private_bindings;
    bool capture_only;
    col_rel_t **capture_out;
    wl_columnar_eval_serial_framed_host_action_t action;
    wl_columnar_eval_cleanup_receipt_key_t receipt_key;
    bool previous_valid;
    wl_columnar_eval_serial_framed_host_reply_kind_t previous_kind;
    int previous_protocol;
    wl_evaluation_control_t *previous_funding;
    uint64_t previous_funding_id;
    wl_columnar_eval_serial_framed_host_reply_t *reply;
};

int wl_columnar_eval_stack_cleanup_receipt_host_source(
    const wl_plan_relation_t *,
    wl_col_session_t *, bool,
    const wl_columnar_eval_serial_framed_host_request_t *,
    wl_session_source_finance_t *);
int wl_columnar_eval_stack_cleanup_receipt_host(const wl_plan_relation_t *,
    wl_col_session_t *, bool,
    const wl_columnar_eval_serial_framed_host_request_t *);

bool wl_columnar_eval_stack_auto_initializer_pending(
    const wl_columnar_eval_stack_cleanup_frame_t *);
int wl_columnar_eval_stack_auto_initializer_inspect(
    const wl_columnar_eval_stack_cleanup_frame_t *, const wl_col_session_t *,
    wl_columnar_eval_stack_prepared_init_view_t *);
/* Canonical private Step siblings. No generic transport or trusted flag;
 * whole Native/caller/ACK qualification remains required before activation. */
int wl_columnar_session_prepared_native_prove(
    wl_col_session_t *, const wl_columnar_eval_stack_cleanup_frame_t *,
    wl_evaluation_control_t *, uint64_t,
    const wl_columnar_eval_stack_prepared_init_action_outcome_t *, bool,
    bool *);
int wl_columnar_eval_stack_auto_initializer_main_launch_prove(
    wl_col_session_t *, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_evaluation_control_t *, uint64_t, int);
int wl_columnar_eval_stack_auto_initializer_main_action_owned(
    wl_col_session_t *, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_evaluation_control_t *, uint64_t,
    wl_columnar_eval_stack_prepared_init_action_outcome_t *);
int wl_columnar_eval_stack_auto_initializer_main_action_ack_owned(
    wl_col_session_t *, wl_columnar_eval_stack_cleanup_frame_t *,
    wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_stack_auto_initializer_action_owned(
    wl_col_session_t *, wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_serial_framed_host_request_t *,
    wl_evaluation_control_t *, uint64_t,
    wl_columnar_eval_stack_prepared_init_action_outcome_t *);
int wl_columnar_eval_stack_auto_initializer_action_ack_owned(
    wl_col_session_t *, wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_serial_framed_host_request_t *,
    wl_evaluation_control_t *, uint64_t);
/* Actual framed owner only. These adapters never lend a mutable receipt. */
int wl_columnar_eval_stack_auto_select(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t, bool *);
int wl_columnar_eval_stack_auto_maintain(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    const wl_columnar_eval_serial_framed_host_request_t *);
bool wl_columnar_eval_stack_auto_present(
    const wl_columnar_eval_stack_cleanup_frame_t *);
int wl_columnar_eval_stack_auto_close_ready(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_auto_consume(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t, bool, bool *);
bool wl_columnar_eval_stack_auto_error_drain(
    const wl_columnar_eval_serial_framed_attempt_t *);
/* Read-only observation of an actual registered native bound child debt.
 * Stored owner association is checked independently of the calling thread.
 * A nonzero first cause protects continuation; it never authorizes progress. */
int wl_columnar_eval_stack_auto_cleanup_debt(const wl_col_session_t *,
    const wl_columnar_eval_private_bindings_t *, uint64_t);
/* Scalar observations only. The complete private session dispatcher combines
 * real registered ownership, both native threads and fresh metadata admission;
 * neither query grants mutation authority or performs cleanup. */
bool wl_columnar_eval_stack_auto_cleanup_current(const wl_col_session_t *);
int wl_columnar_eval_stack_auto_cleanup_shape(const wl_col_session_t *,
    const wl_columnar_eval_serial_framed_attempt_t *);
/* Complete session-derived union of the two observations for the private
 * outer dispatcher. Returns no context loan or mutation permission. */
int wl_columnar_eval_stack_auto_cleanup_ready(const wl_col_session_t *);

typedef enum {
    WL_COLUMNAR_SESSION_METADATA_NATIVE_ERROR,
    WL_COLUMNAR_SESSION_METADATA_JOIN_CLEANUP,
    WL_COLUMNAR_SESSION_METADATA_UNARY_CLEANUP
} wl_columnar_session_metadata_purpose_t;
typedef enum {
    WL_COLUMNAR_SESSION_METADATA_SETUP_REFUSED,
    WL_COLUMNAR_SESSION_METADATA_BODY_RETURNED,
    WL_COLUMNAR_SESSION_METADATA_JOIN_PROOF_CLOSED,
    WL_COLUMNAR_SESSION_METADATA_JOIN_RETURN_CLOSED,
    WL_COLUMNAR_SESSION_METADATA_JOIN_UNUSED_CLOSED
} wl_columnar_session_metadata_event_t;

typedef enum {
    WL_COLUMNAR_SESSION_NATIVE_ERROR_INERT,
    WL_COLUMNAR_SESSION_NATIVE_ERROR_CHILD,
    WL_COLUMNAR_SESSION_NATIVE_ERROR_DISPOSE,
    WL_COLUMNAR_SESSION_NATIVE_ERROR_FINAL,
    WL_COLUMNAR_SESSION_NATIVE_ERROR_DONE
} wl_columnar_session_native_error_phase_t;

enum {
    WL_COLUMNAR_SESSION_SNAPSHOT_FINISH_PENDING = 1,
    WL_COLUMNAR_SESSION_SNAPSHOT_FINISH_SELECTED
};

enum {
    WL_COLUMNAR_SESSION_CONSTRUCTOR_GUARD = 1,
    WL_COLUMNAR_SESSION_CONSTRUCTOR_QUIET,
    WL_COLUMNAR_SESSION_CONSTRUCTOR_FINISH,
    WL_COLUMNAR_SESSION_CONSTRUCTOR_RESET,
    WL_COLUMNAR_SESSION_CONSTRUCTOR_READY,
    WL_COLUMNAR_SESSION_CONSTRUCTOR_QUIET_BORROWS,
    WL_COLUMNAR_SESSION_CONSTRUCTOR_REPORT
};

typedef enum {
    WL_COLUMNAR_SESSION_PRODUCER_NONE,
    WL_COLUMNAR_SESSION_PRODUCER_OWN_FORWARD_ERROR,
    WL_COLUMNAR_SESSION_PRODUCER_MATCHING_ORIGINAL_ENDED,
    WL_COLUMNAR_SESSION_FRONTIER_MATCHING_ORIGINAL_ENDED
} wl_columnar_session_producer_disposition_t;

typedef enum {
    WL_COLUMNAR_SESSION_TERMINAL_NORMAL = 1,
    WL_COLUMNAR_SESSION_TERMINAL_C1,
    WL_COLUMNAR_SESSION_TERMINAL_JOIN,
    WL_COLUMNAR_SESSION_TERMINAL_UNARY,
    WL_COLUMNAR_SESSION_TERMINAL_SNAPSHOT,
    WL_COLUMNAR_SESSION_TERMINAL_SNAPSHOT_PRIOR,
    WL_COLUMNAR_SESSION_TERMINAL_BEGIN_FAILURE,
    WL_COLUMNAR_SESSION_TERMINAL_COMPLETED,
    WL_COLUMNAR_SESSION_TERMINAL_ENDED_PRODUCER,
    WL_COLUMNAR_SESSION_TERMINAL_ENDED_FRONTIER
} wl_columnar_session_terminal_route_t;

typedef enum {
    WL_COLUMNAR_SESSION_TERMINAL_REGISTER = 1,
    WL_COLUMNAR_SESSION_TERMINAL_OLD_REGISTRY,
    WL_COLUMNAR_SESSION_TERMINAL_OLD_HASH_HEAD,
    WL_COLUMNAR_SESSION_TERMINAL_OLD_HASH_NEXT,
    WL_COLUMNAR_SESSION_TERMINAL_OLD_REGISTRY_CREDIT,
    WL_COLUMNAR_SESSION_TERMINAL_OLD_HASH_CREDIT,
    WL_COLUMNAR_SESSION_TERMINAL_IMAGE,
    WL_COLUMNAR_SESSION_TERMINAL_IMAGE_CREDIT,
    WL_COLUMNAR_SESSION_TERMINAL_ENTRIES,
    WL_COLUMNAR_SESSION_TERMINAL_HEADS,
    WL_COLUMNAR_SESSION_TERMINAL_ORIGINALS,
    WL_COLUMNAR_SESSION_TERMINAL_OVERRIDES,
    WL_COLUMNAR_SESSION_TERMINAL_OPS,
    WL_COLUMNAR_SESSION_TERMINAL_FRONTIER_SOURCES,
    WL_COLUMNAR_SESSION_TERMINAL_RETRY,
    WL_COLUMNAR_SESSION_TERMINAL_MAINTENANCE,
    WL_COLUMNAR_SESSION_TERMINAL_METADATA_MOVE,
    WL_COLUMNAR_SESSION_TERMINAL_TX_FREE,
    WL_COLUMNAR_SESSION_TERMINAL_CREDIT,
    WL_COLUMNAR_SESSION_TERMINAL_HANDOFF
} wl_columnar_session_terminal_phase_t;

typedef enum {
    WL_COLUMNAR_SESSION_FINANCE_CLOSE_FINISH = 1,
    WL_COLUMNAR_SESSION_FINANCE_CLOSE_DETACH,
    WL_COLUMNAR_SESSION_FINANCE_CLOSE_RELEASE,
    WL_COLUMNAR_SESSION_FINANCE_CLOSE_CONSUME,
    WL_COLUMNAR_SESSION_FINANCE_CLOSE_OBSERVED,
    WL_COLUMNAR_SESSION_FINANCE_REBEGIN,
    WL_COLUMNAR_SESSION_FINANCE_CLOSE_REPORT,
    WL_COLUMNAR_SESSION_FINANCE_COLD_BIRTH
} wl_columnar_session_finance_close_phase_t;
#ifdef WL_SESSION_TEST_HOOKS
wl_columnar_session_native_error_phase_t
wl_columnar_session_test_native_error_phase(const wl_col_session_t *);
#endif

int wl_columnar_eval_stack_auto_cleanup_admit(
    const wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
void wl_columnar_eval_stack_auto_child_acked(
    wl_columnar_eval_serial_framed_attempt_t *);
int wl_columnar_eval_plan_numeric_native_cleanup_step(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_numeric_native_cleanup_consume(
    wl_columnar_eval_serial_framed_attempt_t *, int, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_numeric_native_cleanup_ack(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
/* Distinct registered owning-session cleanup. No original generation poll,
 * forward evaluation, synthetic AUTO receipt or caller-supplied permit. */
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_stack_test_receipt_lookup_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint32_t);
#endif
int wl_columnar_eval_stack_cleanup_receipt_find_frame_attempt(
    wl_columnar_eval_stack_cleanup_frame_t *, uint32_t *,
    wl_columnar_eval_cleanup_receipt_key_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_stack_cleanup_receipt_frame_index_bind(
    wl_columnar_eval_stack_cleanup_frame_t *, uint32_t,
    const wl_columnar_eval_cleanup_receipt_key_t *);
int wl_columnar_eval_stack_cleanup_receipt_frame_birth_index_bind(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *);

int wl_columnar_eval_stack_cleanup_receipt_index_key_for_frame(
    wl_columnar_eval_stack_cleanup_frame_t *, uint32_t,
    wl_columnar_eval_cleanup_receipt_key_t *);
int wl_columnar_session_native_cleanup_receipt_index(const wl_col_session_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *, uint32_t *);
int wl_columnar_session_filter_append_supported_attempt_controlled(
    const wl_plan_expr_buffer_t *, bool *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_expr_requires_scalar_attempt_controlled(const uint8_t *,
    uint32_t, bool *, wl_evaluation_control_t *, uint64_t);
int wl_columnar_session_join_cleanup_register(wl_col_session_t *,
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t, uint32_t, bool);
int wl_columnar_session_unary_cleanup_register(wl_col_session_t *,
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t,
    uint32_t, bool);
typedef enum {
    WL_COLUMNAR_EVAL_PLAN_CLEANUP_JOIN,
    WL_COLUMNAR_EVAL_PLAN_CLEANUP_UNARY,
    WL_COLUMNAR_EVAL_PLAN_CLEANUP_OBSERVED
} wl_columnar_eval_plan_cleanup_kind_t;
typedef struct {
    bool handled;
    int protocol, execution_result, cleanup_result;
    bool committed;
} wl_columnar_session_observed_ack_result_t;
wl_columnar_session_observed_ack_result_t
    wl_columnar_session_observed_ack_resume(wl_col_session_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *, wl_evaluation_control_t *,
    uint64_t);
typedef struct {
    int protocol, cause;
    bool provisional;
} wl_columnar_session_observed_cleanup_result_t;
wl_columnar_session_observed_cleanup_result_t
    wl_columnar_session_observed_cleanup_prove(
    const wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t, wl_session_source_finance_t *);
wl_columnar_session_observed_cleanup_result_t
    wl_columnar_session_observed_cleanup_frame_prove(const wl_col_session_t *,
    const wl_columnar_eval_stack_cleanup_frame_t *, wl_evaluation_control_t *,
    uint64_t, wl_session_source_finance_t *);
wl_columnar_session_observed_cleanup_result_t
    wl_columnar_session_observed_cleanup_receipt_prove(const wl_col_session_t *,
    const wl_columnar_eval_cleanup_receipt_key_t *, wl_evaluation_control_t *,
    uint64_t, wl_session_source_finance_t *);
int wl_columnar_eval_plan_observed_native_cleanup_step(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_observed_native_cleanup_consume(
    wl_columnar_eval_serial_framed_attempt_t *, int, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_observed_native_cleanup_ack(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_filter_observed_native_cleanup_latch_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_evaluation_control_t *,
    uint64_t, bool *);
int wl_columnar_filter_observed_neverborn_owned(
    wl_columnar_eval_stack_cleanup_frame_t *,
    const void *, bool *);
int wl_columnar_session_unary_cleanup_prove(
    const wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t, wl_session_source_finance_t *, int *);
int wl_columnar_session_unary_cleanup_frame_prove(const wl_col_session_t *,
    const wl_columnar_eval_stack_cleanup_frame_t *, wl_evaluation_control_t *,
    uint64_t, wl_session_source_finance_t *, int *);
int wl_columnar_eval_plan_unary_native_cleanup_step(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_unary_native_cleanup_consume(
    wl_columnar_eval_serial_framed_attempt_t *, int, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_unary_native_cleanup_ack(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_filter_unary_native_cleanup_latch_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_evaluation_control_t *, uint64_t, bool *);
int wl_columnar_session_join_cleanup_prove(
    const wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t, wl_session_source_finance_t *, int *);
int wl_columnar_session_join_cleanup_frame_prove(const wl_col_session_t *,
    const wl_columnar_eval_stack_cleanup_frame_t *, wl_evaluation_control_t *,
    uint64_t, wl_session_source_finance_t *, int *);
int wl_columnar_eval_plan_numeric_join_cleanup_step(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_numeric_join_cleanup_consume(
    wl_columnar_eval_serial_framed_attempt_t *, int, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_plan_numeric_join_cleanup_ack(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_filter_op_native_cleanup_latch_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_evaluation_control_t *, uint64_t, bool *);
int wl_columnar_merge_concat_native_cleanup_latch_owned(
    wl_columnar_eval_stack_cleanup_frame_t *, const void *,
    wl_evaluation_control_t *, uint64_t);
bool wl_columnar_eval_stack_host_geometry(const wl_col_session_t *,
    const wl_columnar_eval_serial_framed_host_request_t *);

/* Serialized caller keeps session/control handles live. Copied outputs must
 * be external to the whole frame and disjoint from each other. Status keeps
 * its existing384 fee; the containing host retains its separate384 fee. */
/* Known protocol-owner storage is never a destination for copied outputs.
 * protocol_copy_output requires an already authenticated live frame.
 * marked_copy_output derives its frame only from the actual live session. */
bool wl_columnar_eval_stack_copy_ranges_disjoint(const void *, size_t,
    const void *, size_t);
bool wl_columnar_eval_stack_protocol_copy_output(
    const wl_columnar_eval_stack_cleanup_frame_t *, const void *, size_t);
bool wl_columnar_eval_stack_marked_copy_output(const wl_col_session_t *,
    const void *, size_t);
int wl_columnar_eval_stack_framed_authenticate(
    const wl_columnar_eval_stack_cleanup_frame_t *, const wl_col_session_t *,
    const wl_columnar_eval_serial_framed_attempt_t *);
int wl_columnar_eval_stack_framed_inspect(
    const wl_columnar_eval_stack_cleanup_frame_t *, const wl_col_session_t *,
    wl_columnar_eval_serial_framed_view_t *);
int wl_columnar_eval_stack_framed_status(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_serial_framed_status_t *,
    wl_columnar_eval_cleanup_receipt_key_t *, wl_evaluation_control_t *,
    uint64_t);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_stack_test_framed_status_checkpoint)(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *);
#endif
int wl_columnar_eval_stack_framed_context(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    wl_columnar_eval_serial_framed_attempt_t **);
int wl_columnar_eval_stack_framed_fresh(
    wl_columnar_eval_stack_cleanup_frame_t *,
    wl_columnar_eval_serial_framed_attempt_t *);
int wl_columnar_eval_stack_framed_claim(
    wl_columnar_eval_serial_framed_attempt_t *, bool);
int wl_columnar_eval_stack_framed_dispose_slot(
    wl_columnar_eval_serial_framed_attempt_t *, uint32_t);
int wl_columnar_eval_stack_framed_prove_slot(
    wl_columnar_eval_serial_framed_attempt_t *, uint32_t);
int wl_columnar_eval_stack_framed_release_gate(
    wl_columnar_eval_serial_framed_attempt_t *);
int wl_columnar_eval_stack_framed_normalize(
    wl_columnar_eval_serial_framed_attempt_t *);
int wl_columnar_eval_stack_framed_close_proof(
    wl_columnar_eval_serial_framed_attempt_t *);
int wl_columnar_eval_stack_framed_close_ready(
    wl_columnar_eval_serial_framed_attempt_t *);
bool wl_columnar_eval_serial_framed_owner_valid(
    const wl_columnar_eval_serial_framed_attempt_t *,
    const wl_columnar_eval_stack_cleanup_frame_t *);
int wl_columnar_eval_serial_framed_attempt_begin(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    const wl_plan_relation_t *, wl_evaluation_control_t *, uint64_t,
    uint64_t, bool, wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_serial_framed_attempt_begin_bound(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    const wl_plan_relation_t *, wl_evaluation_control_t *, uint64_t,
    uint64_t, bool, const wl_columnar_eval_private_bindings_t *, bool,
    col_rel_t **, wl_evaluation_control_t *, uint64_t);
int wl_columnar_eval_serial_framed_attempt_step(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_serial_framed_consume_result(
    wl_columnar_eval_serial_framed_attempt_t *, int,
    wl_evaluation_control_t *, uint64_t);
/* Private caller contract: only the parent dispatcher calls these after its
 * fresh HOST admission. Each call executes one direct cell, never Aconsume. */
int wl_columnar_session_hash_registry_attempt_begin(
    wl_columnar_eval_serial_framed_attempt_t *);
int wl_columnar_session_hash_registry_attempt_step(
    wl_columnar_eval_serial_framed_attempt_t *);
enum {
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_AFTER_BODY = 1,
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_AFTER_MERGE,
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_DURING_MERGE,
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_CONVERGENCE,
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_ALLOCATION_PRECHARGE,
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_ALLOCATION_ADMITTED,
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_SCHEMA_ADOPTED,
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_BEFORE_COMMIT,
    WL_COLUMNAR_SESSION_TEST_RECURSIVE_AFTER_COMMIT
};
#ifdef WL_SESSION_TEST_HOOKS
typedef struct {
    uint32_t phase;
    uint32_t stratum;
    uint32_t relation;
    uint32_t op;
    uint32_t registry_slot;
    uint32_t name_byte;
    uint32_t eval_stratum;
    uint32_t eval_relation;
    uint32_t call_actions;
    uint64_t charged_actions;
    bool ready;
    bool cursor_advance_pending;
    bool target_name_byte_active;
    bool entry_charged;
} wl_columnar_session_test_preflight_state_t;
extern unsigned wl_columnar_session_test_preflight_quantum;
extern void (*wl_columnar_session_test_recursive_step_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint32_t);
int wl_columnar_session_test_preflight_snapshot(wl_session_t *,
    wl_columnar_session_test_preflight_state_t *);
/* Fail one controlled STEP funding creation before it reaches the host. */
extern int wl_columnar_session_test_fail_framed_funding_before_stop;
extern int wl_columnar_session_test_fail_framed_funding_after_stop;
/* Capacity injection and read-only completed-grant observation only. These
 * callbacks never dispatch engines or alter classifier/receipt authority. */
/* Fresh forward registration only; before funding and before Original poll. */
int wl_columnar_session_test_head_scalar_state(wl_col_session_t *,
    uint64_t [4], bool);
extern void (*wl_columnar_session_test_filter_append_checkpoint)(
    wl_evaluation_control_t *, unsigned, bool);
extern void (*wl_columnar_session_test_head_scalar_checkpoint)(
    wl_evaluation_control_t *, unsigned, uint32_t);
extern void (*wl_columnar_session_test_frontier_build_checkpoint)(
    wl_col_session_t *, bool, int);
extern void (*wl_columnar_session_test_join_birth_checkpoint)(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t, unsigned, uint32_t, bool);
extern void (*wl_columnar_eval_stack_test_incoming_launch_checkpoint)(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t, unsigned, int, bool, bool, bool);
extern void (*wl_columnar_eval_stack_test_canonical_before_proof)(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    const wl_columnar_eval_serial_framed_host_request_t *);
int wl_columnar_eval_stack_test_canonical_refusals(
    wl_columnar_eval_stack_cleanup_frame_t *, wl_col_session_t *,
    const wl_columnar_eval_serial_framed_host_request_t *);
int wl_columnar_eval_stack_test_prepared_clear_work(
    wl_columnar_eval_stack_unary_prepared_t *);
extern uint64_t (*wl_columnar_session_test_framed_grant_limit)(
    const wl_col_session_t *, wl_columnar_eval_serial_framed_host_action_t,
    uint64_t);
int wl_columnar_session_test_host_abort(wl_col_session_t *);
extern void (*wl_columnar_session_test_framed_grant_finished)(
    const wl_col_session_t *, wl_columnar_eval_serial_framed_host_action_t,
    wl_evaluation_control_t *, int);
/* Pre-create capacity/diagnostics only; no private metadata pointer or ID.
 * Test-only: quiescent native-INERT debt may reset/rebegin an already inactive
 * ORIGINAL through checked control APIs.
 * Saved IDs/bindings/receipts/proofs and original configuration stay unchanged.
 * STEP/try_destroy probes require existing admission EBUSY before dispatch.
 * Completed observer is pure, BY VALUE, after metadata detach/final release. */
extern uint64_t (*wl_columnar_session_test_metadata_limit)(
    const wl_col_session_t *, wl_columnar_session_metadata_purpose_t, uint64_t);
extern void (*wl_columnar_session_test_metadata_finished)(
    const wl_col_session_t *, wl_columnar_session_metadata_purpose_t,
    wl_columnar_session_metadata_event_t, int, wl_evaluation_control_report_t);
extern int wl_columnar_session_test_exhaust_after_relation;
/* Fail this many restorations of host input into a reset head. */
extern int wl_columnar_session_test_fail_restore_seed;
extern int wl_columnar_session_hash_test_registry_allocation;
extern int (*wl_columnar_session_hash_test_registry_move)(
    wl_columnar_eval_serial_framed_attempt_t *, unsigned, bool);
#endif
int wl_columnar_eval_serial_framed_attempt_publish(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_serial_framed_attempt_discard(
    wl_columnar_eval_serial_framed_attempt_t *, wl_evaluation_control_t *,
    uint64_t);
int wl_columnar_eval_serial_framed_attempt_status(
    wl_columnar_eval_serial_framed_attempt_t *,
    wl_columnar_eval_serial_framed_status_t *, wl_evaluation_control_t *,
    uint64_t);
/* DONE has no remaining resource owner except parent pin and empty frame.
 * After admission ACK and mandatory empty-frame close form one action. No
 * callback/poll/admission/host return intervenes; ctx is freed on success.
 * Final physical/credit/ref release retains the existing invariant contract. */
int wl_columnar_eval_serial_framed_attempt_close(
    wl_columnar_eval_serial_framed_attempt_t *, int *, bool *,
    wl_evaluation_control_t *, uint64_t);
#ifdef WL_SESSION_TEST_HOOKS
extern void (*wl_columnar_eval_serial_test_framed_checkpoint)(
    wl_columnar_eval_serial_framed_attempt_t *);
extern int wl_columnar_eval_serial_test_framed_fail_allocation;
typedef struct {
    unsigned phase, finance_kind;
    uint64_t ticket, operation_identity, original_attempt_id;
    wl_evaluation_control_report_t report;
    bool finance_consumed, local_reset_completed, actor_current;
    bool invocation_accepted, backend_active, endpoint_busy, source_ready;
    bool ack_paid, ack_prepared, transaction_present, main_pending,
        parent_pending;
} wl_columnar_session_test_completed_view_t;
/* Plain descriptive snapshot only; no owner, controller or resource loan. */
int wl_columnar_session_test_completed_view(const wl_col_session_t *,
    wl_columnar_session_test_completed_view_t *);
#endif

/* Retire workers a failed attempt retained.  They can borrow coordinator heads,
 * which refuses a clear of those heads.  Otherwise only the next stratum's
 * worker setup, or destroying the session, would retire them. */
int
wl_columnar_eval_retire_retained_workers(wl_col_session_t *coord);

#endif /* WL_COLUMNAR_INTERNAL_H */
