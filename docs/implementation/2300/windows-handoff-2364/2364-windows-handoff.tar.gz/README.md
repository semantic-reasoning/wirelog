# PR2364 Windows handoff archival reference

This is an archival reference, NOT active production code and NOT an accepted Source/Native bound. The active rebased code is supplied by the Draft PR commits.

original-snapshot contains ALL16 old a8dfa..9914 commits in a verified Git bundle plus the complete9914→3b547 WIP binary patch (53 paths,9 additions) and per-file hashes. Prerequisite a8dfa5b35618a874b8f34fd25efbca0ada99f009 remains in main history. In an independent clone: fetch main, git fetch pre-rebase-commits.bundle HEAD, checkout detached9914e9b4, git apply --check pre-rebase-wip.patch, then git apply pre-rebase-wip.patch. Do NOT apply that old patch on top of the rebased Draft.

ARCHIVAL-NOT-ACTIVE contains isolated Native9caf/tree4a449 and four-FINAL Source53d56/tree705813 experiments. These were NOT ported into active Root code. Preserve their complete types, original versions and unqualified status; never copy them wholesale over current main.

Evidence scripts/fixtures/reports preserve original bytes and original Linux absolute paths/pins. They are reference inputs, NOT turnkey Windows tools: regenerate real Windows compiler/SDK/call/declaration/ABI captures and rebind exact paths/hashes after rebase. Original full-dataset SHA manifests may name omitted captures and cannot be verified from this compact archive. ARCHIVE-MANIFEST.json verifies only actual included bytes.

Excluded deliberately:92GiB original evidence, full AST/LLVM/preprocessed captures, SDK/CRT headers, third-party DLLs, portable PowerShell binary, virtualenvs/caches, environment/credential dumps and signed URLs. OMITTED.json lists top-level files excluded from selected evidence datasets; deeper capture trees are also excluded. Reproduce them with genuine Windows tools.

Known latest Native adapter stop: genuine production-O2 removes standalone helper LLVM bodies; all8 current/equal registrations reject before measurement. No completed C/P upper exists. Old225/254/259 raw-node tallies are NOT contextual scalar lower bounds. Const-member and thread-boundary adapters have only scoped default-OFF method approval, not production fit. Root C1 lifetime approval is source-bound to old3b547; new9caf changed producers still need separate lineage/drain/ABI qualification.

Actual Windows diagnostic branch diagnostic/windows-thread-provider-v1 commit64ab0edd: run43543099572/artifact14092384850 failed before compiler because Get-Command.Source returned three git.exe paths. manifest.json records the actual error. No MSVC-C11/native actor/runtime result was obtained. The earlier run43541685883 failed PowerShell parsing; local isolated real parser fixed that specific syntax issue only.

Fresh rebased source-only snapshot is5c7b6e879703c92c8d3ac0790af37df6f54416c5 on main60e28c6f with16rebased commits. New full Clang720 tests:705OK/13SKIP/2FAIL; reduce report3817vs3560 at194, empty-expression cleanup assertion1180 SIGABRT. LLVM22tidy ratchet PASS. These remain explicit unfinished Draft defects, not flakes or completed acceptance. See evidence/draft-rebase-integration-v1/fresh-broad-summary.json.
