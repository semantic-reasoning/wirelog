"""Binding-only new-method check of held actual Core AST. No cell counting."""
import pathlib,json,argparse
import enum_switch_counter as m
E=pathlib.Path(__file__).parent;D=E.parent/'architect-financial-packets-component-v1'
p=D/'C11-production-Core.ast.jsons';nodes=list(m.c.objects(p.read_text()))
f=next(x for x in nodes if x.get('name')==m.API and any(q.get('kind')=='CompoundStmt' for q in x.get('inner',[])))
source=D/'snapshot/wirelog/evaluation_control.c';data=source.read_bytes()
fs={m.API:{'ast':f,'unit':'Core'}};src={'Core':{'path':str(source),'data':data,'sha256':m.c.sha(data)}}
rows=[]
for state in ['STANDBY','STOPPED_STANDBY','PF_FROZEN','PF_HEADER_BUILT','PF_BODY_BUILT','PF_PUBLISHED','PF_HEADER_CHECKED','PF_TOTALS_CHECKED','FINISH_PENDING','PF_VERIFIED']:
 name='WL_EVALUATION_CONTROL_SOURCE_'+state
 o=m.Counter(fs,src,'',nodes,{m.API:{'enum':'wl_evaluation_control_source_financial_state_t','input':name,'selector':'state'}})
 b=o.bind_function(m.API)
 assert not o.events
 rows.append({'input':name,'value':b['value'],'derived_active':b['active'],'selector_decl_id':b['var'],'enum_decl_id':b['enum']['decl']['id'],'labels_per_switch':[len(x['labels']) for x in b['switches'].values()]})
result={'scope':'v1b binding-only actual frozen B; no packet cells or fit exception','module_sha256':m.c.sha((E/'enum_switch_counter.py').read_bytes()),'core_ast_sha256':m.c.sha(p.read_bytes()),'core_source_sha256':m.c.sha(data),'rows':rows}
target=E/'actual-v1b-binding-audit.json'
a=argparse.ArgumentParser();a.add_argument('--capture',action='store_true');args=a.parse_args()
if args.capture:
 if target.exists():raise RuntimeError('capture refuses overwrite of held binding')
 target.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
else:
 if json.loads(target.read_text())!=result:raise RuntimeError('held binding mismatch')
 print(json.dumps({'status':'PASS','actual_binding_rows':len(rows),'packet_cell_ledgers':0}))
