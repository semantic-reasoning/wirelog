"""Narrow enum-switch extension of unchanged v2a. Upper only; not Source fit."""
import pathlib,sys
BASE=pathlib.Path(__file__).parent.parent
sys.path.insert(0,str(BASE/'architect-source-counter-v2a'))
import counter_v2 as c
import run_profile as r
API='wl_evaluation_control_source_financial_progress_owned'
FIXTURES={'fixture_one','fixture_group','fixture_fall','fixture_default',
 'fixture_return','fixture_condbreak','fixture_seq','fixture_bad','fixture_aggregate'}
class SwitchBreak(Exception):pass

def walk(n):
 yield n
 for q in n.get('inner',[]):yield from walk(q)
def strip(n):
 while n.get('kind')=='ImplicitCastExpr':
  if n.get('castKind') not in {'LValueToRValue','IntegralCast','IntegralToBoolean','NoOp'} or len(n.get('inner',[]))!=1:
   raise RuntimeError('unsupported selector/value promotion')
  n=n['inner'][0]
 return n

def int_const(n,known=None):
 n=strip(n)
 if n.get('kind')=='ConstantExpr':
  if 'value' in n:return int(n['value'])
  if len(n.get('inner',[]))==1:return int_const(n['inner'][0],known)
 if n.get('kind')=='IntegerLiteral':return int(n['value'])
 if n.get('kind')=='DeclRefExpr' and known is not None:
  ident=n.get('referencedDecl',{}).get('id')
  if ident in known:return known[ident][1]
 if n.get('kind')=='UnaryOperator' and n.get('opcode') in ('+','-') and len(n.get('inner',[]))==1:
  v=int_const(n['inner'][0],known);return v if n['opcode']=='+' else -v
 raise RuntimeError('unresolved actual constant')

class EnumCatalog:
 def __init__(self,nodes):
  self.nodes={};self.object_ids=set()
  for root in nodes:
   for q in walk(root):
    self.object_ids.add(id(q))
    if q.get('id'):
     old=self.nodes.get(q['id'])
     if old is None or len(q)>len(old):self.nodes[q['id']]=q
  self.enums={};self.enum_by_typedef={}
  for q in self.nodes.values():
   if q.get('kind')!='EnumDecl':continue
   cs=[x for x in q.get('inner',[]) if x.get('kind')=='EnumConstantDecl']
   if not cs:continue
   vals={};ids={};v=-1
   for x in cs:
    ini=x.get('inner',[])
    if ini:
     if len(ini)!=1:raise RuntimeError('ambiguous enum value')
     v=int_const(ini[0],ids)
    else:v+=1
    if x['name'] in vals:raise RuntimeError('duplicate enum name')
    vals[x['name']]=v;ids[x['id']]=(x['name'],v)
   self.enums[q['id']]={'decl':q,'values':vals,'ids':ids}
  for q in self.nodes.values():
   if q.get('kind')=='TypedefDecl':
    es=[x for x in walk(q) if x.get('kind')=='EnumType']
    if len(es)==1 and es[0].get('decl',{}).get('id') in self.enums:
     self.enum_by_typedef[q['name']]=(q['id'],es[0]['decl']['id'])
 def bind(self,var,annotation):
  t=annotation['enum']
  if t not in self.enum_by_typedef:raise RuntimeError('unknown actual enum typedef')
  alias,eid=self.enum_by_typedef[t]
  if var.get('type',{}).get('typeAliasDeclId')!=alias:
   raise RuntimeError('selector not bound to annotated enum declaration in this TU')
  en=self.enums[eid];name=annotation['input']
  if name not in en['values']:raise RuntimeError('annotation is not an enumerator of selector enum')
  return en,en['values'][name]

class Counter(r.Counter):
 def __init__(self,fs,srcs,hooks,nodes,annotations):
  super().__init__(fs,srcs,hooks);self.catalog=EnumCatalog(nodes)
  self.annotations=annotations;self.contexts=[];self.switch_depth=0;self.audit=[]
 def flatten(self,sw,en):
  cs=sw.get('inner',[])
  if len(cs)!=2 or cs[1].get('kind')!='CompoundStmt':raise RuntimeError('unsupported switch shape')
  seq=[];labels=[];seen=set();default=False
  def add(n):
   nonlocal default
   k=n.get('kind');children=n.get('inner',[])
   if k=='CaseStmt':
    if n.get('isGNURange') or len(children)!=2:raise RuntimeError('case range/malformed label unsupported')
    lab=strip(children[0]);refs=[x.get('referencedDecl',{}) for x in walk(lab) if x.get('kind')=='DeclRefExpr']
    refs=[x for x in refs if x.get('kind')=='EnumConstantDecl']
    if len(refs)!=1 or refs[0].get('id') not in en['ids']:raise RuntimeError('case label from unknown/unrelated enum')
    val=int_const(lab,en['ids'])
    if en['ids'][refs[0]['id']][1]!=val:raise RuntimeError('compiler case value disagrees with enum declaration')
    if val in seen:raise RuntimeError('duplicate case value')
    seen.add(val);token={'label':True,'value':val,'ast':n};labels.append(token);seq.append(token);add(children[1])
   elif k=='DefaultStmt':
    if default or len(children)!=1:raise RuntimeError('default ambiguity')
    default=True;token={'label':True,'value':None,'ast':n};labels.append(token);seq.append(token);add(children[0])
   else:
    if any(x.get('kind') in {'CaseStmt','DefaultStmt','LabelStmt'} for x in walk(n)):
     raise RuntimeError('hidden label unsupported')
    seq.append({'label':False,'ast':n})
  for n in cs[1]['inner']:add(n)
  return seq,labels
 def bind_function(self,name):
  if name!=API and name not in FIXTURES:raise RuntimeError('unqualified engine switch function')
  a=self.annotations.get(name)
  if not a:raise RuntimeError('missing explicit enum path annotation')
  if id(self.fs[name]['ast']) not in self.catalog.object_ids:raise RuntimeError('function/enum must come from same actual TU objects')
  if self.fs[name]['ast'].get('isInvalid'):raise RuntimeError('invalid compiler AST')
  body=next(x for x in self.fs[name]['ast']['inner'] if x.get('kind')=='CompoundStmt')
  if any(x.get('isInvalid') for x in walk(body)):raise RuntimeError('invalid compiler AST')
  vars=[x for x in walk(body) if x.get('kind')=='VarDecl' and x.get('name')==a['selector']]
  if len(vars)!=1:raise RuntimeError('selector is not unique actual local VarDecl')
  var=vars[0];vid=var['id'];en,value=self.catalog.bind(var,a)
  def mentions(n):return any(x.get('kind')=='DeclRefExpr' and x.get('referencedDecl',{}).get('id')==vid for x in walk(n))
  for n in walk(body):
   k=n.get('kind');cs=n.get('inner',[])
   if k in {'ForStmt','WhileStmt','DoStmt','GotoStmt','ContinueStmt','LabelStmt'}:raise RuntimeError('unsupported control in switch function')
   if k in {'BinaryOperator','CompoundAssignOperator'} and cs and (n.get('opcode')=='=' or k=='CompoundAssignOperator') and mentions(cs[0]):
    raise RuntimeError('selector write invalidates saved enum')
   if k=='UnaryOperator' and n.get('opcode') in {'&','++','--'} and mentions(n):
    raise RuntimeError('selector address escape/write')
  allsw=[x for x in walk(body) if x.get('kind')=='SwitchStmt']
  sws=[x for x in body['inner'] if x.get('kind')=='SwitchStmt']
  if len(allsw)!=len(sws) or not sws or len(sws)>2:raise RuntimeError('nested/non-top-level switch unsupported')
  if name==API and len(sws)!=2:raise RuntimeError('actual API must retain both sequential switches')
  result={'var':vid,'enum':en,'value':value,'switches':{},'active':None,'active_var':None,'visits':[]}
  for sw in sws:
   sel=strip(sw['inner'][0])
   if sel.get('kind')!='DeclRefExpr' or sel.get('referencedDecl',{}).get('id')!=vid:
    raise RuntimeError('switches do not consume same original enum local')
   seq,labs=self.flatten(sw,en)
   matches=[i for i,x in enumerate(seq) if x['label'] and x['value']==value]
   if not matches:matches=[i for i,x in enumerate(seq) if x['label'] and x['value'] is None]
   if len(matches)!=1:raise RuntimeError('selected path has no unique matching/default label')
   result['switches'][sw['id']]={'seq':seq,'labels':labs,'start':matches[0]}
  if len(sws)==2:
   classifier_nodes={x.get('id') for x in walk(sws[0])}
   first=result['switches'][sws[0]['id']];chosen=[];has_break=False
   for token in first['seq'][first['start']+1:]:
    if token['label']:continue
    n=token['ast']
    if n['kind']=='BreakStmt':
     has_break=True;break
    chosen.append(n)
   # Derive only an actually unconditional assignment. Recursively finding a
   # write under an IfStmt can use an unexecuted RHS and undercount a ternary.
   if (not has_break or len(chosen)!=1
       or chosen[0].get('kind')!='BinaryOperator'
       or chosen[0].get('opcode')!='='):
    raise RuntimeError('classification requires unconditional direct assignment then break')
   assigns=[chosen[0]]
   lhs=strip(assigns[0]['inner'][0]);rhs=assigns[0]['inner'][1]
   if lhs.get('kind')!='DeclRefExpr':raise RuntimeError('classification target not local')
   av=self.catalog.nodes.get(lhs['referencedDecl']['id'],{})
   if av.get('kind')!='VarDecl' or av.get('type',{}).get('qualType') not in {'bool','_Bool'}:raise RuntimeError('classification target is not actual boolean VarDecl')
   v=int_const(rhs)
   if v not in (0,1):raise RuntimeError('classification value not boolean')
   result['active']=bool(v);result['active_var']=av['id']
   if 'active' in a and a['active']!=result['active']:raise RuntimeError('conflicting active annotation')
   ts=[x for x in walk(body) if x.get('kind')=='ConditionalOperator']
   if name==API:
    ats=[x for x in ts if strip(x['inner'][0]).get('referencedDecl',{}).get('id')==av['id']]
    if len(ats)!=1:
     raise RuntimeError('actual active ternary is not bound to classifier')
   # The derived bool must remain immutable after classification.
   for n in walk(body):
    if n.get('kind')=='UnaryOperator' and n.get('opcode') in {'&','++','--'} and any(x.get('referencedDecl',{}).get('id')==av['id'] for x in walk(n)):
     raise RuntimeError('classification boolean escapes/mutates')
    if n.get('kind') in {'BinaryOperator','CompoundAssignOperator'} and (n.get('opcode')=='=' or n.get('kind')=='CompoundAssignOperator') and n.get('id') not in classifier_nodes and any(x.get('referencedDecl',{}).get('id')==av['id'] for x in walk(n['inner'][0])):
     raise RuntimeError('classification boolean overwritten')
  return result
 def run(self,name):
  if name not in self.annotations:
   # New engine switches without an explicit annotation never acquire support.
   return super().run(name)
  bound=self.bind_function(name)
  old=c.TERNARY.get(name);had=name in c.TERNARY
  if bound['active'] is not None:
   if had and old!=[bound['active']]:raise RuntimeError('caller ternary choices conflict with derived classifier')
   c.TERNARY[name]=[bound['active']]
  self.contexts.append((name,bound))
  try:
   super().run(name)
   self.audit.append({'function':name,'enum_decl_id':bound['enum']['decl']['id'],'selector_decl_id':bound['var'],'input_value':bound['value'],'derived_active':bound['active'],'visited_switch_ids':bound['visits']})
  finally:
   if had:c.TERNARY[name]=old
   else:c.TERNARY.pop(name,None)
   self.contexts.pop()
 def stmt(self,n):
  if n.get('kind')=='SwitchStmt' and self.stack[-1]['name'] in self.annotations:
   if self.switch_depth:raise RuntimeError('nested switch unsupported')
   name,bound=self.contexts[-1]
   if name!=self.stack[-1]['name'] or n['id'] not in bound['switches']:raise RuntimeError('switch not in actual bound function')
   desc=bound['switches'][n['id']];bound['visits'].append(n['id'])
   self.expr(n['inner'][0]);self.emit(n,'enum_switch_front')
   for token in desc['labels']:self.emit(token['ast'],'enum_dispatch_label_front',1,'upper only: every actual case/default label covered')
   self.switch_depth+=1
   try:
    for token in desc['seq'][desc['start']+1:]:
     if not token['label']:self.stmt(token['ast'])
   except SwitchBreak:pass
   finally:self.switch_depth-=1
  elif n.get('kind')=='BreakStmt':
   if not self.switch_depth:raise RuntimeError('break outside supported switch')
   self.emit(n,'break_front');raise SwitchBreak()
  else:super().stmt(n)
