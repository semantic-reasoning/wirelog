import pathlib,sys,tempfile,subprocess,json,hashlib,unittest,os,copy
E=pathlib.Path(__file__).parent
sys.path.insert(0,str(E));import enum_switch_counter as m
c=m.c
import dependency_binding as d
PRE='typedef enum { A=0, B, C, D } state_t; typedef enum { OTHER_A=0, OTHER_B } other_t;\n'
class MethodTests(unittest.TestCase):
 evidence=[]
 @classmethod
 def tearDownClass(cls):
  if os.environ.get('ENUM_METHOD_CAPTURE'):
   pathlib.Path(os.environ['ENUM_METHOD_CAPTURE']).write_text(json.dumps(cls.evidence,indent=2,sort_keys=True)+'\n')
 def compile(self,source):
  with tempfile.TemporaryDirectory(prefix='enum-method-') as td:
   p=pathlib.Path(td)/'fixture.c';p.write_text(source)
   common=['clang','--target=x86_64-pc-linux-gnu','-std=c11']
   cmd=common+['-fsyntax-only','-Xclang','-ast-dump=json',str(p)]
   before=d.inventory(common,p,td)
   v=subprocess.run(cmd,capture_output=True,text=True)
   after=d.inventory(common,p,td);d.compare(before,after);d.verify_files(before)
   rec={'source':source,'source_sha256':c.sha(source.encode()),'command':cmd,'returncode':v.returncode,'ast_sha256':c.sha(v.stdout.encode()),'stderr':v.stderr,'ast_text':v.stdout,'input_binding':before,'dependencies_retained':{name:{'sha256':info['sha256'],'text':pathlib.Path(name).read_text()} for name,info in before['dependencies'].items()}}
   self.evidence.append(rec)
   if v.returncode:raise RuntimeError('compiler rejected fixture: '+v.stderr)
   nodes=list(c.objects(v.stdout));c.register_types(nodes)
   fs={}
   for root in nodes:
    for n in m.walk(root):
     if n.get('kind')=='FunctionDecl' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[])):
      fs[n['name']]={'ast':n,'unit':'Fixture'}
   return fs,nodes,{'Fixture':{'path':str(p),'data':source.encode(),'sha256':c.sha(source.encode())}}
 def count(self,body,input='A',name='fixture_bad',enum='state_t',choices=None,annotation=True,extra='',patch=None):
  source=PRE+extra+'\nint '+name+'(state_t input,int *out){state_t state=input;'+body+'}\n'
  fs,nodes,srcs=self.compile(source)
  if patch:patch(fs,nodes)
  c.CHOICES[name]=list(choices or [])
  annotations={name:{'enum':enum,'input':input,'selector':'state'}} if annotation else {}
  obj=m.Counter(fs,srcs,'',nodes,annotations);self.last_counter=obj
  try:obj.run(name)
  except RuntimeError as error:
   self.evidence[-1]['counter_status']='REJECTED';self.evidence[-1]['counter_reason']=str(error);raise
  self.evidence[-1]['counter_status']='COUNTED_FIXTURE_ONLY';self.evidence[-1]['counter_events']=obj.events
  return obj
 def stores(self,obj):return [q['source'] for q in obj.events if q['kind']=='scalar_store' and q['source'].startswith('*out')]
 def test_single_case_and_following_siblings(self):
  o=self.count('switch(state){case A:*out=11;break;case B:*out=22;break;default:*out=33;break;}*out=44;return 0;',name='fixture_one')
  self.assertEqual(self.stores(o),['*out=11','*out=44'])
  self.assertEqual(sum(x['kind']=='enum_dispatch_label_front' for x in o.events),3)
  self.assertEqual(sum(x['kind']=='enum_switch_front' for x in o.events),1)
 def test_grouped_nested_label_once(self):
  body='switch(state){case A:case B:*out=21;break;default:*out=33;break;}return 0;'
  for state in ['A','B']:
   o=self.count(body,state,name='fixture_group');self.assertEqual(self.stores(o),['*out=21'])
   self.assertEqual(sum(x['kind']=='enum_dispatch_label_front' for x in o.events),3)
 def test_fallthrough_executes_later_body(self):
  o=self.count('switch(state){case A:*out=1;case B:*out=2;break;default:*out=3;break;}*out=9;return 0;',name='fixture_fall')
  self.assertEqual(self.stores(o),['*out=1','*out=2','*out=9'])
  self.assertEqual(sum(x['kind']=='break_front' for x in o.events),1)
 def test_default_only_when_no_matching_case(self):
  o=self.count('switch(state){case A:*out=1;break;default:*out=3;break;}return 0;',input='D',name='fixture_default')
  self.assertEqual(self.stores(o),['*out=3'])
 def test_return_unwinds_function_without_tail(self):
  o=self.count('switch(state){case A:*out=1;return 7;case B:*out=2;break;default:*out=3;break;}*out=9;return 0;',name='fixture_return')
  self.assertEqual(self.stores(o),['*out=1']);self.assertEqual(o.events[-1]['source'],'return 7')
  self.assertFalse(any(x['kind']=='break_front' for x in o.events))
 def test_conditional_break_exits_only_switch(self):
  o=self.count('switch(state){case A:if(input==A)break;*out=1;break;default:*out=3;break;}*out=9;return 0;',name='fixture_condbreak',choices=[True])
  self.assertEqual(self.stores(o),['*out=9'])
 def seq(self,state='A',active=None,bodyextra=''):
  body='_Bool active;switch(state){case A:active=1;break;case B:active=0;break;default:active=0;break;}'+bodyextra+'switch(state){case A:*out=1;break;case B:*out=2;break;default:*out=3;break;}*out=active?1:0;return 0;'
  source=PRE+'int fixture_seq(state_t input,int*out){state_t state=input;'+body+'}'
  fs,nodes,srcs=self.compile(source);c.CHOICES['fixture_seq']=[]
  a={'enum':'state_t','input':state,'selector':'state'}
  if active is not None:a['active']=active
  obj=m.Counter(fs,srcs,'',nodes,{'fixture_seq':a});obj.run('fixture_seq');return obj
 def test_sequential_switches_derive_both_active_values(self):
  for state,active in [('A',True),('B',False)]:
   o=self.seq(state);self.assertIs(o.audit[0]['derived_active'],active);self.assertEqual(len(o.audit[0]['visited_switch_ids']),2)
   self.assertEqual(sum(x['kind']=='enum_dispatch_label_front' for x in o.events),6)
 def test_conflicting_external_active_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'conflicting active'):self.seq('A',False)
 def test_conflicting_existing_ternary_rejected(self):
  c.TERNARY['fixture_seq']=[False]
  try:
   with self.assertRaisesRegex(RuntimeError,'ternary choices conflict'):self.seq('A')
  finally:c.TERNARY.pop('fixture_seq',None)
 def test_selector_write_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'selector write'):self.seq(bodyextra='state=B;')
 def test_selector_address_escape_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'address escape'):self.seq(bodyextra='state_t *alias=&state;*alias=B;')
 def test_selector_passed_to_visible_call_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'address escape'):
   self.count('touch(&state);switch(state){case A:break;default:break;}return 0;',extra='void touch(state_t*);')
 def test_unrelated_enum_same_numeric_annotation_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'selector not bound'):
   self.count('switch(state){case A:break;default:break;}return 0;',input='OTHER_A',enum='other_t')
 def test_unknown_enum_enumerator_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'not an enumerator'):
   self.count('switch(state){case A:break;default:break;}return 0;',input='OTHER_A')
 def test_no_annotation_fails_closed(self):
  with self.assertRaises(RuntimeError):self.count('switch(state){case A:break;default:break;}return 0;',annotation=False)
 def test_unknown_function_not_allowlisted(self):
  with self.assertRaisesRegex(RuntimeError,'unqualified engine'):
   self.count('switch(state){case A:break;default:break;}return 0;',name='unqualified_fn')
 def test_explicit_selector_cast_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'same original enum'):
   self.count('switch((int)state){case A:break;default:break;}return 0;')
 def test_gnu_range_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'case range'):
   self.count('switch(state){case A ... B:break;default:break;}return 0;')
 def test_duplicate_label_compiler_rejection(self):
  with self.assertRaisesRegex(RuntimeError,'compiler rejected'):
   self.count('switch(state){case A:break;case A:break;default:break;}return 0;')
 def test_nonconstant_label_compiler_rejection(self):
  with self.assertRaisesRegex(RuntimeError,'compiler rejected'):
   self.count('switch(state){case input:break;default:break;}return 0;')
 def test_unrelated_samevalued_case_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'unrelated enum'):
   self.count('switch(state){case OTHER_A:break;default:break;}return 0;')
 def test_nested_switch_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'nested'):
   self.count('switch(state){case A:switch(state){case B:break;default:break;}break;default:break;}return 0;')
 def test_loop_continue_goto_rejected(self):
  for body in ['while(input){break;}','for(;input;){continue;}','goto done;done:;']:
   with self.assertRaises(RuntimeError):self.count(body+'switch(state){case A:break;default:break;}return 0;')
 def test_selected_default_abort_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'unqualified/unresolved call abort'):
   self.count('switch(state){case A:break;default:abort();}return 0;',input='D',extra='extern void abort(void);')
 def test_aggregate_call_abi_still_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'aggregate argument'):
   self.count('struct Box box={1};switch(state){case A:*out=use_box(box);break;default:break;}return 0;',name='fixture_aggregate',extra='struct Box{int x;};int use_box(struct Box);')
 def test_malformed_switch_ast_rejected(self):
  def patch(fs,nodes):
   body=next(x for x in fs['fixture_bad']['ast']['inner'] if x.get('kind')=='CompoundStmt')
   sw=next(x for x in body['inner'] if x.get('kind')=='SwitchStmt');sw['inner'].append({'kind':'NullStmt'})
  with self.assertRaisesRegex(RuntimeError,'unsupported switch shape'):
   self.count('switch(state){case A:break;default:break;}return 0;',patch=patch)
 def test_break_outside_switch_rejected(self):
  o=self.count('switch(state){case A:break;default:break;}return 0;')
  # Direct interpreter guard test; not claimed as a compiler-valid C fixture.
  o.stack.append({'name':'fixture_bad','unit':'Fixture'})
  with self.assertRaisesRegex(RuntimeError,'break outside'):o.stmt({'kind':'BreakStmt'})
  o.stack.pop()
 def test_different_selector_declaration_in_second_switch_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'same original enum'):
   self.count('_Bool active;switch(state){case A:active=1;break;default:active=0;break;}state_t other=input;switch(other){case A:break;default:break;}return active?1:0;',name='fixture_seq')
 def test_classification_overwrite_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'boolean overwritten'):self.seq(bodyextra='active=0;')
 def test_classification_escape_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'boolean escapes'):self.seq(bodyextra='_Bool *alias=&active;')
 def test_no_matching_case_without_default_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'no unique'):
   self.count('switch(state){case A:break;}return 0;',input='D')
 def test_cross_translation_unit_catalog_rejected(self):
  source=PRE+'int fixture_one(state_t input,int*out){state_t state=input;switch(state){case A:break;default:break;}return 0;}'
  fs,_,srcs=self.compile(source);_,othernodes,_=self.compile(source)
  c.CHOICES['fixture_one']=[]
  o=m.Counter(fs,srcs,'',othernodes,{'fixture_one':{'enum':'state_t','input':'A','selector':'state'}})
  with self.assertRaisesRegex(RuntimeError,'same actual TU'):o.run('fixture_one')
 def test_invalid_compiler_AST_flag_rejected(self):
  def patch(fs,nodes):fs['fixture_bad']['ast']['inner'][-1]['isInvalid']=True
  with self.assertRaisesRegex(RuntimeError,'invalid compiler AST'):
   self.count('switch(state){case A:break;default:break;}return 0;',patch=patch)
 def test_unselected_default_ternary_not_consumed_as_active(self):
  o=self.count('_Bool active;switch(state){case A:active=1;break;case B:active=0;break;default:return state==C?7:8;}switch(state){case A:*out=1;break;case B:*out=2;break;default:break;}return active?1:0;',name='fixture_seq')
  self.assertEqual(self.stores(o),['*out=1']);self.assertIs(o.audit[0]['derived_active'],True)
 def test_duplicate_default_compiler_rejection(self):
  with self.assertRaisesRegex(RuntimeError,'compiler rejected'):
   self.count('switch(state){case A:break;default:break;default:break;}return 0;')
 def test_default_ambiguity_AST_rejected(self):
  def patch(fs,nodes):
   body=next(x for x in fs['fixture_bad']['ast']['inner'] if x.get('kind')=='CompoundStmt')
   sw=next(x for x in body['inner'] if x.get('kind')=='SwitchStmt')
   default=next(x for x in sw['inner'][1]['inner'] if x.get('kind')=='DefaultStmt')
   sw['inner'][1]['inner'].append(copy.deepcopy(default))
  with self.assertRaisesRegex(RuntimeError,'default ambiguity'):
   self.count('switch(state){case A:break;default:break;}return 0;',patch=patch)
 def conditional_classifier(self,selected):
  body='_Bool active=1;switch(state){case A:'+selected+'case B:active=0;break;default:active=0;break;}switch(state){case A:*out=1;break;case B:*out=2;break;default:*out=3;break;}*out=active?*out:0;return 0;'
  with self.assertRaisesRegex(RuntimeError,'unconditional direct assignment then break'):
   self.count(body,name='fixture_seq',choices=[False])
  self.assertFalse(self.last_counter.events)
 def test_critic_unexecuted_conditional_classifier_rejected(self):
  self.conditional_classifier('if(input==B)active=0;break;')
 def test_conditional_classifier_even_taken_is_outside_narrow_scope(self):
  self.conditional_classifier('if(input==A)active=0;break;')
 def test_conditional_break_before_assignment_rejected(self):
  self.conditional_classifier('if(input==A)break;active=0;break;')
 def test_side_effect_before_assignment_rejected(self):
  self.conditional_classifier('*out=7;active=0;break;')
 def test_nested_compound_classifier_rejected(self):
  self.conditional_classifier('{active=0;}break;')
 def test_conditional_write_after_assignment_rejected(self):
  self.conditional_classifier('active=1;if(input==B)active=0;break;')
if __name__=='__main__':unittest.main()
