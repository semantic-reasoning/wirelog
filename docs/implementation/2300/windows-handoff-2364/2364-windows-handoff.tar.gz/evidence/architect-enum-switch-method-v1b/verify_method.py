"""Read-only sealed-method verification; temporary fixture output stays temporary."""
import pathlib,json,hashlib,subprocess,sys,os
E=pathlib.Path(__file__).parent

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def snapshot():
 p=E/'manifest.json';m=json.loads(p.read_text());out={'manifest.json':sha(p)}
 for name,h in m['files'].items():
  actual=sha(E/name)
  if actual!=h:raise RuntimeError('sealed method mismatch '+name)
  out[name]=actual
 return out
def previous_seal():
 root=E.parent/'architect-enum-switch-method-v1a';p=root/'manifest.json'
 if sha(p)!='15ad7c221c59856f8fe5de6b35d179752f9589a2a3ee005e21d3bb13b3374500':raise RuntimeError('v1a held manifest changed')
 out={'manifest.json':sha(p)}
 for name,h in json.loads(p.read_text())['files'].items():
  if sha(root/name)!=h:raise RuntimeError('v1a preserved bytes changed '+name)
  out[name]=h
 return out
previous_before=previous_seal()
before=snapshot()
records=json.loads((E/'fixture-run-records.json').read_text())
for rec in records:
 if hashlib.sha256(rec['source'].encode()).hexdigest()!=rec['source_sha256']:raise RuntimeError('fixture source changed')
 if hashlib.sha256(rec['ast_text'].encode()).hexdigest()!=rec['ast_sha256']:raise RuntimeError('fixture AST changed')
 b=rec['input_binding']
 if sha(b['compiler_path'])!=b['compiler_sha256']:raise RuntimeError('fixture compiler changed')
 if hashlib.sha256(b['macros_text'].encode()).hexdigest()!=b['macros_sha256']:raise RuntimeError('fixture macros changed')
 for path,info in b['dependencies'].items():
  kept=rec['dependencies_retained'][path]
  if kept['sha256']!=info['sha256'] or hashlib.sha256(kept['text'].encode()).hexdigest()!=info['sha256']:raise RuntimeError('retained fixture dependency changed')
# Never honor an inherited capture variable pointing into sealed evidence.
env=dict(os.environ);env.pop('ENUM_METHOD_CAPTURE',None)
cmd=[sys.executable,'-m','unittest','discover','-s',str(E),'-p','test_enum_switch.py','-v']
r=subprocess.run(cmd,capture_output=True,text=True,env=env)
if r.returncode:raise RuntimeError(r.stdout+r.stderr)
old=subprocess.run([sys.executable,str(E.parent/'architect-source-counter-v2a/verify_sealed.py')],capture_output=True,text=True,env=env)
if old.returncode:raise RuntimeError(old.stdout+old.stderr)
binding=subprocess.run([sys.executable,str(E/'audit_frozen_binding.py')],capture_output=True,text=True,env=env)
if binding.returncode:raise RuntimeError(binding.stdout+binding.stderr)
if previous_before!=previous_seal():raise RuntimeError('v1b rerun mutated v1a')
after=snapshot()
if before!=after:raise RuntimeError('read-only rerun mutated method evidence')
print(json.dumps({'status':'PASS','method_manifest_sha256':before['manifest.json'],'method_sealed_files':len(before)-1,'method_tests':42,'fixture_compilations_retained':len(records),'before_after_identical':True,'new_tests_stdout':r.stdout,'new_tests_stderr':r.stderr,'old_v2a_verification':json.loads(old.stdout),'previous_v1a_preserved':True,'actual_binding':json.loads(binding.stdout),'scope':'v1b method correction only; no packet/source/carry numeric qualification'},indent=2))
