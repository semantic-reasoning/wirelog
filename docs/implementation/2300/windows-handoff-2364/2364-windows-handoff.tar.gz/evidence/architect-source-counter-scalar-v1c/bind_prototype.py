"""Retain fixture provenance and inspect actual frozen += shape; no engine count."""
import sys
sys.dont_write_bytecode=True
import pathlib,json,hashlib,shutil,subprocess
import compound_counter as m
E=pathlib.Path(__file__).parent;B=E.parent;P=B/'architect-scalar-chunk-packet-v1'
sys.path.insert(0,str(B/'architect-source-counter-v2a'));import dependency_binding as d
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
records=[];retained=E/'input-bytes';retained.mkdir(exist_ok=True)
for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
 target='x86_64-pc-windows-msvc' if profile in {'MSVC-C11','Windows-native'} else 'x86_64-pc-linux-gnu'
 command=['clang','--target='+target,'-std=c11']
 if profile in {'C11','MSVC-C11'}:command.append('-DWL_HAVE_C11_THREADS=1')
 binding=d.inventory(command,E/'compound_fixture.c',E)
 for p,info in binding['dependencies'].items():
  output=retained/info['sha256']
  if not output.exists():output.write_bytes(pathlib.Path(p).read_bytes())
  assert sha(output)==info['sha256']
 bp=E/('fixture-'+profile+'-inputs.json');bp.write_text(json.dumps(binding,indent=2,sort_keys=True)+'\n')
 records.append({'profile':profile,'inputs_sha256':sha(bp),'ast_sha256':sha(E/('fixture-'+profile+'.ast.json')),'stderr_sha256':sha(E/('fixture-'+profile+'.stderr')),'command':command+['-fsyntax-only','-Xclang','-ast-dump=json',str(E/'compound_fixture.c')],'uses_primary_windows_headers':False,'claim':'C-AST construct fixture only; not Windows SDK ABI/full-TU proof'})
actual=[]
for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
 path=P/(profile+'-production-Core.ast.jsons');nodes=list(m.c.objects(path.read_text()))
 fn=next(n for n in nodes if n.get('kind')=='FunctionDecl' and n.get('name')=='wl_evaluation_control_charge_locked' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[])))
 assigns=[q for q in m.walk(fn) if q.get('kind')=='CompoundAssignOperator']
 assert len(assigns)==1
 node=assigns[0];lhs,rhs=node['inner'];fid=lhs['referencedMemberDecl']
 fields=[q for n in nodes for q in m.walk(n) if q.get('kind')=='FieldDecl' and q.get('id')==fid]
 assert len(fields)==1 and fields[0]['name']=='consumed' and not fields[0].get('isBitfield')
 inp=P/(profile+'-production-Core-inputs.json')
 for p,info in json.loads(inp.read_text())['dependencies'].items():assert sha(P/'input-bytes'/info['sha256'])==info['sha256']
 actual.append({'profile':profile,'raw_ast':str(path),'raw_ast_sha256':sha(path),'inputs':str(inp),'inputs_sha256':sha(inp),'function':fn['name'],'compound_ast':node,'field_ast':fields[0],'count_executed':False,'claim':'actual frozen expression provenance only; no complete engine count or method approval'})
(E/'actual-compound-bindings.json').write_text(json.dumps(actual,indent=2,sort_keys=True)+'\n')
model=pathlib.Path('/srv/home/joykim/.tmp/2300-operator-recovery-next/docs/MEMORY.md');cp=retained/sha(model)
if not cp.exists():cp.write_bytes(model.read_bytes())
old=json.loads((E/'inherited.json').read_text())
for p,digest in old.items():assert sha(p)==digest
result={'status':'UNAPPROVED_PROTOTYPE_NOT_A_COUNT_CERTIFICATE','narrow_scope':'direct unsigned += only; no ++/memset/hook extension','fixture_profiles':records,'inherited_sha256':old,'cost_model_reference':{'path':str(model),'sha256':sha(model),'retained_copy':str(cp),'lines':[2377,2451,3241],'interpretation':'historical logical source slots, not byte/8 or instruction counts; v1c inherits conservative explicit address/indirect-read/operator/store accounting'},'actual_binding_sha256':sha(E/'actual-compound-bindings.json'),'tests':json.loads((E/'fixture-results.json').read_text())}
(E/'provenance.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('Fixture dependency inventory retained, four actual Core += ASTs bound; no engine counts executed.')
