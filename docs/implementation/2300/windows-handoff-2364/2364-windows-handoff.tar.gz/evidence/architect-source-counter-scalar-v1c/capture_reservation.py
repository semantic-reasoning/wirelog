import sys
sys.dont_write_bytecode=True
import pathlib,json,subprocess,hashlib
import compound_counter as m
sys.path.insert(0,str(m.BASE/'architect-source-counter-v2a'));import dependency_binding as d
E=pathlib.Path(__file__).parent;P=E.parent/'architect-scalar-chunk-packet-v1';src=P/'snapshot/wirelog/columnar/memory_governor.c';store=E/'input-bytes';store.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(P/'snapshot-manifest.json')=='81ca0dcf2e0ff0cc7610fb233f771050c9d9aa526f15bc6ef52b8dad3851b1e6'
assert sha(src)==json.loads((P/'snapshot-manifest.json').read_text())['files']['wirelog/columnar/memory_governor.c']
rows=[]
for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
 cmd=json.loads((P/f'{profile}-production-Core-inputs.json').read_text())['command'][:-1]
 before=d.inventory(cmd,src,E)
 for path,info in before['dependencies'].items():
  retained=store/info['sha256']
  if not retained.exists():retained.write_bytes(pathlib.Path(path).read_bytes())
  assert sha(retained)==info['sha256']
 run=cmd+['-fsyntax-only','-Xclang','-ast-dump=json','-Xclang','-ast-dump-filter=wl_columnar_memory_reservation_init',str(src)]
 out=subprocess.run(run,cwd=E,capture_output=True,text=True)
 d.compare(before,d.inventory(cmd,src,E));d.verify_files(before)
 tag='reservation-'+profile
 (E/(tag+'-inputs.json')).write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
 (E/(tag+'.ast.jsons')).write_text(out.stdout);(E/(tag+'.stderr')).write_text(out.stderr)
 ns=list(m.c.objects(out.stdout));defs=[n for n in ns if n.get('kind')=='FunctionDecl' and n.get('name')=='wl_columnar_memory_reservation_init' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[]))]
 rows.append({'profile':profile,'returncode':out.returncode,'actual_definition_count':len(defs),'definition_invalid':any(n.get('isInvalid') for n in defs),'command':run,'inputs_sha256':sha(E/(tag+'-inputs.json')),'ast_sha256':sha(E/(tag+'.ast.jsons')),'stderr_sha256':sha(E/(tag+'.stderr')),'source_sha256':sha(src),'claim':'definition capture only; no method execution or engine count'})
(E/'reservation-bindings.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
print(json.dumps([{k:r[k] for k in ['profile','returncode','actual_definition_count','definition_invalid']} for r in rows],indent=2))
