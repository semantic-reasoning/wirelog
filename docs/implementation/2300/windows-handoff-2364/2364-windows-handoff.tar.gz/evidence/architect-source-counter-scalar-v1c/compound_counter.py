"""UNAPPROVED v1c prototype: one narrow direct-statement unsigned += rule.
No engine result is an approved Source bound. Old v1b modules stay unchanged.
"""
import pathlib,re,sys,json,hashlib
sys.dont_write_bytecode=True
BASE=pathlib.Path(__file__).parent.parent
inherited=pathlib.Path(__file__).parent/'inherited.json'
if inherited.exists():
    for path,digest in json.loads(inherited.read_text()).items():
        if hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('v1c: inherited method changed: '+path)
sys.path.insert(0,str(BASE/'architect-enum-switch-method-v1b'))
import enum_switch_counter as previous
c=previous.c

def walk(n):
    yield n
    for child in n.get('inner',[]):
        yield from walk(child)

def typ(n):
    t=n.get('type',{})
    return t.get('desugaredQualType',t.get('qualType',''))

def uncast(n):
    while n.get('kind')=='ImplicitCastExpr':
        if n.get('castKind') not in {'LValueToRValue','NoOp'} or len(n.get('inner',[]))!=1:
            raise RuntimeError('v1c: unsupported value conversion')
        n=n['inner'][0]
    return n

UNSIGNED={'unsigned int','unsigned long','unsigned long long','unsigned __int64'}
class Counter(previous.Counter):
    def __init__(self,fs,srcs,hooks,nodes,annotations,enabled_functions=(),unit_nodes=None):
        super().__init__(fs,srcs,hooks,nodes,annotations)
        self.enabled_functions=set(enabled_functions)
        self.statement_node=None
        self.rmw_audit=[]
        if unit_nodes is None:
            if len(nodes)!=1 or nodes[0].get('kind')!='TranslationUnitDecl':
                raise RuntimeError('v1c: explicit same-TU node groups required')
            unit_nodes={fn['unit']:nodes for fn in fs.values()}
        self.unit_nodes=unit_nodes
        self.fields={}
        for unit,roots in unit_nodes.items():
            fields={}
            for root in roots:
                for record in walk(root):
                    if record.get('kind')!='RecordDecl': continue
                    forbidden=record.get('tagUsed')=='union' or any(q.get('kind') in {'PackedAttr','MaxFieldAlignmentAttr'} for q in record.get('inner',[]))
                    for field in record.get('inner',[]):
                        if field.get('kind')=='FieldDecl':
                            fields[field['id']]=(field,record,forbidden)
            self.fields[unit]=fields
    def stmt(self,n):
        if n.get('kind')=='CompoundAssignOperator':
            old=self.statement_node; self.statement_node=n
            try: self.expr(n)
            finally: self.statement_node=old
        else:
            super().stmt(n)
    def expr(self,n):
        if n.get('kind')!='CompoundAssignOperator':
            return super().expr(n)
        if self.statement_node is not n:
            raise RuntimeError('v1c: compound result used outside direct statement')
        function=self.stack[-1]['name']
        if function not in self.enabled_functions:
            raise RuntimeError('v1c: function not explicitly enabled')
        cs=n.get('inner',[])
        if n.get('opcode')!='+=' or len(cs)!=2:
            raise RuntimeError('v1c: only unsigned += enabled')
        lhs,rhs=cs
        q=typ(lhs)
        def qt(t):return t.get('desugaredQualType',t.get('qualType',''))
        if q not in UNSIGNED or typ(n)!=q or qt(n.get('computeLHSType',{}))!=q or qt(n.get('computeResultType',{}))!=q or typ(rhs)!=q:
            raise RuntimeError('v1c: exact unsigned computation types required')
        if lhs.get('valueCategory')!='lvalue':
            raise RuntimeError('v1c: actual lvalue required')
        if any(re.search(r'\bvolatile\b|_Atomic',typ(x)) for x in walk(n)):
            raise RuntimeError('v1c: volatile/atomic RMW not supported')
        fn=self.fs[function]['ast']
        unit=self.fs[function]['unit']
        if not any(fn is node for root in self.unit_nodes.get(unit,[]) for node in walk(root)):
            raise RuntimeError('v1c: function not bound to its actual TU node group')
        declarations={x['id']:x for x in walk(fn) if x.get('kind') in {'ParmVarDecl','VarDecl'} and 'id' in x}
        def local(expr,pointer=False):
            ref=uncast(expr)
            if ref.get('kind')!='DeclRefExpr':raise RuntimeError('v1c: stable local/parameter reference required')
            ident=ref.get('referencedDecl',{}).get('id')
            decl=declarations.get(ident)
            if not decl or decl.get('storageClass') in {'static','extern'}:
                raise RuntimeError('v1c: same-function automatic declaration required')
            if pointer and not typ(ref).endswith(' *'):
                raise RuntimeError('v1c: actual simple pointer parameter required')
            return ident
        member=False;field_id=None
        if lhs.get('kind')=='DeclRefExpr':
            target_id=local(lhs)
        elif lhs.get('kind')=='MemberExpr' and lhs.get('isArrow') is True and len(lhs.get('inner',[]))==1:
            target_id=local(lhs['inner'][0],pointer=True)
            field_id=lhs.get('referencedMemberDecl')
            field,record,forbidden=self.fields[unit].get(field_id,({}, {}, True))
            if forbidden or not field or field.get('isBitfield') or typ(field)!=q:
                raise RuntimeError('v1c: same-TU ordinary unpacked field required')
            member=True
        else:
            raise RuntimeError('v1c: only local or one-level arrow-member lvalue supported')
        rhs_id=local(rhs)
        # One real evaluation of the lvalue, one old-object read if indirect,
        # one RHS evaluation, one unsigned addition and one object store.
        self.expr(lhs)
        if member:self.emit(lhs,'compound_indirect_scalar_read',1,'old object value; address evaluated once')
        self.expr(rhs)
        self.emit(n,'compound_unsigned_add_front',1,'same Clang compute/LHS/result unsigned type')
        self.emit(n,'compound_scalar_store',1,'one real RMW object store')
        self.rmw_audit.append({'function':function,'node_id':n.get('id'),'lhs_decl_id':target_id,'field_decl_id':field_id,'rhs_decl_id':rhs_id,'type':q,'lvalue_evaluations':1,'object_reads':1,'object_writes':1,'local_operand_reads_inherited_zero_front':not member})
