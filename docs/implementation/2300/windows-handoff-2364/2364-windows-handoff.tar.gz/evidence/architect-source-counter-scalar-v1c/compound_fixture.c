typedef unsigned long U;
struct plain { U value; };
struct bits { U value:3; };
struct __attribute__((packed)) packed { U value; };
struct vol { volatile U value; };
struct atomic_s { _Atomic(U) value; };
extern struct plain *get_object(void);
extern U get_value(void);
extern void *memset(void *, int, __SIZE_TYPE__);
U global;
void fixture_local(U value, U work) { value += work; }
void fixture_member(struct plain *p, U work) { p->value += work; }
void fixture_expanded_local(U value, U work) { value = value + work; }
void fixture_expanded_member(struct plain *p, U work) { p->value = p->value + work; }
void fixture_signed(long value, long work) { value += work; }
void fixture_promoted(unsigned char value, unsigned char work) { value += work; }
void fixture_multiply(U value, U work) { value *= work; }
void fixture_volatile(struct vol *p, U work) { p->value += work; }
void fixture_atomic(struct atomic_s *p, U work) { p->value += work; }
void fixture_bitfield(struct bits *p, U work) { p->value += work; }
void fixture_packed(struct packed *p, U work) { p->value += work; }
void fixture_array(U *p, U work) { p[0] += work; }
void fixture_side_base(U work) { get_object()->value += work; }
void fixture_side_rhs(struct plain *p) { p->value += get_value(); }
U fixture_nested(struct plain *p, U work) { return (p->value += work); }
void fixture_global(U work) { global += work; }
void fixture_static(U work) { static U value; value += work; }
void fixture_increment(struct plain *p) { ++p->value; }
void fixture_loop(U value,U work) { while (value) value += work; }
void fixture_memset(struct plain *p) { memset(p, 0, sizeof(*p)); }
void fixture_do_hook(void (*hook)(void)) { do { if (hook) hook(); } while (0); }
