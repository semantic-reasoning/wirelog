import sys
sys.dont_write_bytecode=True
import pathlib,json,subprocess,hashlib,unittest,os
import compound_counter as m
E=pathlib.Path(__file__).parent;c=m.c
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
class CompoundRules(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=E/'compound_fixture.c'
        profile=os.environ.get('SCALAR_METHOD_PROFILE','C11')
        cls.profile=profile
        target='x86_64-pc-windows-msvc' if profile in {'MSVC-C11','Windows-native'} else 'x86_64-pc-linux-gnu'
        cls.command=['clang','--target='+target,'-std=c11']
        if profile in {'C11','MSVC-C11'}:cls.command.append('-DWL_HAVE_C11_THREADS=1')
        cls.command+=['-fsyntax-only','-Xclang','-ast-dump=json',str(cls.source)]
        p=subprocess.run(cls.command,capture_output=True,text=True)
        (E/('fixture-'+profile+'.stderr')).write_text(p.stderr);(E/('fixture-'+profile+'.ast.json')).write_text(p.stdout)
        assert p.returncode==0,p.stderr
        cls.nodes=[json.loads(p.stdout)];c.register_types(cls.nodes)
        cls.fs={n['name']:{'ast':n,'unit':'fixture'} for n in cls.nodes[0]['inner'] if n.get('kind')=='FunctionDecl' and any(x.get('kind')=='CompoundStmt' for x in n.get('inner',[]))}
        for name in cls.fs:c.CHOICES[name]=[];c.TERNARY[name]=[]
    def count(self,name):
        obj=m.Counter(self.fs,{'fixture':{'data':self.source.read_bytes()}},'',self.nodes,{},self.fs)
        obj.run(name);return obj
    def cells(self,name):return sum(x['cells'] for x in self.count(name).events)
    def test_local_read_once_store_once(self):
        obj=self.count('fixture_local');self.assertEqual(self.cells('fixture_local'),3)
        self.assertEqual(obj.rmw_audit[0]['object_reads'],1);self.assertEqual(obj.rmw_audit[0]['object_writes'],1)
        self.assertEqual(self.cells('fixture_local'),self.cells('fixture_expanded_local'))
    def test_member_address_once_read_add_store(self):
        obj=self.count('fixture_member');self.assertEqual(self.cells('fixture_member'),5)
        kinds=[x['kind'] for x in obj.events];self.assertEqual(kinds,['address_front','compound_indirect_scalar_read','compound_unsigned_add_front','compound_scalar_store','implicit_return_front'])
        self.assertEqual(self.cells('fixture_expanded_member'),6)
        self.assertIsNotNone(obj.rmw_audit[0]['field_decl_id'])
    def test_real_ast_negative_fixtures(self):
        for name in ['signed','promoted','multiply','volatile','atomic','bitfield','packed','array','side_base','side_rhs','nested','global','static','increment','loop','memset','do_hook']:
            with self.subTest(name=name):
                with self.assertRaises(RuntimeError):self.count('fixture_'+name)
    def test_function_default_disabled(self):
        obj=m.Counter(self.fs,{'fixture':{'data':self.source.read_bytes()}},'',self.nodes,{})
        with self.assertRaisesRegex(RuntimeError,'not explicitly enabled'):obj.run('fixture_member')
    def test_old_counter_still_refuses_compound(self):
        obj=m.previous.Counter(self.fs,{'fixture':{'data':self.source.read_bytes()}},'',self.nodes,{})
        with self.assertRaisesRegex(RuntimeError,'compound assignment'):obj.run('fixture_member')
    def test_real_filtered_ast_without_definition_rejected(self):
        command=self.command[:-1]+['-Xclang','-ast-dump-filter=fixture_member',str(self.source)]
        p=subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(p.returncode,0)
        (E/('filtered-missing-record-'+self.profile+'.ast.jsons')).write_text(p.stdout)
        nodes=list(c.objects(p.stdout));fn=nodes[0]
        fs={'fixture_member':{'ast':fn,'unit':'filtered'}}
        obj=m.Counter(fs,{'filtered':{'data':self.source.read_bytes()}},'',nodes,{},fs,{'filtered':nodes})
        with self.assertRaisesRegex(RuntimeError,'same-TU ordinary'):obj.run('fixture_member')
if __name__=='__main__':unittest.main(verbosity=2)
