"""Capture actual same-compile field/function provenance, never count engine."""
import sys
sys.dont_write_bytecode=True
import pathlib,json,subprocess,hashlib
import increment_counter as m
sys.path.insert(0,str(m.BASE/'architect-source-counter-v2a'));import dependency_binding as d
E=pathlib.Path(__file__).parent;B=E.parent;P=B/'architect-scalar-chunk-packet-v1';S=P/'snapshot';store=E/'input-bytes';store.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(P/'snapshot-manifest.json')=='81ca0dcf2e0ff0cc7610fb233f771050c9d9aa526f15bc6ef52b8dad3851b1e6'
for rel,digest in json.loads((P/'snapshot-manifest.json').read_text())['files'].items():assert sha(S/rel)==digest
records=[];fixtures=[]
def retain(inv):
 for path,info in inv['dependencies'].items():
  out=store/info['sha256']
  if not out.exists():out.write_bytes(pathlib.Path(path).read_bytes())
  assert sha(out)==info['sha256']
for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
 # Real engine capture is one fresh compiler process, with broad-enough filter
 # to retain the initializer RecordDecl AND its init_step definition together.
 command=json.loads((P/f'{profile}-production-Initializer-inputs.json').read_text())['command'][:-1]
 source=S/'wirelog/columnar/relation.c';before=d.inventory(command,source,E);retain(before)
 run=command+['-fsyntax-only','-Xclang','-ast-dump=json','-Xclang','-ast-dump-filter=wl_columnar_relation_scalar_retirement_init',str(source)]
 p=subprocess.run(run,cwd=E,capture_output=True,text=True);d.compare(before,d.inventory(command,source,E));d.verify_files(before)
 tag='actual-'+profile
 (E/(tag+'-inputs.json')).write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');(E/(tag+'.ast.jsons')).write_text(p.stdout);(E/(tag+'.stderr')).write_text(p.stderr)
 nodes=list(m.c.objects(p.stdout));fn=next(n for n in nodes if n.get('name')=='wl_columnar_relation_scalar_retirement_init_step' and any(x.get('kind')=='CompoundStmt' for x in n.get('inner',[])))
 inc=[x for x in m.walk(fn) if x.get('kind')=='UnaryOperator' and x.get('opcode')=='++'];assert len(inc)==1
 node=inc[0];lhs=node['inner'][0];fields=[x for root in nodes for x in m.walk(root) if x.get('kind')=='FieldDecl' and x.get('id')==lhs['referencedMemberDecl']]
 assert len(fields)==1 and fields[0]['name']=='token_index' and m.typ(lhs)=='unsigned int' and node['isPostfix'] is False
 records.append({'profile':profile,'command':run,'inputs_sha256':sha(E/(tag+'-inputs.json')),'ast_sha256':sha(E/(tag+'.ast.jsons')),'stderr_sha256':sha(E/(tag+'.stderr')),'whole_TU_returncode':p.returncode,'diagnostics':[s for s in p.stderr.splitlines() if ': error:' in s],'function':fn['name'],'increment_ast':node,'field_ast':fields[0],'single_compile_function_and_field':True,'count_executed':False,'source_sha256':sha(source)})
 target='x86_64-pc-windows-msvc' if profile in {'MSVC-C11','Windows-native'} else 'x86_64-pc-linux-gnu';cmd=['clang','--target='+target,'-std=c11']
 if profile in {'C11','MSVC-C11'}:cmd+=['-DWL_HAVE_C11_THREADS=1']
 inv=d.inventory(cmd,E/'increment_fixture.c',E);retain(inv);path=E/('fixture-'+profile+'-inputs.json');path.write_text(json.dumps(inv,indent=2,sort_keys=True)+'\n')
 fixtures.append({'profile':profile,'inputs_sha256':sha(path),'command':cmd+['-fsyntax-only','-Xclang','-ast-dump=json',str(E/'increment_fixture.c')],'main_ast_sha256':sha(E/('fixture-'+profile+'.ast.json')),'other_compile_ast_sha256':sha(E/('other-compile-'+profile+'.ast.json')),'missing_field_ast_sha256':sha(E/('missing-field-'+profile+'.ast.jsons')),'primary_CRT_or_thread_ABI_claim':False})
(E/'actual-increment-bindings.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
(E/'provenance.json').write_text(json.dumps({'status':'UNAPPROVED_METHOD_ONLY_NO_ENGINE_COUNTS','snapshot_manifest_sha256':sha(P/'snapshot-manifest.json'),'inherited_sha256':json.loads((E/'inherited.json').read_text()),'fixture_bindings':fixtures,'actual_bindings_sha256':sha(E/'actual-increment-bindings.json'),'prior_cost_reference':'v1c provenance.json cost_model_reference, unchanged retained MEMORY.md hash9182772c3b182d1c392c3e7d1e0c9fbd3d2b6bda26a627cab0644913b3cb2404'},indent=2,sort_keys=True)+'\n')
print(json.dumps([{k:x[k] for k in ['profile','whole_TU_returncode','single_compile_function_and_field','count_executed']} for x in records],indent=2))
