"""UNAPPROVED v1d: direct-statement ordinary unsigned ++ only.
Upper-cover prototype; no production count, lower bound, tariff or carry claim.
"""
import sys
sys.dont_write_bytecode=True
import pathlib,json,hashlib,re
E=pathlib.Path(__file__).parent;BASE=E.parent
pins=E/'inherited.json'
if pins.exists():
    for path,digest in json.loads(pins.read_text()).items():
        if hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('v1d: inherited method changed: '+path)
sys.path.insert(0,str(BASE/'architect-source-counter-scalar-v1c'))
import compound_counter as previous
c=previous.c
walk=previous.walk;typ=previous.typ;uncast=previous.uncast
class Counter(previous.Counter):
    def __init__(self,fs,srcs,hooks,nodes,annotations,enabled_functions=(),unit_nodes=None,increment_functions=()):
        super().__init__(fs,srcs,hooks,nodes,annotations,enabled_functions,unit_nodes)
        self.increment_functions=set(increment_functions)
        self.increment_statement=None
        self.increment_audit=[]
    def stmt(self,n):
        if n.get('kind')=='UnaryOperator' and n.get('opcode') in {'++','--'}:
            old=self.increment_statement;self.increment_statement=n
            try:self.expr(n)
            finally:self.increment_statement=old
        else:super().stmt(n)
    def expr(self,n):
        if n.get('kind')!='UnaryOperator' or n.get('opcode') not in {'++','--'}:
            return super().expr(n)
        if n is not self.increment_statement:
            raise RuntimeError('v1d: increment result outside direct statement')
        function=self.stack[-1]['name'];unit=self.fs[function]['unit'];fn=self.fs[function]['ast']
        if fn.get('isInvalid') or any(x.get('isInvalid') for x in walk(n)):
            raise RuntimeError('v1d: invalid compiler function/expression')
        if function not in self.increment_functions:
            raise RuntimeError('v1d: increment function not explicitly enabled')
        cs=n.get('inner',[])
        if n.get('opcode')!='++' or len(cs)!=1 or not isinstance(n.get('isPostfix'),bool):
            raise RuntimeError('v1d: only actual prefix/postfix ++ supported')
        lhs=cs[0];q=typ(lhs)
        if q not in previous.UNSIGNED or typ(n)!=q or lhs.get('valueCategory')!='lvalue':
            raise RuntimeError('v1d: ordinary nonpromoted unsigned lvalue required')
        if any(re.search(r'\bvolatile\b|_Atomic',typ(x)) for x in walk(n)):
            raise RuntimeError('v1d: volatile/atomic increment unsupported')
        if not any(fn is node for root in self.unit_nodes.get(unit,[]) for node in walk(root)):
            raise RuntimeError('v1d: function not bound to its actual TU group')
        declarations={x['id']:x for x in walk(fn) if x.get('kind') in {'ParmVarDecl','VarDecl'} and 'id' in x}
        def local(expr,pointer=False):
            ref=uncast(expr)
            if ref.get('kind')!='DeclRefExpr':raise RuntimeError('v1d: stable automatic declaration required')
            ident=ref.get('referencedDecl',{}).get('id');decl=declarations.get(ident)
            if not decl or decl.get('storageClass') in {'static','extern'}:
                raise RuntimeError('v1d: same-function automatic declaration required')
            if pointer and not typ(ref).endswith(' *'):
                raise RuntimeError('v1d: simple actual pointer required')
            return ident
        member=False;fid=None
        if lhs.get('kind')=='DeclRefExpr':target=local(lhs)
        elif lhs.get('kind')=='MemberExpr' and lhs.get('isArrow') is True and len(lhs.get('inner',[]))==1:
            target=local(lhs['inner'][0],pointer=True);fid=lhs.get('referencedMemberDecl')
            field,record,forbidden=self.fields[unit].get(fid,({}, {}, True))
            if forbidden or not field or field.get('isBitfield') or typ(field)!=q:
                raise RuntimeError('v1d: same-TU ordinary unpacked field required')
            member=True
        else:raise RuntimeError('v1d: local or one-level arrow member required')
        self.expr(lhs)
        if member:self.emit(lhs,'increment_indirect_scalar_read',1,'one old object read; address evaluated once')
        self.emit(n,'increment_unsigned_add_one_front',1,'nonpromoted unsigned arithmetic; prefix/postfix result discarded')
        self.emit(n,'increment_scalar_store',1,'one object write')
        self.increment_audit.append({'function':function,'node_id':n.get('id'),'target_decl_id':target,'field_decl_id':fid,'type':q,'isPostfix':n['isPostfix'],'lvalue_evaluations':1,'object_reads':1,'object_writes':1,'result_discarded':True,'separate_local_read_front':False})
