typedef unsigned long U;
struct plain { U value; unsigned token_index; };
struct bits { U value:3; };
struct __attribute__((packed)) packed { U value; };
#pragma pack(push,1)
struct pragma_packed { U value; };
#pragma pack(pop)
union united { U value; U other; };
struct vol { volatile U value; };
struct atom { _Atomic(U) value; };
extern struct plain *get_object(void);
extern void *memset(void *, int, __SIZE_TYPE__);
U global;
void fixture_local_pre(U value) { ++value; }
void fixture_local_post(U value) { value++; }
void fixture_member_pre(struct plain *p) { ++p->value; }
void fixture_member_post(struct plain *p) { p->value++; }
void fixture_token_index(struct plain *p) { ++p->token_index; }
void fixture_expanded_local(U value) { value=value+1U; }
void fixture_expanded_member(struct plain *p) { p->value=p->value+1U; }
void fixture_compound(U value,U work) { value+=work; }
void fixture_signed(long value) { ++value; }
void fixture_char(unsigned char value) { ++value; }
void fixture_short(unsigned short value) { ++value; }
void fixture_bool(_Bool value) { ++value; }
void fixture_volatile(struct vol *p) { ++p->value; }
void fixture_atomic(struct atom *p) { ++p->value; }
void fixture_bitfield(struct bits *p) { ++p->value; }
void fixture_packed(struct packed *p) { ++p->value; }
void fixture_pragma(struct pragma_packed *p) { ++p->value; }
void fixture_union(union united *p) { ++p->value; }
void fixture_array(U *p) { ++p[0]; }
void fixture_deref(U *p) { ++*p; }
void fixture_pointer(U *p) { ++p; }
void fixture_side_base(void) { ++get_object()->value; }
void fixture_cast_base(void *p) { ++((struct plain *)p)->value; }
U fixture_nested_pre(struct plain *p) { return ++p->value; }
U fixture_nested_post(struct plain *p) { return p->value++; }
void fixture_void_cast(struct plain *p) { (void)++p->value; }
void fixture_global(void) { ++global; }
void fixture_static(void) { static U value; ++value; }
void fixture_extern(void) { extern U another; ++another; }
void fixture_decrement(U value) { --value; }
void fixture_loop(U value) { while(value) ++value; }
void fixture_memset(struct plain *p) { memset(p,0,sizeof(*p)); }
void fixture_hook(void (*hook)(void)) { do { if(hook) hook(); } while(0); }
