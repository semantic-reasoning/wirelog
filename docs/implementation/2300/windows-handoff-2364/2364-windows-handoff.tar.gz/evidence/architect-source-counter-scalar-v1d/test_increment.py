import sys
sys.dont_write_bytecode=True
import pathlib,os,json,subprocess,unittest
import increment_counter as m
E=pathlib.Path(__file__).parent;c=m.c
NEGATIVE=['signed','char','short','bool','volatile','atomic','bitfield','packed','pragma','union','array','deref','pointer','side_base','cast_base','nested_pre','nested_post','void_cast','global','static','extern','decrement','loop','memset','hook']
class IncrementRules(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.profile=os.environ.get('SCALAR_METHOD_PROFILE','C11');cls.source=E/'increment_fixture.c'
        target='x86_64-pc-windows-msvc' if cls.profile in {'MSVC-C11','Windows-native'} else 'x86_64-pc-linux-gnu'
        cls.command=['clang','--target='+target,'-std=c11']
        if cls.profile in {'C11','MSVC-C11'}:cls.command+=['-DWL_HAVE_C11_THREADS=1']
        cls.command+=['-fsyntax-only','-Xclang','-ast-dump=json',str(cls.source)]
        p=subprocess.run(cls.command,capture_output=True,text=True);assert p.returncode==0,p.stderr
        (E/('fixture-'+cls.profile+'.ast.json')).write_text(p.stdout);(E/('fixture-'+cls.profile+'.stderr')).write_text(p.stderr)
        cls.nodes=[json.loads(p.stdout)];c.register_types(cls.nodes)
        cls.fs={n['name']:{'ast':n,'unit':'fixture'} for n in cls.nodes[0]['inner'] if n.get('kind')=='FunctionDecl' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[]))}
        for name in cls.fs:c.CHOICES[name]=[];c.TERNARY[name]=[]
    def obj(self,enabled=True):
        return m.Counter(self.fs,{'fixture':{'data':self.source.read_bytes()}},'',self.nodes,{},self.fs,increment_functions=self.fs if enabled else ())
    def count(self,name):
        obj=self.obj();obj.run(name);return obj
    def cells(self,name):return sum(q['cells'] for q in self.count(name).events)
    def test_local_prefix_postfix_one_read_write(self):
        for suffix in ['pre','post']:
            name='fixture_local_'+suffix;obj=self.count(name)
            self.assertEqual(self.cells(name),3);self.assertEqual(obj.increment_audit[0]['isPostfix'],suffix=='post')
            self.assertEqual(obj.increment_audit[0]['object_reads'],1);self.assertEqual(obj.increment_audit[0]['object_writes'],1)
        self.assertEqual(self.cells('fixture_local_pre'),self.cells('fixture_expanded_local'))
    def test_member_and_actual_token_type(self):
        for name in ['fixture_member_pre','fixture_member_post','fixture_token_index']:
            obj=self.count(name);self.assertEqual(self.cells(name),5)
            self.assertEqual([q['kind'] for q in obj.events],['address_front','increment_indirect_scalar_read','increment_unsigned_add_one_front','increment_scalar_store','implicit_return_front'])
            self.assertTrue(obj.increment_audit[0]['field_decl_id'])
        self.assertEqual(self.cells('fixture_expanded_member'),6)
        self.assertEqual(self.count('fixture_token_index').increment_audit[0]['type'],'unsigned int')
    def test_real_source_negative_cases(self):
        for suffix in NEGATIVE:
            with self.subTest(suffix=suffix):
                with self.assertRaises(RuntimeError):self.count('fixture_'+suffix)
    def test_default_disabled(self):
        with self.assertRaisesRegex(RuntimeError,'not explicitly enabled'):self.obj(False).run('fixture_member_pre')
    def test_approved_compound_parent_unchanged(self):
        obj=self.obj();obj.run('fixture_compound');self.assertEqual(sum(e['cells'] for e in obj.events),3)
        old=m.previous.Counter(self.fs,{'fixture':{'data':self.source.read_bytes()}},'',self.nodes,{},self.fs)
        with self.assertRaisesRegex(RuntimeError,'increment/decrement'):old.run('fixture_member_pre')
    def test_real_filtered_missing_field_definition(self):
        command=self.command[:-1]+['-Xclang','-ast-dump-filter=fixture_member_pre',str(self.source)]
        p=subprocess.run(command,capture_output=True,text=True);self.assertEqual(p.returncode,0)
        (E/('missing-field-'+self.profile+'.ast.jsons')).write_text(p.stdout)
        nodes=list(c.objects(p.stdout));fs={'fixture_member_pre':{'ast':nodes[0],'unit':'filtered'}}
        obj=m.Counter(fs,{'filtered':{'data':self.source.read_bytes()}},'',nodes,{},unit_nodes={'filtered':nodes},increment_functions=fs)
        with self.assertRaisesRegex(RuntimeError,'same-TU ordinary'):obj.run('fixture_member_pre')
    def test_real_other_compile_tu_group_rejected(self):
        p=subprocess.run(self.command,capture_output=True,text=True);self.assertEqual(p.returncode,0)
        (E/('other-compile-'+self.profile+'.ast.json')).write_text(p.stdout)
        other=[json.loads(p.stdout)]
        obj=m.Counter(self.fs,{'fixture':{'data':self.source.read_bytes()}},'',self.nodes,{},unit_nodes={'fixture':other},increment_functions=self.fs)
        with self.assertRaisesRegex(RuntimeError,'actual TU group'):obj.run('fixture_member_pre')
if __name__=='__main__':unittest.main(verbosity=2)
