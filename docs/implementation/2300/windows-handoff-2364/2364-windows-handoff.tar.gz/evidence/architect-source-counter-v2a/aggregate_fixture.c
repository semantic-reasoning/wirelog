struct S { int a, b, c; };
struct Inner { int x, y; };
struct Outer { int a; struct Inner n; };
struct Huge { int data[200]; };
union U { int x; long y; };
enum E { E0 }; typedef enum E E;
void uninitialized_scope(void) { struct Huge scope; }
void initialized_members(void) { struct S s = { .a = 1 }; }
void nested_members(void) { struct Outer s = { .a = 1, .n = { .x = 2 } }; }
void compound_assignment(void) { struct S s; s = (struct S){ .a = 1 }; }
void initialized_compound(void) { struct S s = (struct S){ .a = 1 }; }
void opaque_copy(void) { struct S from; struct S to = from; }
void opaque_assignment(void) { struct S from, to; to = from; }
void missing_nested_layout(void) { struct Outer s = { .a = 1 }; }
void array_initializer(void) { int a[3] = { 1 }; }
void union_initializer(void) { union U u = { .x = 1 }; }
struct S aggregate_return(void) { return (struct S){1}; }
struct S external_return(void);
void aggregate_call_return(void) { external_return(); }
void takes_value(struct S s);
void aggregate_argument(void) { takes_value((struct S){1}); }
void aggregate_parameter(struct S s) { }
void enum_scalar(void) { E e = E0; e = E0; }
void increment_unqualified(void) { int x=0; x++; }
void compound_unqualified(void) { int x=0; x+=1; }
void loop_unqualified(void) { while (1) {} }
void unknown_engine(void);
void unknown_call(void) { unknown_engine(); }
void missing_branch(void) { if (1) {} }
