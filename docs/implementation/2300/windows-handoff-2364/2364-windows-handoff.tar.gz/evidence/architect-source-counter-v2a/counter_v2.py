#!/usr/bin/env python3
"""Fail-closed expanded C-AST cell cover; NOT LLVM instruction counting."""
import argparse,collections,hashlib,json,pathlib,subprocess,re
E=pathlib.Path(__file__).parent
F=E.parent/'reviewer-ordinary-gen-frozen-v2'
R=pathlib.Path('/srv/home/joykim/.tmp/2300-operator-recovery-next')
M=json.loads((E.parent/'reviewer-ordinary-gen-frozen-v2-manifest.json').read_text())
BASE=['wl_session_step','wl_session_operation_begin_step','col_session_controlled_financial_offer','wl_session_admission_lock','wl_session_checked_unlock','wl_evaluation_control_source_observation_open','wl_evaluation_control_source_observation_zero_locked','wl_evaluation_control_source_observation_settle_locked','wl_evaluation_control_financier_publish_inactive','wl_evaluation_control_active_attempt_id','wl_mutex_lock','wl_mutex_unlock','wl_evaluation_control_source_observation_test_cancel','wl_evaluation_control_request_cancel']
# Evaluated IfStmt/ConditionalOperator choices only. No numerical body costs.
CHOICES={
 'wl_session_step':[False,False,True,True],
 'wl_session_operation_begin_step':[False,False,False,True,False,False,False,True,True],
 'col_session_controlled_financial_offer':[True,True],
 'wl_session_admission_lock':[], 'wl_session_checked_unlock':[False],
 'wl_evaluation_control_source_observation_open':[False,False,False,False,False,False,True,False],
 'wl_evaluation_control_source_observation_zero_locked':[False,True],
 'wl_evaluation_control_source_observation_settle_locked':[False],
 'wl_evaluation_control_financier_publish_inactive':[],
 'wl_evaluation_control_active_attempt_id':[False],
 'wl_mutex_lock':[False], 'wl_mutex_unlock':[False],
 'wl_evaluation_control_source_observation_test_cancel':[True],
 'wl_evaluation_control_request_cancel':[True],
}
TERNARY={'wl_session_operation_begin_step':[False],'wl_mutex_lock':[True],'wl_mutex_unlock':[True]}
NATIVE={'mtx_lock','mtx_unlock','pthread_mutex_lock','pthread_mutex_unlock'}
TRANSPARENT={'ParenExpr','ConstantExpr','ExprWithCleanups','FullExpr','MaterializeTemporaryExpr'}
TYPE_KINDS={}

def register_types(nodes):
 def walk(n):
  if n.get('kind')=='TypedefDecl':
   tags=[]
   def tag(q):
    if q.get('kind') in ('EnumType','RecordType'):tags.append(q)
    for x in q.get('inner',[]):tag(x)
   tag(n)
   if tags:
    t=tags[-1];TYPE_KINDS[n['name']]='scalar' if t['kind']=='EnumType' else 'aggregate'
  for q in n.get('inner',[]):walk(q)
 for n in nodes:walk(n)
 # Clang supplies actual desugared types on expression/declaration nodes.
 # Bind scalar typedef aliases used in function return signatures from those
 # actual typed nodes; do not guess unknown typedefs are scalars.
 def aliases(n):
  t=n.get('type',{});q=t.get('qualType');raw=t.get('desugaredQualType')
  if q and raw and q!=raw:
   try:kind=type_kind({'type':{'qualType':raw}})
   except RuntimeError:kind=None
   if kind is not None:TYPE_KINDS[q]=kind
  for child in n.get('inner',[]):aliases(child)
 for n in nodes:aliases(n)

def type_kind(n):
 t=n.get('type',{});q=t.get('desugaredQualType',t.get('qualType',''))
 if not q:raise RuntimeError('missing type; cannot infer scalar/aggregate')
 if '[' in q or q.startswith('union '):return 'unsupported_aggregate'
 if '*' in q:return 'scalar'
 q=re.sub(r'\b(const|volatile|restrict|__restrict)\b','',q).strip()
 q=re.sub(r'\s+',' ',q)
 if q.startswith('_Atomic(') and q.endswith(')'):q=q[8:-1].strip()
 if q.startswith('enum '):return 'scalar'
 if q.startswith('struct '):return 'aggregate'
 if q in TYPE_KINDS:return TYPE_KINDS[q]
 if q in {'void','_Bool','bool','char','signed char','unsigned char','short','short int','signed short','unsigned short','unsigned short int','int','unsigned','unsigned int','signed int','long','long int','unsigned long','unsigned long int','long long','long long int','unsigned long long','unsigned long long int','__int128','unsigned __int128','float','double','long double','__int64','unsigned __int64'}:return 'scalar'
 raise RuntimeError('unresolved type '+q)

class Ret(Exception):pass

def sha(b):return hashlib.sha256(b).hexdigest()
def pos(x):return x.get('expansionLoc',x)
def objects(s):
 d=json.JSONDecoder();i=0
 while i<len(s):
  while i<len(s) and s[i].isspace():i+=1
  if i==len(s):break
  n,i=d.raw_decode(s,i);yield n


class Counter:
 def __init__(self,fs,srcs,hooks):
  self.fs=fs;self.srcs=srcs;self.hooks=hooks;self.events=[];self.calls=[];self.stack=[]
 def text(self,n):
  u=self.stack[-1]['unit'];d=self.srcs[u]['data'];r=n.get('range',{});a=pos(r.get('begin',{}));b=pos(r.get('end',{}))
  if 'offset' not in a or 'offset' not in b:return ''
  return d[a['offset']:b['offset']+b.get('tokLen',1)].decode(errors='replace')
 def emit(self,n,kind,count=1,note=''):
  if not count:return
  frame=self.stack[-1];a=pos(n.get('range',{}).get('begin',{}));off=a.get('offset',0);d=self.srcs[frame['unit']]['data']
  self.events.append({'function':frame['name'],'unit':frame['unit'],'offset':off,'line':d[:off].count(b'\n')+1,'kind':kind,'cells':count,'source':self.text(n)[:240],'note':note})
 def choice(self,n,typ):
  f=self.stack[-1];seq=f[typ];i=f[typ+'_i'];f[typ+'_i']+=1
  if i>=len(seq):raise RuntimeError('missing '+typ+' choice in '+f['name']+' '+self.text(n))
  return seq[i]
 def name(self,n):
  if n.get('kind')=='DeclRefExpr':return n.get('referencedDecl',{}).get('name')
  if n.get('kind')=='MemberExpr':return n.get('name')
  for c in n.get('inner',[]):
   v=self.name(c)
   if v:return v
  return None
 def literal_initializer(self,n):
  if n.get('kind') in ('CompoundLiteralExpr','ParenExpr','ConstantExpr','ImplicitCastExpr'):
   cs=n.get('inner',[])
   if len(cs)!=1:raise RuntimeError('ambiguous aggregate initializer wrapper')
   return self.literal_initializer(cs[0])
  if n.get('kind')!='InitListExpr':raise RuntimeError('aggregate copy/opaque initialization requires field/ABI proof')
  return n
 def initialized_leaves(self,n):
  if n.get('array_filler') is not None:raise RuntimeError('array/filler layout not qualified')
  k=type_kind(n)
  if k=='unsupported_aggregate':raise RuntimeError('union/array aggregate not qualified')
  if n.get('kind')=='InitListExpr':
   cs=n.get('inner',[])
   if not cs:raise RuntimeError('empty aggregate has no field shape proof')
   leaves=[]
   for c in cs:
    if type_kind(c)!='scalar':
     if c.get('kind')!='InitListExpr':raise RuntimeError('implicit nested aggregate requires actual field layout')
     leaves.extend(self.initialized_leaves(c))
    else:leaves.append(c)
   return leaves
  raise RuntimeError('no explicit semantic initializer shape')
 def aggregate_initialize(self,target,rhs):
  q=rhs;compound=None
  while q.get('kind') in ('CompoundLiteralExpr','ParenExpr','ConstantExpr','ImplicitCastExpr'):
   if q.get('kind')=='CompoundLiteralExpr':compound=q
   cs=q.get('inner',[])
   if len(cs)!=1:raise RuntimeError('ambiguous aggregate initializer wrapper')
   q=cs[0]
  init=self.literal_initializer(rhs);leaves=self.initialized_leaves(init)
  for leaf in leaves:self.expr(leaf)
  if compound is not None:
   self.emit(compound,'compound_literal_field_target_fronts',len(leaves),'actual temporary object initialization')
   self.emit(compound,'compound_literal_scalar_stores',len(leaves))
   self.emit(rhs,'aggregate_value_scalar_reads',len(leaves),'expanded aggregate lvalue-to-value, not one scalar load')
  self.emit(target,'aggregate_field_target_fronts',len(leaves),'actual semantic scalar leaves; includes omitted scalar value-init')
  self.emit(target,'aggregate_scalar_stores',len(leaves))
 def expr(self,n):
  k=n.get('kind');cs=n.get('inner',[])
  if k in TRANSPARENT:
   for c in cs:self.expr(c)
  elif k=='ImplicitCastExpr':
   if n.get('castKind')=='LValueToRValue' and type_kind(n)!='scalar':raise RuntimeError('aggregate lvalue-to-value outside qualified initialization')
   for c in cs:self.expr(c)
   if n.get('castKind')=='LValueToRValue' and cs and cs[0].get('kind') not in ('DeclRefExpr',):self.emit(n,'indirect_scalar_read')
  elif k in ('DeclRefExpr','IntegerLiteral','CharacterLiteral','StringLiteral','FloatingLiteral','GNUNullExpr','UnaryExprOrTypeTraitExpr'):
   pass
  elif k=='ImplicitValueInitExpr':
   if type_kind(n)!='scalar':raise RuntimeError('implicit aggregate value-init requires layout')
  elif k in ('MemberExpr','ArraySubscriptExpr'):
   for c in cs:self.expr(c)
   self.emit(n,'address_front')
  elif k=='CallExpr':
   if type_kind(n)!='scalar':raise RuntimeError('aggregate call return ABI not qualified')
   for arg in cs[1:]:
    if type_kind(arg)!='scalar':raise RuntimeError('aggregate argument ABI not qualified')
   callee=self.name(cs[0]);self.expr(cs[0])
   for c in cs[1:]:self.expr(c)
   self.emit(n,'argument_fronts',len(cs)-1)
   self.emit(n,'call_front')
   if callee=='session_controlled_financial_offer':callee='col_session_controlled_financial_offer'
   if callee in self.fs:self.run(callee)
   elif callee in NATIVE:self.calls.append({'native_front_only':callee,'no_engine_interior':True})
   else:raise RuntimeError('unqualified/unresolved call '+str(callee)+' '+self.text(n))
  elif k=='AtomicExpr':
   if type_kind(n)!='scalar' or any(type_kind(c)!='scalar' for c in cs):raise RuntimeError('aggregate atomic ABI not qualified')
   for c in cs:self.expr(c)
   self.emit(n,'atomic_argument_fronts',len(cs));self.emit(n,'atomic_native_front',1,n.get('name',''))
  elif k in ('BinaryOperator','CompoundAssignOperator'):
   op=n.get('opcode')
   if op=='=':
    self.expr(cs[0])
    tk=type_kind(n)
    if tk=='aggregate':self.aggregate_initialize(n,cs[1])
    elif tk=='scalar':self.expr(cs[1]);self.emit(n,'scalar_store')
    else:raise RuntimeError('union/array aggregate assignment not qualified')
   else:
    if type_kind(n)!='scalar':raise RuntimeError('aggregate operator not qualified')
    if k=='CompoundAssignOperator':raise RuntimeError('compound assignment read/write proof not yet qualified')
    for c in cs:self.expr(c)
    if op!=',':self.emit(n,'operator_front',1,'logical operands all covered conservatively; no short-circuit saving' if op in ('&&','||') else op)
  elif k=='UnaryOperator':
   if n.get('opcode') in ('++','--'):raise RuntimeError('increment/decrement read/write proof not yet qualified')
   for c in cs:self.expr(c)
   self.emit(n,'unary_front',1,n.get('opcode',''))
  elif k=='CStyleCastExpr':
   if type_kind(n)!='scalar':raise RuntimeError('aggregate cast/value ABI not qualified')
   for c in cs:self.expr(c)
   self.emit(n,'explicit_cast_front')
  elif k=='ConditionalOperator':
   take=self.choice(n,'ternary');self.expr(cs[0]);self.emit(n,'conditional_front');self.expr(cs[1] if take else cs[2])
  elif k in ('CompoundLiteralExpr','InitListExpr'):
   raise RuntimeError('aggregate value without initialization/ABI owner')
  else:raise RuntimeError('unhandled expression '+str(k)+' '+self.text(n))
 def stmt(self,n):
  k=n.get('kind');cs=n.get('inner',[])
  if k=='CompoundStmt':
   for c in cs:self.stmt(c)
  elif k=='DeclStmt':
   for c in cs:
    if c.get('kind')!='VarDecl':raise RuntimeError('unexpected decl')
    init=c.get('inner',[])
    if init:
     if len(init)!=1:raise RuntimeError('multiple var initializer expressions')
     tk=type_kind(c)
     if tk=='aggregate':self.aggregate_initialize(c,init[0])
     elif tk=='scalar':self.expr(init[0])
     else:raise RuntimeError('union/array initialized declaration not qualified')
    self.emit(c,'local_init_or_declaration_front',1,'uninitialized declaration performs NO aggregate stores' if not init else '')
  elif k=='IfStmt':
   take=self.choice(n,'ifs');self.expr(cs[0]);self.emit(n,'if_front',1,'taken' if take else 'not-taken')
   if take:self.stmt(cs[1])
   elif len(cs)>2:self.stmt(cs[2])
  elif k=='ReturnStmt':
   for c in cs:
    if type_kind(c)!='scalar':raise RuntimeError('aggregate return ABI not qualified')
    self.expr(c)
   self.emit(n,'return_front');raise Ret()
  elif k=='NullStmt':pass
  else:self.expr(n)
 def run(self,name):
  fn=self.fs[name]
  ret=fn['ast'].get('type',{}).get('qualType','').split('(',1)[0].strip()
  if type_kind({'type':{'qualType':ret}})!='scalar':raise RuntimeError('aggregate function return ABI not qualified')
  for param in fn['ast'].get('inner',[]):
   if param.get('kind')=='ParmVarDecl' and type_kind(param)!='scalar':raise RuntimeError('aggregate parameter ABI not qualified')
  ifs=list(CHOICES[name]);ts=list(TERNARY.get(name,[]))
  if self.hooks and name in ('wl_session_admission_lock','wl_session_checked_unlock'):ifs=[False]+ifs
  if self.hooks=='dormant' and name=='wl_evaluation_control_source_observation_test_cancel':ifs=[False]
  f={'name':name,'unit':fn['unit'],'ifs':ifs,'ternary':ts,'ifs_i':0,'ternary_i':0};self.stack.append(f);start=len(self.events)
  body=next(c for c in fn['ast']['inner'] if c.get('kind')=='CompoundStmt')
  try:self.stmt(body);self.emit(body,'implicit_return_front')
  except Ret:pass
  for typ in ('ifs','ternary'):
   if f[typ+'_i']!=len(f[typ]):raise RuntimeError('unused '+typ+' choices '+name+str(f))
  self.calls.append({'function':name,'expanded_cells':sum(e['cells'] for e in self.events[start:]),'unit':f['unit']});self.stack.pop()

