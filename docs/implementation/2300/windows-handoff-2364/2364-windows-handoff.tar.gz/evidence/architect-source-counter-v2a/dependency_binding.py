"""Bind real compiler/dependency bytes, preprocessing defines and exact commands."""
import hashlib,json,pathlib,shlex,subprocess
E=pathlib.Path(__file__).parent
F=E.parent/'reviewer-ordinary-gen-frozen-v2'
M=json.loads((E.parent/'reviewer-ordinary-gen-frozen-v2-manifest.json').read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def run(cmd,cwd):
 p=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True)
 if p.returncode:raise RuntimeError('dependency/preprocessor command failed:\n'+p.stderr)
 return p.stdout

def inventory(common,source,cwd):
 deps=run(common+['-M','-MT','source_profile',str(source)],cwd)
 # -M output is Make syntax, with escaped spaces and escaped continuations.
 flat=deps.replace('\\\n',' ')
 if not flat.startswith('source_profile:'):raise RuntimeError('unexpected dependency target')
 names=shlex.split(flat.split(':',1)[1],posix=True)
 files={}
 for name in names:
  p=pathlib.Path(name)
  if not p.is_absolute():p=pathlib.Path(cwd)/p
  p=p.resolve();data=p.read_bytes();actual=sha(data)
  try:rel=str(p.relative_to(F.resolve()))
  except ValueError:rel=None
  if rel is not None:
   if M['files'].get(rel)!=actual:raise RuntimeError('reached frozen engine/header mismatch '+rel)
  files[str(p)]={'sha256':actual,'bytes':len(data),'frozen_engine':rel is not None}
 macros=run(common+['-dM','-E',str(source)],cwd)
 compiler=pathlib.Path(run([common[0],'-print-prog-name=clang'],cwd).strip())
 if not compiler.is_absolute():
  import shutil
  compiler=pathlib.Path(shutil.which(common[0]))
 compiler=compiler.resolve()
 if not compiler.is_file():raise RuntimeError('compiler executable not found')
 extra={}
 for index,flag in enumerate(common[:-1]):
  if flag in ('-ivfsoverlay','-include','-imacros'):
   p=pathlib.Path(common[index+1]).resolve();extra[str(p)]=sha(p.read_bytes())
 return {'command':common+[str(source)],'cwd':str(pathlib.Path(cwd).resolve()),'compiler_path':str(compiler),'compiler_sha256':sha(compiler.read_bytes()),'compiler_version':run([common[0],'--version'],cwd),'target_option':next((x.split('=',1)[1] for x in common if x.startswith('--target=')),None),'dependencies':files,'explicit_input_files':extra,'macros_sha256':sha(macros.encode()),'macros_text':macros}

def compare(expected,actual):
 if expected!=actual:raise RuntimeError('bound preprocessing/dependency inputs changed; explicit new capture required')

def verify_files(record):
 for p,info in record['dependencies'].items():
  if sha(pathlib.Path(p).read_bytes())!=info['sha256']:raise RuntimeError('dependency changed '+p)
 for p,h in record['explicit_input_files'].items():
  if sha(pathlib.Path(p).read_bytes())!=h:raise RuntimeError('explicit preprocessing input changed '+p)
 if sha(pathlib.Path(record['compiler_path']).read_bytes())!=record['compiler_sha256']:raise RuntimeError('compiler changed')
