#!/usr/bin/env python3
"""Actual four-target ROOT-A covers with bound transitive inputs."""
import argparse,collections,json,pathlib,subprocess
import counter_v2 as c
import dependency_binding as d
E=pathlib.Path(__file__).parent
W=E.parent/'architect-windows-source'
EXTRA=['wl_atomic_fetch_add_internal','wl_atomic_exchange_internal']
INTRINSICS={'_InterlockedCompareExchange64','_InterlockedExchange64','_InterlockedExchangeAdd64','EnterCriticalSection','LeaveCriticalSection','memcpy'}
c.CHOICES.update({n:[] for n in EXTRA})

def config(profile,hooks):
 windows=profile in ('MSVC-C11','Windows-native')
 target='x86_64-pc-windows-msvc' if windows else 'x86_64-pc-linux-gnu'
 cmd=['clang','--target='+target,'-std=c11']
 if windows:
  cmd+=['-fms-extensions','-fms-compatibility','-fms-compatibility-version=19.44','-D__STDC_NO_ATOMICS__','-D_CRT_SECURE_NO_WARNINGS','-ivfsoverlay',str(W/'primary-headers-overlay.json'),'-isystem','/wirelog-crt','-isystem','/wirelog-sdk/ucrt','-isystem','/wirelog-sdk/shared','-isystem','/wirelog-sdk/um']
 cmd+=['-I'+str(c.F),'-I'+str(c.F/'wirelog'),'-Ibuild','-Ibuild/wirelog','-Ibuild/subprojects/nanoarrow/src','-Isubprojects/nanoarrow/src']
 if profile in ('C11','MSVC-C11'):cmd+=['-DWL_HAVE_C11_THREADS']
 if hooks:cmd+=['-DWL_SESSION_TEST_HOOKS=1']
 return cmd

def setup(profile,hooks,capture=False):
 fs={};srcs={};bindings={};common=config(profile,hooks)
 thread={'C11':'thread_c11.c','POSIX':'thread_posix.c','MSVC-C11':'thread_c11.c','Windows-native':'thread_msvc.c'}[profile]
 units=[('Core','evaluation_control.c','wl_evaluation_control'),('Session','session.c','wl_session'),('Columnar','columnar/session.c','col_session_controlled_financial_offer'),('Thread',thread,'wl_mutex')]
 if profile in ('MSVC-C11','Windows-native'):units.append(('AtomicShim','evaluation_control.c','wl_atomic_'))
 for unit,rel,flt in units:
  source=c.F/'wirelog'/rel;actual_source=c.F/'wirelog/columnar/mem_ledger.h' if unit=='AtomicShim' else source
  data=actual_source.read_bytes();srcs[unit]={'path':str(actual_source),'data':data,'sha256':c.sha(data)}
  label=profile+'-'+(hooks or 'production')+'-'+unit
  bp=E/(label+'-inputs.json')
  before=d.inventory(common,source,c.R)
  if capture:
   if bp.exists():d.compare(json.loads(bp.read_text()),before)
   else:bp.write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
  else:
   if not bp.exists():raise RuntimeError('missing binding; explicitly use --capture-inputs')
   d.compare(json.loads(bp.read_text()),before)
  d.verify_files(before)
  cmd=common+['-fsyntax-only','-Xclang','-ast-dump=json','-Xclang','-ast-dump-filter='+flt,str(source)]
  p=subprocess.run(cmd,cwd=c.R,capture_output=True,text=True)
  (E/(label+'.stderr')).write_text(p.stderr)
  recovered=False
  if p.returncode:
   errors=[q for q in p.stderr.splitlines() if ': error:' in q]
   names=['wl_columnar_eval_stack_prepared_size_fits_t','wl_columnar_eval_stack_prepared_work_fits_t','wl_columnar_session_managed_init_bound']
   if profile!='MSVC-C11' or unit!='Columnar' or len(errors)!=3 or not all(any("'"+name+"' declared as an array with a negative size" in q for q in errors) for name in names):raise RuntimeError(p.stderr)
   recovered=True
  after=d.inventory(common,source,c.R);d.compare(before,after);d.verify_files(before)
  (E/(label+'.ast.jsons')).write_text(p.stdout)
  nodes=list(c.objects(p.stdout));c.register_types(nodes)
  for n in nodes:
   if n.get('kind')=='FunctionDecl' and n.get('name') in c.BASE+EXTRA and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[])):
    if n.get('isInvalid'):raise RuntimeError('invalid selected function')
    fs[n['name']]={'ast':n,'unit':unit}
  bindings[unit]={'record':str(bp),'record_sha256':c.sha(bp.read_bytes()),'dependency_count':len(before['dependencies']),'macros_sha256':before['macros_sha256'],'selected_accessor_recovered':recovered,'ast_command':cmd,'ast_sha256':c.sha(p.stdout.encode())}
 return fs,srcs,bindings

class Counter(c.Counter):
 def expr(self,n):
  cs=n.get('inner',[])
  if n.get('kind')=='CallExpr' and self.name(cs[0])=='memcpy':
   if not self.stack or self.stack[-1]['name']!='wl_atomic_fetch_add_internal' or not getattr(self,'widths',[]) or self.widths[-1]!=8:raise RuntimeError('memcpy outside proven width8 shim not qualified')
  if n.get('kind')=='CallExpr' and self.name(cs[0]) in EXTRA:
   width=cs[-1]
   if width.get('kind')!='UnaryExprOrTypeTraitExpr' or width.get('name')!='sizeof':raise RuntimeError('shim width not actual sizeof')
   t=width.get('inner',[{}])[0].get('type',{}).get('desugaredQualType','')
   if t not in ('volatile unsigned long long','const volatile unsigned long long'):raise RuntimeError('unproved width8 shim operand '+t)
   if not hasattr(self,'widths'):self.widths=[]
   self.widths.append(8)
   try:super().expr(n)
   finally:self.widths.pop()
  else:super().expr(n)
 def stmt(self,n):
  if n.get('kind')=='SwitchStmt':
   if self.stack[-1]['name'] not in EXTRA or not getattr(self,'widths',[]) or self.widths[-1]!=8:raise RuntimeError('switch without actual width8 caller proof')
   cs=n['inner'];self.expr(cs[0]);self.emit(n,'switch_front',1,'actual target sizeof operand8; select real default arm')
   target=next(q for q in cs[-1]['inner'] if q.get('kind')=='DefaultStmt');self.emit(target,'default_selection_front')
   for q in target['inner']:self.stmt(q)
  else:super().stmt(n)

def execute(profile,hooks,capture):
 fs,srcs,binding=setup(profile,hooks,capture)
 if profile in ('MSVC-C11','Windows-native'):c.NATIVE.update(INTRINSICS)
 if profile=='Windows-native':c.TERNARY['wl_mutex_lock']=[];c.TERNARY['wl_mutex_unlock']=[]
 obj=Counter(fs,srcs,hooks);obj.run('wl_session_step')
 out={'metric':'AST scalar-cell conservative cover v2; strict aggregate/ABI refusal, transitive-input binding','profile':profile,'hooks':hooks,'path':'actual whole ROOT A first0 CANCEL through complete public return','cells':sum(q['cells'] for q in obj.events),'by_function_exclusive':{f:sum(q['cells'] for q in obj.events if q['function']==f) for f in sorted({q['function'] for q in obj.events})},'source_files':{u:{'path':v['path'],'sha256':v['sha256']} for u,v in srcs.items()},'type_catalog':dict(sorted(c.TYPE_KINDS.items())),'input_bindings':binding,'calls':obj.calls,'events':obj.events,'limitations':['aggregate nonliteral copies/arrays/unions/implicit nested aggregates and by-value aggregate arguments/returns reject until field/ABI proof','MSVC+C11 accessor AST recovered amid three pinned baseline layout errors; not whole-TU build success','conservative source cover, never a performed-work lower or Q256 certificate']}
 p=E/(profile+'-'+(hooks or 'production')+'-A.json');p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(p,out['cells'])
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--profile',choices=['C11','POSIX','MSVC-C11','Windows-native'],required=True);ap.add_argument('--hooks',choices=['dormant','armed'],default='');ap.add_argument('--capture-inputs',action='store_true');x=ap.parse_args();execute(x.profile,x.hooks,x.capture_inputs)
