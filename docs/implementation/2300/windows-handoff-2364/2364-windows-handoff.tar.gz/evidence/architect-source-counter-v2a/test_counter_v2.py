import json,pathlib,subprocess,unittest,tempfile
from unittest.mock import patch
import counter_v2 as c
import dependency_binding as d
import run_profile as r
E=pathlib.Path(__file__).parent
class AggregateRules(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  source=(E/'aggregate_fixture.c').read_bytes()
  tmp=E/'test-tmp';tmp.mkdir(exist_ok=True)
  with tempfile.TemporaryDirectory(dir=tmp,prefix='aggregate-') as target:
   p=pathlib.Path(target)/'aggregate_fixture.c';p.write_bytes(source)
   cmd=['clang','--target=x86_64-pc-linux-gnu','-std=c11','-fsyntax-only','-Xclang','-ast-dump=json',str(p)]
   q=subprocess.run(cmd,capture_output=True,text=True);assert q.returncode==0,q.stderr
   (pathlib.Path(target)/'aggregate_fixture.ast.json').write_text(q.stdout)
  n=json.loads(q.stdout);c.register_types([n]);cls.source=source;cls.fs={}
  for f in n['inner']:
   if f.get('kind')=='FunctionDecl' and any(x.get('kind')=='CompoundStmt' for x in f.get('inner',[])):
    cls.fs[f['name']]={'ast':f,'unit':'fixture'};c.CHOICES[f['name']]=[]
 def count(self,name):
  x=c.Counter(self.fs,{'fixture':{'data':self.source}},'');x.run(name);return x
 def cells(self,name):return sum(x['cells'] for x in self.count(name).events)
 def rejects(self,name,why):
  with self.assertRaisesRegex(RuntimeError,why):self.count(name)
 def test_uninitialized_scope_not_memset(self):self.assertEqual(self.cells('uninitialized_scope'),2)
 def test_initialized_all_members_including_implicit_scalars(self):
  x=self.count('initialized_members');self.assertEqual(sum(z['cells'] for z in x.events if z['kind']=='aggregate_scalar_stores'),3);self.assertEqual(self.cells('initialized_members'),8)
 def test_nested_explicit_members_and_scalar_value_init(self):self.assertEqual(self.cells('nested_members'),8)
 def test_actual_compound_temporary_and_value_reads(self):
  x=self.count('compound_assignment');by={q:sum(e['cells'] for e in x.events if e['kind']==q) for q in ['compound_literal_scalar_stores','aggregate_value_scalar_reads','aggregate_scalar_stores']};self.assertEqual(by,dict.fromkeys(by,3));self.assertEqual(self.cells('compound_assignment'),17)
 def test_compound_initialized_declaration(self):self.assertEqual(self.cells('initialized_compound'),17)
 def test_nonreport_copy_rejected(self):self.rejects('opaque_copy','aggregate copy')
 def test_nonreport_assignment_rejected(self):self.rejects('opaque_assignment','aggregate copy')
 def test_implicit_nested_layout_rejected(self):self.rejects('missing_nested_layout','implicit nested aggregate')
 def test_array_filler_rejected(self):self.rejects('array_initializer','union/array')
 def test_union_layout_rejected(self):self.rejects('union_initializer','union/array')
 def test_aggregate_return_abi_rejected(self):self.rejects('aggregate_return','return ABI')
 def test_aggregate_call_return_abi_rejected(self):self.rejects('aggregate_call_return','return ABI')
 def test_aggregate_argument_abi_rejected(self):self.rejects('aggregate_argument','argument ABI')
 def test_aggregate_parameter_abi_rejected(self):self.rejects('aggregate_parameter','parameter ABI')
 def test_enum_scalar_type_proven(self):self.assertEqual(self.cells('enum_scalar'),3)
 def test_increment_rejected(self):self.rejects('increment_unqualified','increment/decrement')
 def test_compound_store_rejected(self):self.rejects('compound_unqualified','compound assignment')
 def test_loop_rejected(self):self.rejects('loop_unqualified','unhandled expression WhileStmt')
 def test_unknown_engine_rejected(self):self.rejects('unknown_call','unqualified/unresolved call')
 def test_missing_branch_rejected(self):self.rejects('missing_branch','missing ifs choice')
class FixtureIsolationRules(unittest.TestCase):
 def test_fixture_preparation_never_mutates_bound_inputs(self):
  manifest=E/'manifest.json'
  if manifest.exists():
   paths=[E/name for name in json.loads(manifest.read_text())['files']]
  else:
   paths=[p for p in E.iterdir() if p.is_file()]
  before={str(p):c.sha(p.read_bytes()) for p in paths}
  AggregateRules.setUpClass()
  after={str(p):c.sha(p.read_bytes()) for p in paths}
  self.assertEqual(before,after)
  self.assertFalse((E/'aggregate_fixture.ast.json').exists())

class BindingRules(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=E);self.p=pathlib.Path(self.tmp.name);self.h=self.p/'bound.h';self.h.write_text('#define BOUND_VALUE 17\n');self.s=self.p/'unit.c';self.s.write_text('#include "bound.h"\nint x=BOUND_VALUE;\n');self.cmd=['clang','--target=x86_64-pc-linux-gnu','-std=c11','-DINPUT_VALUE=3'];self.old=d.inventory(self.cmd,self.s,E)
 def tearDown(self):self.tmp.cleanup()
 def test_transitive_header_is_bound(self):self.assertIn(str(self.h),self.old['dependencies']);d.verify_files(self.old)
 def test_changed_header_rejected(self):
  self.h.write_text('#define BOUND_VALUE 19\n')
  with self.assertRaisesRegex(RuntimeError,'dependency changed'):d.verify_files(self.old)
 def test_changed_macro_rejected(self):
  new=d.inventory(self.cmd+['-DEXTRA_VALUE=1'],self.s,E);self.assertNotEqual(self.old['macros_sha256'],new['macros_sha256'])
  with self.assertRaisesRegex(RuntimeError,'inputs changed'):d.compare(self.old,new)
 def test_changed_target_rejected(self):
  new=d.inventory(['clang','--target=x86_64-pc-windows-msvc','-std=c11','-DINPUT_VALUE=3'],self.s,E)
  with self.assertRaisesRegex(RuntimeError,'inputs changed'):d.compare(self.old,new)
 def test_frozen_engine_header_manifest_checked(self):
  manifest={'files':{'unit.c':d.sha(self.s.read_bytes()),'bound.h':'wrong'}}
  with patch.object(d,'F',self.p),patch.object(d,'M',manifest):
   with self.assertRaisesRegex(RuntimeError,'frozen engine/header mismatch'):d.inventory(self.cmd,self.s,E)
 def test_command_or_dependency_set_changed_rejected(self):
  new=dict(self.old);new['command']=self.old['command']+['-DOTHER=1']
  with self.assertRaisesRegex(RuntimeError,'inputs changed'):d.compare(self.old,new)
class NativeBoundaryRules(unittest.TestCase):
 def test_memcpy_outside_actual_width8_shim_rejected(self):
  x=r.Counter({}, {}, '')
  n={'kind':'CallExpr','inner':[{'kind':'DeclRefExpr','referencedDecl':{'name':'memcpy'}}]}
  with self.assertRaisesRegex(RuntimeError,'outside proven width8'):x.expr(n)
 def test_unknown_width_rejected(self):
  x=r.Counter({}, {}, '')
  n={'kind':'CallExpr','inner':[{'kind':'DeclRefExpr','referencedDecl':{'name':'wl_atomic_fetch_add_internal'}},{'kind':'UnaryExprOrTypeTraitExpr','name':'sizeof','inner':[{'type':{'desugaredQualType':'volatile int'}}]}]}
  with self.assertRaisesRegex(RuntimeError,'unproved width8'):x.expr(n)

class FullProfileRules(unittest.TestCase):
 def test_all_twelve_fresh_traces_have_binding_records(self):
  for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
   for hook in ['production','dormant','armed']:
    x=json.loads((E/(profile+'-'+hook+'-A.json')).read_text())
    for u,info in x['input_bindings'].items():
     p=pathlib.Path(info['record']);self.assertEqual(c.sha(p.read_bytes()),info['record_sha256']);record=json.loads(p.read_text());d.verify_files(record)
     ast=E/(profile+'-'+hook+'-'+u+'.ast.jsons');self.assertEqual(c.sha(ast.read_bytes()),info['ast_sha256'])
     if profile in ('MSVC-C11','Windows-native'):self.assertFalse(any(n.startswith('/usr/include') for n in record['dependencies']))
 def test_v1_delta_is_only_complete_literal_expansion(self):
  for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
   for hook in ['production','dormant','armed']:
    olddir=E.parent/('architect-source-counter-v1' if profile in ('C11','POSIX') else 'architect-windows-source');old=json.loads((olddir/(profile+'-'+hook+'-A.json')).read_text());new=json.loads((E/(profile+'-'+hook+'-A.json')).read_text());self.assertEqual(new['cells']-old['cells'],20)
    names=set(old['by_function_exclusive'])|set(new['by_function_exclusive'])
    for name in names:self.assertEqual(new['by_function_exclusive'].get(name,0)-old['by_function_exclusive'].get(name,0),20 if name=='wl_evaluation_control_source_observation_settle_locked' else 0)
 def test_actual_width8_shim_expanded_not_native(self):
  for profile in ['MSVC-C11','Windows-native']:
   x=json.loads((E/(profile+'-armed-A.json')).read_text());self.assertEqual(x['by_function_exclusive']['wl_atomic_fetch_add_internal'],14);self.assertEqual(x['by_function_exclusive']['wl_atomic_exchange_internal'],7)
if __name__=='__main__':unittest.main()
