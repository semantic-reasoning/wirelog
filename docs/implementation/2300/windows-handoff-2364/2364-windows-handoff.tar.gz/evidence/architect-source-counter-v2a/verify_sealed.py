#!/usr/bin/env python3
"""Verify the sealed evidence, rerun tests, and prove no sealed byte changed."""
import hashlib,json,pathlib,subprocess,sys
E=pathlib.Path(__file__).parent
R=pathlib.Path('/srv/home/joykim/.tmp/2300-operator-recovery-next')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 p=E/'manifest.json';m=json.loads(p.read_text());values={'manifest.json':sha(p)}
 for name,expected in m['files'].items():
  actual=sha(E/name)
  if actual!=expected:raise RuntimeError('sealed evidence mismatch '+name)
  values[name]=actual
 return values
before=snapshot()
result=subprocess.run([sys.executable,str(E/'test_counter_v2.py')],cwd=R,capture_output=True,text=True)
after=snapshot()
if before!=after:raise RuntimeError('test rerun mutated sealed bytes')
if result.returncode:raise RuntimeError(result.stdout+result.stderr)
print(json.dumps({'status':'PASS','sealed_files':len(before)-1,'manifest_sha256':before['manifest.json'],'before_after_identical':True,'tests_stdout':result.stdout,'tests_stderr':result.stderr,'fixture_ast_retained':(E/'aggregate_fixture.ast.json').exists()},indent=2))
