# Draft rebase integration handoff

Frozen rebased HEAD `93bd499a018801aeb6cb75a20a22e046783e385e` on main `60e28c6fa7300c51fc2b2bc150daca44f7fce25c`. Final owned WIP tree `5c7b6e879703c92c8d3ac0790af37df6f54416c5`; no new WIP snapshot commit or push. All original53 WIP paths and nine additions are restored;54 paths now differ from rebased HEAD because the unique original JOIN error-precedence hunk is also preserved. Real index is clean; retained stash remains4e92e59f24cf75f89203fa1ca4fe6c19ee0355f4. No experimental Native9caf/Source4 code was ported.

## Preserved history

All sixteen commits are retained as sixteen nonmerge rebased units; none skipped/squashed/emptied. Original source history remains in the verified bundle.

| Original | Rebased | Subject |
|---|---|---|
| `29c9fa4be6b79f50dd06b873761d66ad39546753` | `fdf971fc3f2f52b290ef81353ba4f7454fe0574a` | join: evaluate numeric right filters in controlled membership probes |
| `51cd875c13a48df84595574084b43cffcb8f9c7a` | `c84650b09975a8e5da6a5846b2f3a87f2cfb6a56` | test: qualify filtered probe session recovery and accounting |
| `bf7079d70e760eb62a021748388ed054dcbe9d30` | `c480aad8d3e376202a77b641ff9452aafc4e5b43` | join: evaluate scalar right predicates with retained bounded owners |
| `e4385f37e66a85f79836338b587dea851ee3aa3e` | `041d875a54222d652db2157133c35b5963f57a03` | reduce: evaluate scalar operands and bound intern-ranked aggregates |
| `9bd344375b4933c50a2f5acf55a2af69eaacc9d5` | `5b21542043bde1739b8b2930b2bf02fec982c9a9` | session: retain canonical observed cleanup across ended attempts |
| `c912d27058a55cfb709c140543b8f05a9f8401c5` | `865fd2aab6ea56d78feedfd6a74060b58272ae4c` | columnar: retain scalar source acquisition and retire it in finite steps |
| `b43f9cf7af293950b4bb5e72b0811950c8991bc2` | `7772e4662b57233a95a246c2f8b700869311ce12` | columnar: preserve prepared JOIN finish during observed native recovery |
| `99b11597362710708da531e30f2cad732a3f733b` | `a0ae1f1d27b190f07b70cd6db19f13e41f648e3c` | session: retire observed abort resources through canonical finite steps |
| `51bee69d3daec6c7f320f3e7ff7aece2ef5e0cb3` | `103b6c41c9b9e7aff7158f72ef97ea1824ac4ad8` | session: retain phased settlement of observed cleanup grants |
| `cfd229e35bd081352040bf6bf6e1993e1bd5b8a9` | `4d86426353d624545c0468c9decb93ae0112fe69` | docs: synchronize retained-reader and observer atomic audit |
| `fd612edea8cfa260712815f0cde095de4b503a9a` | `719bc1c15fe31c9ee52ab4619f883b648beed48b` | plan: bind preserved bodies to their generated K-fusion lineage |
| `9904a8bf88a089ee196574de7d51e63c1fcd7baf` | `6ad3f8c9084754682b79af2add5d5911646dfa41` | columnar: separate ledger description from one-shot publication |
| `226fb72cbb9daa679ae9037ce2c20c0a221f6b4b` | `6a81b972f116034500f34720bf1e3e69371d0bd2` | columnar: journal differential physical retirement before credit return |
| `6f864f4edd3b1ba0332438258bce7e6011e07f08` | `ef2ea9d36aa1be270a1ba48500c0d15020862765` | columnar: retain commit reports through ledger retirement acknowledgement |
| `679396e0aa7a7dbd60f0b86a7a43a0bdaf793cac` | `349ab169841203014e80fcf21346e205b616d044` | columnar: settle differential ledger retirement through finite report acknowledgements |
| `9914e9b4b4f8d9d8f1aad5b4c8af9ce1aed504f9` | `93bd499a018801aeb6cb75a20a22e046783e385e` | columnar: stage managed merge acknowledgement through finite retirement |

## Resolution decisions

- Original29c numeric filtered-membership algorithm is already superseded by main05c/9090 physical-row chains. Main engine/funding/intern-only context was preserved. All unique width0/1/17/65/257, high64 collision, malformed-row/error and cancellation/turnover tests were retained. Only removed internal compact-ordinal50/51 checkpoint cases were omitted in that direct matrix.
- Original51cd generated recovery/governor/metadata matrix remains. Its old50/51 observations now bind actual main28 selected physical-row hash insertion and17 real candidate probing. All nine fault modes, numeric/scalar domains, SEMI/ANTI, ordinary/batch, retained scalar-program ownership, positive results, report/reset and governor baselines remain.
- Originalbf scalar engine fallback is superseded by main256/intern-only behavior; unique long2050-byte string function tests and retained-owner fixtures/Meson/docs remain. Originale438 unique non-COUNT STRING domain, intern-rank helper/prototype, candidate/current validity/ranking and542-line test extension remain atop main scalar256 compiler/evaluation framework.
- Main quiescent general-rollback predicate and new seed/radix audit rows are retained. WIP financial-role binding/dispatch and real completion tickets remain. The WIP completion observer falls back to the actual main state-only rollback observation; invalid completion fallback retains main abort semantics.
- Main REDUCE-aware registered cleanup validation supersedes the obsolete FILTER/MAP-only WIP guard. Both main test registrations and WIP join-forward registration remain. Atomic audit rows/count are the actual union621; no rows or checks were dropped.
- The unique original29c filter-before-projection validation order was restored after its new direct test exposed that a selected invalid NaN must report EINVAL before malformed projection ENOTSUP. This is only the original guard relocation; main physical-row algorithm, intern-only scalar context and all256 prices remain. The unchanged error oracle then passed.

## Fresh validation of frozen source

- Explicit Meson reconfigure succeeded (initial stale configure cache did not yet know new main test targets; that first target-resolution error is retained as a configuration diagnostic). Final focused compilation of eight executable targets passed.
- Final focused tests:8 PASS /1 FAIL. PASS: evaluation_join, evaluation_numeric_operators, evaluation_serial, filtered-numeric and filtered-scalar generated probes, recursive_cursor_parity, evaluation_seed_physical and evaluation_seed_private_compact.
- Remaining deterministic failure: evaluation_expression_reduce at tests/test_evaluation_expression_reduce.c:194 reports actual Native mixed0 consumed3817, expected3560. The exact oracle remains unchanged. Cause/accounting acceptance is unfinished and is explicitly handed off; no magic expected number, fee/cap change or fresh bound claim was introduced.
- All65 owned PR/WIP C/H formatting checks pass; git diff --check passes; real index is clean. Exact threading inventory621 passes. New main recursive cursor parity and private/public seed tests passed against the integrated source.
- Historical old699/686+13skip and old GCC/sanitizer/POSIX results are not post-rebase proof. This pass does not claim current full broad tests, real MSVC/link/runtime or2367/2368/resource acceptance.

Actual commands were run under the existing uv evidence virtualenv. Target list: test_evaluation_join, test_evaluation_join_probes, test_evaluation_serial, test_evaluation_numeric_operators, test_recursive_cursor_parity, test_evaluation_seed_physical, test_evaluation_seed_private_compact, test_evaluation_expression_reduce. Meson test used --no-rebuild only after successful target compilation. Full outputs are final-focused-build.log/final-focused-tests.log, final-format-check.json, final-diff-check.log and threading-doc-v1.log in this directory.

## Exact review inputs and remaining gates

HEAD-to-WIP raw SHA256 `54c14809f60551950144140c1eab56c865e784674e696da8b5d33669c0dec51d` (`candidate.diff`). Main-to-WIP full PR diff SHA256 `ff3b02e183d17ef832c5098e61b00038d2065ee8ee1cb6ca9b4d656bc7baa422` (`full-pr.diff`). Columnar Session source SHA256 `d01b96070d00c077f8900bd7d74910c0b02d585b0ed085ad8e2730947d28e9e6`. `delivery.json` holds every54 file digest and exact candidate tree; `commit-mapping.json` holds full old-to-new identities.

Root takes over fresh broad validation and independent unfinished-Draft RAW, then strictly later distinct final design/risk, normal hooked code checkpoint commit, separate reviewed archival/docs commit and force-with-lease update of existing PR2364 DRAFT. No Closes/Ready/merge/issue-completion claim. The archive/docs directory was not touched by this code writer. Source is frozen; no further Root code writes by this agent.
