# Caller scope remains conditional

This module does not manufacture a live-actor certificate. Existing named synchronous main-stack fixture and joined LIVE foreign-probe histories are held in `../thread-provider-linux-intake-v1/caller-lifetime-receipt.md`, SHA256 dabde118711bf8b801cb57e83f87d6bffe5c4c7ed27b60245951133c4e4842ac. They bind their exact Root source versions, not Native9caf automatically.

Independent adjudication89e54 accepts a finite actual internal-control supplier/creator/driver inventory, rather than a hypothetical universal no-exit proof. Ordinary C1 STEP/CLOSE may retain ctx/p across per-call Source scopes and does not implicitly acquire the explicit exclusive-attempt lease. That route's outstanding certificate stays BLOCK; no thread-generation repair, new engine refusal or public no-exit semantics is authorized. Allocation/control refs and thread_valid are not actor lifetime proof.

Counter fixture purpose is permanently non-production; every emitted example is UNQUALIFIED with route_blocked and no C upper. Production caller descriptors must reference a separately reviewed exact binding and actual producer/source/driver evidence with valid LIVE identity through real ACK/free. No expired equality is executed. Source32 has no callsite membership in this module.
