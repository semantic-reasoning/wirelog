"""Compile genuine pre-existing fixture bytes under explicit -O2; no engine run."""
from pathlib import Path
import subprocess,json,hashlib
E=Path(__file__).parent; B=E.parent/'prepared-native-packet-method-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for profile in ['C11','POSIX']:
 old=json.loads((B/(profile+'-aggregate.inputs.json')).read_text())
 command=old['command']+['-O2'];prefix=E/'fixtures'/profile;prefix.parent.mkdir(exist_ok=True)
 rec=dict(old);rec['command']=command
 for name,flags in [('ast',['-fsyntax-only','-Xclang','-ast-dump=json']),('macros',['-E','-dM']),('ll',['-S','-emit-llvm','-o','-'])]:
  p=subprocess.run(command+flags,cwd=old['cwd'],capture_output=True)
  path=prefix.with_suffix('.'+name);path.write_bytes(p.stdout);path.with_suffix(path.suffix+'.stderr').write_bytes(p.stderr)
  if p.returncode:raise RuntimeError(profile+' capture failed')
 rec['macros_text']=prefix.with_suffix('.macros').read_text();rec['macros_sha256']=sha(prefix.with_suffix('.macros'))
 prefix.with_suffix('.inputs.json').write_text(json.dumps(rec,indent=2)+'\n')
 print(profile,'genuine -O2 AST',sha(prefix.with_suffix('.ast')))
