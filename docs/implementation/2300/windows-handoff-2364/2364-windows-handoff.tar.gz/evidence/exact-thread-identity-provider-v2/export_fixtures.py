import sys
sys.dont_write_bytecode = True
"""Replay genuine captures; all fixture ledgers explicitly UNQUALIFIED."""
from pathlib import Path
import json,hashlib
from test_thread_provider import capture,register_all,counter,E,F
import thread_provider as t
rows=[]
for profile,inline in [('C11',False),('POSIX',False),('C11',True),('POSIX',True),('Windows-native',False)]:
 cap=capture(profile,inline);domain=t.Domain(cap,enabled=True);register_all(cap,domain)
 obj=counter(cap,domain,'actor_current' if profile=='Windows-native' else 'actor_equal')
 obj.run('actor_current' if profile=='Windows-native' else 'actor_equal');ledger=domain.ledger(obj)
 name=profile+('-O2-inline' if inline else '-saved-outofline')
 path=E/(name+'.ledger.json');path.write_text(json.dumps(ledger,indent=2)+'\n')
 rows.append({'name':name,'profile':profile,'fixture_only':True,'ledger':str(path),'ledger_sha256':t.digest(path),
              'qualification':ledger['qualification'],'C_observed':ledger['C_source_cells_observed'],
              'P_symbols':[p['symbol'] for p in ledger['P']],'C_upper':None,'actual_files':cap.files})
cap=capture('MSVC-C11')
from saved_aggregate_proof import make
proof=make(cap);d=t.Domain(cap,enabled=True);register_all(cap,d)
fs=t.inherited.closure({name:{'ast':n,'unit':cap.unit} for name,n in cap.functions.items()},'actor_equal')
c=t.Counter(fs,{cap.unit:{'data':cap.source}},'',cap.roots,{},unit_nodes={cap.unit:cap.roots},contextual_operands=True,aggregate_transfers=True,proof=proof,thread_domain=d)
c.run('actor_equal');ledger=d.ledger(c);p=E/'MSVC-C11-full-aggregate.ledger.json';p.write_text(json.dumps(ledger,indent=2)+'\n')
rows.append({'name':'MSVC-C11-full-primary-aggregate','profile':'MSVC-C11','fixture_only':True,
             'status':'GENUINE_SAME_TU_FULL_AGGREGATE_REPLAY_UNQUALIFIED_PROVIDER_CALLER',
             'actual_files':cap.files,'ledger':str(p),'ledger_sha256':t.digest(p),
             'qualification':ledger['qualification'],'C_observed':ledger['C_source_cells_observed'],
             'P_symbols':[p['symbol'] for p in ledger['P']],'C_upper':None,'scalar_fallback':False})
(E/'fixtures.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in r if k in ['name','qualification','C_observed','P_symbols','status']} for r in rows],indent=2))
