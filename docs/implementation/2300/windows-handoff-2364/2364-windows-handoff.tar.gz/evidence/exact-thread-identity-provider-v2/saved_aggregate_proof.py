import sys
sys.dont_write_bytecode = True
"""Reconstruct and reverify existing genuine primary MSVC proof; no stub AST."""
from pathlib import Path
import json,re
import thread_provider as t
F=Path(__file__).parent.parent/'prepared-native-packet-method-v1'
def make(cap):
 m=t.inherited;profile=cap.profile
 if profile!='MSVC-C11':raise RuntimeError('only the saved primary MSVC fixture')
 prefix=F/(profile+'-aggregate');zp=F/(profile+'-zero')
 natural=m.PrimaryNaturalPack8(profile,cap.roots,Path(str(prefix)+'.ast.json'),Path(str(prefix)+'.ll'),Path(str(prefix)+'.layout'),Path(str(prefix)+'.preprocessed.c'),Path(str(prefix)+'.inputs.json'))
 cat=m.Catalog(cap.roots,natural);ir=Path(str(prefix)+'.ll').read_text()
 results=json.loads((F/(profile+'.results.json')).read_text())
 transfers=results['transfer_witnesses'];zeros={int(k):v for k,v in results['literal_zero_witnesses'].items()}
 labels={q:'extent_'+str(i) for i,q in enumerate(sorted(transfers))}
 extents={q:int(re.search('@'+label+r' = [^\n]*constant i64 (\d+)',ir)[1]) for q,label in labels.items()}
 fs={n['name']:{'ast':n,'unit':'fixture'} for n in cap.roots[0]['inner'] if n.get('kind')=='FunctionDecl' and t.body(n)}
 zr=[json.loads(Path(str(zp)+'.ast.json').read_text())]
 zfs={n['name']:{'ast':n,'unit':'fixture'} for n in zr[0]['inner'] if n.get('kind')=='FunctionDecl' and t.body(n)}
 m.c.register_types(cap.roots);m.c.register_types(zr)
 for fn in [*fs,*zfs]:m.c.CHOICES[fn]=[];m.c.TERNARY[fn]=[]
 bindings={str(p):t.digest(p) for p in [Path(str(prefix)+x) for x in ['.c','.ast.json','.ll','.inputs.json']]+[Path(str(zp)+x) for x in ['.c','.ast.json','.ll','.inputs.json']]}
 return m.CapturedProof(profile,cat,extents,labels,transfers,zeros,m.ABI(ir,cat,extents),bindings,fs,Path(str(prefix)+'.c'),zr,zfs,Path(str(zp)+'.c'),[json.loads(Path(str(prefix)+'.inputs.json').read_text()),json.loads(Path(str(zp)+'.inputs.json').read_text())])
