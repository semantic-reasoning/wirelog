import sys
sys.dont_write_bytecode = True
import unittest, json, copy
from pathlib import Path
import thread_provider as t
E=Path(__file__).parent; F=E.parent/'prepared-native-packet-method-v1'
BLOCK={'status':'BLOCK','reason':'Actual fixture is not a reviewed production provider/caller certificate'}

def capture(profile='C11',inline=False):
 prefix=E/'fixtures'/profile if inline else F/(profile+'-aggregate')
 return t.Capture(prefix.with_suffix('.ast') if inline else Path(str(prefix)+'.ast.json'),
                  F/(profile+'-aggregate.c'),prefix.with_suffix('.inputs.json') if inline else Path(str(prefix)+'.inputs.json'),profile,purpose='fixture',ir=prefix.with_suffix('.ll') if inline else Path(str(prefix)+'.ll'))

def register_all(cap,domain):
 for fn in ['actor_current','actor_equal']:
  for call in cap.calls(fn):
   name=t.reference(call).get('name')
   if name in t.STANDARD[cap.profile]:
    domain.register(call,mode='source' if name in cap.functions else 'platform',provider=BLOCK,caller=BLOCK)

def counter(cap,domain,name='actor_equal'):
 t.inherited.c.register_types(cap.roots)
 header=t.HEADERS[cap.profile][0]
 fs={fn:{'ast':node,'unit':'header' if node.get('loc',{}).get('includedFrom') else cap.unit} for fn,node in cap.functions.items()}
 fs=t.inherited.closure(fs,name)
 for fn in fs:
  t.inherited.c.CHOICES[fn]=[];t.inherited.c.TERNARY[fn]=[]
 src={cap.unit:{'data':cap.source},'header':{'data':Path(header).read_bytes()}}
 obj=t.Counter(fs,src,'',cap.roots,{},unit_nodes={cap.unit:cap.roots,'header':cap.roots},contextual_operands=True,thread_domain=domain)
 return obj

class Tests(unittest.TestCase):
 def test_default_off_unchanged_membership(self):
  cap=capture();old=set(t.inherited.c.NATIVE);d=t.Domain(cap)
  with self.assertRaisesRegex(RuntimeError,'disabled'):d.register(cap.calls('actor_current')[0],mode='platform',provider=BLOCK,caller=BLOCK)
  with self.assertRaises(RuntimeError):counter(cap,d,'actor_current').run('actor_current')
  self.assertEqual(old,set(t.inherited.c.NATIVE))
 def test_real_outofline_two_services_and_fronts(self):
  cap=capture();d=t.Domain(cap,enabled=True);register_all(cap,d);c=counter(cap,d);c.run('actor_equal');r=d.ledger(c)
  self.assertEqual([p['symbol'] for p in r['P']],['thrd_current','thrd_equal'])
  self.assertEqual(r['qualification'],'UNQUALIFIED');self.assertTrue(r['route_blocked']);self.assertIsNone(r['C_upper'])
  self.assertFalse(r['packet_upper_accepted']);self.assertIn('EXCLUDED_BY_TRUSTED_PLATFORM_BOUNDARY',r['theorem'])
  self.assertTrue(any(e['kind']=='argument_fronts' and e['cells']==2 for e in r['C_events']))
  self.assertTrue(any(e['kind']=='return_front' for e in r['C_events']))
  for p in r['P']:self.assertNotIn('cells',p);self.assertNotIn('price',p)
 def test_genuine_inline_equal_no_phantom_P(self):
  for profile,current in [('C11','thrd_current'),('POSIX','pthread_self')]:
   cap=capture(profile,True);self.assertIn('__OPTIMIZE__ 1',cap.input_record['macros_text'])
   d=t.Domain(cap,enabled=True);register_all(cap,d);c=counter(cap,d);c.run('actor_equal');r=d.ledger(c)
   self.assertEqual([p['symbol'] for p in r['P']],[current])
   self.assertTrue(any(a['binding']['mode']=='source' for a in r['call_audit']))
   equal='thrd_equal' if profile=='C11' else 'pthread_equal'
   self.assertTrue(any(e['function']==equal and e['kind']=='return_front' for e in c.events))
   self.assertTrue(any(e['function']==equal and e['kind']=='operator_front' for e in c.events))
 def test_inline_baseline_C_effects_unchanged(self):
  cap=capture('C11',True);name='thrd_equal';d=t.Domain(cap,enabled=True)
  c=counter(cap,d,name);c.run(name)
  base=t.inherited.Counter(c.fs,c.srcs,'',cap.roots,{},unit_nodes={cap.unit:cap.roots,'header':cap.roots},contextual_operands=True);base.run(name)
  self.assertEqual(c.events,base.events)
 def test_unregistered_occurrence_stops(self):
  cap=capture();d=t.Domain(cap,enabled=True)
  with self.assertRaisesRegex(RuntimeError,'unregistered'):counter(cap,d,'actor_current').run('actor_current')
 def test_source_cannot_be_opaque_service(self):
  cap=capture('C11',True);d=t.Domain(cap,enabled=True)
  call=next(c for c in cap.calls('actor_equal') if t.reference(c)['name']=='thrd_equal')
  with self.assertRaisesRegex(RuntimeError,'mode contradicts'):d.register(call,mode='platform',provider=BLOCK,caller=BLOCK)
 def test_no_fabricated_inline_body(self):
  cap=capture();d=t.Domain(cap,enabled=True)
  with self.assertRaisesRegex(RuntimeError,'mode contradicts'):d.register(cap.calls('actor_current')[0],mode='source',provider=BLOCK,caller=BLOCK)
 def test_missing_certificate_not_silent(self):
  cap=capture();d=t.Domain(cap,enabled=True)
  with self.assertRaisesRegex(RuntimeError,'explicit provider BLOCK'):d.register(cap.calls('actor_current')[0],mode='platform',provider=None,caller=BLOCK)
 def test_registration_and_AST_mutations(self):
  for mutate in ['source','type','registration','caller','provider']:
   cap=capture();d=t.Domain(cap,enabled=True);register_all(cap,d)
   if mutate=='source':cap.files[str(cap.source_path.resolve())]='0'*64
   elif mutate=='type':cap.calls('actor_current')[0]['type']['qualType']='void *'
   else:
    row=next(iter(d.registrations.values()))
    if mutate=='registration':row['mode']='source'
    else:row[mutate]['reason']='changed'
   with self.assertRaises(RuntimeError):counter(cap,d,'actor_current').run('actor_current')
 def test_P_and_C_omission_fail(self):
  for what in ['P','C','audit','registration']:
   cap=capture();d=t.Domain(cap,enabled=True);register_all(cap,d);c=counter(cap,d);c.run('actor_equal')
   if what=='P':d.p_events.pop()
   elif what=='C':c.events.pop()
   elif what=='audit':d.audit.pop()
   else:d.registrations.clear()
   with self.assertRaises(RuntimeError):d.ledger(c)
 def test_no_name_coupon_or_duplicate(self):
  cap=capture();d=t.Domain(cap,enabled=True);call=cap.calls('actor_current')[0]
  d.register(call,mode='platform',provider=BLOCK,caller=BLOCK)
  with self.assertRaisesRegex(RuntimeError,'duplicate'):d.register(call,mode='platform',provider=BLOCK,caller=BLOCK)
  other=copy.deepcopy(call)
  with self.assertRaisesRegex(RuntimeError,'unregistered'):d.occurrence(other,'actor_current')
 def test_real_MSVC_full_actor_retained_not_scalarized(self):
  cap=capture('MSVC-C11');d=t.Domain(cap,enabled=True);register_all(cap,d)
  decl=cap.declaration(cap.calls('actor_current')[0]);self.assertIn('cdecl',decl['type']['qualType'])
  records=[n for r in cap.roots for n in t.walk(r) if n.get('kind')=='RecordDecl' and n.get('completeDefinition') and [f.get('name') for f in n.get('inner',[]) if f.get('kind')=='FieldDecl']==['_Handle','_Tid']]
  self.assertTrue(records);self.assertTrue(all([f['name'] for f in r['inner'] if f.get('kind')=='FieldDecl']==['_Handle','_Tid'] for r in records))
  ir=(F/'MSVC-C11-aggregate.ll').read_text();self.assertIn('sret(%struct.thrd_t)',ir);self.assertIn('i64 16, i1 false',ir)
  with self.assertRaises(RuntimeError):counter(cap,d,'actor_current').run('actor_current')
  # No actor P/upper may be emitted when full inherited aggregate proof is absent.
  self.assertEqual(d.p_events,[])
 def test_reviewed_certificate_gate_no_implicit_approval(self):
  cap=capture();d=t.Domain(cap,enabled=True);call=cap.calls('actor_current')[0]
  path=E.parent/'root-3b547-posix-provider-v1/receipt.json'
  descriptor={'status':'PASS','path':str(path),'sha256':t.digest(path)}
  with self.assertRaisesRegex(RuntimeError,'unreviewed'):d.register(call,mode='platform',provider=descriptor,caller=BLOCK)
 def test_derived_index_and_counter_source_mutation(self):
  cap=capture();d=t.Domain(cap,enabled=True);register_all(cap,d)
  cap.owners[id(cap.calls('actor_current')[0])]='other'
  with self.assertRaisesRegex(RuntimeError,'derived'):counter(cap,d,'actor_current')
 def test_production_domain_rejects_fixture_name(self):
  prefix=F/'C11-aggregate';cap=t.Capture(Path(str(prefix)+'.ast.json'),Path(str(prefix)+'.c'),Path(str(prefix)+'.inputs.json'),'C11',purpose='production',ir=Path(str(prefix)+'.ll'))
  d=t.Domain(cap,enabled=True)
  with self.assertRaisesRegex(RuntimeError,'helper/producer'):d.register(cap.calls('actor_current')[0],mode='platform',provider=BLOCK,caller=BLOCK)
 def test_mixed_actual_IR_mode_is_rejected(self):
  cap=t.Capture(E/'fixtures/C11.ast',F/'C11-aggregate.c',E/'fixtures/C11.inputs.json','C11',purpose='fixture',ir=F/'C11-aggregate.ll')
  d=t.Domain(cap,enabled=True)
  call=next(c for c in cap.calls('actor_equal') if t.reference(c)['name']=='thrd_equal')
  with self.assertRaisesRegex(RuntimeError,'LLVM service'):d.register(call,mode='source',provider=BLOCK,caller=BLOCK)
 def test_genuine_MSVC_full_CapturedProof_replay(self):
  from saved_aggregate_proof import make
  cap=capture('MSVC-C11');proof=make(cap);d=t.Domain(cap,enabled=True);register_all(cap,d)
  fs=t.inherited.closure({name:{'ast':node,'unit':cap.unit} for name,node in cap.functions.items()},'actor_equal')
  c=t.Counter(fs,{cap.unit:{'data':cap.source}},'',cap.roots,{},unit_nodes={cap.unit:cap.roots},contextual_operands=True,aggregate_transfers=True,proof=proof,thread_domain=d)
  c.run('actor_equal');r=d.ledger(c)
  self.assertEqual([p['symbol'] for p in r['P']],['thrd_current','thrd_equal'])
  self.assertTrue(r['route_blocked']);self.assertIsNone(r['C_upper']);self.assertEqual(len(r['ABI_audit']),2)
  self.assertTrue(all(p['ABI_transport'] for p in r['P']))
  actor=[a for a in r['transfer_audit'] if a['type']=='struct thrd_t']
  self.assertTrue(actor)
  for a in actor:self.assertEqual([leaf['path'] for leaf in a['leaves']],[['_Handle'],['_Tid']])
 def test_success_then_unknown_attempt_invalidates_old_ledger(self):
  cap=capture();d=t.Domain(cap,enabled=True);register_all(cap,d);c=counter(cap,d);c.run('actor_equal')
  first=d.ledger(c);self.assertEqual(len(first['P']),2)
  with self.assertRaisesRegex(RuntimeError,'single-use measurement'):c.run('not_an_actual_function')
  self.assertIsNone(c._thread_c_seal)
  with self.assertRaisesRegex(RuntimeError,'complete owned'):d.ledger(c)
 def test_shared_Domain_cannot_mix_two_Counters(self):
  cap=capture();d=t.Domain(cap,enabled=True);register_all(cap,d);first=counter(cap,d,'actor_current');first.run('actor_current')
  with self.assertRaisesRegex(RuntimeError,'already bound'):counter(cap,d,'actor_equal')
  record=d.ledger(first)
  self.assertEqual(len(record['P']),1);self.assertEqual(record['C_source_cells_observed'],sum(e['cells'] for e in first.events))
 def test_nested_helper_is_one_complete_measurement(self):
  cap=capture();d=t.Domain(cap,enabled=True);register_all(cap,d);c=counter(cap,d);c.run('actor_equal');r=d.ledger(c)
  self.assertTrue(r['measurement_complete']);self.assertEqual(r['measurement_seal'],d._measurement_seal)
  self.assertEqual([p['symbol'] for p in r['P']],['thrd_current','thrd_equal'])
  self.assertTrue(any(e['function']=='actor_current' for e in r['C_events']))
 def test_failed_first_measurement_never_recovers_old_eligibility(self):
  cap=capture();d=t.Domain(cap,enabled=True);register_all(cap,d);c=counter(cap,d,'actor_current')
  with self.assertRaises(KeyError):c.run('not_an_actual_function')
  with self.assertRaisesRegex(RuntimeError,'single-use measurement'):c.run('actor_current')
  with self.assertRaisesRegex(RuntimeError,'complete owned'):d.ledger(c)
 def test_disabled_counter_repeated_runs_match_inherited(self):
  cap=capture();d=t.Domain(cap);c=counter(cap,d,'actor_identity')
  base=t.inherited.Counter(c.fs,c.srcs,'',cap.roots,{},unit_nodes={cap.unit:cap.roots,'header':cap.roots},contextual_operands=True)
  for _ in range(2):c.run('actor_identity');base.run('actor_identity')
  self.assertEqual(c.events,base.events)
  with self.assertRaisesRegex(RuntimeError,'disabled'):d.ledger(c)
 def test_windows_missing_provider_remains_unqualified(self):
  cap=capture('Windows-native');d=t.Domain(cap,enabled=True);register_all(cap,d);c=counter(cap,d,'actor_current');c.run('actor_current');r=d.ledger(c)
  self.assertEqual([p['symbol'] for p in r['P']],['GetCurrentThreadId']);self.assertTrue(r['route_blocked'])

if __name__=='__main__':unittest.main(verbosity=2)
