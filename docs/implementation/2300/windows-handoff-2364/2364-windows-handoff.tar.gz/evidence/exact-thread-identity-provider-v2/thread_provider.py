"""Default-OFF evidence adapter; no engine/runtime or packet-count permission."""
from pathlib import Path
import copy, hashlib, json, sys, re
sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE / 'prepared-native-packet-method-v1'))
import native_counter as inherited

METHOD = 'exact-thread-identity-provider-v1'
THEOREM = ('A qualified interval reports (C upper, finite P occurrence sequence/maxima, caller/effect/lifetime conditions). C bounds all supported ordinary engine and genuine included-header source work, '
           'helper/control flow, full evaluated arguments/results, complete target ABI transfers '
           'and actual caller/refusal/unwind operations. P lists each exact out-of-line trusted '
           'standard current/equality service occurrence. The service interior is '
           'EXCLUDED_BY_TRUSTED_PLATFORM_BOUNDARY, NOT C0, C1, an inferred instruction count '
           'or hidden omitted work. This is not total implementation/OS instructions or latency.')
FUNCTIONS = frozenset({
    'wl_columnar_eval_serial_framed_thread',
    'wl_columnar_eval_stack_prepared_thread',
    'wl_columnar_eval_serial_framed_attempt_begin_internal',
    'wl_columnar_eval_stack_prepared_init_register',
    'wl_columnar_eval_stack_prepared_join_finish_begin_core',
})
FIXTURE_FUNCTIONS = frozenset({'actor_current', 'actor_equal'})
STANDARD = {'C11': {'thrd_current', 'thrd_equal'},
            'POSIX': {'pthread_self', 'pthread_equal'},
            'MSVC-C11': {'thrd_current', 'thrd_equal'},
            'Windows-native': {'GetCurrentThreadId'}}
HEADERS = {
    'C11': ('/usr/include/threads.h', '99593c9ac86bcb2ad816b24157d525d27f764ff647524be919935ffb0fde274e'),
    'POSIX': ('/usr/include/pthread.h', '5479c95276c6693fdd1baa448f5d457dee57fc02b31277bfa04df63cc0b26a94'),
    'MSVC-C11': (str(BASE/'architect-windows-source/crt/threads.h'), 'c5ff7e0ef7b0edb042e24a87a71216cbeceaa99e2d366cebac36d2f970a212d5'),
    'Windows-native': (str(BASE/'architect-windows-source/sdk/10.0.26100.0/um/processthreadsapi.h'), '3036b32f97a10effb762e773cffc79d2dd7afa156a591c6243d36491063c6250'),
}

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fingerprint(value): return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
def reject(reason): raise RuntimeError(METHOD+': '+reason)
def walk(node):
    yield node
    for child in node.get('inner', []): yield from walk(child)
def body(node): return any(x.get('kind') == 'CompoundStmt' for x in node.get('inner', []))
def reference(call):
    node = inherited.strip(call['inner'][0])
    if node.get('kind') != 'DeclRefExpr': reject('indirect/non-declaration service call')
    return node.get('referencedDecl', {})

def json_objects(text):
    decoder = json.JSONDecoder(); i = 0; roots = []
    while i < len(text):
        while i < len(text) and text[i].isspace(): i += 1
        if i == len(text): break
        node, i = decoder.raw_decode(text, i); roots.append(node)
    return roots

class Capture:
    """Own genuine immutable compiler objects, source and input/provenance bytes."""
    def __init__(self, ast, source, inputs, profile, unit='thread', purpose='production', ir=None, syntax_receipt=None, extra_files=()):
        if profile not in STANDARD or purpose not in {'production', 'fixture'}: reject('unknown capture domain')
        self.profile, self.unit, self.purpose = profile, unit, purpose
        if ir is None: reject('missing actual LLVM mode/transport input')
        self.ir_path=Path(ir);self.ir_text=self.ir_path.read_text()
        self.ast_path, self.source_path, self.inputs_path = map(Path, (ast, source, inputs))
        self.roots = json_objects(self.ast_path.read_text())
        self.source = self.source_path.read_bytes()
        self.syntax_ok=False;self.syntax_receipt_hash=None
        if syntax_receipt is not None:
            receipt=json.loads(Path(syntax_receipt).read_text())
            expected={'kind':'full-tu-syntax','returncode':0,'ast_sha256':digest(self.ast_path),'source_sha256':digest(self.source_path),'inputs_sha256':digest(self.inputs_path),'ir_sha256':digest(self.ir_path)}
            if receipt!=expected: reject('failed/unbound full-TU syntax receipt')
            extra_files=(*extra_files,syntax_receipt);self.syntax_ok=True;self.syntax_receipt_hash=digest(syntax_receipt)
        self.input_record = json.loads(self.inputs_path.read_text())
        record = self.input_record
        target = 'x86_64-pc-windows-msvc' if profile in {'MSVC-C11','Windows-native'} else 'x86_64-pc-linux-gnu'
        if record.get('target_option') != target: reject('target/profile mismatch')
        if ('WL_HAVE_C11_THREADS' in record.get('macros_text','')) != (profile in {'C11','MSVC-C11'}): reject('thread selection macro mismatch')
        self.files = {str(p.resolve()): digest(p) for p in [self.ast_path,self.source_path,self.inputs_path,self.ir_path,*map(Path,extra_files)]}
        for p, info in record.get('dependencies', {}).items(): self.files[p] = info['sha256']
        for p, h in record.get('explicit_input_files', {}).items(): self.files[p] = h
        self.files[record['compiler_path']] = record['compiler_sha256']
        self.nodes = {n['id']:n for root in self.roots for n in walk(root) if n.get('id') and n.get('kind')!='DeclRefExpr'}
        self.functions = {n['name']:n for root in self.roots for n in walk(root) if n.get('kind')=='FunctionDecl' and body(n)}
        self.owners = {}
        for name, fn in self.functions.items():
            for n in walk(fn):
                if n.get('kind')=='CallExpr': self.owners[id(n)] = name
        self.stamp = fingerprint(self.roots); self.file_stamp = fingerprint(self.files)
        self.derived_stamp = self._derived()
        self.configuration_stamp=fingerprint([self.profile,self.unit,self.purpose,self.syntax_ok,self.syntax_receipt_hash])
        self.verify()
    def _derived(self):
        return fingerprint({'functions':{k:id(v) for k,v in self.functions.items()},
                            'nodes':{k:id(v) for k,v in self.nodes.items()},'owners':self.owners})
    def verify(self):
        if fingerprint([self.profile,self.unit,self.purpose,self.syntax_ok,self.syntax_receipt_hash])!=self.configuration_stamp: reject('mutated capture configuration')
        if hashlib.sha256(self.source).hexdigest()!=self.files[str(self.source_path.resolve())] or hashlib.sha256(self.ir_text.encode()).hexdigest()!=self.files[str(self.ir_path.resolve())]: reject('mutated source/IR cache')
        if self._derived()!=self.derived_stamp: reject('mutated derived actual-TU index')
        if fingerprint(self.roots)!=self.stamp or fingerprint(self.files)!=self.file_stamp: reject('mutated compiler/input binding object')
        for p,h in self.files.items():
            if not Path(p).is_file() or digest(p)!=h: reject('changed/missing bound file '+p)
    def calls(self, function):
        return [n for n in walk(self.functions[function]) if n.get('kind')=='CallExpr']
    def declaration(self, node):
        if id(node) not in self.owners: reject('call not in exact actual TU')
        ref = reference(node); decl = self.nodes.get(ref.get('id'))
        if not decl or decl.get('kind')!='FunctionDecl' or decl.get('name')!=ref.get('name'): reject('unresolved declaration identity')
        return decl

class Domain:
    def __init__(self, capture, *, enabled=False, reviewed_certificates=()):
        self.capture, self.enabled = capture, enabled
        self.reviewed = frozenset(reviewed_certificates)
        self.registrations = {}; self._registration_stamp = fingerprint({})
        self._p_expected = []; self._audit_expected = []; self.p_events = []; self.audit = []
        self._native = frozenset(inherited.c.NATIVE)
        self._counter_owner=None;self._measurement_state='UNSTARTED';self._measurement_seal=None
    def bind_counter(self,counter):
        if self._counter_owner is not None and self._counter_owner is not counter:
            reject('single-use Domain already bound to another Counter')
        self._counter_owner=counter
    def begin(self,counter):
        if self._counter_owner is not counter: reject('measurement Counter owner mismatch')
        self._measurement_seal=None
        if self._measurement_state!='UNSTARTED':
            self._measurement_state='FAILED'
            reject('single-use measurement already attempted')
        self._measurement_state='RUNNING'
    def fail(self,counter):
        if self._counter_owner is counter:
            self._measurement_state='FAILED';self._measurement_seal=None
    def measurement_state(self,counter):
        return fingerprint([counter.c_state(),self.p_events,self.audit,self._registration_stamp])
    def complete(self,counter):
        if self._counter_owner is not counter or self._measurement_state!='RUNNING': reject('measurement not owned/running')
        self._measurement_seal=self.measurement_state(counter);self._measurement_state='COMPLETE'
    def _certificate(self, descriptor, kind, binding):
        if not descriptor or descriptor.get('status')=='BLOCK':
            if not descriptor or not descriptor.get('reason'): reject('missing explicit '+kind+' BLOCK reason')
            return False
        if descriptor.get('status')!='PASS' or set(descriptor)!={'status','path','sha256'}: reject('invalid certificate descriptor')
        path = Path(descriptor['path']); h = digest(path)
        if h!=descriptor['sha256'] or h not in self.reviewed: reject('unreviewed/mutated '+kind+' certificate')
        cert = json.loads(path.read_text())
        if cert.get('kind')!=kind or cert.get('binding')!=binding: reject(kind+' certificate does not bind exact caller/ABI')
        if kind=='provider':
            if cert.get('trust')!='STANDARD_PLATFORM_IDENTITY' or cert.get('application_interposition') is not False: reject('nonstandard/interposed provider')
            if not cert.get('symbol_version') or not cert.get('module_path') or not cert.get('module_sha256') or not cert.get('link_receipt'): reject('missing actual provider resolution')
            if digest(cert['module_path'])!=cert['module_sha256']: reject('changed provider module')
        if kind=='caller':
            if cert.get('lifetime')!='VALID_LIVE_ACTOR_THROUGH_ACK': reject('unclosed actor lifetime')
            if not cert.get('producer_bindings') or not cert.get('source_scope') or not cert.get('driver_route'): reject('missing concrete producer/driver/Source lifetime binding')
        if not cert.get('evidence_files'): reject('missing source-bound certificate evidence')
        for p,h in cert['evidence_files'].items():
            if digest(p)!=h: reject('changed certificate evidence '+p)
        return True
    def register(self, node, *, mode, provider, caller):
        if not self.enabled: reject('domain disabled')
        self.capture.verify()
        fn = self.capture.owners.get(id(node)); allowed = FUNCTIONS | (FIXTURE_FUNCTIONS if self.capture.purpose=='fixture' else frozenset())
        if fn not in allowed: reject('unregistered helper/producer domain')
        decl = self.capture.declaration(node); name = decl['name']
        if name not in STANDARD[self.capture.profile]: reject('not this profile standard service')
        header, header_hash = HEADERS[self.capture.profile]
        if digest(header)!=header_hash: reject('changed primary header')
        raw_loc = decl.get('loc', {})
        loc = raw_loc.get('spellingLoc', raw_loc); off = loc.get('offset')
        if off is None or not loc.get('includedFrom') or Path(header).read_bytes()[off:off+len(name)]!=name.encode(): reject('not exact primary header declaration')
        if any(n.get('kind')=='AsmLabelAttr' for n in walk(decl)): reject('asm/aliased declaration')
        equal = name in {'thrd_equal','pthread_equal'}
        params = [n for n in decl.get('inner',[]) if n.get('kind')=='ParmVarDecl']
        if len(params)!=(2 if equal else 0) or len(node['inner'])-1!=len(params): reject('wrong service prototype/arity')
        actor = 'pthread_t' if self.capture.profile=='POSIX' else 'DWORD' if self.capture.profile=='Windows-native' else 'thrd_t'
        expected = ('int ('+actor+', '+actor+')') if equal else (actor+' (void)')
        if self.capture.profile=='MSVC-C11': expected += ' __attribute__((cdecl))'
        if self.capture.profile=='Windows-native': expected += ' __attribute__((stdcall))'
        if decl.get('type',{}).get('qualType')!=expected or any(x.get('type',{}).get('qualType')!=actor for x in params): reject('wrong exact standard signature/calling convention')
        # A source body selected in the genuine TU must never become a P event.
        definition = self.capture.functions.get(name)
        if mode not in {'source','platform'}: reject('unknown occurrence mode')
        if (mode=='source') != bool(definition): reject('source/platform mode contradicts selected actual TU')
        actual_ir = re.search(r'^define [^\n]*@'+re.escape(fn)+r'\([^\n]*\)[^\n]*\{(.*?)^}', self.capture.ir_text, re.M|re.S)
        if not actual_ir: reject('actual caller LLVM body unavailable; cannot infer inline/platform mode')
        actual_service = bool(re.search(r'\b(?:call|invoke)\b[^\n]*@'+re.escape(name)+r'\(',actual_ir[0]))
        if actual_service != (mode=='platform'): reject('mode contradicts actual LLVM service occurrence')
        key = node['id']
        if key in self.registrations: reject('duplicate occurrence registration')
        binding = {'profile':self.capture.profile,'unit':self.capture.unit,'purpose':self.capture.purpose,
                   'source_sha256':digest(self.capture.source_path),'ast_sha256':digest(self.capture.ast_path),
                   'inputs_sha256':digest(self.capture.inputs_path),'syntax_receipt_sha256':self.capture.syntax_receipt_hash,'ir_sha256':digest(self.capture.ir_path),'ir_caller_sha256':hashlib.sha256(actual_ir[0].encode()).hexdigest(),'function':fn,'call_id':key,'call_sha256':fingerprint(node),
                   'decl_id':decl['id'],'decl_sha256':fingerprint(decl),'decl_type':decl['type'],
                   'call_type':node['type'],'argument_types':[x['type'] for x in node['inner'][1:]],
                   'header_sha256':header_hash,'mode':mode}
        provider_ok = True if mode=='source' else self._certificate(provider,'provider',binding)
        caller_ok = self._certificate(caller,'caller',binding)
        qualified = provider_ok and caller_ok and self.capture.purpose=='production' and self.capture.syntax_ok
        if mode=='source' and provider and provider.get('status')=='PASS': reject('inline occurrence cannot inherit external provider certificate')
        self.registrations[key] = {'binding':binding,'name':name,'mode':mode,'qualified':qualified,
                                   'provider':copy.deepcopy(provider),'caller':copy.deepcopy(caller)}
        self._registration_stamp = fingerprint(self.registrations)
        return copy.deepcopy(binding)
    def verify(self):
        self.capture.verify()
        if frozenset(inherited.c.NATIVE)!=self._native: reject('inherited primitive membership changed')
        if fingerprint(self.registrations)!=self._registration_stamp: reject('mutated registration')
    def occurrence(self, node, function):
        self.verify(); r = self.registrations.get(node.get('id'))
        if not r or self.capture.owners.get(id(node))!=function or r['binding']['call_sha256']!=fingerprint(node): reject('unregistered/mutated actual call occurrence')
        # Reverify reviewed certificate bytes each time, not only at registration.
        if r['mode']=='platform': self._certificate(r['provider'],'provider',r['binding'])
        self._certificate(r['caller'],'caller',r['binding'])
        return r
    def record(self, node, r, transport=None):
        if self._measurement_state!='RUNNING': reject('service occurrence outside owned running measurement')
        item = {'ordinal':len(self.audit),'binding':copy.deepcopy(r['binding']),'qualified':r['qualified']}
        self.audit.append(item);self._audit_expected.append(copy.deepcopy(item))
        if r['mode']=='platform':
            event = {**item,'symbol':r['name'],'classification':'EXCLUDED_BY_TRUSTED_PLATFORM_BOUNDARY',
                     'interior_metric':'outside C-source metric; no numeric price','provider':copy.deepcopy(r['provider']),
                     'caller':copy.deepcopy(r['caller']),
                     'ABI_transport':copy.deepcopy(transport),
                     'ABI_storage_semantics':'Hidden sret/byval endpoints are declared return/argument storage only, never callback/key/grant permission.'}
            self.p_events.append(event);self._p_expected.append(copy.deepcopy(event))
    def ledger(self, counter):
        if not self.enabled: reject('disabled method cannot label an inherited result C/P')
        self.verify()
        if self._counter_owner is not counter or self._measurement_state!='COMPLETE' or not self._measurement_seal: reject('no complete owned single-use measurement')
        if self._measurement_seal!=self.measurement_state(counter): reject('measurement C/P/audit binding changed')
        if not isinstance(counter,Counter) or counter.thread_domain is not self or not getattr(counter,'_thread_c_seal',None): reject('no complete actual inherited counter run')
        if counter._thread_c_seal!=counter.c_state(): reject('C event mutation/omission')
        if self.p_events!=self._p_expected or self.audit!=self._audit_expected: reject('P/audit omission, mutation or reordering')
        if any(n.get('cells',0)<0 for n in counter.events): reject('negative C event')
        return {'method':METHOD,'theorem':THEOREM,'enabled':True,'measurement_complete':True,'measurement_seal':self._measurement_seal,
                'qualification':'QUALIFIED_BOUNDARY_ONLY' if self.audit and all(x['qualified'] for x in self.audit) else 'UNQUALIFIED',
                'packet_upper_accepted':False,'C_upper':None,'C_source_cells_observed':sum(n['cells'] for n in counter.events),
                'P_occurrences_observed':len(self.p_events),'P_path_maximum':None,'C_events':copy.deepcopy(counter.events),'ABI_audit':copy.deepcopy(counter.abi_audit),'transfer_audit':copy.deepcopy(counter.transfer_audit),'P':copy.deepcopy(self.p_events),'call_audit':copy.deepcopy(self.audit),
                'route_blocked':not self.audit or any(not x['qualified'] for x in self.audit),
                'limits':'This adapter does not prove whole source closure, path maxima, payer ownership or packet fit.'}

class Counter(inherited.Counter):
    """Explicit adapter; no global NATIVE patch and no change when not enabled."""
    def __init__(self,*args,thread_domain=None,**kwargs):
        super().__init__(*args,**kwargs); self.thread_domain=thread_domain
        self._thread_run_depth=0; self._thread_c_seal=None
        if thread_domain and thread_domain.enabled:
            if not self.contextual_operands: reject('explicit inherited contextual operand mode required')
            cap=thread_domain.capture;cap.verify()
            if self.srcs.get(cap.unit,{}).get('data')!=cap.source: reject('counter source bytes differ from registered capture')
            for name,fn in self.fs.items():
                if cap.functions.get(name) is not fn['ast']: reject('counter function not exact same capture object')
                expected=cap.source if fn['unit']==cap.unit else Path(HEADERS[cap.profile][0]).read_bytes()
                if self.srcs.get(fn['unit'],{}).get('data')!=expected: reject('counter header/source unit not actual bytes')
            thread_domain.bind_counter(self)
    def c_state(self):
        return fingerprint([self.events,self.abi_audit,self.transfer_audit])
    def run(self,name):
        domain=self.thread_domain
        top=self._thread_run_depth==0
        owned=bool(domain and domain.enabled)
        if top and owned:
            # Eligibility dies BEFORE lookup/debit/event emission, including a
            # rejected repeated request. No earlier successful interval revives.
            self._thread_c_seal=None
            domain.begin(self)
        self._thread_run_depth+=1
        try:
            result=super().run(name)
            if top:
                self._thread_c_seal=self.c_state()
                if owned: domain.complete(self)
            return result
        except BaseException:
            if top and owned:
                self._thread_c_seal=None;domain.fail(self)
            raise
        finally: self._thread_run_depth-=1
    def expr(self,node):
        domain=self.thread_domain
        if not domain or not domain.enabled or node.get('kind')!='CallExpr': return super().expr(node)
        ref=reference(node);name=ref.get('name')
        if name not in set().union(*STANDARD.values()): return super().expr(node)
        r=domain.occurrence(node,self.stack[-1]['name'])
        if r['mode']=='source':
            if name not in self.fs or self.fs[name]['ast'] is not domain.capture.functions[name]: reject('inline body not expanded from actual TU')
            result=super().expr(node);domain.record(node,r);return result
        xs=node['inner'];aggregate=inherited.c.type_kind(node)!='scalar' or any(inherited.c.type_kind(a)!='scalar' for a in xs[1:])
        if aggregate:
            if not self.aggregate_transfers or not isinstance(self.proof,inherited.CapturedProof): reject('full actual aggregate transport proof required; never scalarize actor')
            self.proof.verify()
            if self.proof.catalog.roots is not domain.capture.roots: reject('foreign aggregate ABI/TU proof')
            self.proof.catalog.member(node)
        self.expr(xs[0])
        for a in xs[1:]:
            self.expr(a)
            if inherited.c.type_kind(a)!='scalar': self.effect(a,inherited.typ(a),'source-semantic argument transfer',a,node)
        self.emit(node,'argument_fronts',len(xs)-1);self.emit(node,'call_front')
        # Parent assignment/return handling and run() ABI inventory remain intact.
        transport=None
        if aggregate:
            transport={'aggregate':True,'function_abi_inventory':copy.deepcopy(self.abi_audit[-1]),
                       'source_argument_transfers':copy.deepcopy([a for a in self.transfer_audit if a.get('destination_node_id')==node.get('id')])}
        domain.record(node,r,transport)
