struct Key {unsigned long long a,b,c,d,e;};
void outer(struct Key*d,struct Key*s){struct Key {int x;};*d=*s;}
