#include <stddef.h>
#include <string.h>
#include "/srv/home/joykim/.tmp/2300-operator-recovery-next/wirelog/evaluation_control.h"
#if defined(WL_HAVE_C11_THREADS)
#include <threads.h>
typedef thrd_t Actor;
#elif defined(_WIN32)
#include <windows.h>
typedef DWORD Actor;
#else
#include <pthread.h>
typedef pthread_t Actor;
#endif
struct Key { unsigned long long a,b,c,d,e; };
struct Pair { void *p; unsigned long long n; };
struct Nested { struct Pair pair; int flag; };
struct Blob { unsigned char bytes[130]; };
struct Vol { volatile int x; };
struct Atom { _Atomic(int) x; };
struct Bits { unsigned x:3; };
struct __attribute__((packed)) Packed { int x; };
#pragma pack(push,1)
struct Pragma { int x; };
#pragma pack(pop)
union U { int x; unsigned y; };
struct UnionField { union U u; };
struct Array { int x[2]; };
typedef int Vec __attribute__((vector_size(16)));
struct Vector { Vec x; };
struct Wide { long double x; };
struct Hidden { struct Vol v; };
struct Forward;
struct Key key_identity(struct Key x) { return x; }
void key_copy(struct Key *d, struct Key *s) { *d=*s; }
void key_init(struct Key *s) { struct Key k=*s; }
void nested_copy(struct Nested *d, struct Nested *s) { *d=*s; }
struct Key key_direct(struct Key x) { return key_identity(x); }
struct Key key_later(struct Key x) { struct Key y=key_identity(x); return y; }
void key_twice(struct Key *d,struct Key *s) { *d=*s; *d=*s; }
Actor actor_identity(Actor a) { return a; }
Actor actor_direct(Actor a) { return actor_identity(a); }
Actor actor_later(Actor a) { Actor b=actor_identity(a); return b; }
Actor actor_current(void) {
#if defined(WL_HAVE_C11_THREADS)
 return thrd_current();
#elif defined(_WIN32)
 return GetCurrentThreadId();
#else
 return pthread_self();
#endif
}
int actor_equal(Actor a) {
#if defined(WL_HAVE_C11_THREADS)
 return thrd_equal(a,actor_current());
#elif defined(_WIN32)
 return a==actor_current();
#else
 return pthread_equal(a,actor_current());
#endif
}
#define BAD(Name,Type) void Name(Type *d,Type *s){*d=*s;}
BAD(negative_volatile,struct Vol)
BAD(negative_atomic,struct Atom)
BAD(negative_bits,struct Bits)
BAD(negative_packed,struct Packed)
BAD(negative_pragma,struct Pragma)
BAD(negative_union,union U)
BAD(negative_unionfield,struct UnionField)
BAD(negative_array,struct Array)
BAD(negative_vector,struct Vector)
BAD(negative_wide,struct Wide)
BAD(negative_nestedqual,struct Hidden)
void negative_unknown(struct Forward *p) { (void)p; }
int negative_representation(Actor *a,Actor *b) { return memcmp(a,b,sizeof(*a)); }
void negative_memcpy(struct Key *d,struct Key *s) { memcpy(d,s,sizeof(*d)); }
void negative_indirect(struct Key(*f)(struct Key),struct Key a) { struct Key b=f(a); }

void report_copy(wl_evaluation_control_report_t *d,wl_evaluation_control_report_t *s) { *d=*s; }
#pragma pack(push,8)
struct Lookalike { void *_Handle; unsigned int _Tid; };
#pragma pack(pop)
BAD(negative_lookalike,struct Lookalike)
int negative_bytes(Actor *a) {return *((unsigned char*)a);}
#if defined(WL_HAVE_C11_THREADS) && defined(_WIN32)
const unsigned long long primary_actor_size=sizeof(Actor);
const unsigned long long primary_actor_align=_Alignof(Actor);
const unsigned long long primary_ptr_size=sizeof(void*);
const unsigned long long primary_ptr_align=_Alignof(void*);
const unsigned long long primary_uint_size=sizeof(uint32_t);
const unsigned long long primary_uint_align=_Alignof(uint32_t);
const unsigned long long primary_handle_offset=offsetof(Actor,_Handle);
const unsigned long long primary_tid_offset=offsetof(Actor,_Tid);
#endif

void actor_restore(Actor *d,Actor *s) { *d=*s; }
void actor_capture(void) { Actor a=actor_current(); }
int actor_equal_twice(Actor a,Actor b) {
#if defined(WL_HAVE_C11_THREADS)
 return thrd_equal(a,b);
#elif defined(_WIN32)
 return a==b;
#else
 return pthread_equal(a,b);
#endif
}
struct __attribute__((aligned(16))) Aligned {int x;};
struct FieldAligned {_Alignas(16) int x;};
BAD(negative_aligned,struct Aligned)
BAD(negative_fieldaligned,struct FieldAligned)
const unsigned long long lookalike_size=sizeof(struct Lookalike);
const unsigned long long lookalike_align=_Alignof(struct Lookalike);

struct Envelope { unsigned int prefix; Actor actor; struct Key key; };
void actor_embedded_restore(struct Envelope *d,struct Envelope *s) { d->actor=s->actor; }
struct PointerEnvelope { struct Envelope *target; };
void actor_loaded_restore(struct PointerEnvelope *d,struct PointerEnvelope *s) { d->target->actor=s->target->actor; }
void negative_dynamic_actor(struct Envelope *d,struct Envelope *s,unsigned i) {d[i].actor=s[i].actor;}

/* Real scalar assignments for each actual ordinary-record leaf. */
void transfer_witness_0(struct Key *d,struct Key *s) {d->a=s->a;d->b=s->b;d->c=s->c;d->d=s->d;d->e=s->e;}
const unsigned long long extent_0=sizeof(struct Key);
void transfer_witness_1(struct Nested *d,struct Nested *s) {d->pair.p=s->pair.p;d->pair.n=s->pair.n;d->flag=s->flag;}
const unsigned long long extent_1=sizeof(struct Nested);
void transfer_witness_2(struct Pair *d,struct Pair *s) {d->p=s->p;d->n=s->n;}
const unsigned long long extent_2=sizeof(struct Pair);
void transfer_witness_3(thrd_t *d,thrd_t *s) {d->_Handle=s->_Handle;d->_Tid=s->_Tid;}
const unsigned long long extent_3=sizeof(thrd_t);
void transfer_witness_4(wl_evaluation_control_report_t *d,wl_evaluation_control_report_t *s) {d->attempt_id=s->attempt_id;d->limit=s->limit;d->consumed=s->consumed;d->stop_reason=s->stop_reason;d->execution_status=s->execution_status;d->cleanup_status=s->cleanup_status;d->result=s->result;}
const unsigned long long extent_4=sizeof(wl_evaluation_control_report_t);
