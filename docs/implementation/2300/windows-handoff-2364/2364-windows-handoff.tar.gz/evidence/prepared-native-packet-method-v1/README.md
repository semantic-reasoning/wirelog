# Prepared Native packet method prototype v1

Evidence implementation awaiting independent method/fixture review. No production
packet counts, funding certificate, guard removal or Windows CI result.

`native_counter.Counter` inherits the pinned approved contextual scalar counter.
`aggregate_transfers=False` and `bounded_zero=False` are the defaults; they leave
both contextual-OFF and contextual-ON inherited behavior unchanged. New modes
require explicitly selecting contextual scalar mode and a verified CapturedProof.

The driver captures actual complete Clang TUs, primary headers, dependency bytes,
macros, expanded preprocessing, layouts and O0 IR on all four profiles. Generated
C scalar/byte witnesses are compiled, never synthesized as JSON AST. Record leaves
and ABI field/load paths retain actual same-TU record/field IDs. All explicit IR
memcopies and implicit byval call transfers are conservatively covered in addition
to semantic source transfers; this overlap is labeled. Direct sret creates no
invented second copy. Unknown transport rejects.

The sole packing exception is actual primary MSVC C11 thrd_t through the separately
approved CRT8 predicate. Its anonymous RecordType identity, exact primary header
bytes, active declaration-time pragma, primitive sizes/alignments, every field
position, size/alignment and unchanged natural layout are preserved in its ledger.
The old scalar operand counter stays conservative on this alignment attribute.

Zero witnesses contain literal unsigned-char assignments for each length0..64.
Only their actual effect events are used; wrapper returns are separate, and the
real caller's arguments/arithmetic/clamp/cursor/call/return remain. There is no
byte/word cost formula or budget input. The implemented ownership bridge supports
closed genuine automatic-local histories, including an independent cancel cursor.
It rejects external targets, unknown cursor histories, escaped targets, aliases,
qualifiers, callbacks and used results. It does not authorize actual Native storage.

The final fixture run is `final-third-fixture-run.log` (1486 checks). Earlier logs
are development history, not current approval. The old partial checksum text is
preserved as a development diagnostic, not a valid candidate seal. Only final
`SHA256SUMS`, produced after log closure, is the asserted dataset seal.

For independent replay, copy the scripts and fixture inputs into a NEW sibling
evidence directory and use the evidence uv environment. Do not rerun capture or
seal in this sealed directory. No inherited setup/seal scripts need execution.

Before actual Native emission: independent review; fresh complete Native TUs;
actual all-writer/external-journal/quiescence proofs; supported source operators;
and complete caller/footer/return/delayed-ACK ownership. Current guards block the
primary Native TU: an independently critiqued ISOLATED structural-guard candidate
must resolve that capture boundary. Never call guard-suppressed/failing ASTs a
complete production parse. Actual current engine guards remain untouched here.
