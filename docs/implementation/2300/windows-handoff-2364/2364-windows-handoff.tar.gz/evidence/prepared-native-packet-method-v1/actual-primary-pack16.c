#include <corecrt.h>
#undef _CRT_PACKING
#define _CRT_PACKING 16

#include <threads.h>
#include <stddef.h>
#include <stdint.h>
typedef thrd_t Actor;
const unsigned long long primary_actor_size=sizeof(Actor);
const unsigned long long primary_actor_align=_Alignof(Actor);
const unsigned long long primary_ptr_size=sizeof(void*);
const unsigned long long primary_ptr_align=_Alignof(void*);
const unsigned long long primary_uint_size=sizeof(uint32_t);
const unsigned long long primary_uint_align=_Alignof(uint32_t);
const unsigned long long primary_handle_offset=offsetof(Actor,_Handle);
const unsigned long long primary_tid_offset=offsetof(Actor,_Tid);
Actor packing_identity(Actor a){return a;}

#undef _CRT_PACKING
#define _CRT_PACKING 8
