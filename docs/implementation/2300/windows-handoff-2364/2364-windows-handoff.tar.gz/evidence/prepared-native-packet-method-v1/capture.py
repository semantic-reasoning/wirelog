"""New dataset only. Real full TU AST/IR/layout; fixture execution, no engine counts."""
import sys,pathlib,json,hashlib,subprocess,shutil,copy,re
sys.dont_write_bytecode=True
E=pathlib.Path(__file__).parent;B=E.parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
pins={}
for folder in ['root-context-operand-method-v1','architect-source-counter-scalar-v1d','architect-source-counter-scalar-v1c','architect-enum-switch-method-v1b','architect-source-counter-v2a']:
    for p in (B/folder).iterdir():
        if p.is_file() and (p.suffix=='.py' or p.name in {'manifest.json','inherited.json','SHA256SUMS'}):pins[str(p)]=sha(p)
# Expand literal inherited pin maps, so docs and transitive module seals are
# checked before and after rather than trusting an unchanged pointer manifest.
for folder in ['root-context-operand-method-v1','architect-source-counter-scalar-v1d','architect-source-counter-scalar-v1c','architect-enum-switch-method-v1b','architect-source-counter-v2a']:
    inherited=B/folder/'inherited.json'
    if inherited.exists():
        for path,digest in json.loads(inherited.read_text()).items():
            if isinstance(digest,str) and len(digest)==64:
                assert sha(path)==digest
                pins[path]=digest
for name in ['prepared-native-packet-method-plan-v1.md','critic-prepared-native-packet-method-plan-v1.md','critic-root-context-operand-method-v1.md','critic-prepared-native-natural-pack8-clarification-v1.md']:
    pins[str(B/name)]=sha(B/name)
pins[str(B/'architect-session-bridge-packet-root-v1/actor-ABI-evidence.json')]=sha(B/'architect-session-bridge-packet-root-v1/actor-ABI-evidence.json')
if (E/'inherited.json').exists():
    existing=json.loads((E/'inherited.json').read_text());assert all(pins.get(p)==h for p,h in existing.items())
    (E/'inherited.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
else:(E/'inherited.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
import native_counter as m
import run_profile as r
import dependency_binding as d
c=m.c
# Identical genuine inherited primitive set in all old/default/new fixture runs.
c.NATIVE={'mtx_lock','mtx_unlock','pthread_mutex_lock','pthread_mutex_unlock','thrd_current','thrd_equal','pthread_self','pthread_equal','GetCurrentThreadId'}
PROFILES=['C11','POSIX','MSVC-C11','Windows-native']
POS=['actor_embedded_restore','actor_loaded_restore','actor_restore','actor_capture','actor_equal_twice','report_copy','key_copy','key_init','nested_copy','key_direct','key_later','key_twice','actor_identity','actor_direct','actor_later','actor_current','actor_equal']
NEG=['negative_aligned','negative_fieldaligned','negative_lookalike','negative_volatile','negative_atomic','negative_bits','negative_packed','negative_pragma','negative_union','negative_unionfield','negative_array','negative_vector','negative_wide','negative_nestedqual','negative_representation','negative_memcpy','negative_indirect']
ZNEG=['negative_target_escape','negative_volatile_count','negative_atomic_count','negative_side_count','negative_count','negative_overrun','negative_nonzero','negative_used','negative_zero_volatile','negative_zero_atomic','negative_alias','negative_external','negative_overcap','negative_callback','negative_underflow','negative_functionpointer','negative_overflow','negative_unknownhistory']
def run(cmd):
    p=subprocess.run(cmd,cwd=c.R,capture_output=True,text=True)
    if p.returncode:raise RuntimeError('command failed '+str(cmd)+'\n'+p.stderr)
    return p
manifest={'scope':'evidence fixtures only; no production counts/guard removal','profiles':{},'inherited_sha256':sha(E/'inherited.json'),'costs':'real compiled scalar witness effects; not a byte or word formula','ABI_upper_overlap':'all actual LLVM memcpy occurrences covered in addition to retained source transfers; no discount for optimization'}

def compile_capture(common,source,prefix):
    before=d.inventory(common,source,c.R)
    cmd=common+['-fsyntax-only','-Xclang','-ast-dump=json',str(source)]
    p=run(cmd);(E/(prefix+'.ast.json')).write_text(p.stdout);(E/(prefix+'.stderr')).write_text(p.stderr)
    ircmd=common+['-S','-emit-llvm','-O0','-fno-discard-value-names',str(source),'-o',str(E/(prefix+'.ll'))];ir=run(ircmd);(E/(prefix+'.ir.stderr')).write_text(ir.stderr)
    layoutcmd=common+['-fsyntax-only','-Xclang','-fdump-record-layouts-complete',str(source)];layout=run(layoutcmd);(E/(prefix+'.layout')).write_text(layout.stdout+layout.stderr)
    preprocessed=run(common+['-E',str(source)]);(E/(prefix+'.preprocessed.c')).write_text(preprocessed.stdout);(E/(prefix+'.preprocessor.stderr')).write_text(preprocessed.stderr)
    macros=run(common+['-dM','-E',str(source)]);(E/(prefix+'.macros')).write_text(macros.stdout)
    deps=run(common+['-M',str(source)]);(E/(prefix+'.dependencies')).write_text(deps.stdout)
    after=d.inventory(common,source,c.R);d.compare(before,after);d.verify_files(before)
    (E/(prefix+'.inputs.json')).write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
    return [json.loads(p.stdout)],{'ast':cmd,'ir':ircmd,'layout':layoutcmd,'preprocess':common+['-E',str(source)],'inputs_sha256':sha(E/(prefix+'.inputs.json'))}

def funcs(roots):
    return {n['name']:{'ast':n,'unit':'fixture'} for n in roots[0].get('inner',[]) if n.get('kind')=='FunctionDecl' and any(x.get('kind')=='CompoundStmt' for x in n.get('inner',[])) and n.get('name')}
def old(fs,roots,source,name):
    obj=m.previous.Counter(m.closure(fs,name),{'fixture':{'data':source.read_bytes()}},'',roots,{},unit_nodes={'fixture':roots},contextual_operands=True)
    try:obj.run(name);status='COUNTED_UPPER'
    except RuntimeError as e:status='UNSUPPORTED: '+str(e)
    return obj,status
checks_total=0
for profile in ([sys.argv[1]] if len(sys.argv)>1 else PROFILES):
    common=r.config(profile,'')
    # Fixture portability: actual Clang MSVC target does not support __int128.
    abase=(E/'aggregate_fixture.c').read_text()
    if profile in ['MSVC-C11','Windows-native']:abase=abase.replace('struct Wide { __int128 x; };','struct Wide { long double x; };')
    discovery=E/(profile+'-discovery.c');discovery.write_text(abase)
    roots,dcmd=compile_capture(common,discovery,profile+'-discovery')
    natural=m.PrimaryNaturalPack8(profile,roots,E/(profile+'-discovery.ast.json'),E/(profile+'-discovery.ll'),E/(profile+'-discovery.layout'),E/(profile+'-discovery.preprocessed.c'),E/(profile+'-discovery.inputs.json')) if profile=='MSVC-C11' else None
    cat=m.Catalog(roots,natural)
    allowed={};rejected_types={}
    for q in list(cat.records):
        if q not in {'struct Key','struct Pair','struct Nested','struct thrd_t','struct wl_evaluation_control_report_t'}:continue
        try:allowed[q]=cat.leaves(q)
        except RuntimeError as error:rejected_types[q]=str(error)
    # Explicit source for actual record transfer witnesses, not synthetic AST.
    extra='\n/* Real scalar assignments for each actual ordinary-record leaf. */\n'
    witness_names={};extent_names={}
    for i,(q,leaves) in enumerate(sorted(allowed.items())):
        name='transfer_witness_'+str(i);witness_names[q]=name
        spelling=cat.spellings.get(q,q)
        extra+=f'void {name}({spelling} *d,{spelling} *s) {{'+''.join('d->'+'.'.join(x['path'])+'=s->'+'.'.join(x['path'])+';' for x in leaves)+'}\n'
        extent_names[q]='extent_'+str(i);extra+=f'const unsigned long long extent_{i}=sizeof({spelling});\n'
    source=E/(profile+'-aggregate.c');source.write_text(abase+extra)
    roots,commands=compile_capture(common,source,profile+'-aggregate')
    natural=m.PrimaryNaturalPack8(profile,roots,E/(profile+'-aggregate.ast.json'),E/(profile+'-aggregate.ll'),E/(profile+'-aggregate.layout'),E/(profile+'-aggregate.preprocessed.c'),E/(profile+'-aggregate.inputs.json')) if profile=='MSVC-C11' else None
    cat=m.Catalog(roots,natural);fs=funcs(roots);c.register_types(roots)
    for name in fs:c.CHOICES[name]=[];c.TERNARY[name]=[]
    ir=(E/(profile+'-aggregate.ll')).read_text();extents={}
    for q,n in extent_names.items():
        match=re.search(r'@'+n+r' = [^\n]*constant i64 (\d+)',ir)
        assert match,(profile,q,n);extents[q]=int(match[1])
    transfers={}
    for q,name in witness_names.items():
        obj,status=old(fs,roots,source,name);assert status=='COUNTED_UPPER',(profile,name,status)
        effects=[x for x in obj.events if x['kind']!='implicit_return_front']
        leaves=cat.leaves(q);by={}
        body=next(x for x in fs[name]['ast']['inner'] if x.get('kind')=='CompoundStmt')
        for assign,leaf in zip(body['inner'],leaves):
            begin=c.pos(assign['range']['begin'])['offset'];end=c.pos(assign['range']['end']);end=end['offset']+end.get('tokLen',1)
            events=[x for x in effects if begin<=x['offset']<end]
            assert events and any(x['kind']=='scalar_store' for x in events),(profile,q,leaf,effects)
            by['.'.join(leaf['path'])]=sum(x['cells'] for x in events)
        transfers[q]={'function':name,'leaves':leaves,'effects':effects,'effects_by_path':by,'sha256':hashlib.sha256(json.dumps(effects,sort_keys=True).encode()).hexdigest(),'wrapper_events':[x for x in obj.events if x['kind']=='implicit_return_front']}
    # All literal fill witnesses are real scalar AST under same compiler/profile.
    zbase=(E/'zero_fixture.c').read_text();zsource=E/(profile+'-zero.c');zsource.write_text(zbase+'\nconst unsigned long long zero_extent=sizeof(struct Blob);\nconst unsigned long long vol_extent=sizeof(struct Vol);\nconst unsigned long long atom_extent=sizeof(struct Atom);\n')
    zroots,zcommands=compile_capture(common,zsource,profile+'-zero');zfs=funcs(zroots);c.register_types(zroots)
    for name in zfs:c.CHOICES[name]=[True,True,False,True,True,False] if name=='chunks' else [];c.TERNARY[name]=[]
    zeros={}
    for n in range(65):
        obj,status=old(zfs,zroots,zsource,'byte_witness_'+str(n));assert status=='COUNTED_UPPER',status
        effects=[x for x in obj.events if x['kind']!='implicit_return_front'];assert len([x for x in effects if x['kind']=='scalar_store'])==n
        assert all(x['kind'] in {'address_front','scalar_store'} for x in effects)
        zeros[n]={'length':n,'effects':sum(x['cells'] for x in effects),'events':effects,'wrapper_events':[x for x in obj.events if x['kind']=='implicit_return_front'],'sha256':hashlib.sha256(json.dumps(effects,sort_keys=True).encode()).hexdigest()}
    zcat=m.Catalog(zroots);zir=(E/(profile+'-zero.ll')).read_text();zextent={}
    for q,label in [('struct Blob','zero_extent'),('struct Vol','vol_extent'),('struct Atom','atom_extent')]:
        zextent[q]=int(re.search(r'@'+label+r' = [^\n]*constant i64 (\d+)',zir)[1])
    binds={str(path):sha(path) for path in [source,E/(profile+'-aggregate.ast.json'),E/(profile+'-aggregate.ll'),E/(profile+'-aggregate.inputs.json'),zsource,E/(profile+'-zero.ast.json'),E/(profile+'-zero.ll'),E/(profile+'-zero.inputs.json')]}
    proof=m.CapturedProof(profile,cat,extents,extent_names,transfers,zeros,m.ABI(ir,cat,extents),binds,fs,source,zroots,zfs,zsource,[json.loads((E/(profile+'-aggregate.inputs.json')).read_text()),json.loads((E/(profile+'-zero.inputs.json')).read_text())])
    zproof=m.CapturedProof(profile,zcat,zextent,{'struct Blob':'zero_extent','struct Vol':'vol_extent','struct Atom':'atom_extent'},{},zeros,m.ABI(zir,zcat,zextent),binds,{},zsource,zroots,zfs,zsource,[json.loads((E/(profile+'-zero.inputs.json')).read_text())])
    def count(name,aggregate=False,zero=False,z=False,actual_roots=None,actual_proof=None):
        f,rr,ss,pp=(zfs,zroots,zsource,zproof) if z else (fs,roots,source,proof)
        obj=m.Counter(m.closure(f,name),{'fixture':{'data':ss.read_bytes()}},'',rr,{},unit_nodes={'fixture':actual_roots or rr},contextual_operands=True,aggregate_transfers=aggregate,bounded_zero=zero,proof=actual_proof or pp)
        try:obj.run(name);status='COUNTED_UPPER'
        except RuntimeError as error:status='UNSUPPORTED: '+str(error)
        return obj,status
    rows={};checks=[]
    for name in POS+NEG:
        base,bst=old(fs,roots,source,name);off,ost=count(name);assert (bst,base.events,base.calls)==(ost,off.events,off.calls),(profile,name,'default drift')
        obj,status=count(name,True)
        if name in POS:assert status=='COUNTED_UPPER',(profile,name,status)
        else:assert status.startswith('UNSUPPORTED'),(profile,name,status)
        rows[name]={'old_status':bst,'new_status':status,'old_events':base.events,'new_events':obj.events,'calls':obj.calls,'transfer_ledger':obj.transfer_audit,'ABI_completeness_ledger':obj.abi_audit}
        checks+=['default-exact:'+name,('positive:' if name in POS else 'negative:')+name]
    for name in ['zero_'+str(n) for n in range(65)]+['chunks']+ZNEG:
        base,bst=old(zfs,zroots,zsource,name);off,ost=count(name,z=True);assert (bst,base.events,base.calls)==(ost,off.events,off.calls),(profile,name,'zero default drift')
        obj,status=count(name,zero=True,z=True)
        if name not in ZNEG:assert status=='COUNTED_UPPER',(profile,name,status)
        else:assert status.startswith('UNSUPPORTED'),(profile,name,status)
        rows[name]={'old_status':bst,'new_status':status,'old_events':base.events,'new_events':obj.events,'calls':obj.calls,'zero_ledger':obj.zero_audit}
        checks+=['default-exact:'+name,('negative:' if name in ZNEG else 'positive:')+name]
    for name in POS+NEG+['zero_'+str(n) for n in range(65)]+['chunks']+ZNEG:
        f,rr,ss=(zfs,zroots,zsource) if name in zfs else (fs,roots,source)
        subject=m.closure(f,name);out=[]
        for cls in [m.previous.Counter,m.Counter]:
            obj=cls(subject,{'fixture':{'data':ss.read_bytes()}},'',rr,{},unit_nodes={'fixture':rr})
            try:obj.run(name);status='COUNTED_UPPER'
            except RuntimeError as error:status='UNSUPPORTED: '+str(error)
            out.append((status,obj.events,obj.calls))
        assert out[0]==out[1],(profile,name,'literal default changed')
        checks+=['literal-default-context-OFF-exact:'+name]
    obj,status=count('negative_bytes',True)
    if profile=='MSVC-C11':assert 'representation observation' in status
    else:
        base,bst=old(fs,roots,source,'negative_bytes');assert (status,obj.events)==(bst,base.events) and not obj.transfer_audit
    checks+=['representation-domain-record-reject-or-scalar-inherited']
    obj,status=count('negative_dynamic_actor',True)
    if profile=='MSVC-C11':assert status.startswith('UNSUPPORTED')
    else:
        base,bst=old(fs,roots,source,'negative_dynamic_actor');assert (status,obj.events)==(bst,base.events) and not obj.transfer_audit
    checks+=['dynamic-record-copy-path-reject-or-scalar-inherited']

    for name in ['key_copy','zero_1']:
        f,rr,ss,pp=(zfs,zroots,zsource,zproof) if name=='zero_1' else (fs,roots,source,proof)
        try:m.Counter(m.closure(f,name),{'fixture':{'data':ss.read_bytes()}},'',rr,{},unit_nodes={'fixture':rr},aggregate_transfers=True,proof=pp);raise AssertionError('implicit context enable')
        except RuntimeError as error:assert 'explicit approved contextual' in str(error)
    checks+=['context-mode-explicit-no-implicit-enable']
    assert [x['count'] for x in rows['chunks']['zero_ledger']]==[64,64,2,64,64,2]
    assert [x['offset'] for x in rows['chunks']['zero_ledger']]==[0,64,128,0,64,128]
    checks+=['real-local-history-first-middle-final-and-independent-cancel0']
    # Independence of options: enabled aggregate must not silently qualify memset;
    # enabled zero must retain actual aggregate signature rejection.
    _,status=count('zero_1',aggregate=True,z=True);assert status.startswith('UNSUPPORTED');checks+=['aggregate-option-does-not-enable-zero']
    _,status=count('key_direct',zero=True);assert status.startswith('UNSUPPORTED');checks+=['zero-option-does-not-enable-aggregate']
    before_native=set(c.NATIVE);c.NATIVE.update({'memcpy','memmove','memset'})
    try:
        _,status=count('negative_memcpy',True);assert 'own approved method' in status
        _,status=count('zero_1',aggregate=True,z=True);assert 'explicitly enabled bounded-zero' in status
        _,status=count('zero_1',zero=True,z=True);assert status=='COUNTED_UPPER'
    finally:c.NATIVE=before_native
    checks+=['explicit-source-byte-operations-cannot-inherit-native-front-coupon']
    # Genuine second compilation (not a reconstructed AST).
    second=run(commands['ast']);(E/(profile+'-other-compile.ast.json')).write_text(second.stdout)
    secondroots=[json.loads(second.stdout)]
    try:count('key_copy',True,actual_roots=secondroots);raise AssertionError('foreign TU accepted')
    except RuntimeError as error:assert 'same TU' in str(error) or 'actual compiler node/TU' in str(error)
    checks+=['genuine-other-compile-reject']
    # A real filtered AST contains the selected function but no record declarations.
    filtercmd=common+['-fsyntax-only','-Xclang','-ast-dump=json','-Xclang','-ast-dump-filter=key_copy',str(source)]
    filtered=run(filtercmd);(E/(profile+'-missing-record.ast.jsons')).write_text(filtered.stdout)
    selected=list(c.objects(filtered.stdout));missing=m.Catalog(selected)
    try:missing.leaves('struct Key');raise AssertionError('missing record accepted')
    except RuntimeError as error:assert 'unknown/incomplete' in str(error)
    checks+=['real-filtered-missing-record-reject']
    # Actual block-scope same-spelling tags cannot be conflated by a type map.
    shadow_source=E/(profile+'-shadow-tag.c')
    shadow_source.write_text('struct Key {unsigned long long a,b,c,d,e;};\nvoid outer(struct Key*d,struct Key*s){struct Key {int x;};*d=*s;}\n')
    shadow_roots,shadow_commands=compile_capture(common,shadow_source,profile+'-shadow-tag')
    shadow_cat=m.Catalog(shadow_roots)
    try:shadow_cat.leaves('struct Key');raise AssertionError('same-name distinct record collapsed')
    except RuntimeError as error:assert 'ambiguous same-TU' in str(error)
    checks+=['genuine-same-spelling-distinct-record-IDs-reject']
    # Exact raw IR and witness bindings are mandatory, no caller supplied copy list.
    bad=copy.copy(proof);bad.bindings=dict(proof.bindings);bad.bindings[str(E/(profile+'-aggregate.ll'))]='0'*64
    try:count('key_copy',True,actual_proof=bad);raise AssertionError('wrong IR digest accepted')
    except RuntimeError as error:assert 'changed actual proof' in str(error)
    checks+=['wrong-IR-bind-reject']
    missingw=copy.copy(proof);missingw.transfers=copy.deepcopy(proof.transfers);missingw.transfers['struct Key']['leaves'].pop()
    try:count('key_copy',True,actual_proof=missingw);raise AssertionError('missing leaf accepted')
    except RuntimeError as error:assert 'changed witness/extent/profile' in str(error)
    checks+=['missing-leaf-transfer-reject']
    # Every actual memcpy included by computed inventory: there is no external
    # declared copy count. Verify exact count independently from raw function IR.
    abis=[]
    for name in POS:
        inventory=proof.abi.inventory(name,fs[name]['ast']);rawbody=proof.abi.functions[name][1]
        assert inventory['all_memcpy_occurrences']==len(re.findall(r'call void @llvm\.memcpy',rawbody)),(profile,name)
        abis.append(inventory)
    if profile=='MSVC-C11':
        assert extents['struct thrd_t']==16
        assert [x['path'] for x in transfers['struct thrd_t']['leaves']]==[['_Handle'],['_Tid']]
        equal=next(x for x in abis if x['function']=='actor_equal');assert equal['all_memcpy_occurrences']>=1
        direct=next(x for x in abis if x['function']=='actor_direct');assert direct['direct_sret_destination'] and direct['sret_additional_copy_cells']==0
        assert rows['actor_identity']['old_status'].startswith('UNSUPPORTED')
        import packing_fixtures
        checks+=packing_fixtures.execute(m,E,common,compile_capture,roots,natural,proof,cat,fs)
        checks+=['actual-primary-thrd16-both-fields','actual-equality-distinct-copy-graph','direct-sret-no-invented-extra-copy','default-primary-actor-unsupported']
    checks+=['all-raw-memcpy-occurrences-independently-exhausted']
    result={'rows':rows,'transfer_witnesses':transfers,'literal_zero_witnesses':zeros,'natural_pack8_ledger':natural.ledger if natural else None,'ABI_independent_exhaustiveness':abis,'checks':checks,'limitations':['fixtures only; no production cursor/quiescence/ABI certificate','all-IR memcpy overlap may overcount source-semantic transfers','unknown IR endpoint/record ABI remains unsupported','unknown library/representation boundary rejects','aggregate record arrays deliberately unsupported']}
    (E/(profile+'.results.json')).write_text(json.dumps(result,indent=2)+'\n')
    (E/(profile+'.tests.log')).write_text('\n'.join('PASS '+x for x in checks)+'\n')
    manifest['profiles'][profile]={'discovery_commands':dcmd,'aggregate_commands':commands,'zero_commands':zcommands,'checks':len(checks),'aggregate_positive':len(POS),'aggregate_negative':len(NEG),'zero_positive':66,'zero_negative':len(ZNEG),'results_sha256':sha(E/(profile+'.results.json')),'exact_bindings':binds,'extents':extents,'zero_extents':zextent,'filtered_command':filtercmd}
    checks_total+=len(checks)
    print(profile,'PASS',len(checks),flush=True)
m.verify_inherited();manifest['checks_passed']=checks_total
(E/('partial-'+sys.argv[1]+'-manifest.json' if len(sys.argv)>1 else 'manifest.json')).write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')

print('PASS',checks_total,'fixture checks; no production counts',flush=True)
