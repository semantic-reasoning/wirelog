import pathlib
E=pathlib.Path(__file__).parent
s='#include <stddef.h>\n#include <string.h>\nstruct Blob { unsigned char bytes[130]; };\nstruct Vol { volatile int x; };\nstruct Atom { _Atomic(int) x; };\n'
for n in range(65):
    s+=f'void byte_witness_{n}(unsigned char *p) {{'+''.join(f'p[{i}]=0;' for i in range(n))+'}\n'
    s+=f'void zero_{n}(void) {{struct Blob target; memset(&target,0,{n});}}\n'
# Straight-line genuine local cursor history, no fabricated phase authority.
s+='void chunks(void) {struct Blob target; unsigned int cursor=0; unsigned int count;\n'
for i in range(3):s+='count=sizeof(target)-cursor; if(count>64) count=64; memset((unsigned char *)&target+cursor,0,count); cursor=cursor+count;\n'
s+='unsigned int cancel=0;\n'
for i in range(3):s+='count=sizeof(target)-cancel; if(count>64) count=64; memset((unsigned char *)&target+cancel,0,count); cancel=cancel+count;\n'
s+='}\n'
s+='''
struct Blob *escaped_target;
void negative_target_escape(void) {struct Blob target; escaped_target=&target; memset(&target,0,1);}
void negative_volatile_count(void) {struct Blob target; volatile unsigned int count=1; memset(&target,0,count);}
void negative_atomic_count(void) {struct Blob target; _Atomic(unsigned int) count=1; memset(&target,0,count);}
void negative_side_count(void) {struct Blob target; unsigned int count=1; memset(&target,0,count++);}
void negative_count(unsigned int count) {struct Blob target; memset(&target,0,count);}
void negative_overrun(void) {struct Blob target; memset((unsigned char*)&target+129,0,2);}
void negative_nonzero(void) {struct Blob target; memset(&target,1,1);}
void *negative_used(void) {struct Blob target; return memset(&target,0,1);}
void negative_zero_volatile(void) {struct Vol target; memset(&target,0,sizeof(target));}
void negative_zero_atomic(void) {struct Atom target; memset(&target,0,sizeof(target));}
void negative_alias(void) {struct Blob target; struct Blob *alias=&target; memset(&target,0,1);}
void negative_external(struct Blob *target) {memset(target,0,1);}
void negative_overcap(void) {struct Blob target; memset(&target,0,65);}
void unknown_callback(void);
void negative_callback(void) {struct Blob target; unknown_callback(); memset(&target,0,1);}
void negative_underflow(void) {struct Blob target; unsigned int cursor=131; unsigned int count=sizeof(target)-cursor; memset((unsigned char*)&target+cursor,0,count);}
void negative_functionpointer(void *(*fill)(void*,int,size_t)) {struct Blob target; fill(&target,0,1);}
void negative_overflow(void) {struct Blob target; unsigned long long cursor=4294967296ULL; memset((unsigned char*)&target+cursor,0,1);}
void negative_unknownhistory(unsigned int start) {struct Blob target; unsigned int cursor=start; memset((unsigned char*)&target+cursor,0,1);}
'''
(E/'zero_fixture.c').write_text(s)
