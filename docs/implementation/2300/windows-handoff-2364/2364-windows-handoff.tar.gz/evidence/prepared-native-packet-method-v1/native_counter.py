"""Evidence-only exact ordinary transfer / bounded zero prototypes; OFF by default.
No production counts. All actual compiler objects remain in their genuine TU.
"""
import sys,pathlib,json,hashlib,re
sys.dont_write_bytecode=True
E=pathlib.Path(__file__).parent;B=E.parent
sys.path.insert(0,str(B/'root-context-operand-method-v1'))
import context_counter as previous
c=previous.c;walk=previous.walk;typ=previous.typ

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def verify_inherited():
    for p,h in json.loads((E/'inherited.json').read_text()).items():
        if sha(p)!=h:raise RuntimeError('native-v1: inherited bytes changed '+p)
verify_inherited()
def reject(s):raise RuntimeError('native-v1: '+s)
def strip(n):
    while n.get('kind') in {'ImplicitCastExpr','ParenExpr'} and len(n.get('inner',[]))==1:
        if n.get('kind')=='ImplicitCastExpr' and n.get('castKind') not in {'LValueToRValue','NoOp','IntegralCast','ArrayToPointerDecay','FunctionToPointerDecay'}:break
        n=n['inner'][0]
    return n
QUAL=re.compile(r'\bvolatile\b|\brestrict\b|_Atomic|address_space|__attribute__')
SCALARS={'_Bool','bool','char','signed char','unsigned char','short','unsigned short','int','unsigned int','long','unsigned long','long long','unsigned long long','__int64','unsigned __int64','float','double'}
class Catalog:
    def __init__(self,roots,natural=None):
        if natural is not None and (not isinstance(natural,PrimaryNaturalPack8) or natural.roots is not roots):reject("foreign natural CRT8 certificate")
        self.natural=natural
        self.roots=roots;self.objects={id(n) for r in roots for n in walk(r)}
        self.nodes={n['id']:n for r in roots for n in walk(r) if n.get('id') and n.get('kind') not in {'DeclRefExpr'}}
        self.records={};self.aliases={};self.enums={};self.spellings={}
        self.ambiguous_records=set();self.ambiguous_aliases=set();self.ambiguous_enums=set()
        for r in roots:
            for n in walk(r):
                if n.get('kind')=='RecordDecl' and n.get('completeDefinition') and n.get('name'):
                    key=n.get('tagUsed','struct')+' '+n['name']
                    if key in self.records and self.records[key] is not n:self.ambiguous_records.add(key)
                    self.records[key]=n
                if n.get('kind')=='TypedefDecl':
                    if n['name'] in self.aliases and self.aliases[n['name']]!=typ(n):self.ambiguous_aliases.add(n['name'])
                    self.aliases[n['name']]=typ(n)
                if n.get('kind')=='EnumDecl' and n.get('name') and any(x.get('kind')=='EnumConstantDecl' for x in n.get('inner',[])):
                    key='enum '+n['name']
                    if key in self.enums and self.enums[key] is not n:self.ambiguous_enums.add(key)
                    self.enums[key]=n
        # Clang names typedef-owned anonymous records in qualType. Bind through
        # the actual RecordType decl ID, never by guessed layout/name.
        for root in roots:
            for td in walk(root):
                if td.get('kind')!='TypedefDecl':continue
                q=typ(td)
                for t in walk(td):
                    if t.get('kind')=='EnumType' and typ(t)==q:
                        enum=self.nodes.get(t.get('decl',{}).get('id'))
                        if enum and enum.get('kind')=='EnumDecl' and any(x.get('kind')=='EnumConstantDecl' for x in enum.get('inner',[])):
                            if q in self.enums and self.enums[q] is not enum:self.ambiguous_enums.add(q)
                            self.enums[q]=enum
                    if t.get('kind')!='RecordType' or typ(t)!=q:continue
                    record=self.nodes.get(t.get('decl',{}).get('id'))
                    if record and record.get('kind')=='RecordDecl' and record.get('completeDefinition'):
                        if q in self.records and self.records[q] is not record:self.ambiguous_records.add(q)
                        self.records[q]=record;self.spellings.setdefault(q,td['name'])
    def canonical(self,q):
        if q.endswith(' *'):return self.canonical(q[:-2].strip())+' *'
        seen=set()
        while q in self.aliases and self.aliases[q]!=q:
            if q in self.ambiguous_aliases:reject('ambiguous same-TU typedef '+q)
            if q in seen:reject('cyclic typedef')
            seen.add(q);q=self.aliases[q]
        return q
    def leaves(self,q,arrays=False,seen=()):
        if QUAL.search(q):reject('qualified ordinary storage '+q)
        q=self.canonical(q)
        if QUAL.search(q):reject('qualified typedef storage '+q)
        if q in self.ambiguous_records or q in self.ambiguous_enums:reject('ambiguous same-TU record/enum '+q)
        if '[' in q:
            if not arrays:reject('array transfer')
            m=re.fullmatch(r'(.*)\[(\d+)\]',q)
            if not m:reject('unknown array extent')
            return self.leaves(m[1].strip(),True,seen)
        if q.endswith('*'):return [{'path':[],'type':q,'field_ids':[],'record_ids':[]}]
        if q in SCALARS:return [{'path':[],'type':q,'field_ids':[],'record_ids':[]}]
        if q.startswith('enum '):
            n=self.enums.get(q)
            if not n:reject('unknown enum definition')
            if n.get('fixedUnderlyingType',{}).get('qualType') and n['fixedUnderlyingType']['qualType'] not in SCALARS-{'float','double'}:reject('unsupported enum underlying type')
            values=[int(x['value']) for x in walk(n) if x.get('kind')=='ConstantExpr' and 'value' in x]
            if any(v<-(1<<63) or v>=(1<<64) for v in values):reject('oversize enum')
            return [{'path':[],'type':q,'field_ids':[],'record_ids':[]}]
        r=self.records.get(q)
        if not r or q.startswith('union ') or not r.get('completeDefinition'):reject('unknown/incomplete/union record '+q)
        if q in seen:reject('recursive embedded record')
        if any(x.get('kind')=='PackedAttr' for x in r.get('inner',[])):reject('packed record')
        if any(x.get('kind')=='MaxFieldAlignmentAttr' for x in r.get('inner',[])) and not (self.natural and self.natural.accepts(r)):reject('packed record without exact primary CRT8 proof')
        if any(x.get('kind','').endswith('Attr') and x.get('kind')!='MaxFieldAlignmentAttr' for x in r.get('inner',[])):reject('unknown/layout record attribute')
        out=[]
        for f in r.get('inner',[]):
            if f.get('kind')!='FieldDecl':continue
            if f.get('isBitfield') or not f.get('name'):reject('bitfield/anonymous field')
            if any(x.get('kind','').endswith('Attr') for x in f.get('inner',[])):reject('unknown/layout field attribute')
            for x in self.leaves(typ(f),arrays,seen+(q,)):
                out.append({'path':[f['name']]+x['path'],'type':x['type'],'field_ids':[f['id']]+x['field_ids'],'record_ids':[r['id']]+x['record_ids']})
        if not out:reject('empty record')
        return out
    def member(self,n):
        if id(n) not in self.objects:reject('foreign actual compiler node/TU')

def parse_ir(text):
    return {m.group(1):(m.group(0).split('{',1)[0],m.group(2)) for m in re.finditer(r'^define[^\n]*@([\w.$]+)\([^\n]*\)[^\n]*\{\n(.*?)^}',text,re.M|re.S)}
class ABI:
    """All LLVM memcopies covered, including semantic copies: explicit upper overlap.
    Exact record provenance at BOTH ends required; unknown graph rejects.
    Source transfers never removed for optimization/coercion. No instruction prices.
    """
    def __init__(self,text,catalog,extents):
        self.text=text;self.functions=parse_ir(text);self.cat=catalog;self.extents=extents
        self.record_ir={m[1]+' '+m[2]:m[3] for m in re.finditer(r'^%(struct|union)\.([-\w.$]+) = type (.*)$',text,re.M)}
    def field_type(self,record,index):
        if record in self.cat.ambiguous_records:reject('ambiguous GEP parent record')
        r=self.cat.records.get(record);raw=self.record_ir.get(record,'')
        if not r or r.get('tagUsed')!='struct' or not raw.startswith('{ ') or not raw.endswith(' }'):reject('unresolved GEP parent record')
        attrs=[x for x in r.get('inner',[]) if x.get('kind','').endswith('Attr')]
        if attrs and not (self.cat.natural and self.cat.natural.accepts(r)):reject('qualified/packed GEP parent')
        fields=[f for f in r.get('inner',[]) if f.get('kind')=='FieldDecl']
        if any(f.get('isBitfield') or not f.get('name') or any(x.get('kind','').endswith('Attr') for x in f.get('inner',[])) for f in fields):reject('bitfield/anonymous/layout GEP parent')
        # LLVM fields must correspond one-for-one to actual ordinary C fields.
        # Nested type syntax is split only at depth0; padding/union coercions reject.
        parts=[];depth=0;start=0;inside=raw[2:-2]
        for i,ch in enumerate(inside):
            if ch in '[{<(':depth+=1
            elif ch in ']}> )'.replace(' ',''):depth-=1
            elif ch==',' and depth==0:parts.append(inside[start:i].strip());start=i+1
        parts.append(inside[start:].strip())
        if len(parts)!=len(fields) or index<0 or index>=len(fields):reject('unresolved IR/source field correspondence')
        f=fields[index];q=self.cat.canonical(typ(f))
        if QUAL.search(q) or '[' in q or q.startswith('union '):reject('qualified/array/union GEP path')
        if q.endswith(' *') and parts[index]!='ptr':reject('mismatching actual pointer-field IR type')
        if q in self.cat.records:
            irtype='%'+q.replace(' ','.',1)
            if parts[index]!=irtype:reject('mismatching actual embedded record IR type')
        return q,{'record_id':r['id'],'field_id':f['id'],'field_name':f['name'],'field_type':q,'IR_field_index':index,'IR_element':parts[index],'complete_actual_fields':len(fields)}
    def inventory(self,name,fn):
        if name not in self.functions:reject('missing actual function IR '+name)
        header,body=self.functions[name];params={p['name']:typ(p) for p in fn.get('inner',[]) if p.get('kind')=='ParmVarDecl'}
        ptrs={};slots={};paths={}
        # Exact compiler names retained with -fno-discard-value-names.
        for p,q in params.items():
            q=self.cat.canonical(q)
            if q.endswith('*'):ptrs['%'+p]=q[:-1].strip()
            elif q in self.cat.records:ptrs['%'+p]=q
        sret=re.search(r'ptr[^,\n]*sret\(%(?:struct|union)\.([-\w.$]+)\)[^,%]* (%[-\w.$]+)',header)
        if sret:ptrs[sret[2]]='struct '+sret[1]
        for line in body.splitlines():
            m=re.search(r'(%[-\w.$]+) = alloca %(struct|union)\.([-\w.$]+)',line)
            if m:ptrs[m[1]]=m[2]+' '+m[3]
            m=re.search(r'store ptr ([^,]+), ptr (%[-\w.$]+)',line)
            if m:slots.setdefault(m[2],set()).add(m[1])
        for _ in range(len(body.splitlines())+1):
            old=dict(ptrs)
            for line in body.splitlines():
                m=re.search(r'(%[-\w.$]+) = load ptr, ptr (%[-\w.$]+)',line)
                if m:
                    choices=slots.get(m[2],set())
                    if len(choices)==1 and next(iter(choices)) in ptrs:
                        src=next(iter(choices));ptrs[m[1]]=ptrs[src];paths[m[1]]=paths.get(src,[])
                    elif m[2] in ptrs and ptrs[m[2]].endswith(' *'):
                        ptrs[m[1]]=ptrs[m[2]][:-2];paths[m[1]]=paths.get(m[2],[])+[{'load_pointer_field':m[2],'pointee_type':ptrs[m[1]]}]
                g=re.search(r'(%[-\w.$]+) = getelementptr(?: inbounds)?(?: nuw)? %(struct|union)\.([-\w.$]+), ptr (%[-\w.$]+), i(?:32|64) 0, i(?:32|64) (\d+)\s*$',line)
                if g:
                    dest,tag,rname,base,idx=g.groups();q=tag+' '+rname
                    if ptrs.get(base)!=q:continue
                    try:field,path=self.field_type(q,int(idx))
                    except RuntimeError:continue
                    ptrs[dest]=field;paths[dest]=paths.get(base,[])+[dict(path,base=base,result=dest)]
            if ptrs==old:break
        copies=[];byval=[]
        for index,line in enumerate(body.splitlines()):
            if '@llvm.memmove' in line or ' asm ' in line:reject('unresolved IR transport')
            if re.search(r'\bcall\b',line):
                for argument,m in enumerate(re.finditer(r'byval\(%(struct|union)\.([-\w.$]+)\)[^,%]* (%[-\w.$]+)',line)):
                    q=m[1]+' '+m[2]
                    if ptrs.get(m[3])!=q:reject('unresolved byval argument source')
                    byval.append({'ir_line_index':index,'ir':line.strip(),'argument_occurrence':argument,'record':q,'source':m[3],'destination':'actual callee byval parameter','leaves':self.cat.leaves(q),'classification':'actual implicit byval call transport; conservative overlap with source argument transfer'})
            if '@llvm.memcpy' not in line:continue
            m=re.search(r'@llvm.memcpy[^\(]*\(ptr[^,%]* (%[-\w.$]+), ptr[^,%]* (%[-\w.$]+), i64 (\d+), i1 (false|true)\)',line)
            if not m:reject('unresolved actual memcpy operands')
            d,s,n,vol=m.groups();dq,sq=ptrs.get(d),ptrs.get(s)
            if not dq or dq!=sq or dq not in self.cat.records or vol!='false':reject('unresolved/mismatching memcpy endpoint types '+str((d,s,dq,sq)))
            if self.extents.get(dq)!=int(n):reject('memcpy extent does not match exact compiler record')
            leaves=self.cat.leaves(dq)
            copies.append({'ir_line_index':index,'ir':line.strip(),'source':s,'destination':d,'record':dq,'extent':int(n),'source_path':paths.get(s,[]),'destination_path':paths.get(d,[]),'leaves':leaves,'classification':'all-IR-copy conservative upper; may overlap a source-semantic transfer'})
        # Every record-typed aggregate load/store must be understood, not skipped.
        if re.search(r'\b(?:load|store) %(?:struct|union)\.',body):reject('unresolved LLVM aggregate load/store transport')
        return {'function':name,'all_memcpy_occurrences':len(copies),'copies':copies,'byval_call_transfers':byval,'direct_sret_destination':sret[2] if sret else None,'sret_additional_copy_cells':0,'coverage':'ALL actual LLVM memcpy occurrences; source operations independently retained; scalar coercion is not a source discount','ir_function_sha256':hashlib.sha256((header+body).encode()).hexdigest()}

class Counter(previous.Counter):
    def __init__(self,*args,aggregate_transfers=False,bounded_zero=False,proof=None,**kwargs):
        super().__init__(*args,**kwargs)
        self.aggregate_transfers=aggregate_transfers;self.bounded_zero=bounded_zero;self.proof=proof
        self.transfer_audit=[];self.abi_audit=[];self.zero_audit=[];self.env=[]
        if not (aggregate_transfers or bounded_zero):return
        if not self.contextual_operands:reject('new modes require explicit approved contextual scalar mode')
        if not isinstance(proof,CapturedProof):reject('missing exact capture/witness proof type')
        proof.verify()
        self.cat=proof.catalog
        for name,fn in self.fs.items():self.cat.member(fn['ast'])
    def effect(self,n,q,reason,source=None,destination=None):
        leaves=self.cat.leaves(q);q=self.cat.canonical(q)
        witness=self.proof.transfers.get(q)
        if not witness:reject('missing real scalar transfer witness '+q)
        if [x['path'] for x in witness['leaves']]!=[x['path'] for x in leaves]:reject('missing leaf transfer witness')
        for leaf in leaves:
            self.emit(n,'ordinary_leaf_transfer_effect',witness['effects_by_path']['.'.join(leaf['path'])],reason)
        self.transfer_audit.append({'function':self.stack[-1]['name'],'node_id':n.get('id'),'type':q,'reason':reason,'source_node_id':source.get('id') if source else None,'destination_node_id':destination.get('id') if destination else None,'leaves':leaves,'witness_sha256':witness['sha256']})
    def val(self,n):
        if QUAL.search(typ(n)):reject('qualified zero length/cursor expression')
        n=strip(n)
        if QUAL.search(typ(n)):reject('qualified zero length/cursor expression')
        k=n.get('kind');xs=n.get('inner',[])
        if k in {'IntegerLiteral','ConstantExpr'} and 'value' in n:return int(n['value'])
        if k=='DeclRefExpr':
            key=n.get('referencedDecl',{}).get('id')
            if key in self.env[-1]:return self.env[-1][key]
        if k=='UnaryExprOrTypeTraitExpr' and n.get('name')=='sizeof':
            q=n.get('argType',{}).get('desugaredQualType',n.get('argType',{}).get('qualType')) or (typ(xs[0]) if xs else '')
            q=self.cat.canonical(q)
            if q in self.proof.extents:return self.proof.extents[q]
        if k=='BinaryOperator' and len(xs)==2:
            a,b=map(self.val,xs);op=n.get('opcode')
            if op=='+':return a+b
            if op=='-':return a-b
            if op=='>':return int(a>b)
            if op=='==':return int(a==b)
        reject('unresolved finite actual expression '+k)
    def zero(self,n):
        xs=n['inner'];decl=strip(xs[0]).get('referencedDecl',{});d=self.cat.nodes.get(decl.get('id'))
        if not d or d.get('name')!='memset' or d.get('mangledName')!='memset' or not any(x.get('kind')=='BuiltinAttr' for x in d.get('inner',[])):reject('not genuine direct builtin standard memset')
        self.proof.primary_decl(d,'memset')
        if len(xs)!=4 or self.val(xs[2])!=0:reject('nonzero/invalid memset')
        count=self.val(xs[3])
        if count<0 or count>64:reject('zero effect outside literal0..64 domain')
        dest=xs[1]
        while dest.get('kind') in {'ImplicitCastExpr','CStyleCastExpr','ParenExpr'} and len(dest.get('inner',[]))==1:dest=dest['inner'][0]
        offset=0
        if dest.get('kind')=='BinaryOperator' and dest.get('opcode')=='+':
            offset=self.val(dest['inner'][1]);dest=dest['inner'][0]
            while dest.get('kind') in {'ImplicitCastExpr','CStyleCastExpr','ParenExpr'}:dest=dest['inner'][0]
        if dest.get('kind')!='UnaryOperator' or dest.get('opcode')!='&':reject('zero destination lacks genuine automatic owned object')
        base=strip(dest['inner'][0]);did=base.get('referencedDecl',{}).get('id');local=self.locals[-1].get(did)
        if not local or local.get('kind')!='VarDecl' or local.get('storageClass') in {'extern','static'}:reject('zero automatic-local custody not established')
        q=self.cat.canonical(typ(local));self.cat.leaves(q,arrays=True)
        extent=self.proof.extents.get(q)
        if extent is None or offset<0 or offset>extent or count>extent-offset or extent>0xffffffff:reject('zero range/representability proof failed')
        # Closed straight-line local fixture contract, not a production cursor certificate.
        root=self.fs[self.stack[-1]['name']]['ast']
        for a in walk(root):
            if a.get('kind') in {'ForStmt','WhileStmt','DoStmt','GotoStmt','IndirectGotoStmt','GCCAsmStmt'}:reject('unresolved zero all-writer control history')
            if a.get('kind')=='VarDecl' and typ(a).endswith('*'):reject('zero local alias journal')
            if a.get('kind')=='CallExpr' and self.name(a['inner'][0])!='memset':reject('zero unknown escape/callback')
            if a.get('kind')=='ReturnStmt' and a.get('inner'):reject('used memset result/return outside fixture custody')
        allowed_target_refs=set()
        for a in walk(root):
            if a.get('kind')=='CallExpr' and self.name(a['inner'][0])=='memset':
                allowed_target_refs.update(id(x) for x in walk(a['inner'][1]))
            if a.get('kind')=='UnaryExprOrTypeTraitExpr' and a.get('name')=='sizeof':
                allowed_target_refs.update(id(x) for x in walk(a))
        if any(a.get('kind')=='DeclRefExpr' and a.get('referencedDecl',{}).get('id')==did and id(a) not in allowed_target_refs for a in walk(root)):reject('zero target address/representation escapes closed custody')
        old_zero=getattr(self,'inside_zero',False);self.inside_zero=True
        try:
            for a in xs[1:]:self.expr(a)
        finally:self.inside_zero=old_zero
        self.emit(n,'argument_fronts',3);self.emit(n,'call_front')
        witness=self.proof.zeros[count]
        self.emit(n,'bounded_zero_literal_effect',witness['effects'], 'actual compiled literal byte-store effects only; caller fronts retained')
        self.zero_audit.append({'function':self.stack[-1]['name'],'node_id':n.get('id'),'target_decl_id':did,'target_type':q,'offset':offset,'count':count,'extent':extent,'ownership':'closed automatic-local lifetime; no pointer aliases/unknown calls/loops; evaluated actual writes','witness':witness,'zero_length_has_no_stores':count==0})
    def aggregate_initialize(self,target,rhs):
        if not self.aggregate_transfers:return super().aggregate_initialize(target,rhs)
        # Every newly enabled record is ordinary; inherited literal pricing retained.
        self.cat.leaves(typ(target))
        if any(x.get('kind')=='InitListExpr' for x in walk(rhs)):return super().aggregate_initialize(target,rhs)
        self.expr(rhs);self.effect(target,typ(target),'source-semantic assignment/initialization',rhs,target)
    def expr(self,n):
        if not (self.aggregate_transfers or self.bounded_zero):return super().expr(n)
        k=n.get('kind');xs=n.get('inner',[])
        if self.aggregate_transfers and k in {'CStyleCastExpr','ImplicitCastExpr'} and xs and not getattr(self,'inside_zero',False):
            src=self.cat.canonical(typ(xs[0]));dst=self.cat.canonical(typ(n))
            if src.endswith(' *') and src[:-2] in self.cat.records and dst in {'char *','unsigned char *','signed char *','void *'}:reject('record representation observation/unknown escape cast')
        if k=='CallExpr' and self.name(xs[0]) in {'memcpy','memmove'}:reject('explicit source byte copy needs its own approved method')
        if k=='CallExpr' and self.name(xs[0])=='memset':
            if not self.bounded_zero:reject('memset needs explicitly enabled bounded-zero method')
            if id(n) not in self.discarded:reject('used memset result')
            return self.zero(n)
        if self.aggregate_transfers:
            if k=='ImplicitCastExpr' and n.get('castKind')=='LValueToRValue' and c.type_kind(n)!='scalar':
                self.cat.leaves(typ(n));return self.expr(xs[0])
            if k=='CallExpr':
                aggregate=c.type_kind(n)!='scalar' or any(c.type_kind(a)!='scalar' for a in xs[1:])
                if aggregate:
                    callee=self.name(xs[0]);self.expr(xs[0])
                    for a in xs[1:]:
                        self.expr(a)
                        if c.type_kind(a)!='scalar':self.effect(a,typ(a),'source-semantic argument transfer',a,n)
                    self.emit(n,'argument_fronts',len(xs)-1);self.emit(n,'call_front')
                    if callee in c.NATIVE:
                        if callee not in {'thrd_current','thrd_equal','pthread_self','pthread_equal','GetCurrentThreadId'}:reject('unqualified aggregate primitive')
                        ref=strip(xs[0]).get('referencedDecl',{});decl=self.cat.nodes.get(ref.get('id'))
                        if not decl or decl.get('kind')!='FunctionDecl' or decl.get('name')!=callee:reject('unknown primary primitive declaration')
                        loc=decl.get('loc',{});file=loc.get('file','')
                        self.proof.primary_decl(decl,callee)
                        self.calls.append({'native_front_only':callee,'no_engine_interior':True,'qualified_actual_decl_id':decl['id']})
                    elif callee in self.fs:self.run(callee)
                    else:reject('unresolved aggregate library boundary '+str(callee))
                    return
        if k=='BinaryOperator' and n.get('opcode')=='=' and self.env:
            result=super().expr(n)
            lhs=strip(xs[0])
            if lhs.get('kind')=='DeclRefExpr':
                try:self.env[-1][lhs['referencedDecl']['id']]=self.val(xs[1])
                except RuntimeError:self.env[-1].pop(lhs['referencedDecl']['id'],None)
            return result
        return super().expr(n)
    def stmt(self,n):
        if not (self.aggregate_transfers or self.bounded_zero):return super().stmt(n)
        if n.get('kind')=='ReturnStmt' and self.aggregate_transfers:
            for x in n.get('inner',[]):
                self.expr(x)
                if c.type_kind(x)!='scalar':self.effect(x,typ(x),'source-semantic return to actual result destination',x,n)
            self.emit(n,'return_front');raise c.Ret()
        result=super().stmt(n)
        if n.get('kind')=='DeclStmt':
            for x in n.get('inner',[]):
                if x.get('kind')=='VarDecl' and len(x.get('inner',[]))==1:
                    try:self.env[-1][x['id']]=self.val(x['inner'][0])
                    except RuntimeError:pass
        return result
    def run(self,name):
        if not (self.aggregate_transfers or self.bounded_zero):return super().run(name)
        fn=self.fs[name];root=fn['ast'];self.cat.member(root)
        if root.get('isInvalid'):reject('invalid compiler function')
        self.locals=getattr(self,'locals',[]);self.locals.append({n['id']:n for n in walk(root) if n.get('kind') in {'ParmVarDecl','VarDecl'}});self.env.append({})
        body=next(x for x in root['inner'] if x.get('kind')=='CompoundStmt')
        self.discarded=getattr(self,'discarded',set())|{id(x) for n in walk(body) if n.get('kind')=='CompoundStmt' for x in n.get('inner',[]) if x.get('kind')=='CallExpr'}
        frame={'name':name,'unit':fn['unit'],'ifs':list(c.CHOICES.get(name,[])),'ternary':list(c.TERNARY.get(name,[])),'ifs_i':0,'ternary_i':0};self.stack.append(frame);start=len(self.events)
        try:
            if self.aggregate_transfers:
                inventory=self.proof.abi.inventory(name,root);self.abi_audit.append(inventory)
                for copy in inventory['copies']+inventory['byval_call_transfers']:self.effect(root,copy['record'],'additional ALL-IR-copy conservative overlap; never subtract source transfer')
            else:
                ret=root['type']['qualType'].split('(',1)[0].strip()
                if c.type_kind({'type':{'qualType':ret}})!='scalar' or any(c.type_kind(p)!='scalar' for p in root.get('inner',[]) if p.get('kind')=='ParmVarDecl'):reject('aggregate mode disabled')
            try:self.stmt(body);self.emit(body,'implicit_return_front')
            except c.Ret:pass
            for key in ['ifs','ternary']:
                if frame[key+'_i']!=len(frame[key]):reject('unused actual path choices')
            self.calls.append({'function':name,'expanded_cells':sum(x['cells'] for x in self.events[start:]),'unit':fn['unit']})
        finally:self.stack.pop();self.locals.pop();self.env.pop()

def closure(fs,name):
    selected={};todo=[name]
    while todo:
        name=todo.pop()
        if name in selected or name not in fs:continue
        selected[name]=fs[name]
        for node in walk(fs[name]['ast']):
            if node.get('kind')=='CallExpr':
                q=strip(node['inner'][0]);callee=q.get('referencedDecl',{}).get('name')
                if callee in fs:todo.append(callee)
    return selected

def fingerprint(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
class CapturedProof:
    """Fixture-only proof constructor. Independently recomputes witness events.
    Plain supplied numeric prices or a caller-provided copy census cannot qualify.
    """
    def __init__(self,profile,catalog,extents,extent_names,transfers,zeros,abi,bindings,transfer_fs,transfer_source,zero_roots,zero_fs,zero_source,input_records):
        if profile not in {'C11','POSIX','MSVC-C11','Windows-native'}:reject('unknown exact profile')
        self.profile=profile;self.catalog=catalog;self.extents=extents;self.extent_names=extent_names;self.transfers=transfers;self.zeros=zeros;self.abi=abi;self.bindings=bindings;self.inputs=input_records
        self._stamp=None;self._rootstamp=fingerprint(catalog.roots)
        self._catalogstamp=fingerprint({'aliases':catalog.aliases,'spellings':catalog.spellings,'ambiguous':[sorted(catalog.ambiguous_records),sorted(catalog.ambiguous_aliases),sorted(catalog.ambiguous_enums)],'records':{k:(id(v),v.get('id')) for k,v in catalog.records.items()},'enums':{k:(id(v),v.get('id')) for k,v in catalog.enums.items()}})
        if abi.cat is not catalog or abi.extents is not extents:reject('foreign ABI catalog/extent binding')
        if not any(pathlib.Path(p).read_text()==abi.text for p in bindings if p.endswith('.ll')):reject('unbound actual ABI IR text')
        self._abistamp=fingerprint(abi.functions)
        # All extents are actual emitted sizeof globals in this exact IR.
        if len(catalog.roots)!=1 or catalog.roots[0].get('kind')!='TranslationUnitDecl' or not any(json.loads(pathlib.Path(p).read_text())==catalog.roots[0] for p in bindings if p.endswith('.ast.json')):reject('catalog is not a captured real full TU')
        if len(zero_roots)!=1 or not any(json.loads(pathlib.Path(p).read_text())==zero_roots[0] for p in bindings if p.endswith('.ast.json')):reject('zero witness lacks captured full TU')
        ir_text='\n'.join(pathlib.Path(p).read_text() for p in bindings if p.endswith('.ll'))
        for q,v in extents.items():
            label=extent_names.get(q)
            if not label:reject('missing actual sizeof global')
            found=re.search(r'@'+re.escape(label)+r' = [^\n]*constant i64 (\d+)',ir_text)
            if not found or int(found[1])!=v:reject('changed actual extent proof')
        for record in input_records:
            if not any(json.loads(pathlib.Path(p).read_text())==record for p in bindings if p.endswith('.inputs.json')):reject('foreign input record')
            for p,info in record['dependencies'].items():
                if sha(p)!=info['sha256']:reject('changed primary dependency '+p)
            for p,h in record['explicit_input_files'].items():
                if sha(p)!=h:reject('changed explicit input '+p)
            if sha(record['compiler_path'])!=record['compiler_sha256']:reject('changed compiler')
            approved=json.loads((B/'root-context-operand-method-v1/manifest.json').read_text())['compiler']['sha256']
            if record['compiler_sha256']!=approved:reject('unknown compiler binding')
            expected='x86_64-pc-windows-msvc' if profile in {'MSVC-C11','Windows-native'} else 'x86_64-pc-linux-gnu'
            if record['target_option']!=expected:reject('changed/unknown target profile')
            has_c11='WL_HAVE_C11_THREADS' in record['macros_text']
            if has_c11!=(profile in {'C11','MSVC-C11'}):reject('changed actor selection macros')
        def counted(fs,roots,source,name):
            obj=previous.Counter(closure(fs,name),{'fixture':{'data':pathlib.Path(source).read_bytes()}},'',roots,{},unit_nodes={'fixture':roots},contextual_operands=True)
            obj.run(name)
            return obj.events
        for q,w in transfers.items():
            root=transfer_fs.get(w['function'],{}).get('ast')
            if root is None:reject('missing real transfer witness function')
            catalog.member(root)
            params=[p for p in root['inner'] if p.get('kind')=='ParmVarDecl']
            if len(params)!=2 or any(catalog.canonical(typ(p))!=q+' *' for p in params):reject('changed transfer witness prototype')
            leaves=catalog.leaves(q)
            if w['leaves']!=leaves:reject('missing leaf transfer witness')
            body=next(x for x in root['inner'] if x.get('kind')=='CompoundStmt');assigns=body.get('inner',[])
            if len(assigns)!=len(leaves):reject('nonexhaustive/extra actual transfer witness')
            by={}
            for assign,leaf in zip(assigns,leaves):
                if assign.get('kind')!='BinaryOperator' or assign.get('opcode')!='=':reject('non-assignment witness effect')
                for index,operand in enumerate(assign['inner']):
                    operand=strip(operand);ids=[]
                    while operand.get('kind')=='MemberExpr':
                        ids.insert(0,operand.get('referencedMemberDecl'));operand=strip(operand['inner'][0])
                    if ids!=leaf['field_ids'] or operand.get('kind')!='DeclRefExpr' or operand.get('referencedDecl',{}).get('id')!=params[index]['id']:reject('wrong actual field/source/destination transfer witness')
            events=counted(transfer_fs,catalog.roots,transfer_source,w['function'])
            effects=[e for e in events if e['kind']!='implicit_return_front']
            if effects!=w['effects'] or any(e['kind'] not in {'scalar_store','address_front','indirect_scalar_read'} for e in effects):reject('changed actual scalar witness effects')
            for assign,leaf in zip(assigns,leaves):
                begin=c.pos(assign['range']['begin'])['offset'];end=c.pos(assign['range']['end']);end=end['offset']+end.get('tokLen',1)
                by['.'.join(leaf['path'])]=sum(e['cells'] for e in effects if begin<=e['offset']<end)
                if by['.'.join(leaf['path'])]<=0:reject('missing actual leaf scalar effect')
            if by!=w['effects_by_path']:reject('invented transfer effect price')
        if set(zeros)!=set(range(65)):reject('incomplete literal length domain')
        for length,w in zeros.items():
            root=zero_fs['byte_witness_'+str(length)]['ast'];params=[p for p in root['inner'] if p.get('kind')=='ParmVarDecl'];body=next(x for x in root['inner'] if x.get('kind')=='CompoundStmt')
            if len(params)!=1 or typ(params[0])!='unsigned char *':reject('changed byte witness prototype')
            assigns=body.get('inner',[])
            if len(assigns)!=length:reject('wrong real byte witness length')
            for i,a in enumerate(assigns):
                if a.get('kind')!='BinaryOperator' or a.get('opcode')!='=':reject('nonliteral byte witness effect')
                lhs,rhs=a['inner'];lhs=strip(lhs);rhs=strip(rhs)
                if lhs.get('kind')!='ArraySubscriptExpr' or rhs.get('kind')!='IntegerLiteral' or int(rhs['value'])!=0:reject('nonzero/nonarray byte witness')
                base,idx=map(strip,lhs['inner'])
                if base.get('kind')!='DeclRefExpr' or base.get('referencedDecl',{}).get('id')!=params[0]['id'] or idx.get('kind')!='IntegerLiteral' or int(idx['value'])!=i:reject('wrong byte destination sequence')
            events=counted(zero_fs,zero_roots,zero_source,'byte_witness_'+str(length));effects=[e for e in events if e['kind']!='implicit_return_front']
            if w.get('length')!=length or effects!=w['events'] or sum(e['cells'] for e in effects)!=w['effects']:reject('invented literal-zero effect price')
        self._stamp=fingerprint({'extents':extents,'extent_names':extent_names,'transfers':transfers,'zeros':zeros,'profile':profile,'inputs':input_records})
        self.verify()
    def verify(self):
        verify_inherited()
        for p,h in self.bindings.items():
            if sha(p)!=h:reject('changed actual proof/capture '+p)
        if fingerprint(self.catalog.roots)!=self._rootstamp:reject('mutated/foreign actual AST')
        if fingerprint(self.abi.functions)!=self._abistamp or self.abi.functions!=parse_ir(self.abi.text):reject('missing/changed ABI copy graph')
        if self.catalog.natural:self.catalog.natural.verify()
        if fingerprint({'aliases':self.catalog.aliases,'spellings':self.catalog.spellings,'ambiguous':[sorted(self.catalog.ambiguous_records),sorted(self.catalog.ambiguous_aliases),sorted(self.catalog.ambiguous_enums)],'records':{k:(id(v),v.get('id')) for k,v in self.catalog.records.items()},'enums':{k:(id(v),v.get('id')) for k,v in self.catalog.enums.items()}})!=self._catalogstamp:reject('changed same-TU catalog')
        if self._stamp is not None and fingerprint({'extents':self.extents,'extent_names':self.extent_names,'transfers':self.transfers,'zeros':self.zeros,'profile':self.profile,'inputs':self.inputs})!=self._stamp:reject('changed witness/extent/profile proof')

    def primary_decl(self,decl,name):
        if any(x.get('kind')=='AsmLabelAttr' for x in walk(decl)):reject('asm-defined library primitive')
        loc=decl.get('loc',{});off=loc.get('offset');file=loc.get('file')
        allowed={'thrd_current':'threads.h','thrd_equal':'threads.h','pthread_self':'pthread.h','pthread_equal':'pthread.h','GetCurrentThreadId':'processthreadsapi.h','memset':'string.h'}
        suffix=allowed.get(name)
        if not suffix or off is None or not loc.get('includedFrom'):reject('unknown primary primitive header provenance')
        matches=[]
        for record in self.inputs:
            for path,info in record['dependencies'].items():
                if pathlib.Path(path).name.lower() not in ({'string.h','vcruntime_string.h'} if name=='memset' else {suffix}):continue
                data=pathlib.Path(path).read_bytes()
                if data[off:off+len(name)]==name.encode() and sha(path)==info['sha256']:matches.append(path)
        if not matches:reject('primary declaration offset/header mismatch')
        # User replacement/definition cannot inherit a standard primitive boundary.
        for n in self.catalog.nodes.values():
            if n.get('kind')=='FunctionDecl' and n.get('name')==name and any(x.get('kind')=='CompoundStmt' for x in n.get('inner',[])) and not n.get('loc',{}).get('includedFrom'):reject('user-defined library primitive')

class PrimaryNaturalPack8:
    """Exact primary CRT exception approved by separate Critic clarification.
    No field/type name, matching layout, or final macro alone supplies identity.
    """
    THREADS='c5ff7e0ef7b0edb042e24a87a71216cbeceaa99e2d366cebac36d2f970a212d5'
    VCRUNTIME='a2fe9117dc2640e243f91fa94e1d05fc35083218c2a67a446db9e34cece779b5'
    def __init__(self,profile,roots,ast_path,ir_path,layout_path,preprocessed_path,inputs_path):
        if profile!='MSVC-C11':reject('natural CRT8 unknown/wrong profile')
        self.roots=roots;self.paths={str(p):sha(p) for p in [ast_path,ir_path,layout_path,preprocessed_path,inputs_path]}
        if len(roots)!=1 or roots[0]!=json.loads(pathlib.Path(ast_path).read_text()):reject('natural CRT8 foreign AST binding')
        record=json.loads(pathlib.Path(inputs_path).read_text())
        approved=json.loads((B/'root-context-operand-method-v1/manifest.json').read_text())['compiler']['sha256']
        if record['target_option']!='x86_64-pc-windows-msvc' or record['compiler_sha256']!=approved:reject('natural CRT8 compiler/target binding')
        cmd=record['command']
        if not all(x in cmd for x in ['-std=c11','-fms-extensions','-fms-compatibility','-fms-compatibility-version=19.44','-DWL_HAVE_C11_THREADS','-ivfsoverlay']):reject('natural CRT8 configuration binding')
        allowed_f={'-fms-extensions','-fms-compatibility','-fms-compatibility-version=19.44'}
        if any(x.startswith(('-f','-m','-U')) and x not in allowed_f for x in cmd):reject('natural CRT8 unknown configuration flag')
        defines={'-D__STDC_NO_ATOMICS__','-D_CRT_SECURE_NO_WARNINGS','-DWL_HAVE_C11_THREADS','-DWL_SESSION_TEST_HOOKS=1'}
        if any(x.startswith('-D') and x not in defines for x in cmd):reject('natural CRT8 unknown configuration define')
        overlays=[cmd[i+1] for i,x in enumerate(cmd[:-1]) if x=='-ivfsoverlay']
        if overlays!=[str(B/'architect-windows-source/primary-headers-overlay.json')]:reject('natural CRT8 unknown primary overlay')
        macros=record['macros_text']
        if not re.search(r'^#define _CRT_PACKING 8$',macros,re.M) or not re.search(r'^#define _CRT_BEGIN_C_HEADER __pragma\(pack\(push, _CRT_PACKING\)\)$',macros,re.M):reject('natural CRT8 macro binding')
        files=record['dependencies'];headers={}
        for path,info in files.items():
            if pathlib.Path(path).name in {'threads.h','vcruntime.h'}:
                headers[pathlib.Path(path).name]=path
                if sha(path)!=info['sha256']:reject('natural CRT8 changed primary header')
        if not all(name in headers for name in ['threads.h','vcruntime.h']):reject('natural CRT8 missing primary headers')
        if sha(headers['threads.h'])!=self.THREADS or sha(headers['vcruntime.h'])!=self.VCRUNTIME:reject('natural CRT8 changed/lookalike primary header')
        # Walk the ACTUAL -E output's line markers and expanded pragma stack.
        current=None;stack=[];file=None;line=0;active=[];trace=[]
        for out_line,text in enumerate(pathlib.Path(preprocessed_path).read_text().splitlines(),1):
            marker=re.match(r'# (\d+) "([^"]+)"',text)
            if marker:file=marker[2];line=int(marker[1]);continue
            pragma=re.match(r'\s*#pragma pack\(([^)]*)\)',text)
            if pragma:
                args=[x.strip() for x in pragma[1].split(',')]
                if args==['pop']:
                    if not stack:reject('natural CRT8 unknown pragma pop')
                    current=stack.pop()
                elif len(args)==2 and args[0]=='push' and args[1].isdigit():stack.append(current);current=int(args[1])
                elif len(args)==1 and args[0].isdigit():current=int(args[0])
                elif args==['']:current=None
                else:reject('natural CRT8 unknown active pragma')
                trace.append({'output_line':out_line,'file':file,'source_line':line,'pragma':text,'active':current,'depth':len(stack)})
            if file==headers['threads.h'] and line in {84,85,86,87} and text.strip():
                active.append({'source_line':line,'output_line':out_line,'text':text,'active_pack':current,'stack_depth':len(stack)})
            line+=1
        if len(active)!=4 or [x['source_line'] for x in active]!=[84,85,86,87] or any(x['active_pack']!=8 for x in active):reject('natural CRT8 missing/unknown/different active declaration pragma')
        nodes={n['id']:n for root in roots for n in walk(root) if n.get('id') and n.get('kind')=='RecordDecl'}
        td=[n for root in roots for n in walk(root) if n.get('kind')=='TypedefDecl' and n.get('name')=='thrd_t']
        if len(td)!=1:reject('natural CRT8 ambiguous actual typedef')
        rt=[n for n in walk(td[0]) if n.get('kind')=='RecordType'];
        if len(rt)!=1:reject('natural CRT8 unknown typedef RecordType')
        r=nodes.get(rt[0].get('decl',{}).get('id'));attrs=[x for x in r.get('inner',[]) if x.get('kind','').endswith('Attr')] if r else []
        if not r or r.get('name') or not r.get('completeDefinition') or r.get('tagUsed')!='struct' or r.get('loc',{}).get('line')!=84 or r.get('loc',{}).get('col')!=9:reject('natural CRT8 wrong actual anonymous record')
        if len(attrs)!=1 or attrs[0].get('kind')!='MaxFieldAlignmentAttr' or not attrs[0].get('implicit'):reject('natural CRT8 other layout attribute')
        fields=[x for x in r['inner'] if x.get('kind')=='FieldDecl']
        if [(f.get('name'),typ(f)) for f in fields]!=[('_Handle','void *'),('_Tid','unsigned int')] or any(f.get('isBitfield') or f.get('inner') for f in fields):reject('natural CRT8 changed complete field shape')
        ir=pathlib.Path(ir_path).read_text();geometry={}
        for name in ['actor_size','actor_align','ptr_size','ptr_align','uint_size','uint_align','handle_offset','tid_offset']:
            m=re.search(r'@primary_'+name+r' = [^\n]*constant i64 (\d+)',ir)
            if not m:reject('natural CRT8 missing actual primitive/geometry probe '+name)
            geometry[name]=int(m[1])
        if (geometry['ptr_size'],geometry['ptr_align'],geometry['uint_size'],geometry['uint_align'])!=(8,8,4,4):reject('natural CRT8 unknown primitive ABI')
        align=lambda n,a:((n+a-1)//a)*a
        natural_tid=align(geometry['ptr_size'],geometry['uint_align']);natural_align=max(geometry['ptr_align'],geometry['uint_align']);natural_size=align(natural_tid+geometry['uint_size'],natural_align)
        if (geometry['handle_offset'],geometry['tid_offset'],geometry['actor_size'],geometry['actor_align'])!=(0,natural_tid,natural_size,natural_align) or (natural_tid,natural_size,natural_align)!=(8,16,8):reject('natural CRT8 changed natural layout')
        layout=pathlib.Path(layout_path).read_text();block=re.search(r'0 \| struct \(unnamed at '+re.escape(headers['threads.h'])+r':84:9\)\n(.*?)\[sizeof=(\d+), align=(\d+)\]',layout,re.S)
        if not block or not re.search(r'^\s*0 \|\s+void \* _Handle$',block[1],re.M) or not re.search(r'^\s*8 \|\s+uint32_t _Tid$',block[1],re.M) or (int(block[2]),int(block[3]))!=(16,8):reject('natural CRT8 incomplete all-field layout')
        self.record=r;self.ledger={'reason':'exact actual primary CRT8 cap proven not to alter any natural field offset/record size/alignment; attribute retained','record_id':r['id'],'typedef_id':td[0]['id'],'record_type_id':rt[0]['id'],'field_ids':[f['id'] for f in fields],'raw_attributes':attrs,'geometry':geometry,'natural_calculation':{'tid_offset':natural_tid,'size':natural_size,'align':natural_align},'declaration_active_pragma':active,'expanded_pragma_trace':trace,'primary_headers':{p:sha(p) for p in headers.values()},'evidence':self.paths}
        self._stamp=fingerprint(self.ledger)
    def verify(self):
        for p,h in self.paths.items():
            if sha(p)!=h:reject('natural CRT8 changed actual evidence')
        if fingerprint(self.ledger)!=self._stamp:reject('natural CRT8 changed certificate ledger')
    def accepts(self,r):
        self.verify()
        return r is self.record
