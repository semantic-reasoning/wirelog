"""Genuine independent captures for exact CRT8 exception negatives."""
import pathlib,json,re,copy,hashlib

def execute(m,E,common,compile_capture,roots,natural,proof,cat,fs):
    checks=[];rows=[]
    probes='''
#include <threads.h>
#include <stddef.h>
#include <stdint.h>
typedef thrd_t Actor;
const unsigned long long primary_actor_size=sizeof(Actor);
const unsigned long long primary_actor_align=_Alignof(Actor);
const unsigned long long primary_ptr_size=sizeof(void*);
const unsigned long long primary_ptr_align=_Alignof(void*);
const unsigned long long primary_uint_size=sizeof(uint32_t);
const unsigned long long primary_uint_align=_Alignof(uint32_t);
const unsigned long long primary_handle_offset=offsetof(Actor,_Handle);
const unsigned long long primary_tid_offset=offsetof(Actor,_Tid);
Actor packing_identity(Actor a){return a;}
'''
    def certificate(label,rr):
        return m.PrimaryNaturalPack8('MSVC-C11',rr,E/(label+'.ast.json'),E/(label+'.ll'),E/(label+'.layout'),E/(label+'.preprocessed.c'),E/(label+'.inputs.json'))
    for cap in [4,1,16]:
        label='actual-primary-pack'+str(cap);source=E/(label+'.c')
        # Final macro deliberately says8: only ACTUAL declaration-time expansion
        # reveals the differing active pragma. No primary header is modified.
        source.write_text('#include <corecrt.h>\n#undef _CRT_PACKING\n#define _CRT_PACKING '+str(cap)+'\n'+probes+'\n#undef _CRT_PACKING\n#define _CRT_PACKING 8\n')
        rr,cmd=compile_capture(common,source,label)
        try:certificate(label,rr);raise AssertionError('different active pack accepted')
        except RuntimeError as error:assert 'active declaration pragma' in str(error);reason=str(error)
        ir=(E/(label+'.ll')).read_text();geometry={n:int(re.search(r'@primary_'+n+r' = [^\n]*constant i64 (\d+)',ir)[1]) for n in ['actor_size','actor_align','handle_offset','tid_offset']}
        if cap==16:assert geometry=={'actor_size':16,'actor_align':8,'handle_offset':0,'tid_offset':8}
        rows.append({'case':label,'status':'UNSUPPORTED','reason':reason,'actual_geometry':geometry,'commands':cmd,'final_macro8_is_insufficient':True})
        checks+=['actual-active-pack'+str(cap)+'-reject']
    label='actual-primary-unknown-config';source=E/(label+'.c');source.write_text(probes)
    rr,cmd=compile_capture(common+['-fpack-struct=8'],source,label)
    try:certificate(label,rr);raise AssertionError('unknown configuration accepted')
    except RuntimeError as error:assert 'unknown configuration flag' in str(error);reason=str(error)
    rows.append({'case':label,'status':'UNSUPPORTED','reason':reason,'commands':cmd});checks+=['genuine-unknown-config-even-natural-layout-reject']
    # Unknown location provenance comes from a genuine -E -P invocation.
    label='actual-primary-pack-unknown';source=E/(label+'.c');source.write_text(probes)
    rr,cmd=compile_capture(common,source,label)
    import subprocess
    p=subprocess.run(common+['-E','-P',str(source)],cwd=m.c.R,capture_output=True,text=True,check=True)
    (E/(label+'.no-lines.preprocessed.c')).write_text(p.stdout);(E/(label+'.no-lines.stderr')).write_text(p.stderr)
    try:m.PrimaryNaturalPack8('MSVC-C11',rr,E/(label+'.ast.json'),E/(label+'.ll'),E/(label+'.layout'),E/(label+'.no-lines.preprocessed.c'),E/(label+'.inputs.json'));raise AssertionError('unknown active location accepted')
    except RuntimeError as error:assert 'active declaration pragma' in str(error);reason=str(error)
    rows.append({'case':label,'status':'UNSUPPORTED','reason':reason,'commands':cmd,'missing_line_command':common+['-E','-P',str(source)]});checks+=['actual-missing-active-pack-provenance-reject']
    # Genuine header/prototype variants live in NEW private directories only.
    original=next(pathlib.Path(p) for record in proof.inputs for p in record['dependencies'] if pathlib.Path(p).name=='threads.h')
    for variant,old,new in [('changed-layout','uint32_t _Tid;','uint64_t _Tid;'),('changed-prototype','thrd_t __cdecl thrd_current(void);','thrd_t __cdecl thrd_current(int _Extra);')]:
        directory=E/variant;directory.mkdir(exist_ok=True);header=directory/'threads.h'
        text=original.read_text();assert old in text;header.write_text(text.replace(old,new))
        label='actual-primary-'+variant;source=E/(label+'.c');source.write_text(probes)
        rr,cmd=compile_capture(common+['-I'+str(directory)],source,label)
        try:certificate(label,rr);raise AssertionError('changed header qualified')
        except RuntimeError as error:assert 'changed/lookalike primary header' in str(error);reason=str(error)
        rows.append({'case':label,'status':'UNSUPPORTED','reason':reason,'commands':cmd,'changed_header_sha256':hashlib.sha256(header.read_bytes()).hexdigest()});checks+=['genuine-'+variant+'-reject']
    try:m.Catalog(rr,natural);raise AssertionError('foreign certificate TU accepted')
    except RuntimeError as error:assert 'foreign natural CRT8' in str(error)
    checks+=['genuine-other-TU-natural-certificate-reject']
    try:m.PrimaryNaturalPack8('C11',roots,E/'MSVC-C11-aggregate.ast.json',E/'MSVC-C11-aggregate.ll',E/'MSVC-C11-aggregate.layout',E/'MSVC-C11-aggregate.preprocessed.c',E/'MSVC-C11-aggregate.inputs.json');raise AssertionError('wrong profile accepted')
    except RuntimeError as error:assert 'wrong profile' in str(error)
    checks+=['wrong-natural-profile-reject']
    ir=(E/'MSVC-C11-aggregate.ll').read_text()
    assert int(re.search(r'@lookalike_size = [^\n]*constant i64 (\d+)',ir)[1])==16
    assert int(re.search(r'@lookalike_align = [^\n]*constant i64 (\d+)',ir)[1])==8
    try:cat.leaves('struct Lookalike');raise AssertionError('matching16/8 lookalike accepted')
    except RuntimeError as error:assert 'packed record' in str(error)
    checks+=['same16-align8-lookalike-still-reject']
    # Source-only copy lists cannot omit an actual IR temp: tamper with the
    # computed graph while preserving the genuine raw IR and require rejection.
    bad=copy.copy(proof);bad.abi=copy.copy(proof.abi);bad.abi.functions=copy.deepcopy(proof.abi.functions)
    h,b=bad.abi.functions['actor_equal'];assert '@llvm.memcpy' in b
    bad.abi.functions['actor_equal']=(h,'\n'.join(x for x in b.splitlines() if '@llvm.memcpy' not in x))
    try:bad.verify();raise AssertionError('missing actual temporary accepted')
    except RuntimeError as error:assert 'ABI copy graph' in str(error)
    checks+=['missing-genuine-actor-temporary-graph-reject']
    # The exact primitive geometry is preserved, with two distinct equal args.
    inventory=proof.abi.inventory('actor_equal_twice',fs['actor_equal_twice']['ast'])
    assert inventory['all_memcpy_occurrences']==2
    checks+=['two-distinct-real-actor-argument-copies-exhausted']
    for name in ['actor_embedded_restore','actor_loaded_restore']:
        inventory=proof.abi.inventory(name,fs[name]['ast']);assert inventory['all_memcpy_occurrences']==1
        entry=inventory['copies'][0];assert entry['source_path'] and entry['destination_path']
        fields={f.get('id') for n in cat.records.values() for f in n.get('inner',[]) if f.get('kind')=='FieldDecl'}
        assert all(p.get('field_id') in fields for p in entry['source_path']+entry['destination_path'] if 'field_id' in p)
        if name=='actor_loaded_restore':assert any('load_pointer_field' in p for p in entry['source_path'])
        checks+=['genuine-typed-field-and-load-path:'+name]

    (E/'natural-pack8-negative-results.json').write_text(json.dumps({'checks':checks,'rows':rows,'positive_certificate':natural.ledger},indent=2)+'\n')
    return checks
