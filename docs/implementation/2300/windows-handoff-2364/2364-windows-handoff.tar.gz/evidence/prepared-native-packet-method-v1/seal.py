"""Finalize NEW evidence only, after the successful fixture process/log closes."""
import pathlib,json,hashlib,ast
E=pathlib.Path(__file__).parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
log=E/'final-third-fixture-run.log'
assert log.read_text().endswith('PASS 1486 fixture checks; no production counts\n') and 'Traceback' not in log.read_text()
assert not (E/'SHA256SUMS').exists(),'never overwrite a delivered/final seal'
for p in E.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
pins=json.loads((E/'inherited.json').read_text())
for p,h in pins.items():assert sha(p)==h,('inherited changed',p)
manifest=json.loads((E/'manifest.json').read_text());assert manifest['checks_passed']==1486
manifest['module_sha256']=sha(E/'native_counter.py')
manifest['code']={p.name:sha(p) for p in sorted(E.glob('*.py'))}
manifest['final_fixture_log']={'path':log.name,'sha256':sha(log),'checks':1486}
manifest['inherited_verification']={'all_pins_before_after_identical':True,'pinned_files':len(pins),'inherited_sha256':sha(E/'inherited.json')}
manifest['limits']=['evidence implementation awaiting independent review','no production Native count or permission','closed local zero histories only; external Native writer/quiescence bridge pending','all explicit IR memcpy and implicit byval transports deliberately overlap source semantic transfers','unresolved IR/record/profile/qualifier/path fails closed','function pointer leaves, aggregate arrays, unions, extended scalar types remain unsupported','current owner392/work256 guards unchanged; complete primary Native TU capture needs separately critiqued isolated structural candidate','current Native operators such as compound/postincrement are not new supported operators','no Source2370 issuer/carry or real MSVC CI claim']
summary={'checks_passed':1486,'profiles':{},'module_sha256':manifest['module_sha256'],'limits':manifest['limits']}
for profile,meta in manifest['profiles'].items():
    result=json.loads((E/(profile+'.results.json')).read_text());counts={}
    for row in result['rows'].values():
        key='UNSUPPORTED' if row['new_status'].startswith('UNSUPPORTED') else row['new_status'];counts[key]=counts.get(key,0)+1
    summary['profiles'][profile]={'checks_passed':meta['checks'],'aggregate_positive':meta['aggregate_positive'],'aggregate_negative':meta['aggregate_negative'],'zero_positive':meta['zero_positive'],'zero_negative':meta['zero_negative'],'main_rows':len(result['rows']),'new_status_tallies':counts,'negative_statuses':{name:row['new_status'] for name,row in result['rows'].items() if name.startswith('negative_')},'all_checks':result['checks'],'natural_pack8_exception':result['natural_pack8_ledger'] is not None}
(E/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
manifest['summary_sha256']=sha(E/'summary.json')
(E/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
# Preserve the unreviewed earlier checksum bytes, label them honestly.
p=E/'partial-MSVC-C11-SHA256SUMS'
if p.exists():p.rename(E/'development-partial-checksum-before-log-close.txt')
files=sorted(p for p in E.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(E/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(E))+'\n' for p in files))
for line in (E/'SHA256SUMS').read_text().splitlines():
    h,name=line.split('  ',1);assert sha(E/name)==h
print(json.dumps({'module_sha256':sha(E/'native_counter.py'),'manifest_sha256':sha(E/'manifest.json'),'summary_sha256':sha(E/'summary.json'),'seal_sha256':sha(E/'SHA256SUMS'),'files':len(files),'inherited_pins':len(pins),'checks':1486},sort_keys=True))
