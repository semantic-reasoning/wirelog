#include <stddef.h>
#include <string.h>
struct Blob { unsigned char bytes[130]; };
struct Vol { volatile int x; };
struct Atom { _Atomic(int) x; };
void byte_witness_0(unsigned char *p) {}
void zero_0(void) {struct Blob target; memset(&target,0,0);}
void byte_witness_1(unsigned char *p) {p[0]=0;}
void zero_1(void) {struct Blob target; memset(&target,0,1);}
void byte_witness_2(unsigned char *p) {p[0]=0;p[1]=0;}
void zero_2(void) {struct Blob target; memset(&target,0,2);}
void byte_witness_3(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;}
void zero_3(void) {struct Blob target; memset(&target,0,3);}
void byte_witness_4(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;}
void zero_4(void) {struct Blob target; memset(&target,0,4);}
void byte_witness_5(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;}
void zero_5(void) {struct Blob target; memset(&target,0,5);}
void byte_witness_6(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;}
void zero_6(void) {struct Blob target; memset(&target,0,6);}
void byte_witness_7(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;}
void zero_7(void) {struct Blob target; memset(&target,0,7);}
void byte_witness_8(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;}
void zero_8(void) {struct Blob target; memset(&target,0,8);}
void byte_witness_9(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;}
void zero_9(void) {struct Blob target; memset(&target,0,9);}
void byte_witness_10(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;}
void zero_10(void) {struct Blob target; memset(&target,0,10);}
void byte_witness_11(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;}
void zero_11(void) {struct Blob target; memset(&target,0,11);}
void byte_witness_12(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;}
void zero_12(void) {struct Blob target; memset(&target,0,12);}
void byte_witness_13(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;}
void zero_13(void) {struct Blob target; memset(&target,0,13);}
void byte_witness_14(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;}
void zero_14(void) {struct Blob target; memset(&target,0,14);}
void byte_witness_15(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;}
void zero_15(void) {struct Blob target; memset(&target,0,15);}
void byte_witness_16(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;}
void zero_16(void) {struct Blob target; memset(&target,0,16);}
void byte_witness_17(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;}
void zero_17(void) {struct Blob target; memset(&target,0,17);}
void byte_witness_18(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;}
void zero_18(void) {struct Blob target; memset(&target,0,18);}
void byte_witness_19(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;}
void zero_19(void) {struct Blob target; memset(&target,0,19);}
void byte_witness_20(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;}
void zero_20(void) {struct Blob target; memset(&target,0,20);}
void byte_witness_21(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;}
void zero_21(void) {struct Blob target; memset(&target,0,21);}
void byte_witness_22(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;}
void zero_22(void) {struct Blob target; memset(&target,0,22);}
void byte_witness_23(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;}
void zero_23(void) {struct Blob target; memset(&target,0,23);}
void byte_witness_24(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;}
void zero_24(void) {struct Blob target; memset(&target,0,24);}
void byte_witness_25(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;}
void zero_25(void) {struct Blob target; memset(&target,0,25);}
void byte_witness_26(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;}
void zero_26(void) {struct Blob target; memset(&target,0,26);}
void byte_witness_27(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;}
void zero_27(void) {struct Blob target; memset(&target,0,27);}
void byte_witness_28(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;}
void zero_28(void) {struct Blob target; memset(&target,0,28);}
void byte_witness_29(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;}
void zero_29(void) {struct Blob target; memset(&target,0,29);}
void byte_witness_30(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;}
void zero_30(void) {struct Blob target; memset(&target,0,30);}
void byte_witness_31(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;}
void zero_31(void) {struct Blob target; memset(&target,0,31);}
void byte_witness_32(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;}
void zero_32(void) {struct Blob target; memset(&target,0,32);}
void byte_witness_33(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;}
void zero_33(void) {struct Blob target; memset(&target,0,33);}
void byte_witness_34(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;}
void zero_34(void) {struct Blob target; memset(&target,0,34);}
void byte_witness_35(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;}
void zero_35(void) {struct Blob target; memset(&target,0,35);}
void byte_witness_36(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;}
void zero_36(void) {struct Blob target; memset(&target,0,36);}
void byte_witness_37(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;}
void zero_37(void) {struct Blob target; memset(&target,0,37);}
void byte_witness_38(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;}
void zero_38(void) {struct Blob target; memset(&target,0,38);}
void byte_witness_39(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;}
void zero_39(void) {struct Blob target; memset(&target,0,39);}
void byte_witness_40(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;}
void zero_40(void) {struct Blob target; memset(&target,0,40);}
void byte_witness_41(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;}
void zero_41(void) {struct Blob target; memset(&target,0,41);}
void byte_witness_42(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;}
void zero_42(void) {struct Blob target; memset(&target,0,42);}
void byte_witness_43(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;}
void zero_43(void) {struct Blob target; memset(&target,0,43);}
void byte_witness_44(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;}
void zero_44(void) {struct Blob target; memset(&target,0,44);}
void byte_witness_45(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;}
void zero_45(void) {struct Blob target; memset(&target,0,45);}
void byte_witness_46(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;}
void zero_46(void) {struct Blob target; memset(&target,0,46);}
void byte_witness_47(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;}
void zero_47(void) {struct Blob target; memset(&target,0,47);}
void byte_witness_48(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;}
void zero_48(void) {struct Blob target; memset(&target,0,48);}
void byte_witness_49(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;}
void zero_49(void) {struct Blob target; memset(&target,0,49);}
void byte_witness_50(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;}
void zero_50(void) {struct Blob target; memset(&target,0,50);}
void byte_witness_51(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;}
void zero_51(void) {struct Blob target; memset(&target,0,51);}
void byte_witness_52(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;}
void zero_52(void) {struct Blob target; memset(&target,0,52);}
void byte_witness_53(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;}
void zero_53(void) {struct Blob target; memset(&target,0,53);}
void byte_witness_54(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;}
void zero_54(void) {struct Blob target; memset(&target,0,54);}
void byte_witness_55(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;}
void zero_55(void) {struct Blob target; memset(&target,0,55);}
void byte_witness_56(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;}
void zero_56(void) {struct Blob target; memset(&target,0,56);}
void byte_witness_57(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;p[56]=0;}
void zero_57(void) {struct Blob target; memset(&target,0,57);}
void byte_witness_58(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;p[56]=0;p[57]=0;}
void zero_58(void) {struct Blob target; memset(&target,0,58);}
void byte_witness_59(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;p[56]=0;p[57]=0;p[58]=0;}
void zero_59(void) {struct Blob target; memset(&target,0,59);}
void byte_witness_60(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;p[56]=0;p[57]=0;p[58]=0;p[59]=0;}
void zero_60(void) {struct Blob target; memset(&target,0,60);}
void byte_witness_61(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;p[56]=0;p[57]=0;p[58]=0;p[59]=0;p[60]=0;}
void zero_61(void) {struct Blob target; memset(&target,0,61);}
void byte_witness_62(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;p[56]=0;p[57]=0;p[58]=0;p[59]=0;p[60]=0;p[61]=0;}
void zero_62(void) {struct Blob target; memset(&target,0,62);}
void byte_witness_63(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;p[56]=0;p[57]=0;p[58]=0;p[59]=0;p[60]=0;p[61]=0;p[62]=0;}
void zero_63(void) {struct Blob target; memset(&target,0,63);}
void byte_witness_64(unsigned char *p) {p[0]=0;p[1]=0;p[2]=0;p[3]=0;p[4]=0;p[5]=0;p[6]=0;p[7]=0;p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]=0;p[13]=0;p[14]=0;p[15]=0;p[16]=0;p[17]=0;p[18]=0;p[19]=0;p[20]=0;p[21]=0;p[22]=0;p[23]=0;p[24]=0;p[25]=0;p[26]=0;p[27]=0;p[28]=0;p[29]=0;p[30]=0;p[31]=0;p[32]=0;p[33]=0;p[34]=0;p[35]=0;p[36]=0;p[37]=0;p[38]=0;p[39]=0;p[40]=0;p[41]=0;p[42]=0;p[43]=0;p[44]=0;p[45]=0;p[46]=0;p[47]=0;p[48]=0;p[49]=0;p[50]=0;p[51]=0;p[52]=0;p[53]=0;p[54]=0;p[55]=0;p[56]=0;p[57]=0;p[58]=0;p[59]=0;p[60]=0;p[61]=0;p[62]=0;p[63]=0;}
void zero_64(void) {struct Blob target; memset(&target,0,64);}
void chunks(void) {struct Blob target; unsigned int cursor=0; unsigned int count;
count=sizeof(target)-cursor; if(count>64) count=64; memset((unsigned char *)&target+cursor,0,count); cursor=cursor+count;
count=sizeof(target)-cursor; if(count>64) count=64; memset((unsigned char *)&target+cursor,0,count); cursor=cursor+count;
count=sizeof(target)-cursor; if(count>64) count=64; memset((unsigned char *)&target+cursor,0,count); cursor=cursor+count;
unsigned int cancel=0;
count=sizeof(target)-cancel; if(count>64) count=64; memset((unsigned char *)&target+cancel,0,count); cancel=cancel+count;
count=sizeof(target)-cancel; if(count>64) count=64; memset((unsigned char *)&target+cancel,0,count); cancel=cancel+count;
count=sizeof(target)-cancel; if(count>64) count=64; memset((unsigned char *)&target+cancel,0,count); cancel=cancel+count;
}

struct Blob *escaped_target;
void negative_target_escape(void) {struct Blob target; escaped_target=&target; memset(&target,0,1);}
void negative_volatile_count(void) {struct Blob target; volatile unsigned int count=1; memset(&target,0,count);}
void negative_atomic_count(void) {struct Blob target; _Atomic(unsigned int) count=1; memset(&target,0,count);}
void negative_side_count(void) {struct Blob target; unsigned int count=1; memset(&target,0,count++);}
void negative_count(unsigned int count) {struct Blob target; memset(&target,0,count);}
void negative_overrun(void) {struct Blob target; memset((unsigned char*)&target+129,0,2);}
void negative_nonzero(void) {struct Blob target; memset(&target,1,1);}
void *negative_used(void) {struct Blob target; return memset(&target,0,1);}
void negative_zero_volatile(void) {struct Vol target; memset(&target,0,sizeof(target));}
void negative_zero_atomic(void) {struct Atom target; memset(&target,0,sizeof(target));}
void negative_alias(void) {struct Blob target; struct Blob *alias=&target; memset(&target,0,1);}
void negative_external(struct Blob *target) {memset(target,0,1);}
void negative_overcap(void) {struct Blob target; memset(&target,0,65);}
void unknown_callback(void);
void negative_callback(void) {struct Blob target; unknown_callback(); memset(&target,0,1);}
void negative_underflow(void) {struct Blob target; unsigned int cursor=131; unsigned int count=sizeof(target)-cursor; memset((unsigned char*)&target+cursor,0,count);}
void negative_functionpointer(void *(*fill)(void*,int,size_t)) {struct Blob target; fill(&target,0,1);}
void negative_overflow(void) {struct Blob target; unsigned long long cursor=4294967296ULL; memset((unsigned char*)&target+cursor,0,1);}
void negative_unknownhistory(unsigned int start) {struct Blob target; unsigned int cursor=start; memset((unsigned char*)&target+cursor,0,1);}
