# Complete-path method stop and bounded next evidence plan

Status: **BLOCKED, not a packet fit or complete bound**. This pass changes no engine source, metric, counter domain, caller permission, tariff, cap or Original behavior. No runtime, Root port, commit or push was performed.

## Exact candidate and held prior gates

Base d17849d468109081a6f417f8237d01873080211f; candidate4a449288b781e7951b6ddc70db20e707d475388e; Native9caf60fd71f4e525872dae505a7d646f53a6540818166b6f174743260e395d64; unchanged Core777940e64f038d11cf8a012df31c07c7190ba63869faf45846578e19d2b26a36. Root reports receipt of independent raw review e933fc03, all16 Native/CoreSource/CoreControl/profile-correct Thread captures, all-profile28returns/0goto-label declaration bindings, and required LLVM22rc0. Those held gates do not establish complete payer or primitive effects.

The Root C11 linear witnesses109/128/140/78 remain traces, not maxima. In particular their normal footer chooses both claim tests false. A real lexical ACK sets a_claimed and p_claimed true before those exits. The actual conditional stores must be counted on that resource path; do not reuse78 as a complete lexical-body upper or silently add a guessed correction.

## Actual closure attempt and first precise blocker

The first whole auto_maintain traversal using the unchanged actual evaluator stopped in auto_bind at wl_columnar_eval_serial_framed_owner_valid(ctx,f), actual Native call0x5621a530d430, source6886, because its definition was outside the initial Native/Core/Thread captures. Captured the complete actual C11 eval_serial.c and eval_plan.c TUs with AST/IR/layout/preprocessor/transitive input bindings; both report SUCCESS_COMPLETE_NOHOOK_PRODUCTION_TU. These are real source units, not synthesized helper bodies.

Rebound the actual definitions and their unchanged source bytes into the same evaluator. The next whole-path attempt stops at **wl_columnar_eval_serial_framed_thread -> thrd_current()**, actual Serial call0x56409b8aee10, source51. Chain: auto_maintain -> auto_bind -> framed_owner_valid -> framed_thread -> thrd_current. The current method raises `unqualified/unresolved call thrd_current thrd_current()` before auto_bind finishes. See whole-path-method-stop-v2.json SHA256 f5ff12d7424d00ee69bfeb8cbc6952dc5e34afb5501ec59524ee6cab9e4bc83f;319 known cells before the stop are not a bound. Its actual positive-store event indexes94 and213 are the incoming auto_fund128 and nested auto_bind192 stores; no later B/P1/P3 payment may finance this earlier unknown effect.

The existing counter's primitive set contains only mtx_lock, mtx_unlock, pthread_mutex_lock and pthread_mutex_unlock. No thread-identity getter/equality primitive was added. The fresh actual Native profile ASTs contain declarations, but no bodies, for:

- C11: thrd_current `thrd_t(void)` and thrd_equal `int(thrd_t,thrd_t)`.
- POSIX: pthread_self `pthread_t(void)` and pthread_equal `int(pthread_t,pthread_t)`.
- MSVC-C11: actual cdecl thrd_current/thrd_equal declarations.
- Windows-native: actual stdcall GetCurrentThreadId `DWORD(void)` declaration.

Scalar-looking prototypes and full-TU compile success do not qualify provider effects, actual thread identity, actor lifetime or per-profile ABI. Do not assign a one-cell price, treat declaration-only functions as ordinary source, suppress the call, borrow lock-primitive qualification, or assume a cached actor check is equivalent.

## Fresh exit inventory and remaining obligations

actual-owned-23-exit-inventory-v1.json SHA2565e00569b512181ab34abb4dc46c8fdbfdd40ba6cdf661b2bfc1aeb2ca84893df records22 copied exits and one retained normal footer from the exact fresh C11 AST. Each entry includes actual return/release node IDs and enclosing condition branches. All keep p-owned release then a-owned release and returnrc. The inventory deliberately infers no payer from source offset.

Complete incoming/A/autoBind/B/C/P1-P4/D/proof/body/refusal/Core/return bounds remain unknown at the first provider stop. The approved P3 fixed-tail partition applies only after actual same-activation positive P3 and its rc gate; it supplies no credit at this earlier auto_bind stop or failedP3. Every copied tail needs its own actual executed claim combination and earlier payer. Source effects, support references, real ACK, actual caller fields, Source31-or-later handoff, ABORT1920/NC3072/unary4096 and other real capacities, failed charge alternatives and real Windows CI remain outstanding.

## Next bounded evidence-only plan, requiring independent critique

1. Preserve this frozen candidate and all counter bytes. Inspect the existing method's precise primitive/provider contract and bind each actual declaration to its real profile provider, target ABI, header/SDK inputs and available provider source/object. Capture only the two actor-validation helper closures and those thread-identity provider edges initially; no generic all-library expansion or runtime matrix.
2. Determine whether an already accepted method can consume that exact provider's effects without changing the metric/domain. If a real source definition is available, capture and bind it as a real TU and charge its actual branches, transport and return. A provider object/disassembly may identify the dependency, but is not automatically an AST counter certificate. If no accepted method covers it, return the precise missing primitive certificate; do not change a whitelist or manufacture a fixed price. Any genuinely new method/domain needs a separate explicit proposal and independent approval, outside this source-only experiment.
3. Only after that prerequisite is actually resolved, rerun the complete incoming-to-return traversal with real call closure. Establish true lexical claims and real provider/actor/ref lifetime, and derive every branch and failed-payment event owner from actual chronological positive stores. Rebind fresh P3-tail occurrences only on positiveP3 paths; preP3/failedP3 use genuine earlier owners. Include all22 exits plus normal ACK, body denial, NC/ABORT and generic/nonlexical branches. Unknown ABI/aggregate/ref/callback effects still stop, never zero.
4. Produce complete per-profile interval maxima and disjoint event ownership before any runtime or Root port. If an actual supported interval exceeds its existing admission, propose one concrete source repair preserving predicates/errors/ownership, get independent Architect/Critic approval, and freeze a new candidate. No cap raise, branch omission, cached actor substitution, unchecked helper or role switch is authorized by this plan.

This is a plan for identifying the actual missing proof, not permission to implement a counter extension or skip it. It does not close2367/2368 or declare the source-only exit repair ready for production.
