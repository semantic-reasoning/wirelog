# Qualified const-record scalar operands v1

**DEFAULT OFF; evidence method awaiting DIFFERENT independent RAW/method review. No production Source/Native count or fit, actor ABI, provider, execution or Root approval.**

Architect plan060409539f7a920fd5dfd498bcb533d0ecd2fb73a403331a26907de67b50a246 and different Critic55a2a45fdb32e2d212b65431b14a49c7314f7e39956442b26383d4f938c9c911 authorize this bounded implementation experiment. This author supplies no independent judgment of it.

## Method and scope

The new `const_counter.py` augments only the pinned contextual catalog (`90879bc2...`), through the pinned Native scalar counter (`fb20ab5b...`). Inherited files, globals, parser ASTs, type dictionaries, native membership and other opt-ins remain unchanged. `verify_inherited()` verifies those physical sources and invokes their existing transitive pin checks. The default constructor flag `const_record_scalars=False` preserves the parent catalog exactly.

Opt-in requires `contextual_operands=True`. A non-Boolean domain flag rejects. The mixin first calls the **unchanged parent catalog**, then considers only actual MemberExpr candidates for which the pinned parent reported `unknown/aggregate/vector/oversize scalar leaf`. At that exact parent version this means its complete ordinary path, real consumer and enclosing exclusion checks passed before the narrow leaf test failed. An already eligible parent field, missing consumer, blocked/qualified/path/layout candidate or unknown field cannot gain this new rule.

New eligibility requires an immediate actual enclosing ImplicitCastExpr with `castKind=LValueToRValue`, the actual same member object, and a genuine scalar consumer in the same function. The immediate conversion condition is deliberately narrower than arbitrary parentheses/casts. Its absence prevents **both address and read** ownership, including `&s->pointer`, escaped/address-only, unevaluated and discarded operands. No AST/type is rewritten to manufacture this association.

Every field/record object must be the complete actual same-TU identity from the parent field map and full TU. The member's actual base must be a const record view. Field, member and LValueToRValue result retain their complete original type dictionaries, aliases and actual IDs. New cases are only:

1. Ordinary pointer field type `T *`, actual const-record member type `T *const`, actual LValueToRValue result `T *`. Pointer pointee spelling/qualification is identical. A top-level pointer typedef qualifier is deliberately excluded if any of the three nodes carries a top-level typeAliasDeclId; this conservatively avoids unexplained typedef qualification. A field already declared top-level const does not enter the added-const relation.
2. Ordinary enum field `enum E`, actual member `const enum E`, actual value result `enum E`. The exact unique actual EnumDecl, supported underlying representation/value range and exact same alias ID across field/member/conversion must bind. An alias must be an actual TypedefDecl of that same EnumType, with the same canonical type; unknown/foreign/ambiguous/layout-attributed/oversized enum or unexplained typedef qualification refuses. No enum switch selection/domain is added.

Type tokenization is comparison only: it validates these exact relations and rejects unsupported punctuation/spelling. Original compiler types/qualifiers/aliases remain in the evidence and source. It does not strip qualifiers or normalize an AST into a new type. In particular volatile/restrict/_Atomic/address-space, packed/union/bitfield, global/static/computed/cast/index/call/side-effect bases, pointer-valued-member dereference/multiple arrows, absent/incomplete records and every inherited enclosing exclusion retain their parent accounting or refusal.

Only the original occurrence's address_front and indirect_scalar_read ownership can be added. Every actual truth, operator, comparison, logical connector, call/argument, declaration/store, cast/control/dispatch and return remains unchanged; repeated evaluations remain repeated. The new `const_scalar_audit` records actual member/field/record/value-conversion/consumer/type/alias/enum and path associations, with explicit exclusion reasons for considered new candidates. The inherited operand audit continues to record all other original exclusions. New absorbed records carry `const_domain`, actual conversion ID and their exact proof. No constant65 subtraction, cache, new scalar/ABI/provider primitive or source fee follows.

## Composition API

`Counter` is the new mixin composed with the pinned Native Counter. `counter_for(base_class)` supports later composition with a **separately reviewed** Native/identity-adapter subclass. It requires a Native Counter subclass whose catalog is still the exact pinned contextual method. It neither approves an arbitrary new base nor accepts its provider registry/results. The mixin touches `_catalog` only, leaving the base's expression/statement, transfer/ABI and C/P dispatch paths intact. Composition with the eventual thread adapter still needs that exact reviewed module/API/source binding and independent review; no adapter was changed or production P ledger emitted here.

## Genuine validation

`capture_test.py` compiled the actual `const_fixture.c` separately for C11/POSIX Linux and MSVC-C11/Windows-native target-Clang profiles, preserving complete actual TUs, macro/dependency captures and before/after transitive dependency bindings. This is compiler evidence for these ordinary scalar fixtures, not an engine build, native Windows cl/link/runtime or current Meson-profile applicability result.

The final fixture run passed272 groups (68/profile). They cover16 positive functions,32 negatives and caller isolation; parent versus default-OFF exact events/calls/operand/truth/rejection equality; unchanged all non-address/read fronts and truth ledgers; exact added-event delta, repeated occurrences, actual enum IntegralCast, separate genuine TU-object rejection; and13 labeled decoder-only negative mutations. Address-only/escaped/unevaluated, all named qualifier/path/layout and declared/unexplained-const cases remain excluded. Decoder mutations test rejection of missing/changed conversion/field/record/alias/enum identity/type/underlying/layout/value-range/consumer/base evidence. They are not genuine compiler evidence or production proofs.

`capture_legacy_and_actor.py` additionally compiled the exact unchanged approved legacy scalar fixture and compared all63 functions per profile:252 parent/default-OFF/new-ON outcomes including complete events, calls, ownership and truth ledgers are exactly equal; no new const-domain event appears there. This exercises the inherited contexts/refusals instead of testing only the newly supported examples.

The same script freshly compiled a separate actual primary Microsoft `<threads.h>` actor TU with genuine CRT/SDK overlay, complete dependency binding and actual `sizeof(thrd_t)==16`, alignment8 assertions and layout. Both OFF/ON still reject the full aggregate actor parameter/return without a separate approved aggregate/ABI proof. No headerless actor surrogate, Tid-only transport or failed AST was used. This fixture does not make the conditional engine MSVC-C11 profile selected/supported, and does not remove any engine size guard.

`check_api.py` passed four constructor/composition checks: non-Boolean opt-in and missing contextual opt-in reject, a changed parent catalog rejects before execution, and default OFF creates no const-domain audit or Native membership change.

The first development fixture log (260 groups, ten decoder negatives) and first legacy log are preserved outside the sealed unit. The final272 run adds three missing/ambiguous/out-of-range enum decoder negatives; it changes no module or ordinary fixture source. No failed development result was turned into a pass or an upper. All Python ran in the existing uv evidence virtualenv. No engine/probe binary was executed and no production Source value was calculated using this unreviewed mode.

## Delivery and stopping gates

`candidate.diff` contains every new code/fixture/contract input from an empty artifact baseline; generated compiler datasets are separately sealed by `SHA256SUMS`. `delivery.json` identifies the exact code path set/digests, raw hash, validation manifests, inherited pins and seal. The author froze these bytes for a DIFFERENT raw/method Reviewer. Replaying should use a NEW evidence sibling; do not regenerate this delivered dataset/seal.

After independent acceptance, the coordinator may bind real Root twelve224/144 bodies plus genuine caller/ABI/C/P/payer conditions under one declared metric. Fixture totals and this implementation do not qualify them. Unsupported/new operations stay named blockers. Existing Source32 phase experiments remain isolated; no stage count, Source protocol, fee/cap, installed API, Original/report behavior or scope expansion into siblings follows from this unit.
