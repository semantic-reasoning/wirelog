from pathlib import Path
import sys,json,hashlib,subprocess,shutil
sys.dont_write_bytecode=True
E=Path(__file__).parent;B=E.parent
import const_counter as m
c=m.inherited.c
import dependency_binding as dependency
import run_profile as profiles
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=B/'root-context-operand-method-v1/context_fixture.c'
source=E/'legacy_fixture.c'
if source.exists():assert source.read_bytes()==old.read_bytes()
else:source.write_bytes(old.read_bytes())
compiler=Path(shutil.which('clang')).resolve();manifest={'original_fixture_sha256':sha(old),'legacy':{},'primary_actor':None,'production_counts':False};total=0
for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
 windows=profile in ('MSVC-C11','Windows-native')
 common=[str(compiler),'--target='+('x86_64-pc-windows-msvc' if windows else 'x86_64-pc-linux-gnu'),'-std=c11','-O2']
 if windows:common+=['-fms-extensions','-fms-compatibility-version=19.44']
 before=dependency.inventory(common,source,c.R)
 cmd=common+['-fsyntax-only','-Xclang','-ast-dump=json',str(source)]
 p=subprocess.run(cmd,capture_output=True,text=True,cwd=c.R)
 (E/(profile+'.legacy.ast.json')).write_text(p.stdout);(E/(profile+'.legacy.stderr')).write_text(p.stderr)
 assert p.returncode==0,p.stderr
 root=json.loads(p.stdout);nodes=[root];c.register_types(nodes)
 fs={n['name']:{'ast':n,'unit':'legacy'} for n in root['inner'] if n.get('kind')=='FunctionDecl' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[]))}
 for f in fs:c.CHOICES[f]=[True] if f in ['comparison','bare_truth','local_truth','pointer_truth','call_truth','not_truth','logical'] else [];c.TERNARY[f]=[True] if f=='ternary' else []
 annotations={'fixture_one':{'enum':'Kind_t','input':'K0','selector':'state'}}
 rows={}
 for name in fs:
  outcomes=[]
  for flag in (None,False,True):
   cls=m.inherited.Counter if flag is None else m.Counter
   obj=cls(fs,{'legacy':{'data':source.read_bytes()}},'',nodes,annotations,unit_nodes={'legacy':nodes},contextual_operands=True,**({} if flag is None else {'const_record_scalars':flag}))
   try:obj.run(name);status='COMPLETE_SOURCE_COVER'
   except RuntimeError as ex:status='UNSUPPORTED: '+str(ex)
   outcomes.append((status,obj.events,obj.calls,obj.operand_audit,obj.truth_audit))
   if flag is True:assert not [x for x in obj.operand_audit if x.get('classification')=='absorbed' and x.get('const_domain')]
  assert outcomes[0]==outcomes[1]==outcomes[2],('legacy changed',profile,name)
  rows[name]={'status':outcomes[0][0],'events':outcomes[0][1],'calls':outcomes[0][2],'parent_off_on_exact_equal':True}
 after=dependency.inventory(common,source,c.R);dependency.compare(before,after);dependency.verify_files(before)
 (E/(profile+'.legacy.inputs.json')).write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
 (E/(profile+'.legacy.results.json')).write_text(json.dumps(rows,indent=2)+'\n')
 manifest['legacy'][profile]={'command':cmd,'functions_compared':len(rows),'source_sha256':sha(source),'ast_sha256':sha(E/(profile+'.legacy.ast.json')),'inputs_sha256':sha(E/(profile+'.legacy.inputs.json')),'results_sha256':sha(E/(profile+'.legacy.results.json'))}
 total+=len(rows);print('PASS',profile,'legacy',len(rows),flush=True)
actor=E/'primary_actor.c'
actor.write_text('/* Genuine primary declaration; no actor surrogate. */\n#include <threads.h>\n_Static_assert(sizeof(thrd_t)==16, "actual primary actor size");\n_Static_assert(_Alignof(thrd_t)==8, "actual primary actor alignment");\nthrd_t actor_transport(thrd_t actor) { return actor; }\n')
common=profiles.config('MSVC-C11','')+['-O2']
before=dependency.inventory(common,actor,c.R)
cmd=common+['-fsyntax-only','-Xclang','-ast-dump=json',str(actor)]
p=subprocess.run(cmd,cwd=c.R,capture_output=True,text=True)
(E/'primary-actor.ast.json').write_text(p.stdout);(E/'primary-actor.stderr').write_text(p.stderr)
assert p.returncode==0,p.stderr
nodes=[json.loads(p.stdout)];c.register_types(nodes)
fs={n['name']:{'ast':n,'unit':'actor'} for n in nodes[0]['inner'] if n.get('kind')=='FunctionDecl' and n.get('name')=='actor_transport'}
c.CHOICES['actor_transport']=[];c.TERNARY['actor_transport']=[]
results=[]
for flag in (False,True):
 obj=m.Counter(fs,{'actor':{'data':actor.read_bytes()}},'',nodes,{},unit_nodes={'actor':nodes},contextual_operands=True,const_record_scalars=flag)
 try:obj.run('actor_transport');raise AssertionError('aggregate actor admitted')
 except RuntimeError as error:
  assert 'aggregate' in str(error)
  results.append({'enabled':flag,'status':'UNSUPPORTED','reason':str(error),'events':obj.events,'const_domain':obj.const_scalar_audit})
assert results[0]['reason']==results[1]['reason'] and results[0]['events']==results[1]['events']
layout=common+['-fsyntax-only','-Xclang','-fdump-record-layouts-complete',str(actor)]
p=subprocess.run(layout,cwd=c.R,capture_output=True,text=True,check=True)
(E/'primary-actor.layout').write_text(p.stdout+p.stderr)
after=dependency.inventory(common,actor,c.R);dependency.compare(before,after);dependency.verify_files(before)
(E/'primary-actor.inputs.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
(E/'primary-actor.results.json').write_text(json.dumps(results,indent=2)+'\n')
manifest['primary_actor']={'command':cmd,'layout_command':layout,'source_sha256':sha(actor),'inputs_sha256':sha(E/'primary-actor.inputs.json'),'results_sha256':sha(E/'primary-actor.results.json'),'actual_size_align':'full primary thrd_t16/alignment8 assertions pass; method still rejects aggregate ABI without separate proof'}
manifest['legacy_functions_compared']=total;manifest['primary_actor_negative_checks']=2
m.verify_inherited()
(E/'legacy-actor-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS legacy',total,'function/profile comparisons and2 actual primary actor negatives')
