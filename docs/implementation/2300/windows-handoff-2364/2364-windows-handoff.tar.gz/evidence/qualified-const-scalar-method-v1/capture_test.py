from pathlib import Path
import sys,json,hashlib,subprocess,shutil,copy
sys.dont_write_bytecode=True
E=Path(__file__).parent; B=E.parent
import const_counter as m
c=m.inherited.c
import dependency_binding as dependency
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def walk(n):
 yield n
 for q in n.get('inner',[]):yield from walk(q)
POS=['pointer_return','pointer_init','pointer_truth','pointer_compare','pointer_argument','pointer_repeated','enum_return','enum_truth','enum_compare','enum_argument','enum_repeated','direct_enum','embedded_pointer','embedded_enum','pointee_const','local_const_record']
NEG=['address_argument','address_return','standalone','standalone_address','discarded_comma','discarded_void','unevaluated','two_arrow','cast_base','indexed_base','computed_base','call_base','side_base','global_base','static_base','volatile_field','volatile_record','hidden_volatile','volatile_target','atomic_field','restrict_base','packed_field','pragma_field','union_field','union_path','bitfield','declared_const','declared_const_enum','hidden_pointer_qualifier','hidden_enum_qualifier','pointer_alias','direct_switch']
compiler=Path(shutil.which('clang')).resolve(); source=E/'const_fixture.c'; data=source.read_bytes()
manifest={'metric':'DEFAULT-OFF qualified const-record scalar operands; fixture-only','production_counts':False,'source_sha256':sha(source),'module_sha256':sha(E/'const_counter.py'),'compiler':{'path':str(compiler),'sha256':sha(compiler)},'profiles':{}}
total=0
for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
 windows=profile in ('MSVC-C11','Windows-native')
 common=[str(compiler),'--target='+('x86_64-pc-windows-msvc' if windows else 'x86_64-pc-linux-gnu'),'-std=c11','-O2']
 if windows:common+=['-fms-extensions','-fms-compatibility-version=19.44']
 if profile in ('C11','MSVC-C11'):common+=['-DWL_HAVE_C11_THREADS=1']
 before=dependency.inventory(common,source,c.R)
 cmd=common+['-fsyntax-only','-Xclang','-ast-dump=json',str(source)]
 p=subprocess.run(cmd,capture_output=True,text=True,cwd=c.R)
 (E/(profile+'.ast.json')).write_text(p.stdout);(E/(profile+'.stderr')).write_text(p.stderr)
 assert p.returncode==0,p.stderr
 root=json.loads(p.stdout); nodes=[root];c.register_types(nodes)
 fs={n['name']:{'ast':n,'unit':'fixture'} for n in root['inner'] if n.get('kind')=='FunctionDecl' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[]))}
 for f in fs:c.CHOICES[f]=[True] if f in ('pointer_truth','enum_truth') else [];c.TERNARY[f]=[]
 src={'fixture':{'data':data,'path':str(source)}}
 def build(flag=False,othernodes=None,otherfs=None,parent=False):
  cls=m.inherited.Counter if parent else m.Counter
  kw={} if parent else {'const_record_scalars':flag}
  return cls(otherfs or fs,src,'',othernodes or nodes,{},unit_nodes={'fixture':othernodes or nodes},contextual_operands=True,**kw)
 def run(name,flag=False,parent=False,othernodes=None,otherfs=None):
  obj=build(flag,othernodes,otherfs,parent)
  try:obj.run(name); status='COMPLETE_SOURCE_COVER'
  except RuntimeError as error:status='UNSUPPORTED: '+str(error)
  return obj,status
 results={};checks=[]
 for name in POS+NEG+['caller_scope']:
  old,os=run(name,parent=True); off,ofs=run(name); new,ns=run(name,True)
  assert (os,old.events,old.calls,old.operand_audit,old.truth_audit)==(ofs,off.events,off.calls,off.operand_audit,off.truth_audit),('default changed',profile,name)
  added=[e for e in new.operand_audit if e.get('classification')=='absorbed' and e.get('const_domain')]
  if name in POS:assert ns=='COMPLETE_SOURCE_COVER' and added,(profile,name,ns,new.const_scalar_audit)
  if name in NEG:assert not added,(profile,name,added)
  if os=='COMPLETE_SOURCE_COVER' and ns=='COMPLETE_SOURCE_COVER':
   fronts=lambda o:[e for e in o.events if e['kind'] not in {'address_front','indirect_scalar_read'}]
   assert fronts(old)==fronts(new),('nonoperand front changed',profile,name)
   assert old.truth_audit==new.truth_audit,('truth changed',profile,name)
   assert sum(e['cells'] for e in new.events)==sum(e['cells'] for e in old.events)-sum(e['old_cells'] for e in added),(profile,name,'delta mismatch')
  results[name]={'parent_status':os,'off_status':ofs,'new_status':ns,'parent_events':old.events,'new_events':new.events,'parent_calls':old.calls,'new_calls':new.calls,'const_domain':new.const_scalar_audit,'new_absorptions':added,'parent_cells':sum(e['cells'] for e in old.events),'new_cells':sum(e['cells'] for e in new.events),'truth':new.truth_audit}
  checks.append('default-equivalence/domain/fronts:'+name)
 assert len(results['pointer_truth']['truth'])==1 and len(results['enum_truth']['truth'])==1
 assert len([e for e in results['pointer_repeated']['new_absorptions'] if e['absorbed_kind']=='indirect_scalar_read'])==2
 assert len([e for e in results['enum_repeated']['new_absorptions'] if e['absorbed_kind']=='indirect_scalar_read'])==2
 assert not [e for e in results['caller_scope']['new_absorptions'] if e['function']=='callee_standalone']
 # Standard enum promotions remain actual source conversion fronts/expressions;
 # the AST conversion is recorded and never removed/replaced by the catalog.
 ef=fs['enum_return']['ast']
 assert any(n.get('kind')=='ImplicitCastExpr' and n.get('castKind')=='IntegralCast' for n in walk(ef))
 checks+=['bare-truth-identical','repeated-pointer-occurrences','repeated-enum-occurrences','callee-isolation','real-enum-IntegralCast-retained']
 # A second real compile creates a distinct TU object graph; old functions may
 # not borrow its declarations even when text/header/types match.
 again=subprocess.run(cmd,capture_output=True,text=True,cwd=c.R,check=True)
 (E/(profile+'.other.ast.json')).write_text(again.stdout)
 try:build(True,[json.loads(again.stdout)]);raise AssertionError('foreign TU accepted')
 except RuntimeError as e:assert 'actual same TU' in str(e)
 checks.append('separate-genuine-TU-rejected')
 # Decoder-only negatives alter copies of genuine fixture captures. They are
 # not compiler evidence and never qualify any production AST or C upper.
 mutations={
  'missing_conversion':('pointer_return','cast'),
  'conversion_type_mismatch':('pointer_return','conversion_type'),
  'missing_field':('pointer_return','field_id'),
  'incomplete_record':('pointer_return','record'),
  'wrong_enum_alias':('enum_return','alias'),
  'wrong_enum_underlying':('enum_return','underlying'),
  'enum_layout_attribute':('enum_return','enum_attr'),
  'declared_top_const_field':('pointer_return','field_type'),
  'missing_const_object':('pointer_return','base_type'),
  'missing_consumer':('pointer_return','consumer'),
  'missing_enum_decl':('enum_return','enum_missing'),
  'ambiguous_enum_decl':('enum_return','enum_duplicate'),
  'enum_value_outside_range':('enum_return','enum_range'),
 }
 mutation_results={}
 for label,(name,kind) in mutations.items():
  nr=copy.deepcopy(root); nf={n['name']:{'ast':n,'unit':'fixture'} for n in nr['inner'] if n.get('kind')=='FunctionDecl' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[]))}
  fn=nf[name]['ast']; member=next(n for n in walk(fn) if n.get('kind')=='MemberExpr'); conversion=next(n for n in walk(fn) if n.get('kind')=='ImplicitCastExpr' and n.get('castKind')=='LValueToRValue' and n.get('inner',[None])[0] is member)
  field=next(n for n in walk(nr) if n.get('kind')=='FieldDecl' and n.get('id')==member['referencedMemberDecl'])
  if kind=='cast':conversion['castKind']='NoOp'
  elif kind=='conversion_type':conversion['type']={'qualType':'unsigned long long'}
  elif kind=='field_id':member['referencedMemberDecl']='not-a-real-field'
  elif kind=='record':next(n for n in walk(nr) if n.get('kind')=='RecordDecl' and field in n.get('inner',[]))['completeDefinition']=False
  elif kind=='alias':conversion['type']['typeAliasDeclId']='wrong-alias'
  elif kind=='underlying':next(n for n in walk(nr) if n.get('kind')=='EnumDecl' and n.get('name')=='Phase')['fixedUnderlyingType']={'qualType':'unsigned __int128'}
  elif kind=='enum_attr':next(n for n in walk(nr) if n.get('kind')=='EnumDecl' and n.get('name')=='Phase')['inner'].append({'kind':'PackedAttr','id':'decoder-only-attribute'})
  elif kind=='field_type':field['type']={'qualType':'void *const'}
  elif kind=='base_type':member['inner'][0]['type']={'qualType':'struct View *'}
  elif kind=='consumer':next(n for n in walk(fn) if n.get('kind')=='ReturnStmt').pop('id')
  elif kind=='enum_missing':nr['inner']=[n for n in nr['inner'] if not(n.get('kind')=='EnumDecl' and n.get('name')=='Phase')]
  elif kind=='enum_duplicate':
   twin=copy.deepcopy(next(n for n in nr['inner'] if n.get('kind')=='EnumDecl' and n.get('name')=='Phase'));twin['id']='decoder-only-other-enum';nr['inner'].append(twin)
  elif kind=='enum_range':
   ed=next(n for n in nr['inner'] if n.get('kind')=='EnumDecl' and n.get('name')=='Phase');next(n for n in walk(ed) if n.get('kind')=='ConstantExpr')['value']=str(1<<100)
  obj,status=run(name,True,othernodes=[nr],otherfs=nf)
  added=[e for e in obj.operand_audit if e.get('classification')=='absorbed' and e.get('const_domain')]
  assert not added,(profile,label,added)
  mutation_results[label]={'status':status,'const_domain':obj.const_scalar_audit,'domain_accepted':False,'decoder_only':True}
  checks.append('decoder-rejection:'+label)
 (E/(profile+'.results.json')).write_text(json.dumps(results,indent=2)+'\n')
 (E/(profile+'.decoder-negatives.json')).write_text(json.dumps(mutation_results,indent=2)+'\n')
 (E/(profile+'.tests.log')).write_text('\n'.join('PASS '+x for x in checks)+'\n')
 for label,flags in [('macros',['-dM','-E']),('dependencies',['-M'])]:
  q=subprocess.run(common+flags+[str(source)],cwd=c.R,capture_output=True,text=True,check=True)
  (E/(profile+'.'+label)).write_text(q.stdout)
 after=dependency.inventory(common,source,c.R);dependency.compare(before,after);dependency.verify_files(before)
 (E/(profile+'.inputs.json')).write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
 manifest['profiles'][profile]={'command':cmd,'source_sha256':sha(source),'ast_sha256':sha(E/(profile+'.ast.json')),'inputs_sha256':sha(E/(profile+'.inputs.json')),'results_sha256':sha(E/(profile+'.results.json')),'checks_passed':len(checks),'actual_profiles':'target-Clang genuine full fixture TUs only; not engine/MSVC/link/runtime qualification'}
 total+=len(checks);print('PASS',profile,len(checks),flush=True)
m.verify_inherited();manifest['total_checks_passed']=total
(E/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS',total,'fixture checks; no production bounds')
