"""Constructor/composition refusal checks using the genuine saved fixture TU."""
from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
E=Path(__file__).parent
import const_counter as m
root=json.loads((E/'C11.ast.json').read_text()); nodes=[root]
fs={n['name']:{'ast':n,'unit':'fixture'} for n in root['inner'] if n.get('kind')=='FunctionDecl' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[]))}
args=(fs,{'fixture':{'data':(E/'const_fixture.c').read_bytes()}},'',nodes,{})
kw={'unit_nodes':{'fixture':nodes}}
checks=[]
for label,more in [('non-Boolean opt-in',{'contextual_operands':True,'const_record_scalars':1}),('missing contextual opt-in',{'const_record_scalars':True})]:
 try:m.Counter(*args,**kw,**more);raise AssertionError(label+' accepted')
 except RuntimeError as e:checks.append({'check':label,'status':'REJECTED','reason':str(e)})
class ForeignCatalog(m.inherited.Counter):
 def _catalog(self,name,fn):raise AssertionError('must never execute')
try:m.counter_for(ForeignCatalog);raise AssertionError('foreign catalog accepted')
except RuntimeError as e:checks.append({'check':'changed parent catalog','status':'REJECTED','reason':str(e)})
before=set(m.inherited.c.NATIVE)
off=m.Counter(*args,**kw,contextual_operands=True)
assert not off.const_record_scalars and not off.const_scalar_audit
assert set(m.inherited.c.NATIVE)==before
checks.append({'check':'default OFF/no native mutation','status':'PASS'})
m.verify_inherited()
(E/'api-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print('PASS',len(checks),'API/refusal checks')
