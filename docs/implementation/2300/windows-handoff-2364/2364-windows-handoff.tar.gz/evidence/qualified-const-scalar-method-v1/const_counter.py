"""DEFAULT-OFF ordinary const-record scalar operand domain; no production fit.

This augments the pinned catalog rather than rewriting any compiler AST/type.
Only candidates whose old path/consumer checks passed and whose scalar leaf
classification failed may enter the additional, conversion-bound domain.
"""
from pathlib import Path
import hashlib
import sys
import re

sys.dont_write_bytecode = True
E = Path(__file__).parent
B = E.parent
sys.path.insert(0, str(B / 'prepared-native-packet-method-v1'))
import native_counter as inherited
import context_counter as context
import enum_switch_counter as enums

PINS = {
    B / 'root-context-operand-method-v1/context_counter.py':
        '90879bc2b89c49b2829aeb90a3115a8fc5ef6f01bf8d9e57a03b7a94f869d0c1',
    B / 'prepared-native-packet-method-v1/native_counter.py':
        'fb20ab5b886f4f2e755fb98dff0b6653af88860ea169efd3cd5205df0786f4d3',
}


def verify_inherited():
    for path, digest in PINS.items():
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError('const-v1: inherited source changed: ' + str(path))
    inherited.verify_inherited()
    context.verify_inherited()


verify_inherited()


def walk(node):
    yield node
    for child in node.get('inner', []):
        yield from walk(child)


def tokens(text):
    # Comparison only. Original compiler type dictionaries remain unchanged.
    if re.search(r'[^A-Za-z_0-9\s*]', text):
        return None
    return re.findall(r'[A-Za-z_][A-Za-z_0-9]*|\*', text)


class ConstRecordScalarsMixin:
    def __init__(self, *args, const_record_scalars=False, **kwargs):
        if type(const_record_scalars) is not bool:
            raise RuntimeError('const-v1: opt-in must be Boolean')
        if const_record_scalars and not kwargs.get('contextual_operands', False):
            raise RuntimeError('const-v1: explicit contextual scalar mode required')
        self.const_record_scalars = const_record_scalars
        self.const_scalar_audit = []
        super().__init__(*args, **kwargs)

    def _catalog(self, name, fn):
        start = len(self.operand_audit)
        super()._catalog(name, fn)
        if not self.const_record_scalars:
            return
        root = fn['ast']
        unit = fn['unit']
        nodes = list(walk(root))
        by_id = {n['id']: n for n in nodes if n.get('id')}
        parents = {}
        for node in nodes:
            for child in node.get('inner', []):
                if id(child) in parents:
                    raise RuntimeError('const-v1: non-tree compiler node occurrence')
                parents[id(child)] = node
        full = [n for r in self.unit_nodes.get(unit, []) for n in walk(r)]
        all_ids = {}
        for node in full:
            if node.get('id'):
                old = all_ids.get(node['id'])
                if old is None or len(node) > len(old):
                    all_ids[node['id']] = node

        for old in self.operand_audit[start:]:
            if old.get('classification') != 'candidate':
                continue
            n = by_id.get(old.get('node_id'))
            if not n or n.get('kind') != 'MemberExpr':
                continue
            # This exact reason means ALL pinned path, consumer and enclosing
            # exclusion checks passed before its narrow scalar-leaf test failed.
            if old.get('eligible') or old.get('reason') != 'unknown/aggregate/vector/oversize scalar leaf':
                continue
            row = {'function': name, 'unit': unit, 'member_node_id': n['id'],
                   'member_type': dict(n.get('type', {})),
                   'consumer_id': old.get('consumer_id'),
                   'consumer_kind': old.get('consumer_kind'),
                   'eligible': False, 'reason': 'unproved const-record value conversion'}
            self.const_scalar_audit.append(row)
            conversion = parents.get(id(n))
            if (not conversion or conversion.get('kind') != 'ImplicitCastExpr'
                    or conversion.get('castKind') != 'LValueToRValue'
                    or len(conversion.get('inner', [])) != 1
                    or conversion['inner'][0] is not n):
                row['reason'] = 'no immediate actual LValueToRValue'
                continue
            row['conversion_node_id'] = conversion.get('id')
            row['conversion_type'] = dict(conversion.get('type', {}))
            if not old.get('consumer_id') or old['consumer_id'] not in by_id:
                row['reason'] = 'missing actual scalar consumer'
                continue
            field, record, forbidden = self.fields.get(unit, {}).get(
                n.get('referencedMemberDecl'), ({}, {}, True))
            if (forbidden or not field or not record.get('completeDefinition')
                    or all_ids.get(field.get('id')) is not field
                    or all_ids.get(record.get('id')) is not record):
                row['reason'] = 'missing actual same-TU field/record identity'
                continue
            row['field_decl_id'] = field['id']
            row['record_decl_id'] = record['id']
            row['field_type'] = dict(field.get('type', {}))
            base = n.get('inner', [None])[0]
            if base is None:
                continue
            base_type = inherited.typ(base)
            row['const_object_type'] = dict(base.get('type', {}))
            # A complete ordinary field declaration has no new top-level const;
            # the containing const object supplies the actual view qualification.
            if not base_type.startswith('const ') or (n.get('isArrow') and not base_type.endswith('*')):
                row['reason'] = 'no explicit genuine const-containing record view'
                continue
            ft = tokens(inherited.typ(field))
            mt = tokens(inherited.typ(n))
            vt = tokens(inherited.typ(conversion))
            if not ft or not mt or not vt or ft != vt:
                row['reason'] = 'field/value type identity mismatch or unsupported spelling'
                continue
            domain = None
            if ft[-1] == '*' and mt == ft + ['const']:
                if any(x.get('type', {}).get('typeAliasDeclId') for x in (field, n, conversion)):
                    row['reason'] = 'unexplained top-level pointer typedef qualification'
                    continue
                domain = 'ordinary_pointer_const_record_value'
            elif ft[0] == 'enum' and mt == ['const'] + ft:
                enum_name = inherited.typ(field).removeprefix('enum ')
                es = {q['id']: q for q in full if q.get('kind') == 'EnumDecl'
                      and q.get('name') == enum_name
                      and any(c.get('kind') == 'EnumConstantDecl' for c in q.get('inner', []))}
                if len(es) != 1:
                    row['reason'] = 'missing or ambiguous actual EnumDecl'
                    continue
                ed = next(iter(es.values()))
                if any(q.get('kind', '').endswith('Attr') for q in ed.get('inner', [])):
                    row['reason'] = 'layout/unknown enum attribute'
                    continue
                underlying = ed.get('fixedUnderlyingType', {}).get('qualType')
                if underlying and underlying not in {'int', 'unsigned int', 'long', 'unsigned long', 'long long', 'unsigned long long'}:
                    row['reason'] = 'unsupported enum underlying representation'
                    continue
                try:
                    values = enums.EnumCatalog([ed]).enums[ed['id']]['values']
                except (KeyError, RuntimeError):
                    row['reason'] = 'unresolved actual enum values'
                    continue
                if any(v < -(1 << 63) or v >= (1 << 64) for v in values.values()):
                    row['reason'] = 'enum outside supported scalar range'
                    continue
                alias_ids = [q.get('type', {}).get('typeAliasDeclId') for q in (field, n, conversion)]
                if len(set(alias_ids)) != 1:
                    row['reason'] = 'enum alias identity changed across actual conversion'
                    continue
                alias = all_ids.get(alias_ids[0]) if alias_ids[0] else None
                if alias is not None:
                    enum_refs = {q.get('decl', {}).get('id') for q in walk(alias) if q.get('kind') == 'EnumType'}
                    if (alias.get('kind') != 'TypedefDecl'
                            or inherited.typ(alias) != inherited.typ(field)
                            or enum_refs != {ed['id']}):
                        row['reason'] = 'unexplained enum typedef qualification or identity'
                        continue
                elif alias_ids[0]:
                    row['reason'] = 'missing actual enum alias declaration'
                    continue
                row['enum_decl_id'] = ed['id']
                row['enum_underlying_type'] = underlying
                row['enum_values'] = values
                row['type_alias_decl_id'] = alias_ids[0]
                domain = 'ordinary_enum_const_record_value'
            if domain is None:
                row['reason'] = 'not the approved added-const pointer/enum domain'
                continue
            path = []
            q = n
            while q.get('kind') == 'MemberExpr':
                f, r, bad = self.fields[unit][q['referencedMemberDecl']]
                path.append({'member_node_id': q.get('id'), 'field_decl_id': f.get('id'),
                             'record_decl_id': r.get('id'), 'member_type': dict(q.get('type', {})),
                             'field_type': dict(f.get('type', {})), 'is_arrow': q.get('isArrow', False)})
                q = q['inner'][0]
                while q.get('kind') in {'ImplicitCastExpr', 'ParenExpr'}:
                    q = q['inner'][0]
            row.update(eligible=True, reason='exact actual const-record scalar value conversion',
                       domain=domain, path_proof=path)
            # Ownership is keyed to the original physical node occurrences.
            entry = dict(old, eligible=True, reason=row['reason'], path_proof=path,
                         const_domain=domain, value_conversion_node_id=conversion.get('id'),
                         const_proof=row)
            for member in path:
                actual = by_id[member['member_node_id']]
                self.ownership[name][(id(actual), 'address_front')] = entry
            self.ownership[name][(id(conversion), 'indirect_scalar_read')] = entry


def counter_for(base_class):
    """Compose with a separately reviewed Native/identity-adapter Counter.

    Returning a class is not approval of a new base, provider registry or result.
    The parent catalog must still be the exact pinned contextual implementation.
    """
    if not issubclass(base_class, inherited.Counter) or base_class._catalog is not context.Counter._catalog:
        raise RuntimeError('const-v1: unbound parent catalog/composition')

    class Counter(ConstRecordScalarsMixin, base_class):
        pass
    return Counter


Counter = counter_for(inherited.Counter)
