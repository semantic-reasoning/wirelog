/* Genuine compiler fixture only; no engine or fabricated actor declaration. */
typedef enum Phase { PHASE_NEG = -1, PHASE_ZERO = 0, PHASE_ONE = 1 } Phase_t;
typedef void *PointerAlias;
typedef void *const ConstPointerAlias;
typedef const Phase_t ConstEnumAlias;
struct Inner { void *pointer; Phase_t phase; };
struct View {
    void *pointer;
    Phase_t phase;
    enum Phase direct_phase;
    struct Inner inner;
    struct View *next;
    void *volatile volatile_pointer;
    volatile unsigned int volatile_integer;
    const volatile int *volatile_pointee;
    _Atomic(void *) atomic_pointer;
    void *const declared_const_pointer;
    const Phase_t declared_const_enum;
    ConstPointerAlias hidden_const_pointer;
    ConstEnumAlias hidden_const_enum;
    PointerAlias alias_pointer;
    unsigned int bit : 1;
};
struct __attribute__((packed)) Packed { void *pointer; Phase_t phase; };
#pragma pack(push, 1)
struct PragmaPacked { void *pointer; Phase_t phase; };
#pragma pack(pop)
union UnionView { void *pointer; Phase_t phase; };
struct UnionPath { union UnionView inner; };
static const struct View global_view;
typedef volatile struct View VolatileView;

int pointer_sink(void *p) { return p != 0; }
int enum_sink(Phase_t e) { return e == PHASE_ONE; }
int address_sink(void *const *p) { return p != 0; }
const struct View *view_factory(const struct View *p) { return p; }
void *pointer_return(const struct View *p) { return p->pointer; }
void *pointer_init(const struct View *p) { void *q = p->pointer; return q; }
int pointer_truth(const struct View *p) { if (p->pointer) return 1; return 0; }
int pointer_compare(const struct View *p) { return p->pointer == p->pointer; }
int pointer_argument(const struct View *p) { return pointer_sink(p->pointer); }
int pointer_repeated(const struct View *p) { return p->pointer != 0 && p->pointer != 0; }
int enum_return(const struct View *p) { return p->phase; }
int enum_truth(const struct View *p) { if (p->phase) return 1; return 0; }
int enum_compare(const struct View *p) { return p->phase == PHASE_ONE; }
int enum_argument(const struct View *p) { return enum_sink(p->phase); }
int enum_repeated(const struct View *p) { return p->phase + p->phase; }
int direct_enum(const struct View *p) { return p->direct_phase; }
void *embedded_pointer(const struct View *p) { return p->inner.pointer; }
int embedded_enum(const struct View *p) { return p->inner.phase; }
struct ConstPointee { const int *pointer; };
const int *pointee_const(const struct ConstPointee *p) { return p->pointer; }
int local_const_record(void *q) { struct Inner s; s.pointer = q; const struct Inner *p = &s; return p->pointer != 0; }
int callee_standalone(const struct View *p) { p->pointer; return 0; }
int caller_scope(const struct View *p) { return callee_standalone(p) + pointer_sink((void *)0); }

int address_argument(const struct View *p) { return address_sink(&p->pointer); }
void *const *address_return(const struct View *p) { return &p->pointer; }
int standalone(const struct View *p) { p->pointer; return 0; }
int standalone_address(const struct View *p) { &p->pointer; return 0; }
int discarded_comma(const struct View *p) { return (p->pointer, 0); }
int discarded_void(const struct View *p) { (void)p->pointer; return 0; }
unsigned long long unevaluated(const struct View *p) { return sizeof(p->pointer); }
void *two_arrow(const struct View *p) { return p->next->pointer; }
void *cast_base(const void *p) { return ((const struct View *)p)->pointer; }
void *indexed_base(const struct View *p, unsigned int i) { return p[i].pointer; }
void *computed_base(const struct View *p) { return (p + 1)->pointer; }
void *call_base(const struct View *p) { return view_factory(p)->pointer; }
void *side_base(const struct View *p) { return (p++)->pointer; }
void *global_base(void) { return global_view.pointer; }
void *static_base(void) { static const struct View s; return s.pointer; }
void *volatile_field(const struct View *p) { return p->volatile_pointer; }
void *volatile_record(const volatile struct View *p) { return p->pointer; }
void *hidden_volatile(const VolatileView *p) { return p->pointer; }
const volatile int *volatile_target(const struct View *p) { return p->volatile_pointee; }
void *atomic_field(const struct View *p) { return p->atomic_pointer; }
void *restrict_base(const struct View *restrict p) { return p->pointer; }
void *packed_field(const struct Packed *p) { return p->pointer; }
void *pragma_field(const struct PragmaPacked *p) { return p->pointer; }
void *union_field(const union UnionView *p) { return p->pointer; }
void *union_path(const struct UnionPath *p) { return p->inner.pointer; }
int bitfield(const struct View *p) { return p->bit; }
void *declared_const(const struct View *p) { return p->declared_const_pointer; }
int declared_const_enum(const struct View *p) { return p->declared_const_enum; }
void *hidden_pointer_qualifier(const struct View *p) { return p->hidden_const_pointer; }
int hidden_enum_qualifier(const struct View *p) { return p->hidden_const_enum; }
void *pointer_alias(const struct View *p) { return p->alias_pointer; }
int direct_switch(const struct View *p) { switch (p->phase) { case PHASE_ZERO: return 0; default: return 1; } }
