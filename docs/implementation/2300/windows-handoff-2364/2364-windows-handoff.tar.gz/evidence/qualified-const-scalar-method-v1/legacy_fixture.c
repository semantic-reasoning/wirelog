typedef unsigned long long u64;
typedef volatile unsigned int vu;
typedef _Atomic(unsigned int) au;
enum Kind { K0, K1 };
struct Inner { unsigned int x; void *ptr; };
struct S { struct Inner embedded; unsigned int flag; unsigned int value; enum Kind kind; void *ptr; struct S *next; volatile unsigned int vol; au atom; unsigned int bit:1; };
struct __attribute__((packed)) Packed { unsigned int x; };
struct PackedPath { struct Packed nested; };
#pragma pack(push,1)
struct Pragma { unsigned int x; };
#pragma pack(pop)
union U { unsigned int x; void *p; };
struct UnionPath { union U nested; };
struct Qual { vu hidden; au atom; };
typedef unsigned int Vec __attribute__((vector_size(16)));
struct Other { Vec vector; long double wide; unsigned int array[4]; _Complex double complex; };
struct Actor { void *handle; unsigned int tid; };
static struct S global;
unsigned int leaf(unsigned int x) { return x; }
unsigned int truth_call(unsigned int x) { return x; }
unsigned int assignment(struct S *p) { p->flag=p->value; return 0; }
unsigned int initialization(struct S *p) { unsigned int x=p->value; return x; }
unsigned int comparison(struct S *p) { if (p->flag == p->value) return 1; return 0; }
unsigned int bare_truth(struct S *p) { if (p->flag) return 1; return 0; }
unsigned int local_truth(unsigned int x) { if (x) return 1; return 0; }
unsigned int pointer_truth(void *p) { if (p) return 1; return 0; }
unsigned int call_truth(unsigned int x) { if (truth_call(x)) return 1; return 0; }
unsigned int not_truth(struct S *p) { if (!p->flag) return 1; return 0; }
unsigned int logical(struct S *p) { if (p->flag && p->value || p->ptr) return 1; return 0; }
unsigned int ternary(struct S *p) { return p->flag ? p->value : 0; }
unsigned int arithmetic(struct S *p) { p->flag = p->value + p->embedded.x; return p->flag; }
unsigned int repeated(struct S *p) { return p->value + p->value; }
unsigned int call_argument(struct S *p) { return leaf(p->value); }
unsigned int address_argument(struct S *p) { return p->ptr == &p->flag; }
unsigned int take_address(unsigned int *p) { return 0; }
unsigned int field_address_argument(struct S *p) { return take_address(&p->flag); }
unsigned int returned(struct S *p) { return p->value; }
void *pointer_leaf(struct S *p) { return p->ptr; }
unsigned int enum_leaf(struct S *p) { return p->kind; }
unsigned int one_arrow_dot(struct S *p) { return p->embedded.x; }
unsigned int local_record(unsigned int x) { struct S s; s.embedded.x=x; return s.embedded.x; }
unsigned int callee_standalone(struct S *p) { p->value; return 0; }
unsigned int caller_scope(struct S *p) { p->flag=callee_standalone(p); return 0; }
unsigned int two_arrow(struct S *p) { return p->next->value; }
unsigned int pointer_chase(struct S *p) { return *(unsigned int *)p->ptr; }
unsigned int dynamic_index(struct S *p, unsigned int i) { return p[i].value; }
unsigned int cast_base(void *p) { return ((struct S *)p)->value; }
struct S *factory(struct S *p) { return p; }
unsigned int call_base(struct S *p) { return factory(p)->value; }
unsigned int side_base(struct S *p) { return (p++)->value; }
unsigned int global_base(void) { return global.value; }
unsigned int static_base(void) { static struct S s; return s.value; }
unsigned int volatile_leaf(struct S *p) { return p->vol; }
unsigned int atomic_leaf(struct S *p) { return p->atom; }
unsigned int volatile_base(volatile struct S *p) { return p->value; }
unsigned int hidden_qual(struct Qual *p) { return p->hidden; }
unsigned int hidden_atomic(struct Qual *p) { return p->atom; }
unsigned int bitfield(struct S *p) { return p->bit; }
unsigned int packed(struct Packed *p) { return p->x; }
unsigned int pragma_packed(struct Pragma *p) { return p->x; }
unsigned int packed_path(struct PackedPath *p) { return p->nested.x; }
unsigned int union_path(struct UnionPath *p) { return p->nested.x; }
Vec vector_leaf(struct Other *p) { return p->vector; }
long double oversized(struct Other *p) { return p->wide; }
unsigned int array_leaf(struct Other *p, unsigned int i) { return p->array[i]; }
_Complex double complex_leaf(struct Other *p) { return p->complex; }
unsigned int standalone(struct S *p) { p->value; return 0; }
struct Inner aggregate(struct S *p) { return p->embedded; }
struct Actor actor_aggregate(struct Actor actor) { return actor; }
unsigned int native_atomic(struct S *p) { return __c11_atomic_load(&p->atom,0); }
unsigned int compound(struct S *p) { p->flag += p->value; return 0; }
unsigned int increment(struct S *p) { ++p->flag; return 0; }
unsigned int standalone_address(struct S *p) { &p->value; return 0; }
unsigned int pointer_arithmetic(struct S *p) { return (p+1)->value; }
unsigned int void_expression(struct S *p) { (void)p->value; return 0; }
struct Inner aggregate_assignment(struct S *p, struct S *q) { p->embedded=q->embedded; return p->embedded; }
unsigned int discarded_comma(struct S *p) { return (p->value,0); }
typedef enum Kind Kind_t;
unsigned int fixture_one(struct S *p) { Kind_t state=p->kind; switch(state) { case K0: p->flag=1; break; case K1: p->flag=2; break; default: p->flag=3; break; } return p->flag; }
unsigned int nested_consumers(struct S *p) { p->flag=leaf(p->value+p->embedded.x); return p->flag==p->value; }
unsigned int separate_consumers(struct S *p) { p->flag=p->value; return p->value; }
unsigned int direct_field_switch(struct S *p) { switch(p->kind) { case K0: return 0; default: return 1; } }
