/* Genuine primary declaration; no actor surrogate. */
#include <threads.h>
_Static_assert(sizeof(thrd_t)==16, "actual primary actor size");
_Static_assert(_Alignof(thrd_t)==8, "actual primary actor alignment");
thrd_t actor_transport(thrd_t actor) { return actor; }
