# Read-only rebase overlap intake: PR2364 draft handoff

**Recommendation: preserve main's current JOIN algorithms and scalar funding; do not replay the old first/third commit engine implementations. No entire first-three commit is proven disposable because their additional tests/docs contain unique work.** If skipping an old commit as the mechanical rebase operation, explicitly carry its unique test/document hunks into a reviewed salvage unit and map the replacement main commit. Backup preservation alone is not a claim that unique work reached the draft.

## Exact read-only basis

Original16 commits: `a8dfa5b35618a874b8f34fd25efbca0ada99f009..9914e9b4`; new main25 commits: `a8dfa5b35618a874b8f34fd25efbca0ada99f009..60e28c6f`. Root worktree `/srv/home/joykim/.tmp/2300-operator-recovery-next` is stopped replaying `29c9fa4be6b79f50dd06b873761d66ad39546753`; only join.c and test_evaluation_join.c are unmerged. Inspected actual commit diffs and current-main source/tests, not titles alone. No index/worktree/rebase operation performed.

Current index conflict identities:

| File | Base :1 | Main :2 | Old commit :3 |
|---|---|---|---|
| wirelog/columnar/join.c | dd8b265308510f52f3d55a9911566f77f1b87692 | bbda66417ebf1b71e330c1b8096489ca70ae980f | a98042f9ed82d110bb9f2f8fcca08c629abea0fa |
| tests/test_evaluation_join.c | cd27e88b77a4ef7828830e3c7ba1280713926e9d | 87083cdd8f003a0d163bbfa077accac5d36b4b5d | 25ba874492e04992c0108a6cf0d514d13ecdcbe9 |

## Concrete overlap decisions

| Original commit | Main replacement / actual difference | Deduplication recommendation |
|---|---|---|
| 29c9fa4b numeric right-filter membership | 05c8a467 already enables filtered existence probes, with 9090d159 scalar helper. Main deliberately keeps physical original-row hash chains and next[] sized by right_meta.nrows, selected-index insertion, filtered-only256 caller payments and a keyless selected_rows fast membership result. Old29c uses compact selected ordinals, selected_rows-sized chains, repeated ordinal-to-row remaps and old50/51 checkpoints/payments. | **Skip/reject old algorithm and corresponding obsolete financial/checkpoint hunks.** Keep main physical-row implementation, not a hybrid. The mode5 numeric predicate support test is already present on main. Preserve unique tests listed below before dropping the whole old commit. |
| 51cd875c filtered probe session recovery/accounting | Main05c8a467 adds public compiled numeric/scalar keyed/keyless probe positives, empty/collision/retraction cases and recovery in test_evaluation_expression_hosts.c. However main lacks filtered_generated_probes/filtered_checkpoint in test_evaluation_join_probes.c and lacks the filtered-numeric Meson selector. | **Not an exact duplicate; do not blanket skip its tests/docs.** Preserve or explicitly map its65-row, ordinary/batched, governor/allocation/cancel/overflow/report/reset coverage. Rebind obsolete50/51 hit expectations to the actual main algorithm; do not reintroduce removed engine checkpoints merely to satisfy old tests. |
| bf7079d7 scalar right predicates | Main9090d159 implements scalar fallback with explicit256 packets and seven intern-only context stores; main05c8a467 initializes probe scalar_program. Oldbf adds192-funded fallback and a broad extension/worker/session context aggregate. Main also already updates the old string-literal ENOTSUP test to raw false semantics. | **Skip/reject old engine fallback/context and duplicate ENOTSUP-test replacement.** Retain unique direct string-function/long2050-byte tests and filtered-scalar owner fixture/Meson/docs where not mapped to equivalent new tests. Never overwrite main's context isolation or256 packets with old192/aggregate context. |
| e4385f37 scalar REDUCE + intern-ranked aggregates | Main502d13ae already implements scalar aggregate operand fallback with256 packets and raw intern-only context. BUT current main still excludes non-COUNT string operands and has no intern_rank_compare_attempt_controlled helper; olde438 explicitly removes that string exclusion and adds that helper plus ranking/validity logic. | **Partial overlap only.** Preserve unique string/intern-rank implementation/tests; do not blindly skip this commit or reapply its older192-funded scalar/context hunks. Resolve the unique extension against main's newer scalar funding/recovery framework in its own reviewed unit. |

### Unique first-commit tests that must not disappear silently

29c adds filtered_probe_cases and filtered_probe_error_and_stop_cases to test_evaluation_join.c. They cover widths0/1/17/65/257; semi/anti keyed/keyless; noncontiguous accepted rows; original row64 reached through collision chains; rejected duplicate witnesses; cancellation/id-turnover; all-false/division/empty/missing-right paths; and selected versus rejected malformed floating rows/error precedence. Main05 has useful probe_right_filter_edges and expression-host probe_collisions, but these are not byte-identical or demonstrated exhaustive substitutes for that matrix. Preserve the unique assertions with the actual current algorithm. Old phases50/51 and compact-ordinal map counts are implementation-specific and no longer meaningful main checkpoints; omitting those specific obsolete cases requires an explicit mapping, not weakening all recovery expectations.

bf's right_scalar_function_cases exercises genuine intern-backed contains with2050-byte strings and JOIN/SEMI/ANTI interruption. Its filtered-scalar generated fixture also authenticates retained scalar_program ownership. Main expression hosts cover overlapping scalar behavior, but this read-only intake did not establish that every long-string/retained-owner oracle is duplicated. Do not assert they are all redundant from feature titles.

## Original16 inventory and remaining scope

Full old order:29c9fa4b,51cd875c,bf7079d7,e4385f37,9bd34437,c912d270,b43f9cf7,99b11597,51bee69d,cfd229e3,fd612ede,9904a8bf,226fb72c,6f864f4e,679396e0,9914e9b4. The remaining twelve cover observer cleanup retention, finite scalar source acquisition/retirement, prepared JOIN recovery, abort/settlement phases, audit docs, K-fusion lineage and differential/managed ledger retirement. No evidence from the inspected first-four overlap justifies skipping those twelve. Keep/review their actual hunks against new main rather than infer equivalence from general recovery features.

The25 main additions also include computed-MAP/private recovery, scalar schema inference/empty schemas, immutable scalar views, semantic finish copies, timestamps, private seed composition/compaction/receipts, radix preparation and recursive raw-schedule cursor changes. Those independent fixes are not obsolete merely because old branch files overlap; resolving all conflicts with :3 would regress them. This intake did not prove all later branch/main interactions safe, and is not a complete rebase design or validation receipt.

## Safe handoff boundary

Retain exact original tip/bundle/stash mapping and new-base mapping transparently. For each omitted historical patch identify the already-main replacement and separately preserve unique engine/tests/docs work. Old2300 documentation can remain historical evidence, but obsolete compact-mapping/192-price claims must not be presented as descriptions of current main. Do not use blind ours/theirs, double algorithms or old test phase expectations as justification to change main code.

No files/index/rebase state were edited and no build/test/rebase continuation/commit/push was run. This read-only recommendation supports the user's draft Windows handoff; it does not complete2367/2368 or qualify bounds, providers, Windows runtime or final gates.
