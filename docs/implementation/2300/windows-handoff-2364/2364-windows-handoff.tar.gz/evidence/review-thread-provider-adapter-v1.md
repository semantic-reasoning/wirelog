# review_findings / method_validation: exact thread identity adapter v1

**RAW/METHOD outcome: BLOCKED on R1, an interval-ownership/completion seal defect.** The explicitly narrowed trusted-standard C/P design remains accepted; this candidate needs the bounded API repair below before use for fresh Native whole-path evidence. No production upper/provider/caller qualification is approved. No engine, Root, inherited counter or sealed author artifact was edited or executed.

## Exact candidate and scope

Evidence-only candidate `/srv/home/joykim/evidence/2300-completion/exact-thread-identity-provider-v1`; no repository candidate tree is claimed. Delivery SHA256 `804700b42393131e4d70f424d3560de0f7498da01e3a90a432cfcd85fa5183a2`; complete raw `candidate.diff` SHA256 `9df7c6085576e68ed00dca137e4eeef624d2f085c65f412bc0dbda29bc777748`; `files.json` SHA256 `63998f596156d82802e634d0bc196b777c8e178745739c8acdb2b83969844378`.

Reviewed all eleven raw units: `thread_provider.py`, `saved_aggregate_proof.py`, `test_thread_provider.py`, `capture_inline_fixtures.py`, `export_fixtures.py`, `contract.md`, `schema.json`, `provider-manifest.json`, `caller-lifetimes.md`, `fixtures.json`, `results.json`. Reconstructed every raw added-file body and independently verified equality to actual bytes. All entries in files.json hash correctly, including all genuine saved/O2 fixtures and six ledgers. Authored code/support bindings:

| Unit | SHA256 |
|---|---|
| thread_provider.py | `61f52115b737d1841d33640a9c819fab18de15ed25995dd9629246b656ad20b0` |
| saved_aggregate_proof.py | `32bb315e0ae3a8be0652dc43b6a15d6be23053778dd18b2e560ea0f36ca5fc91` |
| test_thread_provider.py | `e32bfa6aaccff39298475f5caeee44b1627b92cd072c8fe9e576f3679d041136` |
| contract.md | `e4d60ad72daa387c2d7e888d4ee634d81d2d0476e2b4a6518f045492913c3a5c` |
| schema.json | `2b85533b9d8c1300a4c0a29ca3d20cb8c9658312b746b0e2df5a4025a82c547a` |
| results.json | `694e1edb223f04b6187646d74881bf942060e289f97baa6b7e7477025c0b901b` |

Independently checked unchanged inherited modules: contextual counter `90879bc2b89c49b2829aeb90a3115a8fc5ef6f01bf8d9e57a03b7a94f869d0c1`, Native counter `fb20ab5b886f4f2e755fb98dff0b6653af88860ea169efd3cd5205df0786f4d3`, ordinary counter `ff847a393c182b0d17a8be45aa894ef003da7bd24291ad4d0218bd35392a9722`. Inspected inherited aggregate call/run/ABI/effect handling and exact new overrides, rather than assuming superclass behavior.

## R1 — blocking: exported C and P do not bind one completed measurement

`thread_provider.py:190–213,230–236`: Domain owns global P/audit arrays, while each Counter independently owns C/ABI/transfer arrays and a C-only success seal. There is no domain-to-counter measurement owner or sealed event range. A new top-level run also leaves the old success seal valid until another run succeeds; failure before event emission does not invalidate it.

Independent reproduction using only genuine branch-free C11 fixtures in a NEW sibling copy:

1. Run actor_equal successfully (C7/P2); call `run('not_an_actual_function')`, which raises KeyError before emission; `domain.ledger(counter)` still ACCEPTS the unchanged old C7/P2 ledger. This contradicts the explicit contract that an incomplete/failed run cannot export a complete ledger. The unknown-function request is not accepted source work; its failure must not silently select an earlier measurement.
2. Use the same registered Domain for one actor_current Counter (C2/P1) and a separate actor_equal Counter (C7/P2). Both successful counter ledgers ACCEPT the shared Domain P3 sequence, paired with their different individual C arrays. No mutation, fabricated AST, private-field edit, provider certificate or engine execution is required. A caller cannot determine which completed interval the composed C/P record certifies. Conservative extra P does not repair its falsely asserted interval identity/chronology.

Bounded repair: explicitly bind a Domain/Counter pair to one single-use top-level measurement, rejecting cross-counter/repeated execution, OR implement immutable per-completed-run C/P/audit ownership/ranges and export only that same snapshot. Invalidate eligibility when a new top-level attempt begins and keep it invalid on every failure. Preserve nested helper runs and all inherited C/ABI charging. Add focused regression checks for these two actual API sequences, then freeze/review the new raw candidate. No new qualification domain, engine change or generic framework is needed.

## Method and other reviewed obligations

**No additional blocking finding.** Default OFF delegates inherited behavior; enabled membership is explicit and does not patch NATIVE. Registration requires exact actual CallExpr/declaration object, primary header spelling/hash, profile signature/arity/calling convention, registered helper/producer and actual caller IR evidence. Genuine header source equality expands as C with no phantom P; platform mode records a separately visible occurrence rather than zero/one numeric C price. Unsupported modes/helpers/next source forms remain refusals. Missing or mutated certificate/index/type/source/P/C bindings are rejected in the tested scope.

Certificates require an explicitly reviewed digest set, exact generated call/ABI/source/input binding, standard noninterposed provider and actual live producer/driver/Source lifetime evidence. Full-TU syntax is separately required for production qualification. These reviewed external assertions are not inferred from ordinary hashes, thread_valid, allocation refs or the method decision. Existing Root79ac/3b receipts are references, not Native9caf certificates. No positive production certificate or Windows provider/caller was manufactured.

The MSVC fixture uses genuine PrimaryNaturalPack8/CapturedProof and same-TU roots, actual full thrd_t record, sret/copies and both aggregate argument transfers. Parent return/assignment and conservative ALL-IR-copy effects remain active. Hidden ABI endpoints are declared transport storage with independently required custody, never callback/actor/key/grant permission. Independent focused replay retains two ABI inventories/four transport audits; no scalar/Tid fallback was accepted. This remains a fixture replay, not Windows runtime or full production-TU qualification.

The theorem visibly excludes trusted standard service interiors; it does not claim total OS work/latency, C0/C1, generic name-based permission, or that observed C/P is a packet upper. Schema and all actual six ledgers preserve UNQUALIFIED, route_blocked=true, C_upper=null and no accepted packet upper. Source-inline equality is C source and current is P in genuine O2 captures; O0 external equality is P. No C/P numeric summation, new price/cap, Source32 membership or inherited theorem weakening is hidden. Actual complete source paths/refusals/ABI/provider/caller/payer chronology/maxima remain mandatory later gates.

## Independent validation and evidence

Copied the candidate to `exact-thread-identity-provider-independent-replay-v1` under EVID and ran only its Python focused tests using the existing EVID/venv interpreter, with bytecode writes disabled. **18/18 PASS**. No compiler capture, engine executable or platform runtime was run by this reviewer. Additional read-only fixture/manifest inspection confirms all six emitted ledgers remain blocked with null uppers.

Independent receipts in that sibling:

- `independent-tests.log`: `b552fa0a9da84e891c644caab67b1e9acd6ce6e605fffca40b2816676ee0735f`.
- `independent-reuse-check.json`: `3d9edd54b0e163658c999b9535ad45023d89f9d184c86ba33ba16502c3d0f811` (R1 observations).
- `independent-binding-check.json`: `599cae7b746813917f5359c0cd76d0006488c8d3dc9a33be208a99b6700e54f5` (all eleven raw bodies match).

The concrete next step is this small measurement-seal repair, followed by independent re-review. Fresh Native captures may then consume the bounded adapter API conditionally; unresolved provider/caller routes must continue emitting only unqualified diagnostic evidence, never an accepted upper. This review grants no production counts, engine/Root edits, commit, push, CI or runtime permission.
