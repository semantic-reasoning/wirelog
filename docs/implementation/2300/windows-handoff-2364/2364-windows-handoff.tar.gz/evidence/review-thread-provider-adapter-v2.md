# review_findings / method_validation: thread-provider adapter R1 repair

**APPROVED for the bounded DEFAULT-OFF evidence-adapter API and conditional fresh Native C/P measurement use; R1 is resolved and no RAW blockers remain.** This accepts the reviewed measurement implementation, not an actual provider/caller certificate, production interval upper, packet fit, engine runtime, Root port or four-profile waiver. Unqualified evidence must remain unqualified.

## Exact evidence candidate

Evidence sibling `/srv/home/joykim/evidence/2300-completion/exact-thread-identity-provider-v2`; no repository tree is claimed. Base is the immutable v1 evidence candidate reviewed in `review-thread-provider-adapter-v1.md`, SHA256 `a5a3feb0a5f0e820f2af9e9bbec1d6fd739a9f28b9fbfe0e48d01bbd16dfda20`.

| Binding | SHA256 |
|---|---|
| delivery.json | `de35091ddb381d945a058522a0f0a87f975c7a7ad5688a19302de6588e1eeaa7` |
| full candidate.diff | `da9110b93a42a63095ec9c92de08cddd8e3b2b1ba722ae2954faac28a68139f1` |
| incremental.diff | `f69fd68e4f1f7ac77e07d82e3f1f1ad29da44bf5cdbef297d0acca23d62dfbb4` |
| files.json | `b21137138a90bc9eda244365a66b3001d62fbb7ffa87ff5fb2572579933fe0a9` |
| thread_provider.py | `245bd5c2b03fe976bee40fc9758c2a47616a9c7bd47146bc5f5a2d80baaeddca` |
| test_thread_provider.py | `edb7ba9eaf7ae38899252ffd6f603f803560b3fb99722c29367a0c22d3ae5233` |
| contract.md | `0b03c27f3d973cfa312fbf10380a4843c824a44cf911fffabfc419c295cbd62e` |
| schema.json | `c3a54c874443ab56e3c9ed7657fa00f388e74863e3534039c638a15e0de13a99` |
| results.json | `58267af7d87fbc7894d8ee48c617a0dc3e0ae671f611c6e892796cfb6ebb320d` |
| r1-preservation.json | `bf8ccfc5ced4f7b1702b5ba3f00cbac0eed3137d0792d52a7e7c2bfbe5ca0810` |

Full RAW path set: thread_provider.py, saved_aggregate_proof.py, test_thread_provider.py, capture_inline_fixtures.py, export_fixtures.py, contract.md, schema.json, provider-manifest.json, caller-lifetimes.md, fixtures.json, results.json, r1-preservation.json. Independently reconstructed every added-file body from full RAW and verified exact actual-file equality; all files.json entries hash correctly. Read full increment and the actual new state machine/run/ledger implementation. Only four authored units change: adapter, focused tests, contract and schema. The remaining fixture/result/preservation changes are regenerated evidence/status bindings. Unchanged method/source/ABI units remain covered by the preceding complete review and hash bindings, not author assertions.

## Findings

**R1 — resolved; no longer blocking.** Enabled Domain binds a unique Counter at construction. A different Counter is rejected before measurement events and cannot mix its C with the owner's P. A top-level run clears the Counter success seal before Domain.begin and before inherited lookup/emission. Domain.begin clears its combined seal and rejects any state beyond UNSTARTED, permanently marking a reused measurement FAILED. A first-attempt exception marks FAILED and clears eligibility. Successful outer completion alone seals C/ABI/transfer state together with P, call audit and registration stamp. ledger requires the same Counter, COMPLETE state and matching combined/current seals.

The begin rejection occurs before the run depth is incremented; it cannot leave a false nested depth or preserve a prior success. Exceptions during inherited expansion/completion clear eligibility through the outer handler. Nested helper runs use the same RUNNING measurement and do not open a second interval. Refusing a different Counter does not corrupt the original completed owner's evidence. Registration/event mutations after completion cannot be silently combined with an old seal. Disabled/default-OFF repeated inherited operation does not bind a Domain measurement or export a C/P ledger.

**No new blocking or non-blocking findings.** The bounded single-use policy directly resolves both demonstrated API sequences without changing source-cell pricing, service membership, certificate rules or engine behavior. A fresh Domain/Counter is required for each separate measurement; callers must not reuse a completed object as a resettable counter. The contract now states that requirement and schema requires measurement_complete=true plus a hexadecimal seal. Schema remains a diagnostic shape, not independently accepted mathematical bound or provider certificate.

## Independent replay and preservation

Created a NEW sibling `exact-thread-identity-provider-independent-replay-v2`; ran its focused tests only with the existing EVID/venv Python interpreter and bytecode writes disabled. **23/23 PASS**, including both original R1 regressions, nested-helper success, failed-first-attempt/no-retry, disabled repeated-run equality, omission/mutation rejection, genuine inline/source handling and full saved MSVC aggregate proof replay.

Separately repeated the original two API sequences: successful C7/P2 followed by an unknown/repeated request is refused and stale export is REJECTED; second Counter binding is REJECTED and the first actor_current owner's exported P remains1. An unregistered-call measurement refusal likewise cannot export a completed ledger. The source state-machine exception path covers later expansion failures without retaining an older eligibility seal; no fake successful partial ledger is adopted.

Independent receipt hashes in that new sibling:

- `independent-tests.log`: `8af91966446878a4c4d20b07777231f218d902ccfc8bd8bc2065b7fd1987d6b4`.
- `independent-r1-check.json`: `587c096d6c9012750a920cf5169fc8250977f9264d7320eaca2bd570eb347f84`.

Independently compared all six v2 ledgers with v1 after removing only the two new measurement fields: every remaining field is identical, including actual C events, P ordering, source-inline classification, ABI inventories and aggregate transfer audits. All remain UNQUALIFIED, route_blocked=true, C_upper=null and packet_upper_accepted=false. Genuine MSVC retains its full Handle/Tid actor, two ABI inventories and four transport audits; the unchanged CapturedProof/PrimaryNaturalPack8 does not grant provider/caller authority.

V1 SHA256SUMS remains `02b1f3f9dd47f0c9e0b7f7fd087e37314a3057169e0f534e47cba8f8d902af3e`. Independently rechecked inherited contextual/Native/ordinary modules as unchanged: `90879bc2b89c49b2829aeb90a3115a8fc5ef6f01bf8d9e57a03b7a94f869d0c1`, `fb20ab5b886f4f2e755fb98dff0b6653af88860ea169efd3cd5205df0786f4d3`, `ff847a393c182b0d17a8be45aa894ef003da7bd24291ad4d0218bd35392a9722`.

## Accepted next use and hard limits

This API can now be used explicitly/default OFF for one fresh, exact-capture Native measurement at a time, retaining C and symbolic P as separate quantities under the already accepted narrowed trusted-standard theorem. A real completed source traversal may report observed conditional evidence while actual provider/caller certificates remain BLOCK. Missing syntax/ABI/helper/source/effect/lifetime obligations still reject or remain explicitly unqualified; no new source name coupon or NATIVE mutation is accepted.

Actual Native9caf whole-path capture/ABI/provider/caller binding, full source/refusal/unwind closure, chronological payer ownership, maxima and unchanged caller capacity gates remain outstanding. Root79ac/3b and saved fixtures are not newNative qualification. Windows profile applicability/provider/full aggregate transport and integrated qualification are not waived. Hidden ABI storage endpoints remain declared transport storage, never callback/actor/grant authority. No numeric C+P summation, provider-interior C0/C1 price, accepted upper or runtime permission follows from this review.

No compiler recapture, engine/platform runtime, production counter change, Root/repository edit, commit, push or workflow run occurred. Only a new evidence replay copy, its Python test logs and this review artifact were written. Any adapter content change invalidates this exact candidate approval and requires independent RAW again.
