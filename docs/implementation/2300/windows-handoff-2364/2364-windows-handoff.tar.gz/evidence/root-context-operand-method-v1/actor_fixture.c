/* Actual primary C11 library declaration, not a reconstructed actor ABI. */
#include <threads.h>
_Static_assert(sizeof(thrd_t)==16, "actual primary MSVC C11 actor size");
_Static_assert(_Alignof(thrd_t)==8, "actual primary MSVC C11 actor alignment");
thrd_t actor_transport(thrd_t actor) { return actor; }
