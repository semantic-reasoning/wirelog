import sys,pathlib,json,subprocess,hashlib
sys.dont_write_bytecode=True
E=pathlib.Path(__file__).parent
import context_counter as m
import run_profile as r
import dependency_binding as d
common=r.config('MSVC-C11','');source=E/'actor_fixture.c'
before=d.inventory(common,source,m.c.R)
cmd=common+['-fsyntax-only','-Xclang','-ast-dump=json',str(source)]
p=subprocess.run(cmd,cwd=m.c.R,capture_output=True,text=True)
(E/'actual-MSVC-C11-actor.ast.json').write_text(p.stdout)
(E/'actual-MSVC-C11-actor.stderr').write_text(p.stderr)
assert p.returncode==0,p.stderr
nodes=[json.loads(p.stdout)];m.c.register_types(nodes)
fs={n['name']:{'ast':n,'unit':'actor'} for n in nodes[0]['inner'] if n.get('name')=='actor_transport' and n.get('kind')=='FunctionDecl'}
m.c.CHOICES['actor_transport']=[];m.c.TERNARY['actor_transport']=[]
obj=m.Counter(fs,{'actor':{'data':source.read_bytes()}},'',nodes,{},unit_nodes={'actor':nodes},contextual_operands=True)
try:obj.run('actor_transport');raise AssertionError('real actor aggregate admitted')
except RuntimeError as error:
    assert 'aggregate' in str(error)
    outcome={'status':'UNSUPPORTED','reason':str(error),'no_scalar_actor_model':True}
layout=common+['-fsyntax-only','-Xclang','-fdump-record-layouts-complete',str(source)]
l=subprocess.run(layout,cwd=m.c.R,capture_output=True,text=True,check=True)
(E/'actual-MSVC-C11-actor.layout').write_text(l.stdout+l.stderr)
after=d.inventory(common,source,m.c.R);d.compare(before,after);d.verify_files(before)
(E/'actual-MSVC-C11-actor.inputs.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
outcome.update({'command':cmd,'layout_command':layout,'actual_size_align_assertions':'actual compiler sizeof(thrd_t)==16, _Alignof(thrd_t)==8 succeeded','inputs_sha256':hashlib.sha256((E/'actual-MSVC-C11-actor.inputs.json').read_bytes()).hexdigest()})
(E/'actual-MSVC-C11-actor.result.json').write_text(json.dumps(outcome,indent=2)+'\n')
m.verify_inherited()
print('PASS actual primary MSVC+C11 actor16/8 remains UNSUPPORTED')
