import sys,pathlib,json,hashlib,subprocess,shutil
sys.dont_write_bytecode=True
E=pathlib.Path(__file__).parent;B=E.parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
# Pin immutable inherited modules/manifests, not old output regeneration scripts.
pins={}
for folder in ['architect-source-counter-v2a','architect-enum-switch-method-v1b','architect-source-counter-scalar-v1c','architect-source-counter-scalar-v1d']:
    for p in (B/folder).iterdir():
        if p.suffix=='.py' or p.name in {'manifest.json','inherited.json','SHA256SUMS'}:pins[str(p)]=sha(p)
for p in [B/'reviewer-ordinary-gen-frozen-v2-manifest.json',B/'critic-session-root-context-method-plan.md',B/'architect-session-bridge-packet-root-audit.md',B/'architect-session-bridge-all-phase-root-refinement.md',pathlib.Path('/srv/home/joykim/.tmp/2300-operator-recovery-next/docs/MEMORY.md')]:pins[str(p)]=sha(p)
if (E/'inherited.json').exists():assert json.loads((E/'inherited.json').read_text())==pins
else:(E/'inherited.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
import context_counter as m
c=m.c
import dependency_binding as dependency
ANNOTATIONS={'fixture_one':{'enum':'Kind_t','input':'K0','selector':'state'}}
POS=['assignment','initialization','comparison','bare_truth','not_truth','logical','ternary','arithmetic','repeated','call_argument','field_address_argument','returned','pointer_leaf','enum_leaf','one_arrow_dot','local_record','fixture_one','nested_consumers','separate_consumers']
NEG=['two_arrow','pointer_chase','dynamic_index','cast_base','call_base','side_base','global_base','static_base','volatile_leaf','atomic_leaf','volatile_base','hidden_qual','hidden_atomic','bitfield','packed','pragma_packed','packed_path','union_path','vector_leaf','oversized','array_leaf','complex_leaf','standalone','aggregate','actor_aggregate','native_atomic','compound','increment','standalone_address','pointer_arithmetic','void_expression','aggregate_assignment','discarded_comma','direct_field_switch']
compiler=pathlib.Path(shutil.which('clang')).resolve()
manifest={'metric':'default-OFF contextual scalar operand upper PROTOTYPE ONLY','compiler':{'path':str(compiler),'sha256':sha(compiler),'version':subprocess.run([str(compiler),'--version'],capture_output=True,text=True,check=True).stdout},'profiles':{},'inherited_sha256':sha(E/'inherited.json'),'production_counts':False}
passed=0
for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
    target='x86_64-pc-windows-msvc' if profile in ['MSVC-C11','Windows-native'] else 'x86_64-pc-linux-gnu'
    common=[str(compiler),'--target='+target,'-std=c11']+(['-DWL_HAVE_C11_THREADS=1'] if profile in ['C11','MSVC-C11'] else [])
    binding_before=dependency.inventory(common,E/'context_fixture.c',c.R)
    cmd=common+['-fsyntax-only','-Xclang','-ast-dump=json',str(E/'context_fixture.c')]
    p=subprocess.run(cmd,capture_output=True,text=True);(E/(profile+'.stderr')).write_text(p.stderr);assert p.returncode==0,p.stderr
    (E/(profile+'.ast.json')).write_text(p.stdout)
    macros=subprocess.run(common+['-dM','-E',str(E/'context_fixture.c')],capture_output=True,text=True,check=True).stdout
    (E/(profile+'.macros')).write_text(macros)
    deps=subprocess.run(common+['-M',str(E/'context_fixture.c')],capture_output=True,text=True,check=True).stdout
    (E/(profile+'.dependencies')).write_text(deps)
    nodes=[json.loads(p.stdout)];c.register_types(nodes)
    fs={n['name']:{'ast':n,'unit':'fixture'} for n in nodes[0]['inner'] if n.get('kind')=='FunctionDecl' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[]))}
    for name in fs:c.CHOICES[name]=[True] if name in ['comparison','bare_truth','local_truth','pointer_truth','call_truth','not_truth','logical'] else [];c.TERNARY[name]=[True] if name=='ternary' else []
    def obj(enabled=False,actualnodes=None):return m.Counter(fs,{'fixture':{'data':(E/'context_fixture.c').read_bytes()}},'',nodes,ANNOTATIONS,unit_nodes={'fixture':actualnodes or nodes},contextual_operands=enabled)
    def count(name,enabled=False):
        o=obj(enabled)
        try:o.run(name);status='COUNTED_UPPER'
        except RuntimeError as e:status='UNSUPPORTED: '+str(e)
        return o,status
    rows={};checks=[]
    for name in POS+NEG+['local_truth','pointer_truth','call_truth','caller_scope']:
        old,oldstatus=count(name);new,status=count(name,True)
        inherited=m.previous.Counter(fs,{'fixture':{'data':(E/'context_fixture.c').read_bytes()}},'',nodes,ANNOTATIONS,unit_nodes={'fixture':nodes})
        try:inherited.run(name);inheritedstatus='COUNTED_UPPER'
        except RuntimeError as e:inheritedstatus='UNSUPPORTED: '+str(e)
        assert oldstatus==inheritedstatus and old.events==inherited.events and old.calls==inherited.calls,('default changed',profile,name)
        absorbed=[e for e in new.operand_audit if e['classification']=='absorbed']
        if name in POS:assert status=='COUNTED_UPPER' and absorbed,(profile,name,status)
        if name in NEG:assert not absorbed,(profile,name,absorbed)
        if status=='COUNTED_UPPER' and oldstatus=='COUNTED_UPPER':
            fronts=lambda o:[e for e in o.events if e['kind'] not in {'address_front','indirect_scalar_read','truth_predicate_front'}]
            assert fronts(old)==fronts(new),('real operation lost',profile,name)
            assert sum(e['cells'] for e in new.events)==sum(e['cells'] for e in old.events)-sum(e['old_cells'] for e in absorbed)+len(new.truth_audit)
        rows[name]={'old_status':oldstatus,'new_status':status,'old_events':old.events,'new_events':new.events,'old_cells':sum(e['cells'] for e in old.events),'new_cells':sum(e['cells'] for e in new.events),'operand_ledger':new.operand_audit,'truth_ledger':new.truth_audit,'old_calls':old.calls,'new_calls':new.calls}
        checks.append('default-equivalence/ownership/fronts:'+name)
    for name in ['bare_truth','local_truth','pointer_truth','call_truth','ternary']:assert len(rows[name]['truth_ledger'])==1,(profile,name)
    assert len(rows['logical']['truth_ledger'])==3
    assert not rows['comparison']['truth_ledger'] and not rows['not_truth']['truth_ledger']
    assert len([x for x in rows['repeated']['operand_ledger'] if x['classification']=='absorbed' and x['absorbed_kind']=='indirect_scalar_read'])==2
    assert not [x for x in rows['caller_scope']['operand_ledger'] if x['classification']=='absorbed' and x['function']=='callee_standalone']
    checks+=['bare-truth-fronts','logical-all-three-truth-leaves','comparison-and-not-no-extra-predicate','repeated-occurrences','callee-context-does-not-bleed']
    other_run=subprocess.run(cmd,capture_output=True,text=True,check=True)
    other=other_run.stdout;(E/(profile+'.other-compile.ast.json')).write_text(other)
    (E/(profile+'.other-compile.stderr')).write_text(other_run.stderr)
    try:obj(True,[json.loads(other)]);raise AssertionError('cross TU accepted')
    except RuntimeError as e:assert 'actual same TU' in str(e)
    filtered=common+['-fsyntax-only','-Xclang','-ast-dump=json','-Xclang','-ast-dump-filter=returned',str(E/'context_fixture.c')]
    f=subprocess.run(filtered,capture_output=True,text=True,check=True);(E/(profile+'.missing-field.ast.jsons')).write_text(f.stdout)
    (E/(profile+'.missing-field.stderr')).write_text(f.stderr)
    selected=list(c.objects(f.stdout));fns={'returned':{'ast':selected[0],'unit':'filtered'}}
    missing=m.Counter(fns,{'filtered':{'data':(E/'context_fixture.c').read_bytes()}},'',selected,{},unit_nodes={'filtered':selected},contextual_operands=True);missing.run('returned')
    assert not [x for x in missing.operand_audit if x['classification']=='absorbed']
    checks+=['separate-real-compile-TU-rejected','actual-filtered-missing-field-old-covered']
    assert rows['actor_aggregate']['new_status'].startswith('UNSUPPORTED')
    checks+=['actor-aggregate-remains-unsupported']
    (E/(profile+'.results.json')).write_text(json.dumps(rows,indent=2)+'\n')
    (E/(profile+'.tests.log')).write_text('\n'.join('PASS '+x for x in checks)+'\n')
    binding_after=dependency.inventory(common,E/'context_fixture.c',c.R)
    dependency.compare(binding_before,binding_after);dependency.verify_files(binding_before)
    (E/(profile+'.inputs.json')).write_text(json.dumps(binding_before,indent=2,sort_keys=True)+'\n')
    manifest['profiles'][profile]={'input_binding_sha256':sha(E/(profile+'.inputs.json')),'command':cmd,'filtered_command':filtered,'source_sha256':sha(E/'context_fixture.c'),'ast_sha256':sha(E/(profile+'.ast.json')),'macro_sha256':sha(E/(profile+'.macros')),'dependency_sha256':sha(E/(profile+'.dependencies')),'input_files':{str(E/'context_fixture.c'):sha(E/'context_fixture.c')},'checks_passed':len(checks),'positive_contexts':len(POS),'negative_contexts':len(NEG),'results_sha256':sha(E/(profile+'.results.json'))}
    passed+=len(checks)
m.verify_inherited()
manifest['total_checks_passed']=passed
(E/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(E/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(E.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('PASS',passed,'checks across4 actual full-TU profiles; no production totals')
