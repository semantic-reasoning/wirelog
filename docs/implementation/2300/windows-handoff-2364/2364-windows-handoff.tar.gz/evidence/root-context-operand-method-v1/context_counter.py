"""Default-OFF contextual scalar-operand upper prototype. No production fit.
Inherits unchanged v1d; no new actor ABI/RMW/byte-copy semantics.
"""
import sys,pathlib,json,hashlib,re
sys.dont_write_bytecode=True
E=pathlib.Path(__file__).parent
BASE=E.parent

def verify_inherited():
    for path,digest in json.loads((E/'inherited.json').read_text()).items():
        if hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('context-v1: inherited bytes changed: '+path)
verify_inherited()
sys.path.insert(0,str(BASE/'architect-source-counter-scalar-v1d'))
import increment_counter as previous
c=previous.c
walk=previous.walk
typ=previous.typ

class Counter(previous.Counter):
    def __init__(self,*args,contextual_operands=False,**kwargs):
        super().__init__(*args,**kwargs)
        if contextual_operands and (self.enabled_functions or self.increment_functions):
            raise RuntimeError('context-v1: scalar prototype does not enable compound/increment opt-ins')
        self.contextual_operands=contextual_operands
        self.ownership={};self.truth={};self.operand_audit=[];self.truth_audit=[]
        if contextual_operands:
            for name,fn in self.fs.items():self._catalog(name,fn)

    @staticmethod
    def _strip(n):
        while n.get('kind') in {'ParenExpr','ImplicitCastExpr'}:
            if n.get('kind')=='ImplicitCastExpr' and n.get('castKind') not in {
                'LValueToRValue','NoOp','IntegralCast','IntegralToBoolean',
                'PointerToBoolean','FloatingToBoolean','FunctionToPointerDecay'}:
                return n
            if len(n.get('inner',[]))!=1:return n
            n=n['inner'][0]
        return n

    def _catalog(self,name,fn):
        unit=fn['unit'];root=fn['ast']
        if root.get('isInvalid') or any(q.get('isInvalid') for q in walk(root)):
            raise RuntimeError('context-v1: invalid actual compiler AST')
        roots=self.unit_nodes.get(unit,[])
        if not any(root is q for r in roots for q in walk(r)):
            raise RuntimeError('context-v1: function not in actual same TU')
        self.ownership[name]={};self.truth[name]=set()
        # Native primitive interiors retain their inherited independent metric.
        if name in c.NATIVE or name.startswith(('wl_mutex_','wl_atomic_')):
            return
        decls={q.get('id'):q for q in walk(root) if q.get('kind') in {'ParmVarDecl','VarDecl'}}
        fields=self.fields.get(unit,{})
        enums={q.get('name'):q for r in roots for q in walk(r) if q.get('kind')=='EnumDecl' and any(x.get('kind')=='EnumConstantDecl' for x in q.get('inner',[]))}
        def ordinary_enum(q):
            e=enums.get(q.removeprefix('enum '))
            if not e:return False
            underlying=e.get('fixedUnderlyingType',{}).get('qualType')
            if underlying and underlying not in {'int','unsigned int','long','unsigned long','long long','unsigned long long'}:return False
            values=[int(x['value']) for x in walk(e) if x.get('kind')=='ConstantExpr' and 'value' in x]
            return all(-(1<<63)<=v<(1<<64) for v in values)
        qualifiers=re.compile(r'\bvolatile\b|\brestrict\b|_Atomic|address_space')
        def eligible(n):
            path=[];q=n;arrows=0
            while q.get('kind')=='MemberExpr':
                if len(q.get('inner',[]))!=1:return False,'unknown member shape',[]
                field,record,forbidden=fields.get(q.get('referencedMemberDecl'),({}, {}, True))
                if not field or forbidden or not record.get('completeDefinition'):
                    return False,'missing/incomplete/union/packed same-TU field',[]
                if field.get('isBitfield') or qualifiers.search(typ(field)) or qualifiers.search(typ(q)):
                    return False,'qualified or bitfield path',[]
                if any(x.get('kind') in {'PackedAttr','MaxFieldAlignmentAttr'} for x in record.get('inner',[])):
                    return False,'packed record path',[]
                if arrows and q.get('isArrow'):
                    return False,'multiple pointer indirections',[]
                arrows+=bool(q.get('isArrow'));path.append(q)
                base=q['inner'][0]
                # Ordinary LValue conversions/paren only; no cast/base arithmetic/index/call.
                while base.get('kind') in {'ImplicitCastExpr','ParenExpr'}:
                    if base.get('kind')=='ImplicitCastExpr' and base.get('castKind') not in {'LValueToRValue','NoOp'}:
                        return False,'nontrivial member-base conversion',[]
                    if qualifiers.search(typ(base)) or len(base.get('inner',[]))!=1:
                        return False,'qualified/unknown base',[]
                    base=base['inner'][0]
                if qualifiers.search(typ(base)):return False,'qualified base',[]
                # A dot after arrow is allowed; arrow through an embedded pointer is not.
                if q.get('isArrow') and base.get('kind')=='MemberExpr':
                    return False,'pointer-valued member dereference',[]
                q=base
            if q.get('kind')!='DeclRefExpr':return False,'computed/global/indirect base',[]
            d=decls.get(q.get('referencedDecl',{}).get('id'))
            if not d or d.get('storageClass') in {'static','extern'}:
                return False,'not an automatic local/parameter base',[]
            if qualifiers.search(typ(d)) or qualifiers.search(typ(q)):
                return False,'qualified automatic base',[]
            leaf=typ(n)
            scalar=(bool(re.fullmatch(r'(?:const )?(?:_Bool|bool|char|signed char|unsigned char|short|unsigned short|int|unsigned int|long|unsigned long|long long|unsigned long long|__int64|unsigned __int64|float|double)',leaf))
                or (leaf.startswith('enum ') and ordinary_enum(leaf)) or (leaf.endswith('*') and not qualifiers.search(leaf)))
            if not scalar:return False,'unknown/aggregate/vector/oversize scalar leaf',[]
            if qualifiers.search(leaf):return False,'qualified scalar leaf',[]
            return True,'same-TU complete ordinary scalar path; <=one arrow then embedded dots',path

        def path_proof(path):
            return [{'member_node_id':q.get('id'),'field_decl_id':q.get('referencedMemberDecl'),'record_decl_id':fields[q.get('referencedMemberDecl')][1].get('id'),'member_type':typ(q),'field_type':typ(fields[q.get('referencedMemberDecl')][0]),'record_complete':fields[q.get('referencedMemberDecl')][1].get('completeDefinition'),'is_arrow':q.get('isArrow',False)} for q in path]

        # Lexical ownership keyed to actual node identity and function; no ambient
        # caller context can enter an expanded callee activation.
        def truth(n):
            q=self._strip(n)
            if q.get('kind')=='BinaryOperator' and q.get('opcode') in {'&&','||'}:
                for child in q.get('inner',[]):truth(child)
            elif not (q.get('kind')=='BinaryOperator' and q.get('opcode') in {'==','!=','<','>','<=','>='}) and not (q.get('kind')=='UnaryOperator' and q.get('opcode')=='!'):
                self.truth[name].add(id(n))
        def visit(n,owner=None,blocked=False):
            k=n.get('kind');cs=n.get('inner',[])
            if k=='AtomicExpr':blocked=True
            if k=='CallExpr' and cs and self.name(cs[0]) in c.NATIVE:blocked=True
            if k in {'IfStmt','ConditionalOperator'} and cs:truth(cs[0])
            if k=='BinaryOperator' and n.get('opcode') in {'&&','||'}:
                for child in cs:truth(child)
            new=(n,'truth_predicate') if id(n) in self.truth[name] else owner
            if k=='VarDecl' and cs:new=(n,'initialization')
            elif k=='ReturnStmt':new=(n,'return')
            elif k=='SwitchStmt':new=(n,'switch_selector')
            elif k=='IfStmt':new=(cs[0],'predicate')
            elif k=='ConditionalOperator':new=(n,'conditional')
            elif k=='CallExpr':new=(n,'call_argument')
            elif k=='BinaryOperator' and n.get('opcode')!=',':new=(n,'assignment' if n.get('opcode')=='=' else 'operator')
            elif k=='UnaryOperator' and n.get('opcode') not in {'&'}:new=(n,'unary_operator')
            if k=='MemberExpr':
                ok,reason,path=eligible(n)
                # Only a scalar leaf can grant coverage for intermediate address nodes.
                kinds=['address_front']
                entry={'function':name,'unit':unit,'node_id':n.get('id'),'type':typ(n),'consumer_id':new[0].get('id') if new else None,'consumer_kind':new[1] if new else None,'eligible':ok and bool(new) and not blocked,'reason':('excluded enclosing cast/index/dereference/native primitive' if blocked else reason) if new else 'standalone/no real scalar consumer','path_proof':path_proof(path) if ok else []}
                self.operand_audit.append(dict(entry,classification='candidate'))
                if entry['eligible']:
                    for p in path:self.ownership[name][(id(p),'address_front')]=entry
            if k=='ImplicitCastExpr' and n.get('castKind')=='LValueToRValue' and cs:
                child=cs[0]
                if child.get('kind')=='MemberExpr':
                    ok,reason,path=eligible(child)
                    if ok and new and not blocked:
                        entry={'function':name,'unit':unit,'node_id':n.get('id'),'type':typ(n),'consumer_id':new[0].get('id'),'consumer_kind':new[1],'eligible':True,'reason':reason,'path_proof':path_proof(path)}
                        self.ownership[name][(id(n),'indirect_scalar_read')]=entry
            # Block standalone dereference/index/base cast and aggregate movements,
            # even when some nested member alone would look simple.
            childblocked=blocked or (k=='MemberExpr' and not eligible(n)[0]) or k in {'ArraySubscriptExpr','CStyleCastExpr'} or (k=='UnaryOperator' and n.get('opcode')=='*')
            for index,child in enumerate(cs):
                childowner=new
                if k in {'CompoundStmt','FunctionDecl'}:childowner=None
                if k=='IfStmt' and index>0:childowner=None
                if k=='BinaryOperator' and n.get('opcode')==',' and index==0:childowner=None
                visit(child,childowner,childblocked or (k=='CallExpr' and index==0) or (k=='BinaryOperator' and n.get('opcode')==',' and index==0))
        visit(root)

    def emit(self,n,kind,count=1,note=''):
        name=self.stack[-1]['name'] if self.stack else None
        entry=self.ownership.get(name,{}).get((id(n),kind)) if self.contextual_operands else None
        if entry and count:
            self.operand_audit.append(dict(entry,classification='absorbed',absorbed_kind=kind,old_cells=count,new_cells=0,activation_depth=len(self.stack)))
            return
        return super().emit(n,kind,count,note)

    def expr(self,n):
        if self.contextual_operands and self.stack and id(n) in self.truth.get(self.stack[-1]['name'],set()):
            self.emit(n,'truth_predicate_front',1,'actual bare scalar truth conversion; separate dispatch/connector retained')
            self.truth_audit.append({'function':self.stack[-1]['name'],'node_id':n.get('id'),'type':typ(n),'new_cells':1,'reason':'bare truth needs explicit predicate after operand absorption'})
        return super().expr(n)
