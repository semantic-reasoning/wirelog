import sys,pathlib,json,hashlib
sys.dont_write_bytecode=True
E=pathlib.Path(__file__).parent
import context_counter as m
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m.verify_inherited()
manifest=json.loads((E/'manifest.json').read_text())
manifest['method_module']={'path':str(E/'context_counter.py'),'sha256':sha(E/'context_counter.py'),'default_contextual_operands':False,'RMW_optins_in_new_mode':'rejected','actor_ABI_model':'not implemented'}
manifest['actual_primary_actor_negative']=json.loads((E/'actual-MSVC-C11-actor.result.json').read_text())
manifest['actual_primary_actor_negative']['result_sha256']=sha(E/'actual-MSVC-C11-actor.result.json')
manifest['total_checks_with_actual_actor']=manifest['total_checks_passed']+1
manifest['limitations']=['prototype awaiting independent method review; no production counts','upper-only logical operation metric, not performed lower/carry/Source cut or tariff','old logical connectors/all enum labels retained; truth leaves are explicit additional fronts','direct-field enum switch remains inherited unsupported shape; approved local-selector switch front is unchanged','RMW/new actor ABI not implemented; primary MSVC+C11 actor16/8 remains unsupported','excluded operands retain old coverage or unsupported status; no false eligible claim for deep/native/qualified movement']
manifest['inherited_after_verification']='PASS; all pinned old modules/manifests/seals/docs byte-identical'
(E/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(E/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(E.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
for line in (E/'SHA256SUMS').read_text().splitlines():
    h,name=line.split('  ',1);assert sha(E/name)==h
m.verify_inherited()
print('SEALED',manifest['total_checks_with_actual_actor'],'checks; seal',sha(E/'SHA256SUMS'))
