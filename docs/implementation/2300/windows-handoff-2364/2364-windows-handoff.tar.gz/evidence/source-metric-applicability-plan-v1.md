# implementation_plan: qualify the actual Root Source consumers under one metric

Independent Architect evidence audit and plan only. A DIFFERENT Critic must judge this plan before any counter-semantic or engine edit. No engine/runtime, Root source, inherited counter, provider registry, fee/cap/guard, commit or PR change was made.

## Decision

The raw AST-node totals225/254/259 are **not lower bounds of the independently accepted contextual scalar-cell method**. They cannot establish the necessity of two, three or four FINAL phases. Conversely, the new80/93 Source32 path totals do not show that the original Root callbacks fit. Replaying the original Root helper with the unchanged contextual counter gives a230-cell complete selected **source upper** before parent-specific validation or containing caller work. This does not qualify CURRENT224 or Snapshot144 and is not a performed-work lower or proof that a protocol split is necessary.

Resolve the exact method/type coverage and qualify the actual twelve Root bodies first. Keep Source32 experiments isolated. Do not port four phases on the strength of unlike node counts, and do not assume a smaller proposed method result without implementation, genuine fixtures and independent review.

## Bound inputs and accepted versus unaccepted claims

Root source is `/srv/home/joykim/.tmp/2300-operator-recovery-next/wirelog/columnar/session.c`, SHA256 `6b5196c17efca57b12dfde773ef8132bbd8433316bec8af1b340329272566182`, in the held Root candidate3b54717ab11570eb3db4d8c89b9f75c947ee08b0. I read the actual quiet helper, root/shape/history/report helpers and all twelve quiet-consuming bodies, plus their actual FINAL/Snapshot dispatch. `source-metric-applicability-v1/actual-functions.json` SHA256 `a31e1a5bcaa3b3cca31c9417b0fbd48942b96d53e1f4eb05030d890dd0783826` binds real FunctionDecl IDs, byte ranges, function hashes and complete source for those consumers.

Inherited contextual module `root-context-operand-method-v1/context_counter.py` SHA256 `90879bc2b89c49b2829aeb90a3115a8fc5ef6f01bf8d9e57a03b7a94f869d0c1` and Native module `prepared-native-packet-method-v1/native_counter.py` SHA256 `fb20ab5b886f4f2e755fb98dff0b6653af88860ea169efd3cd5205df0786f4d3` were read, not edited. `critic-root-context-operand-method-v1.md` explicitly approves the default-OFF method implementation for its declared supported contexts, after genuine four-profile fixture replay. DEFAULT OFF means opt-in and scoped applicability, not that the reviewed method must be discarded. It does **not** confer a production number, body fit, Source price/cut, ABI permission or candidate approval. The later `critic-root-context-session-packet-audit-v1.md` approves only its old exact scoped actual Root upper audit, with remaining packet/global qualification blocked. Its old274..297 whole-Root maxima are not current2367/2368 numbers or a reason to implement unrelated2370 work.

The contextual method absorbs only eligible actual same-TU ordinary scalar member address/read events into their real initialization/store/operator/predicate/call-argument/return owner. It retains actual operators, logical connectors, calls/arguments, declarations/stores/returns, control/dispatch and explicit bare-truth fronts. Repeated occurrences remain repeated. No generic common-subexpression or primitive-interior discount exists. Therefore a raw sum of address+load+OR nodes mixes independently charged fronts with fronts the reviewed method assigns to a scalar consumer.

Source32 four-phase candidate705813930691320ad2c9ad201160f651b0546b74/Source53d56cb5 is a different source, not Root. Read its full report `source32-parent-four-final-v1/report-blocked-v1.md` SHAc5c0bae9eeb14bc6718fb3ae39c0d9320e515bedfeabe4d82ccc9a380e6d05da and actual replay driver. Its80 R1/93 CHECK totals are individual expanded source paths, not all-branch/prepaid-front/ABI/payer224 certificates. The four-phase protocol changes call/report history and is not made necessary by any raw-node diagnostic.

## Fresh unchanged-method Root evidence

I created only new evidence capture/replay drivers. Three genuine full production TUs were captured using the actual Root `build/compile_commands.json` **libwirelog.so** commands and cwd, preserving actual-O2 flags, target macros and primary headers, without test hooks or O0 normalization. Only object/dependency output switches were removed to request AST/macros/dependencies; no macro/type/source replacement was introduced. All nine actual compiler commands succeeded; source hashes were stable before/after. No engine binary was run.

| Actual capture | SHA256 of capture receipt |
|---|---|
| Columnar full TU |7322bec2ebad569d527189b9a67a00db0f5a39d969952c3c403bc106ecd959ff|
| CoreControl full TU |ca84da36795e6b2506f07c30562c0b261745693451a0866ac16ad54c04daa3c1|
| CoreSource full TU |e28cc977687a7072222137db3045637d3c5cd7bd06db3773020e84fbe502e02d|

All files are under `source-metric-applicability-v1/`. Each receipt records exact original production command, actual capture command/cwd, stdout/stderr hashes and source digest. These captures establish source/type provenance, not complete ABI/resource acceptance or Windows evidence. The equality header body selected under these genuine-O2 macros must be source-expanded when reached; normalized-O0 declaration-only equality is not a substitute.

The replay uses unchanged `native_counter.Counter` with contextual operands explicitly enabled; aggregate/zero/increment opt-ins remain disabled. Its enum constructor receives exact actual function-closure objects, while **complete real TU roots** remain `unit_nodes` for every field/type/ownership proof. No AST was rewritten, no switch annotation was enabled and no Native/provider membership changed.

| Exact original helper contour | Actual result |
|---|---|
| `quiet`, full false absence condition, retirement-count-zero helper, parent=false |230 complete selected source cover; receipt3137556921024a29328e8a64e5284ea77d4d5c26ee92b29c2b617e3ed3b86db3|
| first-if refusal with same conservative condition cover |228 complete selected source cover; receipt6c531ae0ab70660acb6174c2661263716202c18ff8acb7a16840e8dcc30cd0f6|
| parent=true, full same absence front |BLOCKED at actual `thrd_current`; no upper; receipt71f1f592d876deb55ab5e1691b66eba5465bdf17d9b8be431add7d77099ff29a|

The first replay's v1 records retain fixture-driver mistakes: unused quiet ternary choices on flat paths, then a missing actor if-choice. V2 fixes only the driver's actual path choices; inherited source/counter bytes are unchanged. No partial sum from a failed record is promoted to an upper. The230 result includes the actual quiet prelude, complete condition and selected retirement helper/return; it omits the parent body by its real `if (!parent)` return, and is not any twelve-body/caller certificate.

The230 cover contains40 retained address,25 retained indirect-read,66 truth,74 operator,14 unary,4 declaration,1 argument,1 call,3 if and2 return cells. It separately records79 absorbed address and50 absorbed indirect-read occurrences. Both retained and absorbed occurrence ownership remain inspectable.

### Concrete type-coverage limitation, not permission to silently discount

Many retained reads have actual MemberExpr types such as `wl_columnar_eval_stack_cleanup_frame_t *const`, `wl_evaluation_control_t *const`, `wl_col_session_t *const` and `const void *const`, produced by reading pointer-valued members through the actual `const` record parameter. The original classifier recognizes a pointer with `leaf.endswith('*')`; a top-level-const pointer does not satisfy that predicate. Actual `const enum ...` leaves likewise miss its `leaf.startswith('enum ')` test. They remain conservatively charged. This is a declared classifier limitation, not proof of extra engine work or a compiler error. Mutable Source32 access paths can classify differently, so its smaller totals cannot be projected back onto these Root helpers.

Do not remove Source const qualifiers, insert casts, rewrite AST type strings, silently treat the old mode as supporting these leaves, or subtract65 globally. Any broader qualification must be an explicit independently reviewed method extension with exact actual types/occurrences and unchanged other fronts.

## Proposed minimal implementation sequence

### Unit A: exact ordinary top-level-const scalar member coverage

A DIFFERENT Critic first decides whether to accept this narrow extension of the existing contextual **metric**, rather than financial staging solely to accommodate the classifier. If rejected, retain the unchanged230 cover and independently choose an engine refinement from complete body results; do not claim necessity from an upper alone.

If accepted, implement a NEW evidence-only sibling module, DEFAULT OFF, leaving all inherited files/seals untouched. Its opt-in catalog adds only these actual ordinary contexts:

1. An actual pointer-valued MemberExpr whose otherwise-supported complete same-TU field path acquires **only top-level const** from its containing ordinary const record, with its actual enclosing LValueToRValue/real scalar consumer and unchanged pointer value/type after that standard conversion. Preserve original qualType, FieldDecl/RecordDecl IDs and actual conversion in the receipt. Require the genuine field declaration/type and all existing path checks. Do not erase pointee qualification, volatile/restrict/_Atomic/address-space, packing, bitfield or alias/extent information.
2. An actual const-qualified ordinary enum leaf, bound unambiguously to the same genuine EnumDecl/FieldDecl and supported underlying type/value range, consumed by the same existing scalar operators/truth/return rules. Unknown/ambiguous/foreign enum identity refuses. No selector value or switch-domain support follows from this enum-leaf classification.

Only address/read ownership can change, using the existing consumer rule. Keep every actual truth/operator/connector/call/argument/return/store/dispatch/declaration and every repeated occurrence. Ordinary const arithmetic is not free work; the method changes operand ownership consistently with its already approved const-integer context. Native primitives, atomics and mutex/atomic wrappers keep their independent metrics. Pointer-valued-member **dereference**/multiple arrows, casts/index/computed/global/static/side-effect bases, standalone discarded fields/comma-left and all previously excluded contexts remain excluded. Do not manufacture a cheaper actor ABI, aggregate copy or provider interior.

Compile genuine fixtures: actual top-level-const pointer and enum reads in real scalar consumers, repeated occurrences, callee context isolation, actual bare-truth preservation, and all negatives above. Verify default-OFF exact event equivalence to the pinned parent; verify all non-address/read/truth-front identities, exact new owned occurrence bindings and unchanged conservative accounting elsewhere. Include missing/mutated field/record/enum/type IDs and const-volatile/restrict/atomic/packed/union/bitfield/address-escape negatives. Reuse genuine MSVC primary declarations for type/ABI negatives; fixture success is not full actor support. No production counts until separate independent RAW/method review accepts the new module/results.

The new trusted-platform adapter is a separate accepted-method implementation in progress. Compose only its exact subsequently reviewed bytes/API, with explicit source-inline versus external-P classification and complete argument/result ABI. Do not alter `NATIVE`, treat a name as a certificate, or use Root79ac provider receipts as a9caf caller binding. Method composition must retain both ledgers/registries and receive independent review before use.

### Unit B: actual Root twelve-consumer qualification before protocol changes

After Unit A is independently accepted (or explicitly declined), replay actual Root sources under ONE declared method. Start C11/POSIX production actual macros and then applicable actual Windows profiles. Bind genuine full TUs, complete same-TU fields/enums, header inline bodies, provider C/P occurrences, all aggregate/zero/actor semantic and ABI transfers and fixed typed payload/whole-Step extents. Existing aggregate/zero methods require their real CapturedProof/effect/alias/lifetime inputs; do not silently enable them merely because a body contains a struct initializer. Failed forced MSVC-C11 guard captures remain failed/no count input pending genuine applicability and finite Native repair.

The eleven FINAL consumers at CURRENT224 are parent_closed, end_original, reset_original, ready, retry_begin, retry_end, retry_reset, retry_ack, quiet_read, forget_dirty_history and close_discard (all prefixed `wl_columnar_session_observer_error_`). The twelfth, snapshot_retire, is the actual outer Snapshot metadata144 action. Preserve actual208/224/80 and208/144/80 policies and all caps; do not give Snapshot an unowned FINAL issuer.

For every consumer derive full success plus each real phase/shape/root/history/report/quiet/actor/refusal branch, Original active/inactive/failed begin/finish/report paths, malformed/pending return and actual OPERATION/CLOSE/Snapshot selection. Every positive debit must own exact later work; denied/prepositive fronts, result transport, report/unlock/return and mandatory cleanup need genuine prior payers. Body-only source covers do not settle those containing intervals. Keep actual STOP/error/report history and full-C/P maxima visible. Use existing reviewed Source role/output/caller closure only with exact new-source rebind; no hypothetical universal private-writer proof is needed, and no real newly enabled writer may be omitted.

Dispatch independent result/method review for this exact matrix. A remaining unsupported operation is a named stop with one targeted next proposal, not permission for an unlimited method expansion. Review only newly enabled2367/2368 intervals and explicit sibling handoff; do not pull unrelated global2370 ROOT/ROW or2369 RUNNING/FINISH work into this bundle.

### Unit C: refine engine only where the complete matrix warrants it

Only after the common metric/body comparison, choose the smallest coherent Source protocol change that satisfies actual remaining bounds. Existing Source32 candidate is available for comparison, not preapproved integration. Four phases, repeated512 reports and temporal CHECK-to-BODY fact reuse require their own exact proof; they are not automatically necessary or cheaper than two/three phases or a shared bounded predicate schedule.

If a staged unsigned quiet_predicate switch remains necessary, plan a separate DEFAULT-OFF exact domain: real constant0..14 thunks, immutable unsigned parameter forwarding through actual FunctionDecl/ParmVarDecl IDs, no selector writes/address escape or arbitrary callbacks, all real labels/defaults/terminal returns and exact chosen arm. Preserve real selector/dispatch/control and conservative case-label costs for all alternatives; no generic width8 or enum coupon, no invented no-fallthrough claim. The actual switch body and mapper must be inspected, with missing/changed literal, hidden label, mutation, overflow/promotion, wrong thunk/cell and unknown default negatives. DIFFERENT Critic must approve before implementing that domain. It is unnecessary for qualifying the unchanged Root helper, which contains no such unsigned switch.

## Limits and handoff

The old raw-node lower claims are corrected, not replaced with a smaller fabricated certificate. Fresh230/228 are selected helper source uppers under unchanged accepted contextual mode; parent and whole-body maxima remain blocked. The proposed const-scalar domain is **not implemented or approved**. No new stage count, bound, fee, cap, provider, runtime or Root adoption is accepted here. Real integrated Windows/MSVC, route/lifetime/resource tests, independent exact-tree RAW followed by distinct final design/risk and normal atomic commit gates still apply.

This plan and all captures/replays were created using the existing uv evidence virtualenv. Only compiler/static evidence was executed. No inherited evidence was regenerated or altered, and no independent Critic/RAW/final approval of this artifact is asserted by its author.
