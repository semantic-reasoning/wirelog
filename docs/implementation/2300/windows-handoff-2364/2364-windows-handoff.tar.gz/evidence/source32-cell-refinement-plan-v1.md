# implementation_plan: authenticate CELL, then execute its guarded predicate/body

Independent Architect proposal ONLY; a DIFFERENT Critic must approve before edits. This explicitly adds one finite genuine FINAL phase and revises guard lifetime/payment across the authentication/body boundary. No Core/Native/header/counter/provider/API/fee/cap change, Root port or fit is authorized by this proposal alone.

## Exact basis

Candidatece409f6948ea2582437442c232c1aeb9887d80b6; Sessiond5b2b308806610dbff922915e02230886c0f68557a615be6af6103cd6ca8041a; full report8b109564277de8f9f9d8354025e96e36eff4ad1dce2c0429abde5634082d1f6a and incremental raw74aba25f4f91d7c8c19864ef17b7f8c5b70581f9f0e3f802030827d29148aa0f read. Reviewed two-fallback composition2c548773 remains separate. Prior three-phase plan9d36abc8/critique8bcb and caller/role/output closure99431 are the temporal/effect basis; Root3b547/Source6b519 and its green functional runs do not qualify this experiment.

Healthy Q5 has254 unique known CELL events:133 auth +78 predicate prelude/Q5 +43 execution. This is not an upper; helper/provider/ABI/fronts remain missing. R1/R2 known114/141 are also not bounds. No254-minus78 calculation predicts either new phase.

## One finite Session-only source protocol revision

Keep R1 identity and R2 actor/scope/header/compact-guard logic unchanged. Split former CELL into **CHECK** and **BODY**, yielding exactly four sequential existing FINAL calls for the same selected Q cell in one backend invocation. No public return, durable new cursor, persistent proof flag or caller Boolean separates them. Select paired constant CHECK/BODY thunks from the same closed cell switch; unknown selection refuses as before.

**CHECK CURRENT224:** run the entire actual former quiet_cell_auth, including own TLS/self/cell, actual Session/Step/Original association, actual active Original id, four hybrid current head/mask/offer/BIND checks and the FULL Q0 inert or resumed identity/mode/cursor/origin/id/operation/failure-coherence condition. Preserve every predicate and short-circuit/refusal order. CHECK invokes no q hook and writes no Step/progress/marker. On authentication failure it removes only its exact owned TLS and returns EBUSY. On success it returns0 while leaving the R2-owned OUTER automatic guard live. Do not initialize a new `checked` flag or store an auth result in Step/payload.

**BODY CURRENT224:** reached only after actual CHECK action_called/phase_finished/financial0/action0, and its real report FINISH/rearm prerequisites. Before q BEFORE, require exact own TLS/self/cell and freshly recheck the actual current Original id against the same immutable e.original_id. Bind actual pointer/id/association reads needed to access it safely; no unchecked pointer or later payment supplies that lifetime. A mismatch pops only own TLS, returns EBUSY, and writes no journal or hook. Then execute byte-identical q BEFORE → selected predicate/old marker/cursor/Q14 body → q AFTER → own pop. Preserve the predicate's current source prelude/switch and all selected conditions initially; do not inline/hoist it or move a predicate across q BEFORE to fit. Q0 still captures no published history, same-cell success alone clears its marker, Q14 commits parent_closed without Original FINISH/Native authority, and q AFTER remains guarded after Q14 clears prefix.

BODY does not repeat the FULL CHECK progress/hybrid condition ONLY under the explicit same-activation proof below. It repeats current id because cancellation/lifecycle observations must remain honest at the last pre-hook point. All actual current/resume/hybrid predicates were executed in CHECK, not inferred from R1/R2 or a source receipt. If Critic requires any additional current revalidation, state and count it explicitly; no implicit omission is allowed.

## Exact new temporal/lifetime condition

The original compact owner lives in the same outer drive object through R1/R2/CHECK/BODY. Continuous TLS remains installed from successful R2 to BODY/owned refusal cleanup. Between CHECK return and BODY entry the actual selected Core FINAL finish/report/unlock, wrapper, issuer/observation_end/rearm/BEGIN/geometry graph has no arbitrary callback, role writer, Source-scope replacement, Step reset/free or OS-thread handoff. Rebind99431 actual caller/output/role graph and all new callback identities. TLS is same-thread exclusion, not a cross-thread lock; real public admission and exact foreign Source rejection remain required. A suspended outer old hook cannot run until the entire nested drive returns. Provider effects remain independently unqualified; unknown callbacks/TLS/actor effects invalidate reuse.

Thus progress/mode/failure/hybrid facts remain immutable from successful CHECK until q BEFORE. External Original cancellation is allowed and changes no cached q journal; real current-id checks and financial stops remain. A real admissible writer/free/phase change in that interval is STOP, not something made safe by a stale checked Boolean or isolated reread. No authentication survives a backend/public return; every retry restarts R1/R2/CHECK from current state.

This is an explicit revision to the former “CELL authenticates then runs body in the same callback” rule. It is not automatic authority from a completed Source report or membership in an old actor domain. The result gate is actual synchronous control flow and genuine called/finished results, not copied permission.

## Genuine four-attempt financial chronology

Each next call requires prior action_called, phase_finished, financial_result0 and action_result0. Existing FINAL physically FINISHes/verifies its actual report, clears context/running/callback state and unlocks; sealed class/lane/ref2/inactive/report_verified rearm and a real new BEGIN must succeed before the next CURRENT. Sticky cancel is not reset. Four normal phases each really charge208+224+80=512, total2048 across FOUR separate768 attempts; no2048-in-one-grant assertion or cap/tariff increase. This is explicit additional real work and report history, not old-consumption equivalence. Preserve first-parent-only one selected Q cell per public invocation.

A CHECK post-action finance failure may have performed authentication but no durable mutation; do NOT enter BODY. Pop owned guard using a genuine earlier payer, return the real pending/error mapping and repeat full checks on retry. BODY post-action finance failure may follow genuine marker/cursor/parent changes; preserve those changes and do not replay the performed cell. Body financial failure is not rolled back into unperformed state.

## Disjoint payer and effect obligations

- Incoming/R1 fronts remain on actual earlier caller payers. R1 pays its own successful return/next-R2 prepositive and denied-R2 alternatives as already specified.
- R2 CURRENT pays complete context/guard install and the next-CHECK prepositive/Core/denial/unlock/result path, including mandatory guard cleanup if CHECK never calls or R2 itself later financially fails. It cannot use future CHECK credit.
- CHECK CURRENT pays complete current/resume auth and its own auth-refusal pop/return, plus the fixed next-BODY prepositive/Core/denial/unlock/result/owned outer pop and actual failure return. If CHECK never succeeds as a positive payment, those costs stay with R2. A real CHECK payment preceding a later finance-stop remains actual consumed work; no refund is manufactured.
- BODY CURRENT pays the exact own/current-id front, hook/predicate/body/owned-pop/return and all actual success/refusal alternatives after its positive debit. Failed BODY supplies no credit for its denied front or outer cleanup: CHECK's preceding successful payment owns them.

Specify exact occurrence/path owners for the single actual outer cleanup; do not charge it twice to R2 and CHECK or omit it from both. Prefer explicit source branches with immediate owned cleanup for each failed phase, keeping no new prepayment-status initializer before CURRENT. If a new automatic status field is proposed, its initialization, effect extent and exact earlier payer require a separate explicit source decision. All scratch/payload/TLS/whole-Step geometries remain real and distinct; no TLS-in-Step claim or free enlarged payload.

## Required implementation and stopping gates

After independent Critic, new isolated Session sibling only: CHECK callback extraction, BODY pre-hook own/current-id check, finite paired thunks and fourth gated FINAL. Preserve R1/R2 clauses/guard, selected predicate/marker source and all writer/history/error/hook contracts. Complete predicate-union/order and exact flow/no-write-before-auth maps must prove no missing comparison. Other eleven consumers and Snapshot144 remain unapproved.

First fresh all4 production/hooks full TUs/SDK/IR/layout/provider/ABI, then COMPLETE R1/R2/CHECK/BODY224 plus208/80/caller/geometry/refusal/return maxima across all Q0..14 and malformed/cancel/finance alternatives. CHECK also owns real BODY denied fronts; R2 retains denied-CHECK duty. Old133/78/43 or114/141 cannot prove fit. MSVC size assertions and unknown provider boundaries remain OFF; do not suppress them. If any closure is unknown or overbudget, freeze the first real blocker and ONE next repair; no unplanned fifth stage, fee/cap rise, cheaper branch or counter extension.

After meaningful bounds and independent raw/method review, require genuine CHECK/BODY before/after-action financial refusal, no hook/marker on failed auth, performed-body nonreplay, TLS leak/reentry/foreign no-write, rightful OPERATION/CLOSE, same-cell marker recovery, Q14 after-hook exclusion and all original EIO/report7/retry/quiet/mutation/Snapshot/CLOSE/governor histories. Actual WindowsCI and final resource gates remain separate. No edit/build/runtime/Root port was performed for this plan.
