from pathlib import Path
import sys,json,hashlib,traceback
sys.dont_write_bytecode=True
E=Path(__file__).parent;B=E.parent;O=E/'complete-C11';sys.path.insert(0,str(B/'prepared-native-packet-method-v1'))
import native_counter as m
c=m.c
def walk(n):
 yield n
 for q in n.get('inner',[]):yield from walk(q)
def direct(n):
 while n.get('kind') in ['ImplicitCastExpr','ParenExpr'] and len(n.get('inner',[]))==1:n=n['inner'][0]
 return n.get('referencedDecl',{}).get('name')
roots={};allfs={};srcs={};bind={}
for unit in ['Columnar','CoreSource','CoreControl','DeltaCallback']:
 cap=json.loads((O/(unit+'.capture.json')).read_text());assert cap['status']=='COMPLETE_STATIC_CAPTURE';source=Path(cap['source']);data=source.read_bytes();assert hashlib.sha256(data).hexdigest()==cap['source_sha256'];p=O/(unit+'.ast');root=json.loads(p.read_text());roots[unit]=[root];srcs[unit]={'path':str(source),'data':data,'sha256':cap['source_sha256']};bind[unit]={'capture':str(O/(unit+'.capture.json')),'capture_sha256':hashlib.sha256((O/(unit+'.capture.json')).read_bytes()).hexdigest(),'ast_sha256':hashlib.sha256(p.read_bytes()).hexdigest()};c.register_types([root])
 for n in root.get('inner',[]):
  if n.get('kind')=='FunctionDecl' and any(q.get('kind')=='CompoundStmt' for q in n.get('inner',[])):
   name=n.get('name');off=n.get('loc',{}).get('offset',-1)
   if data[off:off+len(name)]==name.encode():allfs[name]={'ast':n,'unit':unit}
def closure(entry):
 out={};todo=[entry]
 while todo:
  name=todo.pop()
  if name in out or name not in allfs:continue
  out[name]=allfs[name]
  for n in walk(allfs[name]['ast']):
   if n.get('kind')=='CallExpr':
    name=direct(n['inner'][0])
    if name in allfs:todo.append(name)
 return out
paths={
 'R1':{'entry':'wl_columnar_session_quiet_identity','ifs':{'wl_columnar_session_quiet_identity_auth':[False,False],'wl_evaluation_control_active_attempt_id':[False]},'ternary':{'wl_columnar_session_quiet_identity':[True],'wl_evaluation_control_identity':[True]}},
 'R2':{'entry':'wl_columnar_session_quiet_guard_5','ifs':{'wl_columnar_session_quiet_guard_execute':[False],'wl_columnar_session_quiet_context_auth':[False]},'ternary':{}},
 'CHECK':{'entry':'wl_columnar_session_quiet_check_5','ifs':{'wl_columnar_session_quiet_check_execute':[False],'wl_columnar_session_quiet_cell_auth':[False,False,False],'wl_evaluation_control_active_attempt_id':[False]},'ternary':{}},
 'BODY':{'entry':'wl_columnar_session_quiet_cell_5','ifs':{'wl_columnar_session_quiet_execute':[False,False,False,False,False],'wl_columnar_session_quiet_body_auth':[False],'wl_evaluation_control_active_attempt_id':[False]},'ternary':{'wl_columnar_session_quiet_execute':[True]}},
}
for stage,path in paths.items():
 fs=closure(path['entry']);oldifs=dict(c.CHOICES);oldternary=dict(c.TERNARY)
 for name in fs:c.CHOICES[name]=path['ifs'].get(name,[])
 for name,v in path['ternary'].items():c.TERNARY[name]=v
 obj=None;error=None
 try:
  # No enum-switch annotation is requested by this source experiment. Supply
  # its exact actual function closure to the enum-catalog constructor; retain
  # COMPLETE real TU roots for all contextual member/type/field ownership.
  # This avoids parsing unrelated deprecated header enums, not a node rewrite
  # or permission to price the unsigned CELL switch.
  obj=m.Counter(fs,srcs,'',[fn['ast'] for fn in fs.values()],{},unit_nodes=roots,contextual_operands=True)
  obj.run(path['entry'])
 except Exception as ex:error=type(ex).__name__+': '+str(ex)
 finally:c.CHOICES.clear();c.CHOICES.update(oldifs);c.TERNARY.clear();c.TERNARY.update(oldternary)
 events=obj.events if obj else [];result={'status':'COMPLETE_EXISTING_COUNTER_SOURCE_PATH_ONLY_NOT_FULL_PAYER_ABI_ACCEPTANCE' if error is None else 'EXISTING_COUNTER_BLOCKED_NO_UPPER','stage':stage,'profile':'C11 production','entry':path['entry'],'actual_source_binding':bind,'path_choices':path,'counter_module':str(Path(m.__file__)),'counter_sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),'mode':'existing contextual scalar operands, aggregate/zero/increment extensions disabled, no Native/provider additions or annotation/domain extension','complete_source_path_cells':sum(e['cells'] for e in events) if error is None else None,'partial_event_cells_not_upper':sum(e['cells'] for e in events) if error else None,'error':error,'expanded_calls':obj.calls if obj else [],'events':events,'count_permission':False,'unqualified':'not all branches/profiles; mandatory next-phase denied fronts/pop,208/80/caller, ABI/effects and Native guards remain separate; method judgment not self-approved'}
 result['catalog_input']='exact actual FunctionDecl closure; full unit_nodes for all field/type evidence; empty enum annotations; no switch/domain bypass'
 (E/(stage+'-existing-counter.json')).write_text(json.dumps(result,indent=2)+'\n');print(stage,result['status'],result['complete_source_path_cells'],error,flush=True)
