from pathlib import Path
import json,subprocess,hashlib
E=Path(__file__).parent
W=Path('/srv/home/joykim/.tmp/2300-source32-parent-four-final-v1')
R=Path('/srv/home/joykim/.tmp/2300-operator-recovery-next')
overlay=E.parent/'architect-windows-source/primary-headers-overlay.json'
for profile in ['C11','POSIX','MSVC-C11','Windows-native']:
 windows=profile in ['MSVC-C11','Windows-native']
 base=['clang','--target='+('x86_64-pc-windows-msvc' if windows else 'x86_64-pc-linux-gnu'),'-std=c11']
 if windows:base+=['-fms-extensions','-fms-compatibility','-fms-compatibility-version=19.44','-D__STDC_NO_ATOMICS__','-D_CRT_SECURE_NO_WARNINGS','-ivfsoverlay',str(overlay),'-isystem','/wirelog-crt','-isystem','/wirelog-sdk/ucrt','-isystem','/wirelog-sdk/shared','-isystem','/wirelog-sdk/um']
 base+=['-I'+str(W),'-I'+str(W/'wirelog'),'-Ibuild','-Ibuild/wirelog','-Ibuild/subprojects/nanoarrow/src','-Isubprojects/nanoarrow/src','-iquote'+str(W/'wirelog/columnar')]
 if profile in ['C11','MSVC-C11']:base+=['-DWL_HAVE_C11_THREADS']
 for hooks in [False,True]:
  cmd=base+(['-DWL_SESSION_TEST_HOOKS=1'] if hooks else [])+['-fsyntax-only','-Xclang','-ast-dump=json','-Xclang','-ast-dump-filter=wl_columnar_session_quiet_',str(W/'wirelog/columnar/session.c')]
  prefix=E/(profile+('-hooks' if hooks else '-production'))
  p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
  prefix.with_suffix('.ast.jsons').write_text(p.stdout);prefix.with_suffix('.stderr').write_text(p.stderr)
  record={'profile':profile,'hooks':hooks,'command':cmd,'cwd':str(R),'returncode':p.returncode,'source_sha256':hashlib.sha256((W/'wirelog/columnar/session.c').read_bytes()).hexdigest(),'ast_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'status':'FILTERED_AST_FULL_TU_SYNTAX_SUCCESS' if p.returncode==0 else 'FULL_TU_BLOCKED_NO_ADMITTED_COUNT_INPUT','count_permission':False}
  prefix.with_suffix('.capture.json').write_text(json.dumps(record,indent=2)+'\n');print(profile,hooks,p.returncode,p.stderr[-800:])
