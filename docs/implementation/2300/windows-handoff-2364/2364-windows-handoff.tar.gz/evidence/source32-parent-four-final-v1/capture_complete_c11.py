from pathlib import Path
import json,subprocess,hashlib,concurrent.futures
E=Path(__file__).parent;W=Path('/srv/home/joykim/.tmp/2300-source32-parent-four-final-v1');R=Path('/srv/home/joykim/.tmp/2300-operator-recovery-next');O=E/'complete-C11';O.mkdir(exist_ok=True)
base=json.loads((E/'C11-production.capture.json').read_text())['command'];base=base[:base.index('-fsyntax-only')]
def cap(pair):
 name,rel=pair;source=W/rel;records={};prefix=O/name
 for label,flags in [('ast',['-fsyntax-only','-Xclang','-ast-dump=json']),('ir',['-S','-emit-llvm','-O0','-fno-discard-value-names','-o',str(prefix.with_suffix('.ll'))]),('layout',['-fsyntax-only','-Xclang','-fdump-record-layouts-complete']),('dependencies',['-M']),('macros',['-dM','-E'])]:
  cmd=base+flags+[str(source)]
  with prefix.with_suffix('.'+label).open('w') as out,prefix.with_suffix('.'+label+'.stderr').open('w') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,text=True)
  records[label]={'command':cmd,'cwd':str(R),'returncode':p.returncode,'output':str(prefix.with_suffix('.'+label)),'sha256':hashlib.sha256(prefix.with_suffix('.'+label).read_bytes()).hexdigest()}
  if p.returncode:break
 record={'unit':name,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'profile':'C11 production','records':records,'status':'COMPLETE_STATIC_CAPTURE' if len(records)==5 and all(r['returncode']==0 for r in records.values()) else 'STATIC_CAPTURE_BLOCKED','count_permission':False};prefix.with_suffix('.capture.json').write_text(json.dumps(record,indent=2)+'\n');return name,record['status']
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(cap,[('Columnar','wirelog/columnar/session.c'),('CoreSource','wirelog/session.c'),('CoreControl','wirelog/evaluation_control.c'),('DeltaCallback','wirelog/session_delta_callback.c')]):print(*result,flush=True)
