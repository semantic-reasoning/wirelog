from pathlib import Path
import re
W=Path('/srv/home/joykim/.tmp/2300-source32-parent-four-final-v1');p=W/'wirelog/columnar/session.c';s=p.read_text()
def replace(a,b):
 global s
 assert s.count(a)==1,(a[:90],s.count(a));s=s.replace(a,b)
replace('throughout all three FINALs.', 'throughout all four FINALs.')
point=s.index('/* Each case is a fixed field cluster;')
s=s[:point]+'''/* CHECK executes the complete old CELL auth, but no hook or journal write.
 * Its successful result is only a synchronous flow edge in this drive. */
static int
wl_columnar_session_quiet_check_execute(void *payload, unsigned cell)
{
    wl_columnar_session_quiet_payload_t *p = payload;
    if (!wl_columnar_session_quiet_cell_auth(p, cell)) {
        if (wl_columnar_session_quiet_inflight == &p->owner)
            wl_columnar_session_quiet_inflight = NULL;
        return EBUSY;
    }
    return 0;
}

/* CHECK's full current/resume proof remains inside this guarded lexical
 * interval. BODY still reads the actual Original id immediately pre-hook. */
static bool
wl_columnar_session_quiet_body_auth(wl_columnar_session_quiet_payload_t *p,
    unsigned cell)
{
    wl_columnar_session_quiet_inflight_t *owner = &p->owner;
    if (wl_columnar_session_quiet_inflight != owner) return false;
    wl_col_session_t *sess = p->session;
    wl_columnar_controlled_step_t *s = p->step;
    return owner->identity == owner && owner->cell == cell
           && sess && s && sess->controlled_step == s
           && s->observer_error.original == sess->base.evaluation_control
           && s->observer_error.original_id
           && wl_evaluation_control_active_attempt_id(s->observer_error.original)
           == s->observer_error.original_id;
}

'''+s[point:]
# Only the existing BODY entry chooses the new narrow pre-hook auth.
start=s.index('wl_columnar_session_quiet_execute(void *payload, unsigned cell)');i=s.index('!wl_columnar_session_quiet_cell_auth(p, cell)',start);s=s[:i]+s[i:].replace('!wl_columnar_session_quiet_cell_auth(p, cell)','!wl_columnar_session_quiet_body_auth(p, cell)',1)
point=s.index('static int\nwl_columnar_session_quiet_cell_0(')
thunks=''
for n in range(15):thunks+=f'''static int
wl_columnar_session_quiet_check_{n}(void *payload)
{{
    return wl_columnar_session_quiet_check_execute(payload, {n});
}}

'''
s=s[:point]+thunks+s[point:]
point=s.index('static int\nwl_columnar_session_quiet_progress_drive(')
s=s[:point]+'''static int
wl_columnar_session_quiet_result(wl_evaluation_control_source_final_result_t result)
{
    if (result.financial_result == WL_EVALUATION_CONTROL_CANCELLED
        || result.financial_result == WL_EVALUATION_CONTROL_WORK_LIMIT
        || result.financial_result == EAGAIN) return EAGAIN;
    if (result.action_called && !result.phase_finished) return EINVAL;
    if (result.financial_result) return result.financial_result;
    if (!result.action_called) return result.action_result ? result.action_result : EINVAL;
    return result.action_result ? result.action_result : EAGAIN;
}

'''+s[point:]
replace('wl_evaluation_control_source_action_fn guard_fn, fn;', 'wl_evaluation_control_source_action_fn guard_fn, check_fn, fn;')
for n in range(15):replace(f'        guard_fn = wl_columnar_session_quiet_guard_{n};\n        fn =',f'        guard_fn = wl_columnar_session_quiet_guard_{n};\n        check_fn = wl_columnar_session_quiet_check_{n};\n        fn =')
a=s.index('    if (result.action_called && result.phase_finished',s.index('wl_columnar_session_quiet_progress_drive(wl_col_session_t *sess,\n'));b=s.index('\nstatic int\nwl_columnar_session_observer_error_end_original',a)
s=s[:a]+'''    if (!result.action_called || !result.phase_finished
        || result.financial_result || result.action_result)
        return wl_columnar_session_quiet_result(result);

    /* Actual R1 owns this R2 prepositive/refusal transport; no guard exists. */
    result = wl_session_source_final_metadata(&sess->base, &policy, guard_fn,
        &payload, sizeof(payload), s, sizeof(*s));
    if (!result.action_called || !result.phase_finished
        || result.financial_result || result.action_result) {
        /* Only called successful R2 can have installed this exact address.
         * Its CURRENT prepays this own cleanup after a later R2 stop. */
        if (wl_columnar_session_quiet_inflight == &payload.owner)
            wl_columnar_session_quiet_inflight = NULL;
        return wl_columnar_session_quiet_result(result);
    }
    if (wl_columnar_session_quiet_inflight != &payload.owner) return EINVAL;

    result = wl_session_source_final_metadata(&sess->base, &policy, check_fn,
        &payload, sizeof(payload), s, sizeof(*s));
    if (!result.action_called) {
        /* R2-paid denied CHECK: no future CHECK payment is borrowed. */
        if (wl_columnar_session_quiet_inflight == &payload.owner)
            wl_columnar_session_quiet_inflight = NULL;
        return wl_columnar_session_quiet_result(result);
    }
    if (!result.phase_finished || result.financial_result || result.action_result) {
        /* Called CHECK has a genuine CURRENT; it owns its own late-stop
         * suffix. Authentication refusal may already have popped inside. */
        if (wl_columnar_session_quiet_inflight == &payload.owner)
            wl_columnar_session_quiet_inflight = NULL;
        return wl_columnar_session_quiet_result(result);
    }
    if (wl_columnar_session_quiet_inflight != &payload.owner) return EINVAL;

    result = wl_session_source_final_metadata(&sess->base, &policy, fn,
        &payload, sizeof(payload), s, sizeof(*s));
    if (!result.action_called) {
        /* CHECK-paid denied BODY: this is a distinct executed occurrence
         * from the R2-owned denied-CHECK cleanup above. */
        if (wl_columnar_session_quiet_inflight == &payload.owner)
            wl_columnar_session_quiet_inflight = NULL;
        return wl_columnar_session_quiet_result(result);
    }
    /* Every called BODY path pops inside its actual CURRENT, including auth
     * refusal. Performed cursor/marker/Q14 changes survive a later stop. */
    return wl_columnar_session_quiet_result(result);
}

'''+s[b:]
p.write_text(s)
