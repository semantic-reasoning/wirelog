/* Called only after the actual FINAL CURRENT payment. No wrapper hook or
 * TLS store precedes that debit. Authentication refuses without journal writes. */
static bool
wl_columnar_session_quiet_identity_auth(wl_col_session_t *sess,
    wl_columnar_controlled_step_t *s)
{
    if (!sess || !s || sess->controlled_step != s
        || wl_columnar_session_quiet_inflight) return false;
    const wl_columnar_session_observer_error_t *e = &s->observer_error;
    if (e->identity != e || e->session != sess || e->step != s
        || e->phase != WL_COLUMNAR_SESSION_OBSERVER_ERROR_RESOURCES_DONE
        || !e->resources_done || e->parent_closed
        || e->original != sess->base.evaluation_control || !e->original
        || e->original_identity != wl_evaluation_control_identity(e->original)
        || !e->operation_identity ||
        e->operation_identity != s->operation_identity
        || !e->original_id || !s->operation_active
        || s->operation_id != e->original_id
        || wl_evaluation_control_active_attempt_id(e->original) !=
        e->original_id) return false;
    return true;
}

/* R2 follows only actual successful R1 in this hook-free invocation. */
static bool
wl_columnar_session_quiet_context_auth(wl_col_session_t *sess,
    wl_columnar_controlled_step_t *s)
{
    const wl_columnar_session_observer_error_t *e = &s->observer_error;
    if (!e->actor_valid || !wl_columnar_session_actor_current(e->actor)
        || (!wl_session_source_operation_scope_owned(&sess->base)
        && !wl_session_source_close_scope_owned(&sess->base))
        || wl_session_delta_callback_is_current(&sess->base)
        || sess->base.source_financial_head || s->metadata_offer.recipe
        || s->metadata_presentation_mask
        || wl_columnar_session_metadata_bind_pending(s)) return false;
    return true;
}

/* Actual CHECK CURRENT checks association/id and complete progress. R2 actor
 * and issuer remain bound only by the accepted same-activation fixed graph;
 * mutable metadata absence is still observed again before hooks/writes. */
static bool
wl_columnar_session_quiet_cell_auth(wl_columnar_session_quiet_payload_t *p,
    unsigned cell)
{
    wl_columnar_session_quiet_inflight_t *owner = &p->owner;
    if (wl_columnar_session_quiet_inflight != owner) return false;
    wl_col_session_t *sess = p->session;
    wl_columnar_controlled_step_t *s = p->step;
    if (owner->identity != owner || owner->cell != cell
        || !sess || !s || sess->controlled_step != s
        || s->observer_error.original != sess->base.evaluation_control
        || !s->observer_error.original_id
        || wl_evaluation_control_active_attempt_id(s->observer_error.original)
        != s->observer_error.original_id
        || sess->base.source_financial_head || s->metadata_presentation_mask
        || s->metadata_offer.recipe ||
        wl_columnar_session_metadata_bind_pending(s))
        return false;
    const wl_columnar_session_observer_error_t *e = &s->observer_error;
    const wl_columnar_session_quiet_progress_t *q = &e->quiet_progress;
    if (!cell)
        return !q->identity && !q->mode && !q->next_cell && !q->origin_phase
               && !q->failed_cell && !q->failed_result && !q->original_id
               && !q->operation_identity;
    return q->identity == q && q->mode == 1 && q->next_cell == cell
           && q->origin_phase == (unsigned)e->phase
           && q->original_id == e->original_id
           && q->operation_identity == e->operation_identity
           && ((!q->failed_cell && !q->failed_result)
           || (q->failed_cell == cell && q->failed_result > 0));
}

/* R1 has no owner/TLS/journal/hook writes. */
static int
wl_columnar_session_quiet_identity(void *payload)
{
    wl_columnar_session_quiet_payload_t *p = payload;
    return wl_columnar_session_quiet_identity_auth(p->session, p->step)
           ? 0 : EBUSY;
}

static int
wl_columnar_session_quiet_guard_execute(void *payload, unsigned cell)
{
    wl_columnar_session_quiet_payload_t *p = payload;
    if (!wl_columnar_session_quiet_context_auth(p->session,
        p->step)) return EBUSY;
    wl_columnar_session_quiet_inflight_t *owner = &p->owner;
    owner->cell = cell; owner->identity = owner;
    wl_columnar_session_quiet_inflight = owner;
    return 0;
}

/* CHECK executes the complete old CELL auth, but no hook or journal write.
 * Its successful result is only a synchronous flow edge in this drive. */
static int
wl_columnar_session_quiet_check_execute(void *payload, unsigned cell)
{
    wl_columnar_session_quiet_payload_t *p = payload;
    if (!wl_columnar_session_quiet_cell_auth(p, cell)) {
        if (wl_columnar_session_quiet_inflight == &p->owner)
            wl_columnar_session_quiet_inflight = NULL;
        return EBUSY;
    }
    return 0;
}

/* CHECK's full current/resume proof remains inside this guarded lexical
 * interval. BODY still reads the actual Original id immediately pre-hook. */
static bool
wl_columnar_session_quiet_body_auth(wl_columnar_session_quiet_payload_t *p,
    unsigned cell)
{
    wl_columnar_session_quiet_inflight_t *owner = &p->owner;
    if (wl_columnar_session_quiet_inflight != owner) return false;
    wl_col_session_t *sess = p->session;
    wl_columnar_controlled_step_t *s = p->step;
    return owner->identity == owner && owner->cell == cell
           && sess && s && sess->controlled_step == s
           && s->observer_error.original == sess->base.evaluation_control
           && s->observer_error.original_id
           && wl_evaluation_control_active_attempt_id(
        s->observer_error.original)
           == s->observer_error.original_id;
}

/* Each case is a fixed field cluster; no whole quiet/valid/history expansion. */
static bool
wl_columnar_session_quiet_predicate(const wl_col_session_t *sess,
    const wl_columnar_controlled_step_t *s, unsigned cell)
{
    const wl_columnar_session_observer_error_t *e = &s->observer_error;
    const wl_columnar_session_observed_observer_t *j = &s->observed_observer;
    const wl_columnar_session_observed_origin_t *o = &s->observed_origin;
    const wl_columnar_session_prepared_parent_t *p = &s->prepared_parent;
    const wl_columnar_session_financier_t *f = &o->terminal_funding;
    switch (cell) {
    case 0: return true;
    case 1:
        return s->observed && s->complete && s->published &&
               !s->general_observed
               && !s->recursive_route && !s->recursive && !s->transaction
               && !s->snapshot_owned && !s->snapshot && !s->snapshot_retry;
    case 2:
        return j->control == e->original &&
               j->control_identity == e->original_identity
               && j->operation_identity == e->operation_identity
               && j->reason == 3 && !j->native
               && j->attempt_id == e->observer_attempt_id
               && j->disposal_attempt_id == e->observer_disposal_id;
    case 3:
        return j->generation == e->observer_generation
               && j->parent_phase == e->observer_parent_phase
               && j->parent_count == e->observer_parent_count
               && j->head_count == e->observer_head_count
               && j->old_count == e->observer_old_count
               && e->cause > 0 && e->cause != EAGAIN;
    case 4:
        return !sess->cleanup_active && !sess->cleanup_pending &&
               !s->previous_valid
               && !s->previous_funding && !s->join_cleanup.kind
               && !s->unary_cleanup.registered && !s->terminal_receipt_ack
               && !s->retirement_native_count && !s->retirement_busy
               && !s->retirement_begin_busy &&
               !s->retirement_begin_failure_pending;
    case 5:
        return !s->staging_progress.identity && !s->staging_cancel_pending
               && !s->staging_maintenance && !s->successor_input_reader.owner
               && !s->successor_input_reader.secondary_owner
               && !s->successor_input_reader.identity
               && !s->successor_input_reader.thread_valid
               && !s->successor_input_reader.acquire_stage
               && !s->successor_input_reader.release_stage
               && !s->successor_input_reader.transferable && !s->relation_active
               && !s->observer_cleanup_pending;
    case 6:
        return !s->observer_preparing && !s->observer_prepare_discard
               && s->baseline_ready && s->observer_prepared &&
               s->observer_evaluated
               && !s->main_action.identity && !s->main_action.executing
               && !j->identity && !j->session && !j->transaction &&
               !j->main_owned
               && !j->actor_valid;
    case 7:
        return j->finished && j->native_finished && j->acknowledged &&
               !j->native
               && j->reason == 3 && !j->resource.identity &&
               !j->resource.session
               && !j->resource.busy && !j->close_busy;
    case 8:
        return !j->finance.control && !j->finance.phase &&
               !j->finance.metadata.ready
               && !j->finance.metadata.semantic_valid &&
               !j->finance.metadata.scheduled
               && !j->finance.snapshot_financial_stop &&
               !j->finance.outer_source.ready;
    case 9:
        return !sess->delta_observer && !sess->delta_observer_build
               && !sess->delta_observer_prepare
               && !sess->delta_observer_retirement_governor
               && !sess->delta_observer_retirement_gc;
    case 10:
        return wl_columnar_session_retirement_native_equal(s) && !o->identity
               && !o->transaction && !o->terminal_phase && !o->terminal_busy
               && !o->earlier_identity && !o->bootstrap_finance_pending
               && !o->terminal_maintenance.control;
    case 11:
        return !o->terminal_maintenance.metadata.ready
               && !o->terminal_maintenance.metadata.scheduled
               && !o->terminal_maintenance.metadata.semantic_valid
               && !o->terminal_maintenance.outer_source.ready
               && !o->terminal_maintenance.phase &&
               !s->bootstrap_receipt.identity
               && !s->bootstrap_receipt.phase && !s->metadata_presentation_mask
               && !sess->base.source_financial_head &&
               !s->metadata_offer.recipe;
    case 12:
        return p->identity == p && p->session == sess && p->step == s
               && wl_columnar_session_prepared_parent_actor(p)
               && p->operation_id == e->original_id
               && p->phase == WL_COLUMNAR_SESSION_PREPARED_PARENT_CLOSED
               && p->control == sess->base.evaluation_control
               && p->control_identity ==
               wl_evaluation_control_identity(p->control)
               && p->operation_identity == s->operation_identity;
    case 13:
        return !p->action_frame && !p->action_pending && !p->finish_pending
               && !p->origin_owned && !f->control && !f->id && !f->phase &&
               !f->owner
               && !f->report_valid && !f->metadata.ready &&
               !f->metadata.scheduled
               && !f->metadata.semantic_valid && !f->outer_source.ready;
    case 14: return true;
    default: return false;
    }
}

#ifdef WL_SESSION_TEST_HOOKS
void (*wl_columnar_session_test_quiet_action)(const wl_col_session_t *,
    unsigned, bool, int);
#endif

static int
wl_columnar_session_quiet_execute(void *payload, unsigned cell)
{
    wl_columnar_session_quiet_payload_t *p = payload;
    wl_col_session_t *sess = p->session;
    wl_columnar_controlled_step_t *s = p->step;
    wl_columnar_session_quiet_inflight_t *owner = &p->owner;
    if (!wl_columnar_session_quiet_body_auth(p, cell)) {
        if (wl_columnar_session_quiet_inflight == owner)
            wl_columnar_session_quiet_inflight = NULL;
        return EBUSY;
    }
#ifdef WL_SESSION_TEST_HOOKS
    if (wl_columnar_session_test_quiet_action)
        wl_columnar_session_test_quiet_action(sess, cell, false, 0);
#endif
    wl_columnar_session_observer_error_t *e = &s->observer_error;
    wl_columnar_session_quiet_progress_t *q = &e->quiet_progress;
    int rc = wl_columnar_session_quiet_predicate(sess, s, cell) ? 0 : EBUSY;
    if (!rc && !cell) {
        q->mode = 1; q->origin_phase = (unsigned)e->phase;
        q->original_id = e->original_id;
        q->operation_identity = e->operation_identity;
        q->failed_cell = 0; q->failed_result = 0; q->next_cell = 1;
        q->identity = q;
    } else if (rc) {
        if (!q->failed_cell) {
            q->failed_cell = cell; q->failed_result = rc;
        }
    } else {
        q->failed_cell = 0; q->failed_result = 0;
        if (cell == 14) {
            e->parent_closed = true;
            q->mode = 0; q->origin_phase = 0; q->original_id = 0;
            q->operation_identity = 0; q->next_cell = 0; q->identity = NULL;
        } else q->next_cell = cell + 1;
    }
#ifdef WL_SESSION_TEST_HOOKS
    if (wl_columnar_session_test_quiet_action)
        wl_columnar_session_test_quiet_action(sess, cell, true, rc);
#endif
    if (wl_columnar_session_quiet_inflight != owner) return EINVAL;
    wl_columnar_session_quiet_inflight = NULL;
    return rc;
}

static int
wl_columnar_session_quiet_guard_0(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 0);
}

static int
wl_columnar_session_quiet_guard_1(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 1);
}

static int
wl_columnar_session_quiet_guard_2(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 2);
}

static int
wl_columnar_session_quiet_guard_3(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 3);
}

static int
wl_columnar_session_quiet_guard_4(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 4);
}

static int
wl_columnar_session_quiet_guard_5(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 5);
}

static int
wl_columnar_session_quiet_guard_6(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 6);
}

static int
wl_columnar_session_quiet_guard_7(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 7);
}

static int
wl_columnar_session_quiet_guard_8(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 8);
}

static int
wl_columnar_session_quiet_guard_9(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 9);
}

static int
wl_columnar_session_quiet_guard_10(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 10);
}

static int
wl_columnar_session_quiet_guard_11(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 11);
}

static int
wl_columnar_session_quiet_guard_12(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 12);
}

static int
wl_columnar_session_quiet_guard_13(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 13);
}

static int
wl_columnar_session_quiet_guard_14(void *payload)
{
    return wl_columnar_session_quiet_guard_execute(payload, 14);
}

static int
wl_columnar_session_quiet_check_0(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 0);
}

static int
wl_columnar_session_quiet_check_1(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 1);
}

static int
wl_columnar_session_quiet_check_2(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 2);
}

static int
wl_columnar_session_quiet_check_3(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 3);
}

static int
wl_columnar_session_quiet_check_4(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 4);
}

static int
wl_columnar_session_quiet_check_5(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 5);
}

static int
wl_columnar_session_quiet_check_6(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 6);
}

static int
wl_columnar_session_quiet_check_7(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 7);
}

static int
wl_columnar_session_quiet_check_8(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 8);
}

static int
wl_columnar_session_quiet_check_9(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 9);
}

static int
wl_columnar_session_quiet_check_10(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 10);
}

static int
wl_columnar_session_quiet_check_11(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 11);
}

static int
wl_columnar_session_quiet_check_12(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 12);
}

static int
wl_columnar_session_quiet_check_13(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 13);
}

static int
wl_columnar_session_quiet_check_14(void *payload)
{
    return wl_columnar_session_quiet_check_execute(payload, 14);
}

static int
wl_columnar_session_quiet_cell_0(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 0);
}

static int
wl_columnar_session_quiet_cell_1(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 1);
}

static int
wl_columnar_session_quiet_cell_2(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 2);
}

static int
wl_columnar_session_quiet_cell_3(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 3);
}

static int
wl_columnar_session_quiet_cell_4(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 4);
}

static int
wl_columnar_session_quiet_cell_5(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 5);
}

static int
wl_columnar_session_quiet_cell_6(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 6);
}

static int
wl_columnar_session_quiet_cell_7(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 7);
}

static int
wl_columnar_session_quiet_cell_8(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 8);
}

static int
wl_columnar_session_quiet_cell_9(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 9);
}

static int
wl_columnar_session_quiet_cell_10(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 10);
}

static int
wl_columnar_session_quiet_cell_11(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 11);
}

static int
wl_columnar_session_quiet_cell_12(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 12);
}

static int
wl_columnar_session_quiet_cell_13(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 13);
}

static int
wl_columnar_session_quiet_cell_14(void *payload)
{
    return wl_columnar_session_quiet_execute(payload, 14);
}

static int
wl_columnar_session_quiet_result(
    const wl_evaluation_control_source_final_result_t *result)
{
    if (result->financial_result == WL_EVALUATION_CONTROL_CANCELLED
        || result->financial_result == WL_EVALUATION_CONTROL_WORK_LIMIT
        || result->financial_result == EAGAIN) return EAGAIN;
    if (result->action_called && !result->phase_finished) return EINVAL;
    if (result->financial_result) return result->financial_result;
    if (!result->action_called) return result->action_result ?
               result->action_result : EINVAL;
    return result->action_result ? result->action_result : EAGAIN;
}

static int
wl_columnar_session_quiet_progress_drive(wl_col_session_t *sess,
    wl_columnar_controlled_step_t *s)
{
    static const wl_evaluation_control_source_phase_policy_t policy = {208, 224,
                                                                       80};
    if (!sess || !s || sess->controlled_step != s) return EINVAL;
    wl_columnar_session_quiet_progress_t *q = &s->observer_error.quiet_progress;
    unsigned cell = q->identity ? q->next_cell : 0;
    wl_evaluation_control_source_action_fn guard_fn, check_fn, fn;
    switch (cell) {
    case 0:
        guard_fn = wl_columnar_session_quiet_guard_0;
        check_fn = wl_columnar_session_quiet_check_0;
        fn = wl_columnar_session_quiet_cell_0; break;
    case 1:
        guard_fn = wl_columnar_session_quiet_guard_1;
        check_fn = wl_columnar_session_quiet_check_1;
        fn = wl_columnar_session_quiet_cell_1; break;
    case 2:
        guard_fn = wl_columnar_session_quiet_guard_2;
        check_fn = wl_columnar_session_quiet_check_2;
        fn = wl_columnar_session_quiet_cell_2; break;
    case 3:
        guard_fn = wl_columnar_session_quiet_guard_3;
        check_fn = wl_columnar_session_quiet_check_3;
        fn = wl_columnar_session_quiet_cell_3; break;
    case 4:
        guard_fn = wl_columnar_session_quiet_guard_4;
        check_fn = wl_columnar_session_quiet_check_4;
        fn = wl_columnar_session_quiet_cell_4; break;
    case 5:
        guard_fn = wl_columnar_session_quiet_guard_5;
        check_fn = wl_columnar_session_quiet_check_5;
        fn = wl_columnar_session_quiet_cell_5; break;
    case 6:
        guard_fn = wl_columnar_session_quiet_guard_6;
        check_fn = wl_columnar_session_quiet_check_6;
        fn = wl_columnar_session_quiet_cell_6; break;
    case 7:
        guard_fn = wl_columnar_session_quiet_guard_7;
        check_fn = wl_columnar_session_quiet_check_7;
        fn = wl_columnar_session_quiet_cell_7; break;
    case 8:
        guard_fn = wl_columnar_session_quiet_guard_8;
        check_fn = wl_columnar_session_quiet_check_8;
        fn = wl_columnar_session_quiet_cell_8; break;
    case 9:
        guard_fn = wl_columnar_session_quiet_guard_9;
        check_fn = wl_columnar_session_quiet_check_9;
        fn = wl_columnar_session_quiet_cell_9; break;
    case 10:
        guard_fn = wl_columnar_session_quiet_guard_10;
        check_fn = wl_columnar_session_quiet_check_10;
        fn = wl_columnar_session_quiet_cell_10; break;
    case 11:
        guard_fn = wl_columnar_session_quiet_guard_11;
        check_fn = wl_columnar_session_quiet_check_11;
        fn = wl_columnar_session_quiet_cell_11; break;
    case 12:
        guard_fn = wl_columnar_session_quiet_guard_12;
        check_fn = wl_columnar_session_quiet_check_12;
        fn = wl_columnar_session_quiet_cell_12; break;
    case 13:
        guard_fn = wl_columnar_session_quiet_guard_13;
        check_fn = wl_columnar_session_quiet_check_13;
        fn = wl_columnar_session_quiet_cell_13; break;
    case 14:
        guard_fn = wl_columnar_session_quiet_guard_14;
        check_fn = wl_columnar_session_quiet_check_14;
        fn = wl_columnar_session_quiet_cell_14; break;
    default: return EINVAL;
    }
    if (!wl_session_source_operation_scope_owned(&sess->base)
        && !wl_session_source_close_scope_owned(&sess->base)) return EBUSY;
    wl_columnar_session_quiet_payload_t payload;
    /* Preserve only the existing two-pointer initialization before payment.
     * No owner field, acquisition flag or TLS store is initialized here. */
    payload.session = sess; payload.step = s;
    wl_evaluation_control_source_final_result_t result =
        wl_session_source_final_metadata(&sess->base, &policy,
            wl_columnar_session_quiet_identity, &payload, sizeof(payload),
            s, sizeof(*s));
    if (!result.action_called || !result.phase_finished
        || result.financial_result || result.action_result)
        return wl_columnar_session_quiet_result(&result);

    /* Actual R1 owns this R2 prepositive/refusal transport; no guard exists. */
    result = wl_session_source_final_metadata(&sess->base, &policy, guard_fn,
            &payload, sizeof(payload), s, sizeof(*s));
    if (!result.action_called || !result.phase_finished
        || result.financial_result || result.action_result) {
        /* Only called successful R2 can have installed this exact address.
         * Its CURRENT prepays this own cleanup after a later R2 stop. */
        if (wl_columnar_session_quiet_inflight == &payload.owner)
            wl_columnar_session_quiet_inflight = NULL;
        return wl_columnar_session_quiet_result(&result);
    }
    if (wl_columnar_session_quiet_inflight != &payload.owner) return EINVAL;

    result = wl_session_source_final_metadata(&sess->base, &policy, check_fn,
            &payload, sizeof(payload), s, sizeof(*s));
    if (!result.action_called) {
        /* R2-paid denied CHECK: no future CHECK payment is borrowed. */
        if (wl_columnar_session_quiet_inflight == &payload.owner)
            wl_columnar_session_quiet_inflight = NULL;
        return wl_columnar_session_quiet_result(&result);
    }
    if (!result.phase_finished || result.financial_result ||
        result.action_result) {
        /* Called CHECK has a genuine CURRENT; it owns its own late-stop
         * suffix. Authentication refusal may already have popped inside. */
        if (wl_columnar_session_quiet_inflight == &payload.owner)
            wl_columnar_session_quiet_inflight = NULL;
        return wl_columnar_session_quiet_result(&result);
    }
    if (wl_columnar_session_quiet_inflight != &payload.owner) return EINVAL;

    result = wl_session_source_final_metadata(&sess->base, &policy, fn,
            &payload, sizeof(payload), s, sizeof(*s));
    if (!result.action_called) {
        /* CHECK-paid denied BODY: this is a distinct executed occurrence
         * from the R2-owned denied-CHECK cleanup above. */
        if (wl_columnar_session_quiet_inflight == &payload.owner)
            wl_columnar_session_quiet_inflight = NULL;
        return wl_columnar_session_quiet_result(&result);
    }
    /* Every called BODY path pops inside its actual CURRENT, including auth
     * refusal. Performed cursor/marker/Q14 changes survive a later stop. */
    return wl_columnar_session_quiet_result(&result);
}
