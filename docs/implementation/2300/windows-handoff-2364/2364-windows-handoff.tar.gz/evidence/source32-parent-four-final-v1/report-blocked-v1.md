# Source32 four-FINAL candidate and actual contextual-counter replay

**Frozen for independent RAW/method review; resource/runtime acceptance remains BLOCKED. No engine execution, Root port, commit or push.**

Base tree `ce409f6948ea2582437442c232c1aeb9887d80b6`; candidate `705813930691320ad2c9ad201160f651b0546b74`; sole changed path `wirelog/columnar/session.c`, SHA256 `53d56cb5332eb2f8c442030a7bb1aaa3a19bae31c418f492043513a0f5f42c9e`; raw diff SHA256 `1b72acda3375996cf981bf81f296f6c1bee8e5dad3a39ae9ff700128313654be`. Immutable before/after/raw/delivery are in this directory. Root's moving work and full tests were not used as this candidate's source or validation.

## Metric correction — old node tallies are not contextual lower bounds

Actual replay of the existing contextual scalar-operand counter completes native R1 and CHECK source paths with80 and93 cells respectively. This method absorbs proven operand fronts; it does not charge the earlier raw AST-node sum as independent operations. Therefore the old225/254/259 node tallies **are not valid lower bounds for this contextual metric** and cannot justify the necessity of two/three/four financial phases. Those old receipts must be read as raw-node diagnostics in a different accounting interpretation, not admitted resource results. Carrying them forward as lower certificates would be wrong.

This candidate implements the independently approved experiment, not a finding that four stages are necessary. The genuine current whole-Root quiet validator and prior three-stage implementation still need independent applicability/comparison under the same actual contextual metric, with their own captured sources and provider/switch/ABI evidence. I did not rewrite an AST, synthesize a cheaper result, implement a new method or mutate Root to make that comparison. Root has assigned it separately.

| Actual C11 replay | Result | Practical limit |
|---|---|---|
| R1 complete expanded source path | 80 | One admitted symbolic success path; not full profiles/branches, ABI/effect or next-R2 denied fronts. |
| R2 | No upper: `unqualified/unresolved call thrd_current thrd_current()` | No native whitelist/provider addition was made. Root's separately reviewed service-boundary module was not yet incorporated here. |
| CHECK Q5 complete expanded source path | 93 | Complete selected source closure, not BODY denied-front/prepaid-pop ownership or all Q0..14/error/ABI alternatives. |
| BODY Q5 | No upper: `switch without actual width8 caller proof` | The unchanged unsigned `quiet_predicate` switch is outside the existing restricted switch domain. No unsigned-case annotation, native-inline shortcut or counter extension was added. |

Files `R1-existing-counter.json`, `R2-existing-counter.json`, `CHECK-existing-counter.json`, `BODY-existing-counter.json` hold exact source/capture/method hashes, actual path choices, expanded calls and events/stops. No partial event sum is an upper. Existing contextual scalar mode was replayed; aggregate/zero/increment extensions remain disabled, native/provider sets unchanged, switch annotations empty, and count_permission remains false.

The initial whole-header enum catalog rejected an unrelated multi-child enum initializer before any stage. Those four initial records remain in `initial-whole-catalog-*.json`. The successful replay supplies the exact actual FunctionDecl closure to the unused enum-switch catalog, while retaining **complete real TU unit_nodes** for every field/type/ownership proof. No source/AST node or counter implementation was changed; the unsigned switch still properly refuses. This is input projection for the actual closure, not permission to drop a required enum or bypass a switch.

## Source change and mechanical preservation

R1 identity and R2 actor/scope/header/compact-guard functions remain byte-identical to the predecessor. CHECK calls the byte-identical complete old `quiet_cell_auth`; it invokes no q hook and writes no Step/progress/marker. Success leaves the outer guard installed. Auth refusal pops only exact own TLS and returns EBUSY.

BODY adds `quiet_body_auth` immediately before the original q BEFORE. It requires exact own TLS/self/selected cell, actual Session/Step association, actual Original pointer association and a fresh positive Original id comparison. On refusal it pops only own TLS, returns EBUSY and performs no q hook or durable write. After that narrow front, the old predicate/prelude/switch and q BEFORE/predicate/marker/cursor/Q14/q AFTER/pop body are unchanged. In particular no predicate was moved across q BEFORE, no first-published history was recaptured, and Q14 does not FINISH Original or authorize Native action.

The existing closed switch now pairs actual guard/CHECK/BODY thunks for the same0..14 value. Unknown selection still refuses. `preservation.json` SHA256 `4b4e6bf35363dd68cf3c6d330651409318e9ba04011187f3ec4a6ef5da7265ad` verifies R1/R2/complete CHECK auth/whole predicate byte equality and that BODY execute differs only in its pre-hook auth callee. Only old quiet_execute and quiet_progress_drive bodies changed; other existing functions, all four lint fixes, both reviewed hook fallback compounds, remaining eleven quiet consumers and Snapshot144 are retained. This is author mechanical evidence, not self-RAW approval.

The result mapper takes a const pointer to the actual local result; it adds no by-value aggregate helper transport. Existing genuine FINAL aggregate return/assignment/ABI costs still require actual qualification.

## Four real phases, no new unpaid state

Drive declares its outer payload uninitialized and performs only the existing two Session/Step prefix stores before R1. There is no `checked` Boolean, status initializer, persistent proof bit or new cursor. Compact owner self/cell and TLS are still initialized only inside paid R2 after the complete original root union. The outer object lives through all four calls; no callback-local address escapes.

Each next call is gated by the preceding genuine action_called/phase_finished/financial0/action0 result. The unchanged Core FINAL physically FINISHes/verifies each report, clears context/running/callback state and unlocks; sealed lane/class/ref2/inactive/verified-report rearm must succeed before each new BEGIN. A healthy schedule is four real512 financial reports in four distinct768-capacity generations, not2048 inside one allowance. Sticky cancellation is not reset, and Original is not relabeled or restarted.

The implementation uses explicit disjoint failure branches rather than a new prepayment flag:

| Source occurrence/path | Genuine required payer and cleanup |
|---|---|
| Failed R1 | No R2/CHECK/BODY or installed owner. Return actual mapping; incoming/R1 obligations remain. |
| R2 front/uncalled refusal | R1's earlier positive payment must own this actual transport; no guard was installed. |
| R2 performed install followed by late finance failure | Exact-own caller pop in the failed-R2 branch, requiring R2's earlier CURRENT. No CHECK. |
| CHECK uncalled | Distinct failed-CHECK branch owns exact-own pop under preceding R2, even if the uncalled geometry case happened to consume CHECK work. No future credit is borrowed. |
| CHECK called but auth/late finance failure | CHECK actually had CURRENT. Its own failure path pays exact-own pop; auth refusal may already have popped inside CHECK. No BODY. |
| BODY uncalled | A different caller pop occurrence belongs to preceding successful CHECK. |
| BODY called | Its positive CURRENT owns actual pre-hook auth/refusal or old performed body/own pop. No duplicate caller TLS pop. Performed cursor/marker/Q14 effects survive later financial failure. |

Every pop compares the exact outer-owner address. An uncalled R2 never causes reads of uninitialized owner fields; foreign TLS is preserved. No return retains an own stack pointer. These are explicit occurrence owners, **not completed numerical upper certificates**: prior-paid prepositive/Core/report/unlock/result/refusal fronts and mandatory pops still need full bounds, without overlap or refunds.

Actual payload/compact-owner/TLS/whole-Step effects remain separate regions. FINAL receives the entire typed payload and Step journal; TLS is not claimed to live in Step geometry. Source/ABI/layout proof cannot infer that stack reservation, return structs or larger extents are free. No fee, cap, Original tariff, counter/provider permission, Core/header/Native or public API changed.

## Temporal/writer/output/role rebind

The received99431 bounded installed-opaque-output/actual raw caller/all-four-role closure is rebound to CHECK/BODY: no new caller outputs, role executor, Original semantic writer, Step replacement/free or scope-TLS setter is introduced. R1/R2/CHECK/BODY all execute synchronously in the same admitted drive. Fixed kernel events cancel the private financial lane or refuse local geometry; they are not arbitrary callbacks. An old suspended hook cannot execute between nested CHECK and BODY. Actual public competitors fail admission and actual foreign Core take fails scope/thread-cookie before consumption. Private TLS supplies same-thread exclusion only; it is not a cross-thread lock.

CHECK current/hybrid/progress facts remain bound through the fixed CHECK-return→FINISH/report/unlock→BODY issuer/rearm/BEGIN/geometry graph. BODY independently checks the last actual id before its q hook. A new actual provider callback, owner/free, scope writer or admissible raw role/output writer invalidates this reuse and stays STOP; a stale checked Boolean or one reread cannot repair a race. Provider effects and all containing fronts remain unqualified until their separate method receipts are actually held. Between-cell prefix and in-BODY TLS guards still preserve real raw negative cases and legal callback-current configuration outside a proof.

## Static inputs and next stop

Eight fresh exact-source full-TU syntax/filtered AST captures: C11/POSIX/Windows-native production and hooks all six pass. Forced MSVC-C11 production/hooks both fail preserved Native prepared-size392/work256 assertions. They remain failed inputs; current real Windows C11-link applicability is under separate investigation and is not waived here.

`complete-C11/` additionally captures full Columnar/CoreSource/CoreControl/DeltaCallback TUs: actual AST, LLVM O0 IR, complete record layouts, dependency commands and macro sets. Each source digest was checked against the frozen file. These complete actual inputs enabled the source-counter replay above instead of stopping at a raw-node tally. Other-profile full ABI/provider/front closure and actual Windows CI remain outstanding. No engine runtime or broad test was run.

One concise evidence-only next method proposal is an exact domain for this **single unsigned quiet_predicate switch**: bind real constant0..14 BODY thunks→unchanged unsigned parameter forwarding→predicate parameter, prove no selector write/address escape, map all actual case/default labels and terminal returns, and retain every dispatch/control/source/contextual operand cost for all healthy/error branches. This would need DIFFERENT Architect/Critic approval before any implementation; no arbitrary native coupon, AST replacement or broad switch whitelist is authorized. Independently compare current whole-Root/prior three-stage semantic costs before retaining protocol bloat. No fifth phase or additional framework was implemented here.
