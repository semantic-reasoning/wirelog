# Memory budget contract

This document defines the memory contract for a managed wirelog session. It
is normative for the resolver, governor, allocation sites, and TDD workers;
it does not turn the current accounting ledger into an allocator or an
admission controller.

## Scope and terminology

The contract covers memory reservations owned by one session: its coordinator,
workers, relation buffers, arenas, arrangements, caches, timestamps, exchange
buffers, and spill state. It does not promise a process-wide or host-wide OOM
guarantee. The following quantities remain distinct:

| Quantity | Meaning | Contract role |
| --- | --- | --- |
| Managed reservation | Bytes admitted to the session governor | Enforced budget |
| Ledger attribution | Best-effort current/peak counters by subsystem | Observability only |
| RSS/working set | Process residency, including allocator retention | Safety signal, not a reservation |
| cgroup/job/address-space limit | An external limit imposed by the host | Input to automatic resolution |
| Physical RAM | Installed or visible machine memory | Never a bounded guarantee by itself |

`wl_mem_ledger_t` currently implements attribution and reporting. Its
`budget == 0` compatibility value means “unlimited ledger accounting”; it
does not mean that a user supplied zero budget is accepted.

## Selecting a budget

There is one environment namespace: `WIRELOG_MEMORY_BUDGET`. The eventual
versioned session-options API has precedence over the environment, and the
environment has precedence over automatic resolution:

```text
versioned API option > WIRELOG_MEMORY_BUDGET > automatic resolution
```

The reusable `scripts/ci/run-memory-pressure.sh` helper records external-limit
evidence for a command: source and binary identity, command arguments,
effective ceiling, enforcement mechanism, exit/timeout classification, output
hashes, and Linux cgroup memory events when available. It prefers a writable
cgroup v2 and otherwise records a kernel-enforced `RLIMIT_AS` ceiling as a
different enforcement class. A bare `SIGKILL`/exit 137 is not treated as OOM;
resource-error mode requires supporting cgroup evidence. This runner is
qualification infrastructure only: its evidence does not prove that Wirelog
allocation classes, JOINs, TDD transport, or DOOP are bounded.

Values are decimal bytes (not MiB or a human-readable suffix). The following
table is part of the interface contract:

| Input | Result |
| --- | --- |
| API option absent and environment unset | Automatic resolution |
| Explicit positive value at least 256 MiB | Enforcing managed budget |
| Explicit zero | Invalid configuration; never silently becomes unlimited |
| Empty, signed, negative, non-decimal, or overflowed value | Invalid configuration |
| Positive value below 256 MiB | Invalid configuration |
| Explicit value on a supported platform | Enforcing managed budget |
| Automatic resolution with no supported limit source | Advisory/unbounded mode, with an explicit diagnostic; no bounded guarantee |

The minimum is a progress floor, not a promise that every workload fits. All
parsing and arithmetic must reject overflow before converting to `uint64_t`.
The internal zero value remains available only to represent an unlimited
ledger in tests and compatibility paths.

For the existing accounting hint, a threshold of `0` means pressure is true
for any valid nonzero subsystem cap, `100` means pressure starts at the cap,
and a value above `100` is invalid and returns false. This is not an admission
decision and does not reject an allocation.

Automatic resolution examines effective limits, not just the first file it can
read:

1. cgroup v2 `memory.max` and `memory.high`, including relevant ancestors;
2. cgroup v1 memory limits, including ancestors and unlimited sentinels;
3. `RLIMIT_AS` where supported, treating it as virtual address-space, not RSS;
4. supported Windows Job Object process-memory limits;
5. no physical-RAM-only fallback for an enforcing guarantee.

The internal `wl_session_create_with_options()` entry point accepts a
versioned, non-installed options object. Its `windows_job_handle` is a
borrowed opaque handle used only during synchronous creation; Wirelog stores
the resolved byte limit and provenance in the governor, and never duplicates
or closes the host handle. Missing, unsupported, or invalid handles clear the
provider and leave automatic resolution advisory unless another finite source
is available. `WIRELOG_MEMORY_BUDGET` remains higher precedence.
Options version 2 (#1473) adds `memory_governor`: a caller-retained governor
reference the session retains for its own lifetime in place of any resolved
source, so create-time admission can be driven deterministically from tests;
`windows_job_handle` and `WIRELOG_MEMORY_BUDGET` are ignored when it is set.
The program-owned intern table attached at creation keeps its own reference
until `wirelog_program_free()`, so the governor can outlive the session.

An unlimited cgroup value, an absent optional source, and an unsupported
platform are different observations. The resolver records which source was
selected and whether the result is enforcing or advisory. Tests use injected
provider fixtures for these cases; they must not depend on the host's actual
cgroup or RAM configuration.

## Reservation lifecycle

Every managed allocation follows this transaction:

```text
reserve(bytes) -> commit/transfer(owner) -> release(bytes)
       |                 |
       +-- rollback/cancel on failure
```

- `reserve` is an atomic admission operation against the shared session
  budget. It happens before the allocation can become visible to another
  operation.
- `commit` attaches the reservation to its owner. A transfer between the
  coordinator and a worker changes attribution, not the shared limit.
- `release` is idempotent for a committed reservation and returns capacity.
- Failed allocations roll back their reservation. Cancellation releases
  reservations and must not publish a partial result.
- A realloc that needs both old and new storage reserves the new size while
  the old size is still counted; only after a successful move may it release
  the old reservation.
- A governed replacement uses the same overlap accounting even when the new
  footprint is smaller:

  ```text
  committed(old) -> begin_replacement(new)
      -> commit_replacement(new) -> release
      -> rollback_replacement(old) when publication cannot complete
  ```

  `begin_replacement` is the downsize-only primitive: it admits the complete
  new footprint before replacement
  storage is allocated or published, so the governor accounts for old and
  new storage at the same time. Commit drops the old charge only after the
  new storage is published and the old storage has been freed; rollback drops
  only the temporary new charge. If the final accounting transition is
  rejected after publication, rollback retains the old reservation as a
  conservative upper bound rather than under-accounting the live storage.
  The reservation identity, owner attribution, and generation remain on the
  original token throughout the transition. Relation-level writer gates
  still serialize storage publication; this reservation lifecycle provides
  the memory admission and rollback guarantee.
- Batch compaction admits every governed replacement before preparing any
  member. If one overlap cannot fit, all reservations admitted for that batch
  are rolled back and no member is published; this is a finite no-progress
  result, not an unbounded retry.
- Overflow in a size, sum, or headroom calculation is a distinct
  representation-overflow failure, never a wrapped small reservation.
- A reserved cleanup/drain headroom remains available for rollback, error
  reporting, and worker teardown. It is not handed out as ordinary work
  capacity.

Coordinator and worker operations use one shared governor. A worker's ledger
share is an attribution and reporting figure that no scheduling reads; `W`
workers do not receive `W` independent hard budgets. RSS sampling, allocator
retention, and sampling lag may trigger a safety brake, but they do not rewrite
committed ownership.

## Failure and retry contract

These outcomes remain distinguishable internally and at the public boundary:

| Outcome | Meaning | Retry/reset rule |
| --- | --- | --- |
| Budget denial | Reservation would consume available managed capacity | Reclaim, reduce work, spill, or report a bounded-memory failure |
| Allocator failure | `malloc`/system allocation returned failure | Release reservation; report memory failure |
| Representation overflow | Size arithmetic cannot be represented | Release reservation; report invalid/overflow failure |
| I/O/spill failure | External backing store failed | Release or retain only durable committed state; report I/O failure |
| Cancellation | Host or operation cancellation | Roll back unpublished work and reservations |
| Unsupported configuration | Requested enforcement source/platform is unavailable | Explicit request fails; automatic mode may remain advisory as above |

On a successful retry after reclaim or a smaller request, the operation's
error state is reset and no partial rows are published. Retry loops are
bounded; the governor must not spin indefinitely while RSS or capacity is
unchanged. Public `create`, `insert`, `step`, and `snapshot` paths, including
typed and easy facades, must map these outcomes consistently when enforcement
is implemented.

## Ownership and sequencing

This issue defines the contract and boundary fixtures. Implementation is
owned as follows:

| Work | Owner | This contract supplies |
| --- | --- | --- |
| Budget source resolution, shared governor, advisory/enforcing state | #1368 | Precedence, providers, minimum, headroom, source provenance |
| Allocation-site admission and public propagation | #1369 | Reservation lifecycle, error taxonomy, retry/reset boundaries |
| Arrangement/cache lifetime and reclaim primitives | #1384 | Release/transfer behavior and cleanup reserve |
| Join admission, ingestion, TDD backpressure | #1382, #1402, #1383 | Workload-specific reservation sizes and rollback tests |
| Bounded DOOP and downstream gates | #1385–#1387 | Evidence that the contract works under constrained memory |

The existing ledger tests prove accounting invariants only: they do not prove
admission, allocator ownership, RSS control, or OOM prevention. In
particular, `wl_mem_ledger_alloc()` remains a post-allocation accounting call
and must not be used as a substitute for `reserve()`.

```mermaid
flowchart TD
  A[#1380 baseline/report] --> B[#1381 this contract]
  B --> C[#1368 resolver/governor]
  B --> D[#1384 lifetime/reclaim]
  C --> E[#1369 allocation admission]
  D --> E
  E --> F[#1382 join admission]
  E --> G[#1402 bounded ingestion]
  F --> H[#1383 TDD backpressure]
  H --> I[#1385 bounded DOOP]
  I --> J[#1386 six-workload gate]
```

## Acceptance evidence

The contract unit is complete only when documentation and executable ledger
fixtures agree on:

- exact percentage arithmetic at `UINT64_MAX` scale;
- zero/unlimited internal ledger behavior and clamped remaining capacity;
- threshold `0`, `100`, and invalid values above `100`;
- saturating accounting rather than counter wraparound;
- deterministic subsystem percentages summing to 100;
- the boundary between accounting evidence and future admission evidence.

Resolver-provider, reservation-lifecycle, and session-lifecycle tests now cover
the #1368/#1413 foundation. Allocation-site admission tests belong to #1369;
the current ledger still does not claim to enforce individual allocations.

## Foundation implementation status

The internal wirelog/columnar/memory_governor.{h,c} foundation implements
the resolver and tokenized reservation primitive for #1368. Explicit
WIRELOG_MEMORY_BUDGET values are strict decimal bytes: empty, signed,
negative, non-decimal, overflowing, zero, and values below 256 MiB are
invalid. When the variable is unset, injected or runtime providers reduce
finite cgroup v1/v2 and RLIMIT_AS limits to the effective minimum; Windows
job limits have the same provider boundary. If no finite supported source is
available, resolution is advisory and unbounded.

An enforcing resolution reserves 5% cleanup headroom, capped at 256 MiB and
never above half the budget. Ordinary reservations can consume only the
remaining usable limit. Reservation tokens move through reserved, committed,
and released states; rollback is valid only from reserved, and release
returns capacity exactly once. Session lifetime/public error integration is
#1413. Allocation-site admission remains the responsibility of #1369, with
the public batch result collector as the scoped exception implemented by
#1418: the result object, relation table, names, row buffers, and type arrays
share one governor reservation. Growth uses replacement buffers and admits
the full new footprint while the old buffer is still live, so a failed growth
leaves the previous result unchanged. The result retains the governor until
`wirelog_result_free()`, which releases the reservation exactly once.

The #1413 integration adds a reference-counted coordinator-owned governor to
columnar sessions before relation, pool, arena, cache, or worker setup. Worker
sessions retain the same governor reference and release it during every
normal or partial teardown path. The fixed eval arenas now use
`wl_arena_create_managed()`: their complete backing capacity is admitted before
`malloc`, retained across reset, and released exactly once at destruction.
Recursive TDD subpasses retain popped results, lower stack entries and CONCAT
segment boundaries in persistent cleanup frames. Segment metadata is disposed
with its entry; a refused owned relation keeps its metadata and allocator
storage reachable. The specialized nonrecursive parallel rule evaluators use
the same frames; K-Fusion is the one evaluator still draining an unframed
stack, tracked by #1648.

Hybrid TDD initialization gives existing empty IDBs private governed worker
relations, preserving schema, graph/compound metadata and timestamp mode.
Only EDB/earlier-stratum inputs use shared views: borrowing empty IDB storage
would prevent the coordinator from publishing the first delta. Partial setup
reclaims every untransferred slot, including the current incomplete relation. The
partitioned, replicated and global-read initializers likewise inspect every
allocated worker row and original relation slot on failure. Non-NULL matrix
entries remain caller-owned; worker creation NULLs entries only on transfer.
Attempted-worker counts control checked teardown, never caller-slot cleanup.
A refused worker stays in the coordinator cohort until release and retry.

Final recursive aggregate canonicalization takes the canonical relation's source
writer and excludes live storage aliases before changing rows or timestamps.
Borrowed destinations refuse publication. Reader/alias refusal and group-map
allocation failure preserve the relation; access is released before arrangement
invalidation. TDD final relation normalization likewise uses an admitted private
candidate and checked publication after worker dependencies retire. Merge paths
consume worker results before teardown; finalization errors do not record
convergence or advance completed iteration history. Private exchange intermediates
and global-read exchange publication remain separate from this final boundary.
Specialized nonrecursive publication stages independent worker results before
retiring input views, then publishes one checked normalized replacement.

Heap and pooled constructors create independently owned Arrow schemas, including
untyped and zero-width relations. Clones preserve declared width, names, types,
graph metadata and required compound maps; a failed required map copy fails
construction instead of changing tuple interpretation. Arena-backed pooled
construction initializes schema without replacing arena columns. Partitions
preserve that metadata and scatter timestamps with their rows. Empty and
replicated worker inputs use governed clones; legacy partition buffer allocation
still follows its existing admission contract.

The fixed delta-pool slab and data arena follow the same lifecycle through
`delta_pool_create_managed()`. Coordinator, ordinary worker, and K-fusion
branch arenas and pools all use the same shared governor; legacy standalone
constructors remain unmanaged. Their ledgers remain attribution-only: each
TDD worker's ledger gets an equal share of the coordinator's budget, which the
worker's report measures against and which limits no allocation (section 6),
and a K-fusion branch's ledger copies the coordinator's. The removed
`tdd_budget_per_party` value is no longer a second governor admission domain.
Explicit invalid budgets fail session creation with the existing public
execution error mapping and leave output handles null. Parser AST, IR/program,
execution plan, executor wrapper, caller-owned fact buffers, CSV staging, and
advanced-API conversion buffers remain outside the result-only admission unit;
extending admission across parse → IR → optimize → plan requires a separate
lifetime and caller-owned context design.

The next #1369 allocation unit, #1425, admits only the `ht_head` and
`ht_next` backing arrays of primary, delta, and filtered hash arrangements.
Each arrangement retains the shared session governor while its registry entry
is alive. Full rebuilds and incremental capacity growth reserve the
prospective footprint before allocating replacement arrays; the old
reservation remains live until publication, and failed admission leaves the
old index unchanged. Sorted and differential arrangements, registry metadata,
relation/timestamp storage, cache policy, and join/TDD scratch remain separate
allocation classes.

## #1418 Allocation Coverage Matrix

The session relation-name hash owns a governor reservation for its bucket and
chain arrays. Rebuilds reserve both replacement arrays while the old index is
live; denied optional rebuilds leave lookup on its linear fallback.
Transactional registry images hold their hash reservation until discard or
publication, when it moves to the session. Coordinator and worker relation
pointer arrays reserve their full capacity before allocation or replacement.
A prepared image separately reserves its future relation array and validation
copy; publication moves the future array token to the session and releases
the validation copy. Relation descriptors, names and schema metadata remain
a separate allocation class.

The following matrix is the boundary for allocations created outside a
managed columnar session. “Covered” means that the owner retains a governor
reservation and publishes growth only after both admission and allocation
succeed. “Excluded” is an explicit non-guarantee; the owner must still
propagate failure and must not report a truncated successful result.

| Allocation class | Owner and lifetime | #1418 status | Failure contract |
| --- | --- | --- | --- |
| Parser AST and parse diagnostics | `wirelog_program_t`, released by `wirelog_program_free()` | Excluded; parse context is created before a managed session | Return `NULL` with `WIRELOG_ERR_PARSE` or `WIRELOG_ERR_MEMORY`; no partial program is published |
| Interned strings (`wl_intern_t`: hash slots, id segments, string copies) | `wirelog_program_t`; the reservation is retained until `wirelog_program_free()` | Covered from the first managed session (#1431): session creation attaches the program's table to that session's governor and admits the bytes it already holds transactionally, so session creation fails with `ENOMEM`/`EOVERFLOW` (public `WIRELOG_ERR_MEMORY`) when they exceed the budget; session destruction never releases it; while a live session, worker or result still holds that governor, later sessions get `EBUSY` and leave it in place, and once the table is the only holder the next session creation rebinds the table transactionally (#1469): the retained footprint is admitted under the new governor first and only then credited back to the orphaned one, so a denied rebind (`ENOMEM`/`EOVERFLOW`, session creation fails) leaves the old reservation and the new governor unchanged. Each unique `wl_intern_put()` reserves the string copy plus any new id segment or doubled slot array before allocating, with the old footprint still held; duplicates are uncharged | `wl_intern_put()` returns `-1` and leaves every existing id, `wl_intern_reverse()` result and the reservation unchanged. String builtins, `uuid5_rfc` and non-pre-interned literals whose result cannot be interned fail the evaluation step with `ENOMEM` and publish no row (#1470), which the easy, advanced and legacy facades report as `WIRELOG_ERR_MEMORY` without a scalar-extension diagnostic (#1521); invalid operands still yield `-1` as before |
| IR/program relation metadata | `wirelog_program_t`, released with the program | Excluded; same owner as parser output | Return `NULL` with the existing parse/IR error; callers retain no partially initialized program |
| Optimized execution plan | `wirelog_executor_t`, released by `wirelog_executor_free()` | Excluded; plan construction precedes result collection | Return `NULL` with `WIRELOG_ERR_INVALID_IR`, `WIRELOG_ERR_MEMORY`, or the existing executor error |
| Executor/session wrapper and columnar session storage | `wirelog_executor_t` and its session | Covered by #1413/#1369 session admission, not charged again here | Session creation fails with the existing public memory error and releases all reservations |
| Public result object, relation table, names, row buffers, and type arrays | `wirelog_result_t`, released by `wirelog_result_free()` | Covered by #1418 | Reserve the prospective footprint before replacement allocation; rollback leaves the old result unchanged and reports `WIRELOG_ERR_MEMORY` |
| Caller-owned fact buffers and input rows | Caller, released by the caller or input adapter | Excluded; ownership is external to wirelog | Reject the operation or return the existing input error; never charge or free caller storage |
| CSV staging and advanced-API conversion buffers | CSV/advanced API call, released at call completion | Excluded; temporary caller-facing buffers have independent ownership | Return `false` or the existing API error and discard the temporary buffer |

The matrix intentionally has one admission owner per allocation. The result
collector uses reservation move semantics when publishing a new token, so
the reservation identity follows `wirelog_result_t` rather than a temporary
stack object. The governor's denial, rollback, overflow, and exact-release
fixtures provide the admission primitive evidence; the Linux-only
`wirelog_result_oom` test uses linker allocation-failure injection over a
32-row result so relation-table and row-buffer growth cannot silently return
a truncated success. `wirelog_public_api` covers result lifetime after
executor destruction and the public error path. Other platforms retain the
same production transaction and ABI checks, while platform-specific allocator
failure injection remains outside this unit because GNU `--wrap` is not a
portable linker contract.
# wirelog Memory Instrumentation

This document describes what the columnar engine measures about its own
memory use, how to read the numbers, what they cost, and the baselines that
bounded-memory work (Issue #1367 and its sub-issues) starts from.  It covers
Issue #1380.

The ledger is an accounting instrument, while the memory governor uses the
resolved budget to admit covered allocation classes before they grow. Coverage
is incremental; the sections below describe which paths participate.

## 1. Units and conventions

- Every value is a byte count of an exact allocation size as requested from
  `malloc`/`calloc`/`realloc`, not a page count and not what the allocator
  actually reserved.
- The human-readable report uses binary prefixes: `1.0KB` is 1024 bytes,
  `1.0MB` is 1048576 bytes, `1.0GB` is 1073741824 bytes, printed with one
  decimal.
- Peak RSS (`rss_peak`) comes from `getrusage(RUSAGE_SELF).ru_maxrss`.  It
  is a process-wide, monotonically increasing kernel value: kilobytes on
  Linux (converted to bytes), bytes on macOS, unavailable on Windows
  (reported as 0).
- `current` is the value at the moment of the report; `peak` is the
  session-lifetime high-water mark of that counter.  Peaks are never reset
  by a second `wl_session_snapshot()`.

## 2. The ledger

Each `wl_col_session_t` embeds one `wl_mem_ledger_t`
(`wirelog/columnar/mem_ledger.h`).  It holds a total, a total peak and one
current/peak pair per subsystem. Every accounting writer acquires a ledger-local
writer gate; protected saturating/clamped arithmetic uses finite atomic
loads/stores. K-fusion branch threads and TDD workers can share a ledger, while
raw writer admission may wait and does not guarantee fairness or cancellation.
Snapshots retain relaxed atomic reads and may observe intermediate counter
updates. Initialization/reset is quiescent; no callbacks, reclaimers, allocations
or other lock acquisition run inside an accounting critical section. Two update
styles exist:

- **Event accounting** (`wl_mem_ledger_alloc`/`wl_mem_ledger_free`): the
  owner of an allocation charges when it allocates and credits when it
  frees.  Used where allocation and release are paired in code.
- **Gauge sampling** (`wl_mem_ledger_set_gauge`): the session re-measures a
  class it can enumerate and publishes the absolute value; the total moves
  by the difference.  Used where objects are mutated by many code paths
  without a single owner.

TDD worker sessions are separate `wl_col_session_t` values with their own
ledgers (budget = the per-party share, see §6).  Their peaks are folded into
the coordinator's aggregates when a worker is torn down, which happens after
every stratum that ran under TDD.

### 2.1 Subsystems

| Subsystem | Style | What is counted | Where |
|---|---|---|---|
| `RELATION` | event | Column buffers of operator output relations whose `col_rel_t.mem_ledger` is attached; today that is every join output (`col_join_attach_ledger`). Capacity-based (`capacity × owned columns × 8`). | `relation.c` growth, compaction and free paths |
| `ARENA` | event | Fixed capacity of the session's delta pool (slot slab + data arena) and eval arena, plus the compound arena object, generation table, payload buffers, and entry metadata. Each retained capacity is admitted before allocation with old/new peak overlap and released at destruction; the ledger remains attribution-only. `delta_pool_reset()`/`wl_arena_reset()` and compound epoch GC do not return retained capacity. K-fusion branch sessions charge their per-branch pool/arena to the parent. | `session.c`, `kfusion.c`, `arena.c`, `delta_pool.c`, `compound_arena.c` |
| `CACHE` | event | Materialization-cache entries. On insert the cached result is re-parented: its RELATION (and TIMESTAMP) charge is credited and the same bytes are charged to CACHE, so a cached join is counted once. Credited on eviction, truncation and clear. | `cache.c` |
| `ARRANGEMENT` | event | Hash arrangements (`ht_head` + `ht_next`), delta and filtered arrangements, sorted copies for LFTJ (`nrows × ncols × 8`, a full duplicate of the relation), differential arrangements (struct + keys + buckets + chain), and differential-registry arrays plus each entry's relation name and key columns. Worker clones are charged to the worker ledger. | `arrangement.c`, `diff_arrangement.c` |
| `TIMESTAMP` | event | `timestamps[]` arrays (24 bytes per row of capacity) of ledger-attached relations. Reconciled together with RELATION. | `relation.c` |
| `CHANNEL` | event | TDD delta transport: the stratum's channel side buffers (channel object, lanes, consumer list heads and staging flags, charged at channel creation) plus the transport bytes reserved for every published batch (columns + timestamps) between the worker's publish and the coordinator's take or discard. Charged on the coordinator's ledger because ownership transfers at publish. Batch descriptors are admitted under the governor with tokens of their own and are not charged here. | `eval.c`, `eval_tdd_channel.c` |
| `STORED` | gauge | Session-owned relations in `rels[]`: EDB and IDB relations on the coordinator, partitions on a worker. Column buffers plus timestamps; arena-owned columns count 0. | sampled, see §2.2 |
| `TEMPORARY` | gauge | Delta-pool temporaries whose column buffers spilled to the heap because the pool arena was full (`pool_owned && !arena_owned`), excluding those already attached to RELATION, plus admitted evaluator cleanup frames and retained delta-step rollback records. | sampled, see §2.2 |

The per-subsystem cap printed in the report is `budget × share / 100` with
shares `50/10/10/10/5/5/5/5` in the order above.  Only the RELATION share
has an observable effect (§6); the others exist for the report.

### 2.2 Sampling points

`col_session_mem_sample()` re-measures STORED and TEMPORARY:

- on the sequential evaluator, immediately before every `delta_pool_reset()`
  (end of a non-recursive stratum, end of every recursive sub-pass, end of
  the recursive stratum), which is the high-water point of the temporaries;
- on a TDD worker, at the same point of its sub-pass;
- on the TDD coordinator, once per outer iteration;
- at the end of every `wl_session_snapshot()`, and once more in
  `col_session_destroy()` when a report is requested.

Cost is one pass over `nrels` plus the used pool slots, with no allocation.

### 2.3 What is not counted

The difference between `rss_peak` and the ledger peak is the unaccounted
remainder.  Known contributors, in roughly decreasing order for large
workloads:

- **Allocator overhead and fragmentation.** The ledger records requested
  sizes; glibc's arenas, per-thread caches and retained free chunks are
  invisible to it.  This is the largest term on DOOP-sized runs.
- **Delta-pool overflow structs.** When the slot slab is exhausted,
  temporaries fall back to `calloc`'d `col_rel_t` structs that are not
  enumerable from the pool and therefore not sampled into TEMPORARY.  Their
  column buffers are still counted if they are join outputs (RELATION).
- **K-fusion branch sessions.** A branch session is a struct copy of its
  parent, including a bitwise copy of the ledger that is discarded at
  teardown.  Branch arenas and pools are redirected to the parent (ARENA),
  but join outputs, arrangements and caches created inside a parallel
  branch (K ≥ 4) charge the throwaway copy.  #1375 retires this path.
- Parser and IR, the execution plan, nanoarrow schemas, the compound-term
  arena, exchange buffers, thread stacks (8 MB per TDD worker by default)
  and the work queue.  The intern table is program-owned but charged to
  the first managed session's governor (#1431, see the #1418 matrix); its
  bytes appear in that governor's reserved total, not in the session ledger.
  Once no live session, worker or result holds that governor, the next
  session creation rebinds the table to its own governor (#1469).

## 3. Reading the report: `WL_MEM_REPORT`

`WL_MEM_REPORT` is read once at session creation.

| Value | Effect |
|---|---|
| unset, empty, `0` | No memory output. |
| `1` | At `col_session_destroy()` print the coordinator summary: one header line with `rss_peak`, the ledger table, and one aggregate line for TDD workers. |
| `2` | Additionally print the full ledger of every TDD worker when it is torn down (after every TDD stratum, so this is verbose). |

Example (`W=8`, the 100-edge closure fixture, level 2, one worker shown):

```
[wirelog mem] scope=coordinator workers=8 rss_peak=9.0MB
[wirelog mem] budget=94.3GB current=128.2MB peak=224.5MB
  RELATION     current=0B         peak=1.0MB      cap=47.2GB
  ARENA        current=128.1MB    peak=224.1MB    cap=9.4GB
  CACHE        current=0B         peak=0B         cap=9.4GB
  ARRANGEMENT  current=64.1KB     peak=64.1KB     cap=9.4GB
  TIMESTAMP    current=0B         peak=0B         cap=4.7GB
  CHANNEL      current=0B         peak=0B         cap=4.7GB
  STORED       current=100.6KB    peak=248.6KB    cap=4.7GB
  TEMPORARY    current=0B         peak=80.0KB     cap=4.7GB
[wirelog mem] tdd_workers reports=8 peak_max=12.5MB peak_sum=98.8MB
[wirelog mem] scope=worker id=0 workers=8
[wirelog mem] budget=10.5GB current=12.3MB peak=12.5MB
  RELATION     current=0B         peak=128.0KB    cap=5.2GB
  ARENA        current=12.0MB     peak=12.0MB     cap=1.0GB
  ...
```

`reports` is the number of worker teardowns folded in, `peak_max` the
largest single worker peak and `peak_sum` the sum of all worker peaks (an
upper bound on their concurrent footprint, since the same worker slot is
recreated per stratum).

The report is not async-signal-safe and goes to `stderr` unconditionally;
it does not use `WL_LOG`.

## 4. Programmatic access

`col_session_get_mem_stats()` (`wirelog/columnar/columnar_nanoarrow.h`,
internal) fills a `wl_columnar_mem_stats_t` with the same numbers: budget,
current, peak, per-subsystem current/peak indexed by `WL_MEM_SUBSYS_*`,
`rss_peak_bytes`, and the three worker aggregates.
`wl_columnar_mem_subsys_name()` maps an index to its name.  The accessor is
NULL-safe and never touches the atomics directly (it goes through
`wl_mem_ledger_snapshot()`).

`bench_flowlog --format json` emits the stats of the last run as
`ledger_peak_bytes`, `ledger_budget_bytes`, `ledger_worker_reports`,
`ledger_worker_peak_max_bytes`, `ledger_worker_peak_sum_bytes` and the
object `ledger_subsys_peak_bytes`, next to the existing `peak_rss_kb`.

## 5. Overhead

- **Event accounting:** one relaxed `fetch_add` (plus a peak CAS loop) per
  charge and one CAS loop per credit.  Charges happen on buffer growth, not
  per row: a relation that doubles its capacity is charged once per
  doubling.  The fast path of the join operator is unchanged.
- **Gauge sampling:** O(`nrels` + used pool slots) at each point in §2.2,
  typically a few hundred pointer reads per iteration.
- **Report:** a handful of `fprintf` calls at session teardown; nothing at
  all unless `WL_MEM_REPORT` is set.
- **Result identity:** instrumentation is always on; `WL_MEM_REPORT` only
  adds output.  `tests/test_mem_instrumentation.c` runs the fixture with the
  variable unset, `1` and `2` at W=1 and W=8 and requires identical tuple
  counts, iteration counts, relation contents and ledger peaks.

The instrumentation adds one pointer to `col_arrangement_t`,
`col_diff_arrangement_t`, `col_sorted_arr_t` and `col_mat_cache_t`, and one
`uint64_t` to `col_rel_t` and `col_mat_entry_t`.

## 6. Budget: `WIRELOG_MEMORY_BUDGET`

`WIRELOG_MEMORY_BUDGET=<bytes>` is the explicit managed-memory budget. An
unset value resolves the effective minimum of supported cgroup, address-space,
and host Job Object limits; when no finite source exists, the resolver is
advisory/unbounded. Explicit `0`, malformed values, overflow, and values below
256 MiB are invalid. This resolver does not use physical RAM as an enforcing
fallback. The legacy ledger worker-share hint remains separate from governor
admission. Fixed eval-arena, delta-pool, compound-arena backing storage, and
the covered join allocation paths use admission. LFTJ iterator/sort workspace
and operator staging use governor reservations; remaining LFTJ output/source
boundaries, auxiliary metadata, and eval-entry segment allocations remain
follow-up work tracked by #1978.

The recursive TDD path's batch channel (#1373) derives its capacity from
the budget: an eighth of an enforcing budget, clamped to [4 MiB, 1 GiB], or
256 MiB when no budget is enforced. `WIRELOG_TDD_CHANNEL_BYTES=<bytes>`
overrides it with a positive decimal that fits in 64 bits; any other value
is ignored. The capacity bounds the transport bytes queued or reserved at
once, apart from one batch larger than the capacity, which is admitted into
an empty channel. Producers wait for space while the coordinator takes
batches; the batches it has taken are not counted against the capacity.

The batches the coordinator has taken are held until the round's exchange
stages their relation into the delta matrix. While the round runs, each
take onto a (worker, relation) list is followed by a cap pass: when the
charges of the resident batches held exceed the held cap and the session
has a spill store (`spill_directory`), the coordinator spills the largest
of them until they fit. The held cap is a quarter of an enforcing budget,
or none when no budget is enforced. `WIRELOG_TDD_HELD_BYTES=<bytes>`
overrides it with a positive decimal that fits in 64 bits; any other value
is ignored. A batch whose spill fails stays resident and governed, so the
held bytes can exceed the cap; `held_over_cap` in the consumer statistics
counts the passes that ended over it.

The exchange stages one relation at a time. Before it coalesces a
relation's batches into the delta matrix, reading the spilled ones back, it
spills the other relations' resident batches, largest first, while their
charges, the matrix slots the other relations still hold, and an estimate
of the staging's peak together exceed the held cap. The estimate counts an
adopted batch's charge; for a fresh slot it counts the resident inputs and
the slot's row bytes, and when two or more batches may be consolidated, the
row bytes again and 4 bytes a row. Owner mode keeps the batches it adopted
until its commit retires them, but destroys a slot that staging built as
soon as its exchange has copied it, unless the destroy is refused. Unless
`stage_over_cap` counts a staging, the other relations' held batches and
matrix slots fit within the cap while a relation stages (`stage_peak_bytes`
in the consumer statistics). The cap does not bound that relation's staged
slots, the buffers the exchange builds from them, the publication
candidates owner mode has built for the relations exchanged before it, or
the next round's inputs. The exchange creates its unions, gathered
partitions, broadcast copies and BDX combinations under the governor. The
partitions `col_rel_exchange_partition` writes for the hash scatter, BDX,
owner and global-read exchanges are accounted after allocation, when the
exchange attaches them to the governor; global-read's exchange attaches
each partition it installs once it is renamed and destroys the empty ones
unattached. The partitions global-read's stratum-start seed
(`tdd_seed_global_read_initial_deltas`) installs on the workers are not put
under the governor. The shared views the exchange installs on workers hold
no storage of their own and are not put under the governor, and neither is
the destination of the deep copy a view falls back to.

Three more things exceed the caps: one batch larger than the channel
capacity, which an empty channel admits, batches that cannot be spilled,
and batches taken in discard mode. The spill refuses, among others, a
batch with a `STRING` column, a batch with compound columns, inline or
not, and a batch without timestamps; such a batch stays resident, and each
cap pass that ends over the cap for it counts in `held_over_cap`. Without
a spill store nothing is spilled, and only the governor limits what the
coordinator holds. Once a round cannot succeed, because a lane has closed
with an error, a batch was invalid or a pump failed, the coordinator
pushes each batch it takes onto its discard list with no cap pass: those
batches stay resident and governed until the round's producers are joined
and the list is disposed of, and neither the held bytes nor
`held_over_cap` count them. A worker error does not cancel the round, so
the other workers may publish the rest of their round's output, which the
coordinator takes onto that list before the join.

Each worker's ledger is initialized with an equal share of the coordinator
ledger's budget, which the worker's report measures against and which
limits no allocation: the workers allocate under the coordinator's one
governor, so a skewed worker may use far more than its share of the
budget. Producing a JOIN's output as sub-batches through the channel,
evaluating batches downstream as they arrive within a round, and their SCC
and frontier integration remain with #1383, and qualifying DOOP under a
budget with #1385.

The ledger's RELATION worker-share hint,
`wl_mem_ledger_should_backpressure(RELATION, 80)`, has no caller in the
library, so it triggers no join backpressure. The governor admits covered
allocations and reports refusals upstream. The legacy
`WIRELOG_JOIN_OUTPUT_LIMIT` row cap is disabled when unset, empty, or zero; a
positive decimal keeps the optional per-join cap, clamped to `UINT32_MAX`.
Malformed values fail session creation. This row cap is not the memory budget
and does not replace allocation admission.

## 7. Baselines

### 7.1 DOOP zxing (`bench_flowlog --workload doop`)

Dataset checksum `154593343fefd18306d4098ba9f6286947b134b56ebcf83d8e8eae368d5867e7`,
35 fact files, `--repeat 1`, release-like build, `WL_MEM_REPORT=1`, taken
on 2026-09-06 with the ledger coverage that existed at the time (RELATION
only; every other subsystem read 0).

| workers | duration | OS peak RSS | ledger peak (RELATION) | tuples | iterations | status |
|---:|---:|---:|---:|---:|---:|---|
| 1 | 2,335,563 ms (38 min 56 s) | 54,646,124 KB (52.1 GiB) | 32.0 GB | 13,828,835 | 153 | OK |
| 2 | 2,064,134 ms (34 min 24 s) | 56,718,660 KB (54.1 GiB) | 15.2 GB | 13,828,835 | 153 | OK |

The W=2 ledger peak is lower because half of the join outputs were charged
to worker ledgers, which were not aggregated at the time; OS RSS is higher
at W=2.  The 20 to 39 GiB gap between RSS and the ledger is the §2.3
remainder plus the classes that were not yet instrumented (stored
relations, arrangements, transport).  A rerun with the current coverage is
part of #1385; the nightly perf portfolio (§7.3) records the numbers per
run from now on.

### 7.2 Fixture: 100-edge chain closure (`tests/test_mem_instrumentation.c`)

`r(x,y) :- edge(x,y).  r(x,z) :- r(x,y), r(y,z).`, 5050 closure rows,
7 iterations, `WIRELOG_TDD_MIN_ROWS_PER_WORKER=1` for W=8 so the stratum
runs under TDD.  Printed by the test on every CI run as `mem-baseline`
lines; values in bytes, `current/peak`.

| build | W | ledger peak | rss_peak | worker peak_max (reports) | RELATION | ARENA | ARRANGEMENT | CHANNEL | STORED | TEMPORARY |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fused | 1 | 135,721,092 | 5,545,984 | 0 (0) | 0/1,048,576 | 134,303,744/134,303,744 | 65,604/65,604 | 0/0 | 103,040/254,528 | 0/81,920 |
| fused | 8 | 134,961,176 | 5,750,784 | 13,055,492 (8) | 0/0 | 134,303,744/134,303,744 | 0/0 | 0/657,432 | 133,120/133,120 | 0/0 |
| nofusion | 1 | 135,721,092 | 5,701,632 | 0 (0) | 0/1,048,576 | 134,303,744/134,303,744 | 65,604/65,604 | 0/0 | 103,040/254,528 | 0/81,920 |
| nofusion | 8 | 134,961,176 | 8,491,008 | 13,055,300 (8) | 0/0 | 134,303,744/134,303,744 | 0/0 | 0/657,432 | 133,120/133,120 | 0/0 |

Reading the table: at W=1 the coordinator runs the joins itself (RELATION
and ARRANGEMENT non-zero); at W=8 they move to the workers (coordinator
RELATION/ARRANGEMENT 0, worker peak 12.5 MB each of which 12 MB is the
worker's own pool + arena), and the delta transport shows up as CHANNEL.
ARENA on the coordinator is the 64 MB pool arena + 256 slots + 64 MB eval
arena regardless of W.  `rss_peak` is below the ledger peak here because
the arenas are reserved but never touched at this size.

### 7.3 CI evidence

- `meson test` runs `mem_instrumentation_default` and
  `mem_instrumentation_nofusion` on every PR; their stdout carries the
  `mem-baseline` lines above for the current commit.
- `.github/workflows/perf-nightly.yml` runs `scripts/perf/run-flowlog-portfolio.py`,
  which now records `ledger_peak_bytes`, `ledger_worker_peak_max_bytes` and
  `ledger_subsys_peak_bytes` per (workload, workers) in `portfolio.jsonl`
  and the first two in `portfolio.tsv`, uploaded as the
  `perf-portfolio-<os>-<compiler>` artifact (35-day retention).

### 7.4 Reproducing

```
# Fixture baselines (both builds)
meson test -C build mem_instrumentation_default mem_instrumentation_nofusion -v

# Any bench_flowlog workload, JSON with ledger fields
./build/bench/bench_flowlog --workload tc --data bench/data/graph_100.csv \
    --workers 8 --repeat 1 --format json

# Human-readable report from any program
WL_MEM_REPORT=1 ./build/wirelog_cli --workers 8 program.dl
WL_MEM_REPORT=2 ./build/wirelog_cli --workers 8 program.dl   # + every worker

# DOOP (needs bench/data/doop, ~40 GB peak, tens of minutes)
WL_MEM_REPORT=1 ./build/bench/bench_flowlog --workload doop \
    --data-doop bench/data/doop --workers 1 --repeat 1 --format json
```

## 8. Compound-arena mutation window (#1423)

The coordinator owns compound-arena mutation and its governor reservations.
Workers acquire a non-copyable read lease before using a borrowed arena; the
lease remains active for the lifetime of any lookup pointer. Allocation,
retain, freeze/unfreeze, epoch GC, and destruction acquire the exclusive
mutation gate and therefore fail while a worker lease is active. The
coordinator must close all worker leases before destroying the arena.

Compound payload, entry-offset, and multiplicity growth is staged as one
transaction. A failure at any staging allocation frees only the new buffers,
rolls back pending reservations, and leaves the old pointers, counters and
governor charge unchanged. The unmanaged constructor remains independent of
the governor and the standalone fuzz target.

## 9. Related

- Issue #1380 (this instrumentation), #1385 (DOOP under a budget),
  #1367 / #1368 (memory governor and admission), #1375 (K-fusion
  retirement, which removes the branch-session gap in §2.3).
- `docs/THREADING.md` §5.1 audits every atomic in `mem_ledger.c`.
- `docs/STRESS_BASELINE.md` §Issue #598 for the rotation canary that
  asserts `current_bytes` is unchanged across `wl_arena_reset()`.

## 10. Primary arrangement leases (#1384)

### Integrated ownership and reader boundaries

The following matrix describes the implemented ownership mechanisms. A cache
pin protects its entry; a source reader protects the relation version that an
operator actually reads. Neither is implied merely by putting a pointer on
the evaluation stack. Paths below are relative to `wirelog/columnar/`.

| Resource | Owner and reader protection | Release / invalidation boundary | Implementation |
|---|---|---|---|
| Session relation columns, schema and timestamps | Session owns the relation; source readers bind its descriptor and ultimate storage owner | Checked mutation/destruction requires writer access; identity, view and storage generations invalidate dependent views | `relation.c`, `session.c` |
| Worker relation views and compound arena | Worker owns private descriptors/arrangements and borrows coordinator storage through source/arena leases | Drain tasks and release aliases/read leases before coordinator storage is destroyed | `session.c`, `../arena/compound_arena.c` |
| Owned evaluation-stack result and segment boundaries | Stack entry owns destruction of its relation and its segment array | `eval_entry_dispose` destroys the relation before freeing segment metadata; a refused disposal retains the entry | `eval_stack.c` |
| Borrowed evaluation-stack result | Relation remains owned by its session, cache or enclosing operation; the entry does not acquire a general-purpose pin | Owner must outlive every consuming operator; disposing the entry does not destroy the borrowed relation | `eval_stack.c`, `eval_plan.c` |
| Primary hash arrangement | Session cache owns buckets/chains; probe bundle holds index pin and source readers | Eviction skips pins; invalidation defers; final release permits lazy rebuild | `arrangement.c`, `join.c` |
| Sorted arrangement | Session owns sorted copy; LFTJ probe pins entry and source | Release probe before teardown; source changes require rebuild, deferred while pinned | `arrangement.c`, `lftj.c` |
| Differential arrangement | Session owns persistent index; transaction owns unpublished replacement; pin binds source snapshot | Replacement/invalidation cannot overwrite a leased index; abort discards staged work; final release applies deferred reset | `diff_arrangement.c`, `diff_join_batch.c` |
| Filtered-relation cache | Cache owns filtered relation; explicit cache pins defer replacement | Last pin release destroys an invalidated entry; immediate-release lookup wrapper does not retain a pin for its caller | `filter.c` |
| Materialization cache | Cache exclusively owns accepted heap results; lookup pin protects copying | JOIN exposes an independent copy to the stack; eviction/clear waits for pins and destroys the cached result once | `cache.c`, `join.c` |
| Delta transport payload | Producer transfers an owned relation to the channel at publish, then to the coordinator matrix | A (worker, relation) slot may receive several batches; the held cap may replace a taken batch's relation with its spilled payload, which coalescing reads back; coalescing unions them into one matrix slot; discard destroys each owned queued or listed payload; owner mode destroys a slot that staging built for the coordinator alone once its exchange has copied it, unless the destroy is refused, and keeps refused retirements on the lifetime's retained list | `eval_tdd_channel.c`, `eval.c` |
| Continuation scratch and published batches | Producer owns scratch and input/index leases; synchronous sink owns committed output | Cursor advances at publication commit; destroy releases producer state; no asynchronous lifetime is implied for scratch-backed payloads | `continuation.c`, `join_batch.c`, `diff_join_batch.c` |
| Delta-step rollback snapshots | Session owns admitted metadata, copied names and flat rows; stable relation identities prevent restoration into replacement registrations; a GC-only compound hold preserves handle IDs | Capture completes before detachment; checked restoration retains refused backups; successful evaluation or recovery releases them once; teardown discards pending backups after evaluator cleanup | `eval_delta.c`, `relation.c`, `session.c` |

Differential-registry memory is admitted before allocation. A session plan with
keyed JOIN candidates reserves a flat registry large enough for the candidate
JOIN count (at least four entries); each entry's copied relation name and key
columns are admitted before construction. Worker clones reserve their own
registry and entry metadata, while each cloned differential arrangement
reserves its own storage. Registry growth outside a controlled attempt admits
the complete old-plus-new allocation overlap before copying and releases the
old-array charge after the swap. Growth remains a synchronous allocation and
copy; a controlled attempt that unexpectedly needs registry growth fails
closed instead of entering that unbounded region.

### Residual lifetime evidence (#1812)

`timestamp_capacity` counts timestamp rows, not columns (`ncols`). Auditing
`col_rel_prepare_resize`, `col_rel_publish_resize`, `col_rel_compact_impl`,
`col_rel_install_shared_view_unprotected` and `col_rel_free_contents_impl` gives these
boundaries: nonempty compaction prepares both replacements before publication,
sets timestamp capacity to the tight row capacity, advances storage generation,
and frees the old timestamps before settling accounting. Preparation failure
keeps the old buffers; a later accounting refusal can conservatively retain a
reservation after publication. Empty non-nullary compaction frees timestamps and
zeros their capacity; nullary compaction is a no-op. A shared-column view owns
its copied timestamp array, sized to the larger of source row capacity and
source timestamp capacity. Column-only COW can retain that array. Consequently
row capacity and timestamp capacity must be accounted separately; shrinking
columns is not proof that the timestamp allocation shrank. Row reset frees the
array, while copying/transferring replacements must preserve its metadata.

The existing **Delta-step rollback snapshots** row is the live rollback-buffer
policy, rather than a second row for dormant `retract_backup_*` fields. Its six
axes are: **owner**, the session's `delta_rollback` record; **acquire**,
`wl_columnar_eval_delta_capture`, before detachment; **last reader**, active
evaluation or a pending recovery attempt; **invalidation**, stable relation
identity checks prevent restoring into a replacement registration; **destruction**,
`wl_columnar_eval_delta_rollback_discard`, after cleanup permits it; and
**rebuildability**, not reconstructible from mutated live rows, so refused
restoration retains the captured names/flat rows and compound GC hold.
`wl_columnar_eval_delta_rollback_retry` consumes that record in recovery, and
session/worker teardown calls discard after evaluator cleanup. This flat-row
snapshot is not a claim to preserve arbitrary timestamp provenance.

The following controls establish specific assertions, not merely that a named
binary runs under a sanitizer:

| Obligation | Assertion-bearing evidence |
|---|---|
| Pinned cache value resists reclaim | `test_cache_reclaimer.c:test_pin_generation_and_idempotence` holds an epoch pin through clear/reclaim; final release permits destruction. `test_borrowed_stack_keeps_independent_cache_pin` keeps exact borrowed rows and charge through reclaim and stack drain; the enclosing operation, not the stack entry, owns the explicit pin. |
| Suspended reader resists eviction | `test_join_batch_resume.c:test_suspended_producer_survives_eviction` publishes a nonterminal batch, triggers normal LRU eviction with an unpinned control, preserves the live cursor/index, resumes to 40 exact unique rows, then permits eviction on release. |
| Reordered rules preserve exact results | `test_recursive_scc.c:check_scc` runs both `original` and `reordered` at W1/W8 in the default and unfused test binaries; it checks all 66 `p` pairs and three `r` tuples and rejects duplicates/unexpected rows. |
| Partial worker construction is cleaned and retryable | `test_worker_session.c:test_partial_worker_adoption_cleanup_and_retry` refuses the second partition's reader after adopting the first view; checks caller ownership, released leases/compound borrow and balanced charges; releases the writer and retries successfully. This fails before worker arena/pool creation. |
| Checked destruction and coordinator reuse | `test_worker_session.c:test_worker_alias_chain_checked_teardown` releases two aliases in order and then inserts into the coordinator. `test_worker_teardown_refusal_is_retryable` retains owned resources across a refused destroy. `test_worker_arena_borrow.c` separately checks borrowed-arena survival and frozen lookup semantics. |

Normal, ASan/UBSan and POSIX TSan executions of these controls validate the
primitive lifetime contract. They do not replace the downstream bounded JOIN,
transport and full DOOP integration acceptance in #1382/#1383/#1385.

### Pin acquisition and release sites

The table above names the mechanism and the file.  This one names the call
site, because #1801 has to decide, per evaluation-stack producer, whether the
value it pushes is owned or borrowed and who the owner is; a file name does not
answer that.  Anchors are symbols rather than line numbers: these files churn,
and `scripts/ci/check-ownership-matrix.sh` resolves every symbol below against
a definition index, so a rename fails `meson test --suite abi` instead of
rotting the doc.  It also requires every cited symbol to have a caller under
`wirelog/`, so a row that only tests reach is refused.  That last check is a
heuristic: a definition paired with a forward declaration, a doc-comment
mention, a same-named static elsewhere, or an `#ifdef`-gated test wrapper as
its only caller still passes it.  The index
covers ordinary C definitions; it is not a substitute for the linker's symbol
table.

**This table is not complete and nothing establishes that it is.**  The gate
proves each row's subject exists, resolves uniquely, and has a caller under
`wirelog/`.  It does not prove that no further ownership class exists, because
the class list is a reading result, not something derivable from a regex.  Do
not read completeness into it. The timestamp row describes a relation-owned
sub-resource, not an independently pinned peer. Live rollback snapshots are
covered by the table above and the explicit lifecycle mapping above; the
per-relation `retract_backup_*` form remains dormant infrastructure with no
production producer and does not get a misleading live-resource row.

It also does not prove a row's *cells* are true, so the rows carry their own
audit state.  At least nine cells across seven of these rows were wrong on
first writing, and the two failure modes are worth separating because they
need different defences.  Most were in rows nobody had read, and those errors
named the wrong *mechanism* entirely.  But two were written while the row was
being actively read and repaired, and those named a real function with a wrong
claim attached -- `join.c:wl_columnar_join_dispose_left` was cited as the
unchecked disposal when it delegates to the checked one.  Reading a row is
necessary and not sufficient; a citation must be read for what the function
*does*, not only for its existence.  What a function does is the one thing the
gate cannot check. A new row's author must check the cited code before marking
it `author-read`. An independent
reviewer may promote that marker to `reviewer-read` after checking the cited
definitions, production callers, and lifecycle claim. The reviewer must not be
the row's author, and must approve the PR that changes the marker. New rows
start at `author-read`; only a distinct reviewer may promote them. The CI gate
pins the counts for both states but does not authenticate who made the change;
that authority comes from the recorded PR approval. Any material change to a
reviewed row's claim or citations downgrades it to `author-read` until another
independent review approves the changed row. The fifteen rows present
when this issue was raised were independently re-read during review, so this
change promotes those rows to `reviewer-read`. The timestamp sub-resource row
was added later and remains `author-read` until an independent reviewer checks
it.

| Class | Owner | Acquire | Last reader | Invalidation | Destruction | Rebuildable | Read |
|---|---|---|---|---|---|---|---|
| Session relation storage | Session registry | `relation.c:col_rel_source_reader_acquire` | Operator holding the reader | Identity, view and storage generations invalidate dependent cached state; the held reader itself ends only at release | `relation.c:col_rel_destroy` | No | reviewer-read |
| Timestamp sub-resource | Containing relation owns its timestamp allocation, including a private copy in a shared-column view | `relation.c:col_rel_enable_timestamps` allocates under writer exclusion; containing-relation access uses `relation.c:col_rel_source_reader_acquire` | Operator holding the relation reader; there is no separate timestamp pin | Physical resize/compaction changes storage generation; row reset clears timestamp storage | `relation.c:col_rel_free_contents_impl` frees timestamps; `relation.c:col_rel_compact_impl` replaces or frees them under its writer; `relation.c:col_rel_reset_rows_locked` frees them on reset | Not from columns alone: signed differences and timestamp provenance require an explicit producer | author-read |
| Worker relation view | Worker, borrowing coordinator storage | `session.c:wl_columnar_session_adopt_shared_view` | Worker task before drain | Lease retirement | `session.c:wl_columnar_session_source_leases_release_all` releases the lease; `session.c:session_destroy_relation_array_pass` destroys the view | Yes, from coordinator storage | reviewer-read |
| Coordinator compound arena | Coordinator, borrowed by workers | `compound_arena.c:wl_compound_arena_borrow` | Worker holding the borrow | None; a live borrow holds the access gate against the writer, so only the holder ends it | `compound_arena.c:wl_compound_arena_borrow_release` | No | reviewer-read |
| Owned evaluation-stack result | Stack entry, until it transfers out | `eval_stack.c:eval_stack_push` with `owned` true | Consuming operator | Ownership transfers out at `eval_stack.c:eval_stack_drain_to_session`, and where a consumer clears `owned` after handing the relation on (`eval_serial.c:wl_columnar_eval_serial_framed_relation`, and after a TDD delta publish in `eval.c`); otherwise the entry is the owner | `eval_stack.c:eval_entry_dispose`, which propagates a refusal, and `eval_stack.c:eval_stack_dispose_entry`, which re-pushes the complete entry on one; `join.c:diff_txn_commit_after_push` uses this checked path after a failed commit | No | reviewer-read |
| Borrowed stack value, session relation | Session registry, not the entry | `ops.c:col_op_variable` pushes `owned` false | Consuming operator | Owner outlives the entry; no pin is taken | Owner's, not the entry's | Yes, re-read from the registry | reviewer-read |
| Borrowed stack value, registered delta | Session registry delta | `ops.c:col_op_variable` pushes `owned` false with `is_delta` | Consuming operator, within the round | Not mutated while workers are dispatched; the registration is replaced per sub-pass by `eval.c:wl_columnar_eval_retire_prior_deltas`, which runs immediately before the exchange dispatch and is not the exchange, and which the converged round and the non-recursive path skip. The borrow itself is stack-scoped exactly like the session-relation borrow -- `ops.c:col_op_variable` selects the delta or the full relation and pushes both the same way | Owner's, not the entry's | Yes, until retirement | reviewer-read |
| Borrowed stack value, batch payload | Batch producer | `join_pipeline.c:pipeline_sink_append` pushes `owned` false onto a function-local scratch stack, so this borrow never reaches the evaluator's stack | Filter and map within that function | Batch publication boundary | Producer's, not the entry's | Yes, from the producer | reviewer-read |
| Primary hash arrangement | Session; see §10 above and THREADING §13-§14 | `arrangement.c:col_arrangement_probe_bundle_acquire_primary` | Probe holder | Source change, deferred while pinned | `arrangement.c:col_arrangement_probe_bundle_release`, which internally calls `arrangement.c:col_arrangement_pin_release` on the probe's arrangement pin | Yes, lazily | reviewer-read |
| Differential arrangement | Session owns the index; a transaction owns an unpublished replacement | `arrangement.c:col_session_pin_diff_arrangement`, see §11 below | Pin holder | Replacement cannot overwrite a leased index; `arrangement.c:wl_columnar_arrangement_diff_txn_abort` discards staged work | `arrangement.c:col_diff_arrangement_pin_release` | Yes, lazily | reviewer-read |
| Source-storage dependency reader | Storage owner of the probed relation | `arrangement.c:col_arrangement_probe_bundle_acquire_dependency` | Probe bundle holder | None; it is a reader on resolved storage | `arrangement.c:col_arrangement_probe_bundle_release` | No | reviewer-read |
| Sorted arrangement | Session; see §11 below | `arrangement.c:col_session_acquire_sorted_arrangement_probe_with_source_reader` | LFTJ probe holder | Source change requires rebuild, deferred while pinned | `arrangement.c:col_sorted_arrangement_probe_release` | Yes, re-sort | reviewer-read |
| Filtered-relation cache entry | Filter cache | `filter.c:filt_cache_pin_take` | Pin holder | Replacement deferred while pinned | `filter.c:col_filt_cache_pin_release`, and only when eviction was deferred; the ordinary destruction sites are stale rebuild in `filter.c`, session invalidation and teardown in `session.c`, and worker teardown in `kfusion.c` | Yes, re-filter | reviewer-read |
| Materialization cache entry | Cache, exclusively | `cache.c:col_mat_cache_lookup_pin_keyed` | Pin holder; the stack gets a copy, not the entry | `cache.c:mat_cache_evict_lru` skips pinned entries and returns false; admission in `cache.c:col_mat_cache_insert_pin_keyed` then returns `ENOSPC` | `cache.c:col_mat_cache_pin_release` on the last pin, and only when eviction was deferred | Yes, recompute the join | reviewer-read |
| Delta transport payload | Producer, then channel, then consumer | Ownership transfers at publish | Consumer matrix | Coalescing unions the batches of one (worker, relation) slot; the held cap may replace a held batch's relation with its spilled payload | `eval_tdd_channel.c:wl_columnar_eval_tdd_batch_discard`, `wl_columnar_eval_tdd_discard_list`, `wl_columnar_eval_tdd_channel_discard_lists` and `wl_columnar_eval_tdd_discard_sink` on discard; `eval_tdd_channel.c:wl_columnar_eval_tdd_coalesce_slot` for coalesced sources; `eval_tdd_channel.c:wl_columnar_eval_tdd_batch_spill`, through `wl_columnar_batch_payload_take`, for a relation it spills; in owner mode `eval.c:tdd_owner_release_private_slots` destroys the slots staging built for the coordinator alone unless the destroy is refused, and a refused retirement stays on the lifetime's retained list until `eval.c:wl_columnar_eval_tdd_owner_lifetime_retry`; matrix slots are destroyed by `eval.c:tdd_destroy_delta_slots` and by several open-coded sites in `eval.c` | No | reviewer-read |
| Continuation scratch and published batches | Producer owns scratch; sink owns committed output | `continuation.c:wl_columnar_continuation_create` for the continuation; `continuation.c:wl_columnar_continuation_publish` for each batch | The sink's append, before the cursor advances | Cursor advance at publication commit | `continuation.c:wl_columnar_continuation_destroy` | No | reviewer-read |

Continuation producers that install the optional disposition callback use two
cursors: the private producer-scan cursor and the externally reported
published cursor. A zero-payload PROGRESS outcome may advance scan state while
the public cursor stays at the last committed endpoint. A non-empty batch
descriptor returned with OK is copied into continuation-owned pending state
and is passed unchanged to every sink retry. The producer is not called again
until that payload is acknowledged after a durable commit or dropped on
terminal cleanup.
A refused begin means no transaction started, so it is retried without abort.
Reserve, append, or uncommitted commit refusal aborts the transaction once and
retains the same payload. A committed result, including an ambiguous status,
acknowledges once and advances both cursors. Stale validation, explicit
cancellation, or destruction disposes a pending payload without acknowledgment
and retires the producer once. Existing producers without disposition retain
the legacy one-call/rebuild behavior; the real JOIN producer is not wired to
this protocol yet. Callbacks are synchronous: reentrant publish is rejected,
and cancellation requested from a callback is applied after that callback
returns. An active uncommitted sink transaction is aborted once; a durable
commit is published and acknowledged before cancellation retires the producer.
Callbacks may reenter publish, cancel, or destroy. Nested publication is
rejected; cancellation and destruction are deferred until the active publish
finishes. A requested destroy also requests cancellation: an uncommitted
transaction aborts and drops its pending payload, while a durable commit is
acknowledged before the producer is retired and the continuation is freed.
Recursive destroy from the producer's destroy callback is ignored.
PROGRESS must preserve input, arrangement, and generation identity, keep its
position monotonic, and advance its sequence.

One row carries two assertions the code already makes, so it is checked at
runtime rather than only by reading: `cache.c` asserts `pin_count == 0` before
destroying an entry and `pin_count > 0` before decrementing.  No other row has
a runtime check, and none was added for this table -- an assertion over a
resource whose producer never runs would pass for the wrong reason.

Two functions on #1801's consumer list are **not** borrow producers and need
no pin: `col_op_consolidate` and `col_op_consolidate_diff` copy a borrowed
input to owned before pushing, so `work_owned` is unconditionally true at every
push site in `merge.c` and `diff.c`.  Recorded here so that audit is not
repeated.

`eval_entry_t` carries `bool owned` and `bool is_delta` and no other
borrow-flavor field.  Two of the three borrowed rows share a producer, and
`is_delta` separates them only in combination with `owned == false`: it is set
on owned entries too.  A consumer that needs to know which owner a borrowed
value belongs to cannot get it from the entry and must get it from this
table.

Delta-step rollback preserves the existing empty-descriptor restoration policy:
only a relation actually detached by the step, still registered with the same
identity, and still without columns is restored. Populated partial evaluation
results and replacement registrations are preserved. This is not a transaction
that rolls back the entire stratum. Storage rollback alone does not recover
notifications for partial results; whole-step observer ownership below provides
that guarantee for public incremental steps. Failed steps publish no callbacks.

Whole-step notification ownership is separate from per-stratum storage rollback.
An observer transaction captures admitted, owned logical output names and flat
row sets before any affected stratum runs. Duplicate output names are captured
once, including absent or empty outputs. A compound GC hold protects handles
through retry and callback delivery. Relation replacement does not invalidate
this baseline; changed arity yields old removals and new additions with their
respective row widths.

For the controlled observed successor STEP, recomputation uses a separate
registered private target while the old public output remains in the session
registry. Observer preparation reads that private target through an explicit
output override and retains the public output name in its signed events. After
all preparation and callback work are funded, the private target is detached,
renamed and prepared as a replacement. A successful registration commit is the
publication boundary; before it, cancellation, work limits and replacement
refusal leave the old output authoritative. The detached candidate and prepared
events remain owned for retry or teardown, and only the commit path replaces
the old relation. This narrow internal route does not change the broader
whole-step transaction semantics described below.
The host admits at most three relation registry slots for this route. It charges
candidate-slot scanning, name copying and replacement preparation before the
final poll; once replacement preparation succeeds, commit has no fallible work.

Evaluation failures retain the original observer baseline and affected mask.
After evaluation succeeds, the transaction remembers that phase, so compaction
or event-staging failure retries completion without rerunning evaluation. Final
sets are sorted and deduplicated with the same comparator before constructing
net signed events. All fallible preparation precedes delivery. Metadata, baseline
payload and staging have stable governor reservations; temporary accounting
includes all retained observer bytes. Buffers are freed before reservations are
released, and worker clones do not inherit observer ownership.

Pending transactions refuse nonzero input mutation, compound construction and
snapshot; step is the retry route. Callback publication also refuses reentrant
step. Each event reads the current callback/data pair, so replacement receives
the remaining suffix. NULL cancels the transaction's remaining notifications
without freeing active storage. Cancellation stays effective even if observation
is re-enabled, and retains evaluation phase until completion or teardown. This
preserves reconstruction on retry with a NULL callback. Successful completion
releases the observer hold before replaying coalesced frontier GC; failure and
teardown do not replay GC. Callback-triggered destruction remains unsupported.

One active or pending rollback record is permitted per session. Metadata and flat
payloads are admitted before allocation, and the governor reference and compound
hold remain owned until all snapshots are released. Capture failure changes no
live IDB. Detachment processes aliases before their owners; a later reader refusal
may leave a detached prefix, which is restored or retained for retry. Readiness
first drains evaluator frames, then attempts a finite restoration sweep. Repeated
reader or allocation refusal preserves unresolved backups and blocks mutation.
Quiescent cache reclamation is suppressed while this ownership remains pending.
Synchronous teardown rejects active work and discards pending backups after
frame cleanup without allocating restoration columns. Frontier GC requests made
through the rotation strategy while a record is active are coalesced. Successful
evaluation releases the backups and hold, then explicitly dispatches one requested
frontier collection before observer publication. Failed recovery and teardown do
not replay GC, and generic hold release still performs no collection. Independent
holds or a frozen arena can still defer that explicit collection attempt.

The resident-floor contract below applies across the managed session, including
coordinator and worker dependencies; it is not limited to arrangement leases.

Variable-size operator result storage is part of the session memory budget,
including temporary relations consumed by another operator. Pool descriptor
slabs and arena backing already admitted at creation are charged once; separate
heap names, schemas and column payloads require their own reservations. CONCAT
uses the checked governed pool/heap constructor for its result and admits growth
before appending either input. Constructor or staging failure preserves both
input stack entries and their segment metadata for retry, returning `ENOSPC`
for budget denial and `ENOMEM` for allocator failure. Once input consumption
starts, the existing checked-disposal/retained-owner contract still applies;
this is not a transaction over a refused input destruction.

VARIABLE's empty skip and missing-delta results also use the checked governed
pool/heap constructor, selecting the session governor or, when absent, the
source governor. Budget denial returns `ENOSPC` without changing the stack or
source. Allocator and representation errors remain distinct. Failed stack
publication destroys the private output and releases its reservations; a pool
slot consumed by successful construction remains inert until the pool resets.
Seed conditions, delta tags and borrowed-full iteration-zero behavior are
unchanged.

MAP resolves the session governor first, then the source governor, for scratch,
compiled expressions and result storage. Governed MAP results use independently
owned heap storage with capacity for every input row, admitted before row
expressions or extension callbacks execute. Existing pool/arena backing stays
reserved; this route bypasses those allocators without charging their storage a
second time. With no governor, MAP retains its pool/arena allocation path.
Scratch, result-construction and expression-compilation budget refusals restore
the complete input entry for retry. Ordinary allocation/expression failures keep
the existing checked-disposal error precedence. This is not rollback of callbacks
that have already executed. A zero-column projection admits its non-null row
scratch buffer as well.

REDUCE uses the same session-first/source-fallback policy for scratch, output
and compiled aggregate expressions. Its governed heap output starts at the
smaller of the input row count and the initial relation capacity, then admits
growth as new groups appear. It does not reserve one output row per input for
low-cardinality reductions. Pre-aggregation budget refusal restores the complete
input entry. Late growth denial also restores it for COUNT, absent expressions,
and successfully compiled expressions. Interpreter fallback may modify intern
state, so late refusal retains the existing checked-disposal behavior; universal
late-refusal input retention remains outstanding. Ordinary allocator, arithmetic
and disposal errors keep their existing precedence. Only a private output's
confirmed denial flag converts a collapsed growth `ENOMEM` into `ENOSPC`;
shared growth overflow/invalid-state propagation is tracked separately in #1991.

Borrowed CONS copies also select the session governor before the source
fallback and hold a source reader through schema/row capture. Governed copies
use the checked consolidation workspace for segmented and unsegmented input,
including hash scratch for large inputs. Copy or consolidation refusal captures
actual budget evidence before cleanup, returns `ENOSPC`, and restores the full
borrowed entry and segment metadata. Allocator failure stays `ENOMEM`. If
checked destruction refuses, the private copy remains the owned retry entry;
the original source stays unchanged. Timestamped borrowed copies follow the
same failure contract and retain signed timestamp representatives. Successful
publication preserves entry metadata and releases the consumed segment array.
Governed owned CONS admits its complete radix/merge workspace before COW or
row mutation. Prepublication admission and allocation refusal retain the full
owned entry and segment metadata for retry. A cleanup error after successful
normalization retains the normalized owner and clears obsolete boundaries.
Ungoverned routing and the earlier invalid-float disposal behavior remain
unchanged. The differential CONSOLIDATE (`col_op_consolidate_diff`) reports a
governor denial of its consolidation workspace -- the k-way branch's merge or
hash-dedup scratch, the fallback radix sort, or the incremental merge -- as
`ENOSPC` and sets `memory_budget_denied` before it disposes of the relation
that carried the denial (#2182). Unlike governed owned CONS, it still disposes
of an owned input on that refusal unless checked destruction refuses, as
before; an allocator failure stays `ENOMEM`.

This is CONCAT, VARIABLE empty-output, MAP, REDUCE and borrowed CONS result
coverage, not completion of all temporary admission (#1978/#1369). LFTJ still
needs audit and integration. Direct radix calls and governed owned CONS now
admit radix scratch before mutation, while supplied workspaces reuse their
existing reservation. Workspace failures preserve typed admission causes
(#1993). Eval-entry segment boundaries and other
auxiliary metadata/scratch need lifetime accounting through their actual free
sites; they are not covered by CONCAT's relation reservation or excluded from
the intended budget contract.

An iteration or frontier boundary alone does not authorize reclamation. All
queued tasks, consumer-held values, active probes and rollback obligations
must be accounted for first. The resident floor includes pinned inputs,
required indexes, rollback state and the scratch needed to make progress.
Admission may fail when that floor and the next required allocation cannot
fit; it must not retry indefinitely without released capacity. This is a
contract for admitted allocations, not a claim that all allocation classes,
spill access or downstream pipelines are already bounded (#1369, #1372,
#1475).

Every `col_eval_stratum` caller, including worker sessions, coordinator fallback,
recursive snapshot and delta steps, admits a persistent cleanup frame before
executing each relation plan. Ordinary direct recursive TDD subpasses use the
same framed relation helper. Outbound subpasses have a separate framed publisher.
The frame owns its stack,
popped result and segment metadata until publication or checked disposal.
Refusal preserves allocators, caches and registry owners until session readiness
can drain the frame; snapshot errors return before delta cleanup in this state.
Checked result renaming preserves the original name while a reader is active.
For an owned result appended to an existing target, a governed private heap
copy remains frame-owned while the original result is disposed. Target
publication follows successful disposal, so refusal cannot append duplicate
rows on initial snapshot retry. This requires an additional full temporary
copy; admission denial leaves the target unchanged.

Recursive rule-frame refusal preserves registered delta owners and caches.
Successful previous-pass publication empties all private delta slots before
rule evaluation; the error path asserts this invariant and releases only local
bookkeeping. Recursive delta-step refusal drains retained frames before storage
rollback restores detached relations. The whole-step observer keeps the original
notification baseline throughout both recovery stages.

Delta IDB consolidation also owns a persistent frame. It reads the registered
source into a governed private relation and prepares a checked replacement.
The temporary must be disposed before publication; refusal discards replacement
staging and releases the destination writer while the frame retains its owner.
Recovery drains that frame before storage rollback. Zero/one-row inputs validate
float values and return without mutating sort metadata.

Timestamped private candidates use typed set normalization that moves complete
provenance records with their rows. Equal tuples retain the earliest original
row's timestamp, including its signed multiplicity; this is set normalization,
not weighted aggregation. The original-index scratch is admitted and included
in active cleanup temporary accounting, then released before publication or
unwind. This path requires a private candidate and a replacement copy, increasing
peak admitted memory. Generic sorting timestamp correspondence remains #1689.

Normal FILTER output preserves the complete timestamp record for every selected
source row, including signed multiplicity and empty timestamp-enabled results.
Untimestamped output retains the legacy representation.

Right-side FILTER paths preserve the complete timestamp record for each selected
row in both pool-owned and cached filtered relations, and cached relations
retain the same correspondence across rebuilds and leases (#1720). Deterministic
allocation-failure and admission-retry coverage remains tracked separately in
#1729; normal FILTER provenance is #1715 and shared sort/deduplication is #1689.

The specialized parallel evaluator remains separate. An unsafe parallel plan
(such as CONCAT) returns EAGAIN before dispatch and then uses the framed serial
fallback. A late overflow fallback follows checked worker cleanup; cleanup
refusal must retain its error rather than trigger serial evaluation.

TDD correctness-check replay follows the same error boundary: failed serial
replay skips result restoration and releases only its independent saved copies.
Pending frames keep registered partial replay state and allocator storage alive
until snapshot retry drains them; no callbacks or arena reset precede recovery.

At quiescent snapshot failure and cache-reclaim boundaries, the coordinator
checks both its own cleanup owners and the retained TDD worker cohort. A pending
worker frame therefore prevents coordinator delta removal, registry compaction
and cache-pin release/reclamation. Worker lists are inspected only after the
dispatch barrier; checked teardown retains refused workers for readiness retry.
Callback-free public steps exercise nonrecursive TDD dispatch and error-time
cache reclamation. Snapshot selection currently excludes nonrecursive TDD; its
post-evaluation cohort guard also protects ordinary recursive TDD frames.
Public compound construction also checks quiescent cleanup readiness before
creating a side relation or allocating a handle, preserving pending input state
when coordinator or worker cleanup refuses.

Generic `col_eval_stratum_multiworker` arrays remain caller-owned. Their caller
must join, release readers and perform checked destruction; a full nonrecursive
retry recreates workers rather than rerunning partially published worker state.
They are not implicitly included in the coordinator's retained TDD cohort.

Prior registered TDD deltas remain immutable throughout worker dispatch. After
all workers join successfully and have no retained cleanup, the coordinator
prepares admitted, independent empty replacements before exchange. It retires
aliases across the cohort before roots, using checked registration replacement.
Empty registrations preserve later-round outbound AUTO semantics. Preparation
failure changes no registration; publication is atomic per registration, so a
successful prefix remains owned while a refused owner and its lease stay intact.
Exchange aborts on refusal and releases only newly produced queue/matrix deltas.
Recursive TDD workers check local cleanup readiness before changing
iteration state or worker flags. Their retained frames keep prior-round delta
dependencies alive. Ordinary subpasses produce fresh deltas after all rules
finish; outbound subpasses may publish independent deltas after each rule.
A refused frame therefore stops exchange and retains the cohort for public retry.

Outbound frames own a governed independent delta candidate and dispose the
original result and lower entries before publication. Diff/dedup preparation
keeps the candidate private. Publication reuses checked timestamp storage and
holds its source writer through provenance stamping and queue/slot transfer,
refusing live readers or aliases. Transfer clears the frame's pointer before
releasing the writer; consumers wait for the worker barrier. Failure retains
the candidate for checked disposal. Earlier queued payloads remain independent
and are reclaimed after the barrier if a later rule fails.

Global-read exchange prepares admitted empty replacements for every worker view
of a changed IDB, then retires those views with checked registration replacement
before publishing coordinator rows. External readers still refuse publication;
a retired prefix remains independently owned. Combined deltas preserve schema,
compound metadata and timestamps and use checked normalization. First
publication into a schema-less target adopts complete metadata through checked
replacement. A recursive stratum's placeholder for a pure IDB (rules, no inline
facts, no compound or graph column, width above 0) is not schema-less when the
plan records it (#2334). With a `.decl` it starts with the declared width and
lane types, STRING and FLOAT as declared and every other lane INT64. Without
one, when no rule head has an aggregate and all agree on one arity, it starts
with that arity and no lane types, and the first rows published into it, while
it is empty and untyped, define those types. Worker views refresh only after
publication; zero-progress targets and empty next-delta registrations retain
their existing semantics. An exchange failure reclaims every untransferred fresh
matrix payload before checked cohort cleanup.
Publication is atomic per target, not per exchange: a successful prefix can
remain, and public snapshot retry completes the exact set after dependencies
release without emitting callbacks for the failed attempt.

Specialized nonrecursive workers evaluate in persistent worker-owned cleanup
frames. A coordinator frame admits a fixed slot for each worker before dispatch;
workers copy into separate governed slots and finish their original results,
lower entries and segment metadata on their own threads. The coordinator reads
those slots only after the dispatch barrier, clears transient join-counter
pointers and retires worker views through checked teardown. A refused worker
frame retains its allocator and dependencies for public retry.

A governed final candidate combines existing output and worker rows, preserving
append behavior without CONSOLIDATE and performing checked private normalization
when requested. Existing outputs use prepared replacement: all staging cleanup
must succeed before commit, and replacement reservations are always discarded.
Missing outputs transfer the private candidate only when the registry owns it.
Reader, admission or allocation failure leaves an existing target unchanged.
This costs independent staging and replacement storage, admitted before use; it
is an atomic relation publication, not a transaction across a whole stratum.
Specialized slices and staging preserve incoming timestamp records. FILTER's
pre-existing loss of selected-row provenance is tracked separately by #1715,
and generic sorting/consolidation provenance remains #1689.

K-Fusion refusal handling (#1648, and the parallel-branch retention orphan
#1765) still precedes closing #1384; #1661's
integration audit is discharged for the framed callers. What remains there is
the per-sub-pass delta removal, which stays a discard deliberately now that
the terminal one propagates; the single TDD delta-exchange removal no test
reaches; and the worker-registry gap: `col_worker_session_create`
writes partitions straight into the registry without the pool and arena
promotion `session_add_rel` performs. Pool/arena relations cannot use the
heap-only deferred registry, and a live reader prevents promoting their
descriptors.
Internal checked cleanup can return `EBUSY`; public session destruction remains
synchronous and does not offer recoverable deferred destruction. See
`wirelog/session.c` and `session.c` for that distinction.

Primary hash arrangements are session-owned cache entries. A join that probes
one through `col_session_pin_arrangement()` holds a non-public lease until the
probe has finished; the lease protects both the hash-table buffers and the
embedded entry identity from cache eviction. The flat entry registry is never
grown while a lease is active, so lookup may report the arrangement unavailable.
The caller decides whether that status permits an ephemeral fallback or must
be propagated as an error. `col_arrangement_pin_release()` must be called
exactly once, including on allocation and join-error paths.

| Event | Pinned entry | Unpinned entry |
|---|---|---|
| LRU eviction | skip and defer reclamation | reclaim and clear the token |
| relation invalidation | mark rebuild deferred; keep the old index readable | clear the token immediately |
| stale or cleared token, row growth, or pending invalidation on lookup | defer rebuild and return unavailable; preserve hash buffers and chains | rebuild before returning |
| final lease release | apply deferred invalidation by clearing the token, without rebuilding; next lookup rebuilds lazily | no action |

An index is unbuilt exactly when its buffers are freed or its source token is
invalid; invalidation, deferred release and eviction clear the token (#1500).
An empty relation's index is built (16 buckets, no chain array) and is not
stale: it is handed out as is, leased or not, and a second lease on it
succeeds.

This is an internal coordinator/worker-session contract, not a public API or a
general concurrent-reader mechanism. Release all leases before session teardown.
Primary probes, compound/side-relation dependencies, and differential working
arrangements are acquired as one operation-scoped transactional bundle. The
bound source reader and ultimate storage-owner generation protect source
columns, row positions, aliases, metadata, and compound storage for that
operation. Mutation is denied with `EBUSY` while the bundle is live and may be
retried after release; aborted differential work leaves the persistent index
and accounting unchanged.

Checked internal teardown drains queued work and rejects destruction while a
live source lease remains. Filtered, materialization, differential and sorted
cache ownership is described below; those mechanisms do not remove the
cleanup-refusal limitations in the matrix's accompanying contract.

## 11. Sorted-arrangement leases for LFTJ

Sorted row-major copies used by leapfrog triejoin are session-owned storage,
not borrowed scratch buffers. `col_session_acquire_sorted_arrangement_probe`
acquires a source reader and pins the cache entry before LFTJ receives the
`sorted` pointer. The lease remains active until the join, its callbacks, and
stack publication have finished. LFTJ tracks cache-backed inputs explicitly;
cleanup never re-queries the cache to decide whether an input may be freed.

While a sorted lease is active, source writers are blocked, the entry's sorted
buffer cannot be rebuilt or freed, and growth that would relocate the sorted
registry is rejected. A freshness change observed against a pinned entry is
recorded as deferred invalidation. The old buffer and its ledger charge stay
valid until the final lease is released; the next acquisition then rebuilds it
lazily. Every success and error path must release the lease before session or
worker teardown.

### Filtered-relation cache leases (#1435)

The filtered-relation cache (`filt_cache`, #386) carries the same lease shape.
`wl_columnar_filter_apply_right_filter_cached_pin()` returns the cached
filtered relation under a lease released exactly once by
`col_filt_cache_pin_release()`; the unleased lookup is a wrapper that takes and
immediately releases a lease, so with no other lease active its behaviour is
unchanged, and with one active it can report the cache unavailable exactly as
the leased lookup does. Leases hold entry pointers, so while any lease is
active the entry array is neither grown nor compacted: a miss that would need
growth reports the cache unavailable, and an invalidation empties unpinned
entries for the relation in place instead of compacting. The counter is
asserted zero at session and worker teardown (an `assert`, active unless the
build disables assertions).

| Event | Pinned entry | Unpinned entry |
|---|---|---|
| lookup with a stale token | mark deferred; keep the old relation readable; report unavailable | rebuild in place |
| relation invalidation (`session_add_rel`) | mark deferred; keep the old relation readable | destroy (emptied in place while any lease is active) |
| cache growth on a miss | refused while any lease is active | grow |
| final lease release | destroy the deferred relation; next lookup rebuilds | no action |

A keyed join whose cache lookup returns NULL uses an owned filtered relation
for that operation. Production JOIN currently calls the immediate-release
wrapper, not the explicit cache-pin interface. Its source-reader bundle is a
separate mechanism and must not be described as a retained filtered-cache pin.
Owned filtered fallbacks bypass the non-delta filtered-arrangement and
materialization caches; their operation-local descriptors cannot become cache
keys or retained cache dependencies.

The filtered-cache lease is likewise an internal coordinator/worker-session
contract, not a public API or a general concurrent-reader mechanism.
Relation-generation validation and the other cache-specific lifetime
mechanisms are integrated, as described in the ownership matrix and adjacent
sections. This does not establish a universal pin for borrowed stack values.

### Materialization-cache ownership

The materialization cache accepts only a result whose storage is exclusively
heap-owned by that result: pool-owned, arena-owned, shared-view, and aliased
relations are rejected before cache or ledger state changes. This is required
because eviction, clear, and reclaimer paths destroy accepted results. A
rejected result remains the producer's responsibility and may be destroyed or
reused by the caller. An accepted result transfers its relation charge to the
cache ledger and is destroyed exactly once when its final unpinned entry is
removed.

### Differential-arrangement leases

Differential hash arrangements use a separate registry-entry lease because
their row links refer to relation positions and are replaced transactionally.
`col_session_pin_diff_arrangement()` acquires a source-reader lease and records
the entry generation and source snapshot; `col_diff_arrangement_pin_release()`
releases both exactly once. While a lease is active, source invalidation is
deferred, registry growth that would relocate entries is refused, and
differential transaction replacement returns `EBUSY`. The final release
applies the deferred reset and advances the entry generation. A continuation
must treat a generation or snapshot mismatch as stale and release the lease
before session teardown. Session teardown also rejects any still-active
differential pin or replacement transaction before destroying relations.

## 10a. Bounded join sub-batches (#1446)

`WIRELOG_JOIN_BATCH_BYTES=N` (strict decimal, default unset = off) makes
an eligible keyed join run the resumable sub-batch producer in
`wirelog/columnar/join_batch.c` instead of the one-shot probe loop.
Eligible means: `key_count > 0`, no right filter expression, and either a
persistent primary arrangement on the right relation with no right-side
delta, or a worker run that resolves the JOIN's operands by input slot.
The runs that do are a TDD bound run and an insert clone, which may read a
range piece or a delta under the relation's name.  There the producer
builds an index of its own over the relation the slot holds
(`col_join_batch_producer_create_over`) and pins nothing by name, so a
delta right operand is eligible too (#2201).  Other worker sessions, TDD
workers and non-recursive workers alike, have also been eligible since
that change; where non-recursive workers share one output counter, the
producer charges it per committed batch.  No JOIN records `worker-session`
since #2201.  Every other shape falls back to the one-shot join; the
session records the fallback count and last reason and logs one `JOIN`
warning per reason.  The session also counts the bounded runs that
complete, per route (ordinary, differential, pipeline; #2201).  A worker
session starts with its own counts and reason cleared, and its teardown
folds them into the coordinator (#1382, #2201), so a coordinator's counts
include what its workers recorded once they are destroyed.  The snapshot
route for an incremental insert (#2114) runs its joins on worker clones
that keep the knob, strict mode included, since #2201; their JOINs run the
producer over the relations their slots hold, and their teardown folds
their counts into the session.  Strict mode can therefore refuse a clone's
JOIN after an earlier stratum's heads were merged; the snapshot then
evaluates in full, as after any refusal of the route.  A memory budget
denial on a clone is not folded: `wl_columnar_session_budget_denied` reads
the session's and its TDD workers' flags, not an insert clone's, as for
the one-shot JOIN a clone runs.  With the knob set, K-Fusion also
evaluates its branches serially on the calling session instead of on
parallel branch sessions (#1382): a branch session is a shallow copy of
the calling session, so its joins would otherwise run the bounded producer
concurrently, and K-Fusion does not fold a branch session's records into
the calling session.  The legacy row cap (`WIRELOG_JOIN_OUTPUT_LIMIT`) is
then checked against each join's own output, as at one worker, instead of
the counter a parallel branch set shares (#959).
`WIRELOG_JOIN_BATCH_STRICT=1` (ignored unless the bytes knob is set) turns
a fallback into an `ENOTSUP` failure, which is the explicit bounded-mode
result for unsupported shapes.  Differential keyed joins have the separate
producer described below.

The internal col_join_batch_control_* interface can bind an already prepared
ordinary JOIN continuation to one active evaluation-control attempt. Binding
retains that control, saves its attempt ID, claims the continuation's producer,
and refuses generic continuation publication until the continuation is
discarded. Step calls are serialized on the bind thread and admit at most the
requested work units. This controlled slice admits only one native INT64
equality key and at most 64 output lanes. Key setup and one collision-chain
advance cost one unit; hashing costs nine units (fixed setup plus the eight
canonical key bytes); comparing one collision candidate costs two units;
writing a complete output row costs output_width + 1. Hashing never walks the
collision chain: its row cursor persists across step calls, so a long collision
bucket cannot become one unbounded operation. The checked ordinal advances
only after successful charges. WORK_LIMIT, CANCELLED, STALE_ATTEMPT, STALE_INPUT,
and execution errors are sticky and retain the exact execution errno where
applicable.

`col_join_batch_runner_start/advance/discard` is the opt-in caller for this
producer. Start accepts only an already-built current arrangement and rejects
a cache miss or stale entry without building/rebuilding it. It acquires source
readers for both inputs, pins the exact right arrangement, then synchronously
allocates and admits fixed-capacity private output. That capacity-proportional
setup is outside the `advance` work allowance; start performs no input-row scan
or hash construction. Each advance charges complete indivisible actions
before work. Zero allowance is a true no-op. If a positive allowance cannot
cover the next action, advance returns resumable progress with `required_work`
and leaves cursors/output unchanged. Each ready batch is copied into the
private result under the same attempt; no capacity growth is allowed. A batch
remains unpublished while its copy is partial. Once complete, the runner
validates input/attempt state, then publishes the private row count and
generation-checked producer ACK in one no-fail section. The final attempt/input
poll immediately before transfer is the completion linearization point; only
DONE transfers the relation. Exceeding the fixed row capacity latches
`EXECUTION_ERROR/ENOSPC`; discard is then required. Discard releases both
source readers, arrangement lease, scratch/governor reservations, retained
control reference, and private output exactly once. This runner is not wired
into ordinary plan dispatch or STEP; arrangement construction and other JOIN
families remain follow-on work.

The controlled producer never grows its scratch: its batch row ceiling is the
smaller of the prepared rows-per-batch and the already admitted scratch
capacity. Each ready batch contains complete private rows. Repeated peek
returns the same relation and generation; only acknowledgement of that exact
generation advances the producer-local acknowledged cursor. `cursor_get`
reports that acknowledged cursor while bound; speculative scan progress and
peek do not change it. Generic cancellation after bind is sticky before the
arrangement lease is released. Discard releases the continuation's
arrangement pin, scratch and descriptor reservations, and retained control
reference. The runner remains an explicit opt-in prerequisite: ordinary JOIN
dispatch, STEP publication and end-to-end cancellation lifecycle remain
follow-on work.

A non-differential eligible join is consumed batch by batch on the eval
stack together with its tail (#1475, #1370): the longest prefix of the
operators after it that are row-local FILTERs or consumable SEMIJOIN and
ANTIJOIN probe stages (below), optionally ended by one row-local MAP.  A MAP
always ends the tail.  The full join intermediate is therefore not
materialized while the pipeline runs: each batch is filtered (and mapped)
into one output relation, which is published only after the last batch and
has the schema the sequential operators would publish -- the JOIN output's
for a FILTER ending, the last stage's after a probe stage, and for a MAP
ending `col0..` with the column types the MAP operator gives the tail's
input, so a result the MAP operator types FLOAT stays FLOAT.  Operators
after the tail run as before, and what reads the tail's output decides
strict mode as described below.  The FILTERs may use only numeric variables,
numeric and boolean literals, and comparisons.  The MAP may project columns
or evaluate numeric expressions -- integer and float arithmetic and
comparisons (#1777).  A MAP with a string, digest, UUID, aggregate or
extension expression is not consumed; those have no batch contract yet.  A
pipeline whose input goes stale mid-stream, or whose arrangement is
unavailable, re-runs on the ordinary JOIN with reason
`pipeline-not-consumable` (`ENOTSUP` under `WIRELOG_JOIN_BATCH_STRICT=1`).
A FILTER or MAP failure inside the pipeline returns that operator's errno --
for MAP, `ERANGE` for a failed expression and `ENOSPC` for a denied
admission -- and publishes no rows.

The tail may also contain SEMIJOIN and ANTIJOIN probe stages (#1370).  A
stage is consumed when it is keyed, has no right filter, is not materialized
and reads a relation whose name does not start with `$`, and when, checked
once per pipeline against the stage's input, that relation exists and the
keys resolve in range with compatible types.  A stage that fails the
run-time check ends the tail before it and runs as before.  With the knob
set, a stage whose right relation has rows but no columns fails that check
and ends the tail before it.  Without strict mode the standalone operator
then refuses that right with `EINVAL`, and when that stage directly follows
the JOIN the pipeline first records `pipeline-not-consumable`; under strict
mode the pipeline refuses with `ENOTSUP` and keeps the left (#2209).  Each
consumed stage probes a hash set built once per pipeline, on the first batch
that reaches the stage, from its right relation as it is when the pipeline
starts; a change to that relation, checked whenever a batch reaches the
stage, is reported as stale (`pipeline-not-consumable`, `ENOTSUP` under
`WIRELOG_JOIN_BATCH_STRICT=1`).  In a governed session each set holds the
bytes the standalone operator admits for it (`nbuckets * 4` plus `max(nrows,
1)` next links for SEMIJOIN, `nrows + 1` for ANTIJOIN) from that first batch
until the pipeline ends, on top of the producer and output terms below; it
scales with the right relation, not with `WIRELOG_JOIN_BATCH_BYTES`.  A
stage's per-batch output and row scratch, and for a parallel SEMIJOIN its
worker contexts and offsets, are held only while that batch is in the tail.
Setting the stages up admits at most two zero-row stage output templates at
a time, and the last one is held until the output relation's schema is set,
after the producer.  A MAP ending compiles its expressions once more at that
point, without evaluating them, to resolve the output's column types; that
compile is admitted as the MAP operator admits its own, and freed before the
first batch.  Because the pipeline holds the producer, its output and the
sets at once, a budget the sequential operators fit can deny the pipeline; a
denied set fails it with `ENOSPC`, keeping the left input.

Outside the pipeline, the SEMIJOIN and ANTIJOIN operators
(`wl_columnar_semijoin_op`, `wl_columnar_antijoin_op`) return their input
entry instead of a copy when they would keep every input row (#1370), with
the knob on or off.  Before emitting, the operator builds its probe set in
its own next-link mode and scans the input, stopping at the first row it
would drop; a scan that drops nothing publishes the input itself, with its
ownership unchanged, without CONCAT segment boundaries and as not a delta,
and a scan that drops a row hands the same set to the emit, which builds no
other.  The input passes through only when the copy would be equal to it as
later operators observe it: not in a TDD bound run, a non-empty input
without timestamps or compound metadata, and every column named; for
SEMIJOIN also an identity projection, column types present, no graph
column, and each name exactly `col<i>` (the copy is a fresh
`col0..colN` relation, and a name lookup tries an exact match before the
`col<N>` fallback).  ANTIJOIN's copy is created like its input, names
included.  A passed-through input keeps its relation name and any sort
metadata (`sorted_nrows`, `run_ends`), which a copy does not carry, so a
CONSOLIDATE over it may merge sorted runs instead of sorting; the rows are
the same.  The pass-through admits only the probe set and the key scratch,
which the copying operator also admits; it skips the copy's output and its
row scratch.  The scan costs probe work: when the first dropped row comes
late, the scan and then the emit both probe the input, up to twice the
copying operator's probe work, with the same memory.  The pipeline's probe
stages are unchanged: they copy each batch through the emit.  Measured on
DOOP (zxing facts, workers 1, `WIRELOG_JOIN_BATCH_BYTES=65536`,
`MALLOC_PERTURB_` unset, a `MemoryMax=90G` user scope) at the 51,666th
differential JOIN dispatch, just after a 641,550,746-row JOIN whose
SEMIJOIN keeps every row: peak RSS (VmHWM) was 35.5 GB with the
pass-through against 56.0 GB without it (-36.7%), the session ledger peak
35.3 GB against 69.7 GB (-49.3%), and the time to that point 554 s
against 765 s.
These are single runs at one checkpoint; the full DOOP run does not
complete under that scope (#2182).

A keyed SEMIJOIN or ANTIJOIN whose left input, or whose right operand
after the right filter, has rows but no columns fails with `EINVAL` before
the probe set and the pass-through scan (#2209).  A missing right still
repushes the left, and a right that the filter empties is not refused.
When neither input is a zero-column input with rows, an empty zero-column
input keeps the operator's empty-input result: SEMIJOIN keeps no row, and
ANTIJOIN keeps no row of an empty left and every row of a left whose right
is empty.  Neither operator consults the bounded-join knob here.

When the pipeline does not consume a JOIN, the reason decides what is
recorded.  These rules apply to non-differential evaluation only: the
pipeline is not attempted while differential operators are active, so a
strict differential `JOIN -> REDUCE` is not refused as
`pipeline-not-consumable`; its JOIN follows the differential join's own
bounded-mode rules below, which refuse its excluded shapes.

- For a keyed JOIN without a right filter that is not materialized, the
  pipeline first applies the JOIN's right-operand selection, a key-column
  range check and the key-type check, in that order and before looking at
  what follows the JOIN.  In a run that resolves operands by input slot the
  selected right operand is the relation the slot holds, and the tail ends
  before a SEMIJOIN or ANTIJOIN stage, which would resolve its operand by
  name (#2201).  A missing right relation, a forced-empty right operand, an
  empty right operand in a run that resolves operands by input slot, or a
  key that resolves outside a zero-column input is left to the ordinary
  JOIN, whose result stands in both modes and nothing is recorded; there a
  zero-column input with rows (the left, or a right that remains after the
  right filter) fails with `EINVAL`, except that a missing or forced-empty
  right keeps its empty result; when neither input is a zero-column input
  with rows, an empty zero-column input yields the empty result (#2170,
  #2209).  A FLOAT key paired with a non-FLOAT key is `EINVAL`, as from the
  ordinary JOIN.  A `$d$` or `$r$` right operand records `delta-right`, and
  strict mode refuses it with `ENOTSUP` before the JOIN runs; a delta the
  slot holds in a run that resolves operands by input slot is consumed
  like any other right operand.
- Otherwise, when the session, the JOIN or the shape of its tail is not
  consumable, what reads the JOIN's output decides.  If the output reaches
  the end of the plan only through CONCAT, CONSOLIDATE, or an EXCHANGE that
  partitions across more than one worker, nothing is recorded for the
  pipeline and the JOIN has the outcome a final JOIN would have, under the
  ordinary JOIN's own bounded-mode rules; for example, a cross JOIN still
  records its own exclusion and is refused under strict mode.  If another
  operator reads the output -- JOIN, REDUCE, or a FILTER, MAP, SEMIJOIN or
  ANTIJOIN the pipeline did not consume -- the session records
  `pipeline-not-consumable`, and strict mode returns `ENOTSUP` before the
  JOIN runs.
- When the pipeline would consume the tail but another operator reads the
  tail's output, strict mode returns `ENOTSUP` before any producer exists
  and records `pipeline-not-consumable`; without strict mode the pipeline
  runs and nothing is recorded.

Ownership and admission:

- The producer holds one arrangement lease for its whole lifetime, one
  governed descriptor allocation (the producer struct itself plus the key
  row and the key-index arrays, admitted at create), and one governed
  scratch relation.  Since #1481 that relation is sized
  LAZILY: create admits only the 64 rows a fresh relation pre-allocates,
  and the fill loop doubles it on demand under admission, clamped to
  `rows_per_batch = N / row_bytes`.  A small join under a large `N`
  therefore reserves what it uses rather than what the knob allows, and
  an `N` below 64 output rows still gets the 64-row floor -- the floor
  wins, as it did before, and the clamp never sizes below it.  `N`
  smaller than one output row, or a zero-width output, is a
  recorded fallback (`row-too-large`).
- The output relation is heap allocated (never from the delta pool, whose
  reset frees nothing) and attached to the session governor.  Its retained
  token owns every visible output byte: the sink admits the capacity the
  relation already owns at attach, grows it when the next batch does not
  fit (`col_rel_reserve_capacity_admitted`), and holds no token of its own.
  Since #2173 the growth is geometric with an exact fallback: the sink first
  asks for double the current capacity (clamped to `UINT32_MAX`, and to at
  least the rows the batch needs), and only when the governor denies that
  doubling does it retry at exactly the rows the batch needs.  A denied
  doubling that is retried exactly is not a failure: the denial is cleared
  before the retry, so a successful retry leaves no denial pending.  Any
  other failure of the doubling fails the batch without a retry, including
  an allocation failure that no governor denied, so near memory exhaustion
  a batch that the exact-fit rule would have admitted can fail.  Either
  way the governor admits the retained footprint formula of `relation.c`
  for the new capacity while the old buffers are still live.  The exact-fit
  rule it replaces reallocated and copied the whole output for every batch
  that did not fit: 4096 output rows in 7-row batches reached storage
  generation 578, and reach 7 with geometric growth
  (`test_join_batch_resume.c:test_sink_growth_is_geometric`).  The
  consumed pipeline's output relation grows by the same rule.
- A batch becomes visible only when the sink commits it; the cursor
  advances only after commit.  A sink failure before commit rewinds
  `nrows` and retries the same batch without a new reservation; the
  capacity admitted for it is retained, as after a failed bulk append.
  Any mutation of either input or a rebuild of the arrangement between
  batches is reported as stale rather than resumed.
- Per-producer bound (measured, #1370).  Under a governor, a bounded
  producer's own reservations are, between scratch growths, `D + S +
  P(cap)`, and during a growth at most `D + S + P(old) + P(new) + R`,
  where:
  - `D` is the descriptor allocation: the producer struct plus the key row
    and the key-index arrays (the struct's size is a governed quantity, so
    a field added to it is not free);
  - `S` is the scratch relation's fixed reservations: its descriptor and
    owned name, and its metadata (column names, types, Arrow schema);
  - `P(n)` is the scratch payload for `n` rows,
    `col_rel_retained_bytes_for(scratch, n)`, timestamps included when the
    left input carries them.  The scratch starts at the 64 rows a fresh
    relation pre-allocates and grows on demand to `cap < rows_per_batch / 2
    ? 2 * cap : rows_per_batch`, so `cap` never exceeds
    `max(rows_per_batch, 64)` and never drops below 64; when one row is
    wider than `N / 64`, the 64-row floor alone exceeds the knob's `N`
    bytes;
  - `R` is the one row of scratch (`ncols * 8` bytes) the payload
    transaction charges while a growth is pending.
  On top of `D + S + P(64)`, create also holds briefly the column-type
  metadata that `col_join_set_output_types` installs while the scratch's
  untyped metadata is still reserved.  Without a governor the same
  allocations are made but nothing is admitted.  A clean doubling holds
  1.5x the new payload, but `P(old) + P(new)` approaches `2 *
  P(rows_per_batch)` when the last doubling is clamped (measured 1.8x at
  `rows_per_batch = 80`, 1.64x at 100, 1.985x at 65), and which step lands
  last depends on where `rows_per_batch` falls relative to the doubling
  sequence, so budget against twice the scratch payload.  The right relation's
  arrangement is not part of the bound.  A producer in a run that resolves
  operands by input slot also holds `I(n)`, the index it builds over the
  slot's `n`-row right relation: `8 * next_pow2(max(2n, 16))` bytes of bucket
  heads plus `4 * max(n, 16)` bytes of row chain when `n > 0`
  (`col_arrangement_owned_bytes`).  It is admitted after `D` and before the
  build, so `D + I(n)` is held before `S` and `P(64)` are admitted.  The knob
  does not bound `I(n)`, which grows with the right relation, just as it does
  not bound the arrangement a producer pins on other sessions (#2201).  On the
  non-differential path the plain JOIN operator builds or rebuilds its
  persistent arrangement before it creates the producer, but the consumed
  pipeline creates the producer directly, and that create builds a missing or
  stale arrangement after admitting the descriptor, so a pipeline's create can
  peak at the descriptor plus that build.  The differential arrangement is
  described below.  The output relation is a separate account: its own fixed
  reservations and `P_out(capacity)`, and during each growth `P_out(old) +
  P_out(new)` plus its own `R`.  The sink asks for `new = max(2 * old, need)`
  rows, where `need` is at most `old + rows_per_batch`, and retries at exactly
  `need` when the governor denies the doubling, which was the rule for every
  growth before #2173.  After a growth the admitted output capacity is
  therefore at most twice the rows the output holds; an output that never grew
  keeps the 64-row capacity it was created with, which can exceed twice its
  rows.  For a non-differential JOIN into a relation sink, the
  join's peak is the larger of the producer's growth transient plus the
  output's current footprint and the output's growth transient plus the
  producer's current footprint; on a large result the output's last growth
  dominates.  A consumed pipeline adds its tail's transients (each batch's
  FILTER or MAP output, and the probe sets its SEMIJOIN and ANTIJOIN stages
  build once per pipeline), and a differential join's create-time
  arrangement transaction (below) can exceed both terms.  The full join
  result is still materialized into the output relation: this unit bounds
  producer memory and admits output growth, it does not bound the output
  itself.
- A grow the governor refuses is answered with a SHORT BATCH, not a failed
  produce: the producer parks on the candidate it was about to write and
  emits what it has, so a tight budget costs batch boundaries rather than
  progress.  A short batch always carries at least the 64-row floor, so it
  can never be mistaken for the `rows == 0 && complete` terminal shape.
  Lazy sizing is therefore more tolerant in COMPLETION than the eager
  reservation it replaced -- a budget that made create fail outright can
  now finish in short batches -- but not in PEAK reservation, which the
  2x transient above can push higher than eager's single create charge.
  The binding constraint remains the output relation's growth.
- One narrowing came with it: a publish that returns
  `RESERVATION_DENIED` may now leave the session's reserved total higher
  than it found it, because the producer's scratch transaction is separate
  from and earlier than the sink's.  Everything the caller can observe --
  rows, cursor, output reservation, arrangement pin -- is still unchanged.
  It follows this file's existing rule that a failed operation keeps the
  capacity it was admitted (see `sink_abort` in `join_batch.c`), so the
  retry costs no new reservation.
- The legacy row cap `WIRELOG_JOIN_OUTPUT_LIMIT` stays distinct and is
  checked once per committed batch, so it may be overshot by at most
  `rows_per_batch - 1` rows in bounded mode.  No ledger backpressure
  heuristic is consulted per row in bounded mode; admission is the bound.

Differential keyed joins use `wirelog/columnar/diff_join_batch.c` when
bounded mode is enabled for a normal keyed join.  Its scratch grows lazily
by the same rule as the non-differential producer, and the per-producer
bound above applies to it with its own descriptor; its scratch is never
timestamped.  Its create also runs the right relation's differential
arrangement transaction in `index_right`.  Once an earlier create has
committed that arrangement, `index_right` deep-copies it on every create,
even when no row is new, and grows the copy's hash table when new rows need
it; until that transaction commits, the governor holds the arrangement
twice.  The arrangement belongs to the session and outlives the producer, so
this transaction is outside the per-producer bound; it ends, committed or
aborted, before the first batch.  The right relation is incrementally
indexed in a differential transaction before the continuation starts; that
cache transaction is committed before a differential generation/source pin
is held for the continuation.  Since #2173 the bounded differential join
publishes the one-shot `$join_diff` contract: its scratch and its
`$join_diff_batch` output carry no timestamps, and the producer reads
neither input's timestamp column, so it neither reads nor multiplies input
multiplicities.  (Until #2173 each batch carried the signed product
`left * right`, which failed the join with `EINVAL` on overflow.)  Stale
input, generation changes, overflow, cancellation, or failed admission
discard the output relation and release the differential pin exactly once.
Materialized/cache joins and delta-right, filtered and cross shapes remain
on their existing one-shot paths until their publication contracts are
bounded; runs that resolve operands by input slot do not reach the
differential join, since they refuse or clear differential operators, and
the differential producer refuses a call from one with `EINVAL` (#2201).  Since
#1382 the differential join decides them with the same eligibility check as
the ordinary join and then excludes materialized joins.  Without strict mode
each records its reason (`cross-join`, `delta-right`, `filtered-right` or
`materialized`, and `row-too-large` when create refuses a batch budget below
one output row); under `WIRELOG_JOIN_BATCH_STRICT` each returns `ENOTSUP`
instead of running one-shot and records nothing.  A materialized join whose
result is already cached is copied from the cache before this decision, so
it is neither recorded nor refused.  Under strict mode a differential
evaluation therefore fails as soon as one of its joins reads a delta on the
right or filters the right relation; it is a diagnostic setting.  A keyed
differential join whose left input, or whose right operand after selection
and the right filter, has rows but no columns fails with `EINVAL` with the
knob off or on, as the ordinary JOIN does, before the cache lookup and the
bounded-mode decision, so nothing is recorded (#2202, #2209).  A missing or
forced-empty right operand still yields the empty result first, a right
whose filter leaves no rows is not refused by this check and takes the
filtered-right path above, and an error from the right relation's filter,
which runs before the check, is returned instead.  For a shape eligible for
bounded mode that passes this check, an empty input on either side is joined
one-shot without the producer, and nothing is recorded or refused; an
excluded shape is still recorded, or refused under strict mode, before that
decision.  Two empty zero-column inputs therefore yield the empty result
with or without strict mode; before #2202 the producer refused their
zero-width output, recorded as `row-too-large`, or `ENOTSUP` under strict
mode.  The producer itself rejects a key index outside either input with
`EINVAL`, before any reservation, reader or arrangement is taken (#2202).

A governor denial on these bounded paths is reported as a budget denial: the
JOIN returns `ENOSPC`, and `wl_columnar_session_budget_denied()` is true
afterwards because the session's `memory_budget_denied` is set before the
object that carried the denial is discarded (#2185).  That covers both
producers' scratch relations and their column types (`$join_batch` for the
non-differential join and the consumed pipeline, `$diff_join_batch` for the
differential join), the consumed pipeline's output attachment and growth,
the operator's and the differential join's output growth, the differential
output's column types, and the differential arrangement's hash-table
growth.  A failure that no governor denied, such as a resize-preparation
failure of the output, stays `ENOMEM` and is not reported as a denial.  A
batch that would take the output of any of these paths past `UINT32_MAX`
rows fails before any growth is requested and returns `EOVERFLOW`, which is
not a denial either (#1382).  The consumed pipeline counts the batch before
its FILTER and MAP tail, so the check is conservative there.  An `EOVERFLOW`
returned by the output's capacity reservation itself is still reported as
`ENOMEM`.  The differential arrangement's creation and copy reservations in
the same transaction still return `ENOMEM` when denied; the check is already
true for them.

LFTJ is outside bounded mode: `col_op_lftj` builds the whole `$lftj` output
in one append batch before publishing it.  Since #1382, with
`WIRELOG_JOIN_BATCH_BYTES` set and without strict mode it records the
`lftj` fallback each time it runs; under `WIRELOG_JOIN_BATCH_STRICT` it
returns `ENOTSUP`, recording nothing, before it reserves memory or reads
its inputs.  The planner forms LFTJ only from a chain of at least three EDB
relations joined on one shared `col<N>` key (`lftj_chain_len` in
`exec_plan_gen.c`).  When the session has a memory governor, `col_op_lftj`
reserves its staging before allocating, including `nrows * ncols * 8` bytes
per input for the input copy it makes when no sorted arrangement can be
pinned, and the `$lftj` output's growth is admitted by that governor; a
denial returns `ENOSPC` and sets `memory_budget_denied`
(`test_lftj_integration`).  Without a session governor neither that input
copy nor the output is admitted, even when the inputs carry a governor;
that remains #1978 work.  When this paragraph was written (#1370), the
knob-on test suite ran LFTJ 10 times with at most 3 output rows, and none
of the ten `bench_flowlog` programs nor DOOP planned an LFTJ.  These counts
describe the repository's workloads, not a bound: an EDB-only star join on
one key multiplies its inputs' per-key fanouts.

Cross joins and the ephemeral hash path also stay one-shot.  On the
non-differential path, a join with no key columns (`key_count == 0`) is
excluded from the bounded producer and, when it reaches the eligibility
check, records `cross-join`; an otherwise eligible keyed join whose
persistent arrangement is unavailable runs the ephemeral hash probe and
records `no-arrangement`; under `WIRELOG_JOIN_BATCH_STRICT` both return
`ENOTSUP`.  The differential bounded path requires a key column, so a
differential cross join runs as one-shot `$join_diff`; since #1382 it
records `cross-join` and strict mode refuses it, as on the non-differential
path.  In a run that resolves operands by input slot the ordinary JOIN
does not use the persistent arrangement: an eligible keyed JOIN with both
inputs non-empty runs the producer over its own index there, or falls
back as `row-too-large`, and so does not record `no-arrangement` (#2201).
When this paragraph was written (#1370), the knob-on test
suite ran 613 cross joins with at most 6,400 output rows, the ten
`bench_flowlog` programs one (100 rows), and DOOP 16 before its run stopped
(10,792 rows in total), and no workload recorded the `no-arrangement`
fallback.  These counts describe the repository's workloads, not a bound: a
cross join's output is the product of its inputs' row counts.

When this paragraph was written (#1370), bounded mode was checked by two gates
over the test suite without its tidy, abi, perf and bench suites.  The knob-on
gate (`WIRELOG_JOIN_BATCH_BYTES=224`, `MALLOC_PERTURB_=165`) ran at timeout
multiplier 1.0 and reported no failing test on the tree that integrated the
#1370 changes.  The strict gate adds `WIRELOG_JOIN_BATCH_STRICT=1` and ran at
multiplier 0.3; at 0.3 the slow tests (`example_13_daemon_style_paced`,
`tdd_recursive`) can time out on budget alone, and its one TIMEOUT was
`example_13_daemon_style_paced`.  The other strict failures are expected:
strict mode turns each recorded fallback into `ENOTSUP`, so a test whose
program plans a shape bounded mode does not cover can fail under it, and the
strict gate is compared by test name against its previous list rather than
expected to be empty.

Cost, measured when this paragraph was written (#1370) with `bench_flowlog`
release builds, `WIRELOG_MEMORY_BUDGET` pinned at 64 GiB in both arms, and the
CPU governor at `schedutil`, so the figures are indicative.  The default path
compares, with the knob off, the tree with the later #1370 changes against the
tree before them, which already contained the first #1370 pipeline units (the
operand checks and the successor-based fallback decisions) and the earlier
bounded producer, over nine interleaved rounds; the explicit knob compares
`WIRELOG_JOIN_BATCH_BYTES` of 1 MiB against the knob off on the #1370 tree of
that time, over five interleaved rounds.  Every pair produced the same tuple
counts, and CSPA's result digest matched (also at 64 KiB).  The cause of CSPA's
difference under the explicit knob is not established.

| Workload | Default path (knob off) | Explicit knob (1 MiB) |
|---|---|---|
| CSPA | -2.3% | -24.4% |
| Galen | +1.0% | -0.5% |
| Polonius | -4.9% | +13.2% |

Bounded mode is not chosen automatically: it runs only when
`WIRELOG_JOIN_BATCH_BYTES` is set, and #2186 records the measurements and a
design for an automatic mode.  When this paragraph was written (#1370), it
would not have helped the two workloads measured under memory pressure.  On
DOOP under a 90 GiB cgroup budget, the bytes reserved above the session's
starting reservation reached at most 36.5% of the usable budget above it at
any JOIN dispatch, and the run stopped at a single large CONSOLIDATE scratch
request.  CSPA's smallest passing `WIRELOG_MEMORY_BUDGET` among those probed
was the same with the knob off and at 1 MiB, consistent with its pressure
being the JOIN outputs, which the relation sink still materializes.

### Scope of bounded JOIN mode (#1382)

What `WIRELOG_JOIN_BATCH_BYTES` bounds is each producer's own working set:
the per-producer bound above, plus the output growth the governor admits
batch by batch.  The output relation itself is still materialized in full,
and the differential arrangement transaction and a consumed pipeline's tail
transients are outside the knob.  Each JOIN operator publishes one relation;
publishing its batches downstream one at a time (bounded exchange) is #1383,
after #1373.  The non-differential producer holds no source reader on its
inputs, which is safe only because it is drained synchronously before the
operator returns; that must change before #1383 publishes batches
asynchronously.  On a worker the right operand can be a view of the
coordinator's storage, so the ordinary JOIN drains the producer while its
primary arrangement probe holds a reader on that operand, and the fused
pipeline acquires one on it for the drain (#2201).  A producer in a run
that resolves operands by input slot holds its own reader on the right
operand from create until destroy or cancel (#2201).

Controlled initial STEP also has a deliberately narrow #1821 compatibility
route for `VARIABLE → JOIN → FILTER → MAP → CONSOLIDATE`. It materializes the
whole private JOIN relation before applying FILTER and MAP, so the configured
batch size is an admission signal for this route, not a memory bound on the
joined intermediate or the end-to-end evaluation. The governor and existing
output limits still apply. Only successful registry publication increments
the dedicated controlled-fallback counter; refusal, cancellation and cleanup
retry do not.

Where bounded mode runs, as the program-level test
`test_join_batch_program_{default,nofusion}` measures it in both planner
builds at one and four workers, reading the per-route run counts:

- strata whose inputs are below the parallel thresholds are evaluated on the
  calling session, where joins of an eligible shape run bounded (the
  two-hop, filtered two-hop and closure programs succeed under strict mode,
  on the ordinary, pipeline and differential routes; the K = 4 recursive
  rule records its excluded shapes);
- a snapshot after an incremental insert takes the insert route (#2114) in
  both modes, and its clones run the producer on the pipeline route,
  recording nothing (#2201); at four workers the clones run concurrently.
  A strict snapshot whose route merges one stratum's heads and then has a
  clone refuse a JOIN that feeds another JOIN returns `ENOTSUP` from the
  full evaluation that follows, and a snapshot whose clone overflows the
  legacy row cap returns `EOVERFLOW`.  With strict mode or the cap
  cleared, the next snapshot is exact;
- at four workers, with `WIRELOG_TDD_MIN_ROWS_PER_WORKER` or
  `WIRELOG_NONREC_TDD_MIN_ROWS_PER_WORKER` forced to 1, the workers
  themselves run the producer (#2201): TDD workers on the differential
  route for the linear closure, which takes the owner strategy, and for
  the self-joined closure, which takes bdx and still records its own
  `delta-right` exclusion; non-recursive workers on the ordinary route for
  two-hop and on the pipeline route for the filtered two-hop.  Nothing
  records `worker-session`, and strict mode succeeds for the linear
  closure and both two-hop programs.  In strict mode the full
  re-evaluation after an insert ran on workers again for the non-recursive
  programs and on the calling session for the closure;
- K-Fusion runs its branches serially on the calling session, so no branch
  session exists while the knob is set.

With W workers up to W producers run at once, one per worker, each within
the per-producer bound above, and all of them are admitted by the
session's single memory governor; the aggregate working set is therefore
up to W times the per-producer bound, plus each worker's output relation.
Each worker still publishes one relation per JOIN operator, so no worker
emits more than one payload into the one-payload-per-worker transport;
bounded exchange is still #1383 after #1373.  A TDD bound run reads the
knob from its worker and runs the producer over the slot's relation
(#2201), with `I(n)` added to that producer's bound; so does each
insert-route clone, up to one producer per clone, all admitted by the
session's governor. The expanded and CSPA K1 bound forms are exercised
only by unit tests (`test_tdd_occurrence_execution`); in the instances
that test runs, the first JOIN feeds another JOIN and records
`pipeline-not-consumable`, so strict mode refuses them.  Which route a
given production workload takes depends on its data sizes and is not
claimed here, and no performance claim is made.

The shapes bounded mode excludes record these reasons, and each is refused
under `WIRELOG_JOIN_BATCH_STRICT`: `cross-join`, `delta-right`,
`filtered-right`, `no-arrangement`, `row-too-large`, `pipeline-not-consumable`,
`materialized` (differential path; a cached result is copied before the
decision and is neither recorded nor refused) and `lftj`.  Neither
`worker-session` nor `insert-route` is recorded since #2201.
A controlled attempt on the JOIN route of #1821 refuses the knob with
`ENOTSUP` without recording a reason; the numeric plan driver that
dispatches it is not yet reached from session evaluation.
Strict mode therefore refuses incremental differential programs whose joins
read a right delta, LFTJ chains, and recursive multi-way rules (whose joins
feed joins and read right deltas); it is a diagnostic setting.  A keyed
ordinary or differential JOIN whose left input, or whose right operand after
selection and the right filter, has rows but no columns fails with `EINVAL`
before the materialization cache and the bounded-mode decision (#2209).
Nothing is recorded, and such a delta, filtered or (differential)
materialized right gets `EINVAL`, not `ENOTSUP`, under strict mode.  A
missing or forced-empty right keeps its empty result.

The bounded paths report failures as typed errors:
- a governor denial is `ENOSPC` with `wl_columnar_session_budget_denied()`
  set, except a denial of the differential arrangement's creation or copy
  reservation in the differential producer's create, which returns `ENOMEM`
  with the flag set (above); the JOIN does not reclaim and retry on a
  denial, and cancelling a running join from the host is #1821;
- a batch that would take the output past `UINT32_MAX` rows is `EOVERFLOW`;
  an `EOVERFLOW` from the output's capacity reservation itself is still
  `ENOMEM`, and an overflow in the differential scratch's retained-bytes
  arithmetic is reported as a budget denial (`ENOSPC`);
- `col_join_batch_run_to_relation` returns `EAGAIN` for stale inputs and
  `EIO` for an ambiguous commit, and the legacy row cap is `EOVERFLOW`.

The tests pin, on one session, a fault after committed batches, a second
fault on the retried operator run, and an exact clean run, with reserved
bytes back at the warmed baseline in each
(`test_diff_operator_fault_retry_restores_baseline`,
`test_operator_fault_during_retry`, and for the consumed pipeline
`test_pipeline_midstream_fault_retry_baseline`); the differential test also
checks that both inputs' readers are released, and the pipeline test that
the left input is put back on the stack; through the session API, reuse is
shown after the row-cap `EOVERFLOW`.  A second fault on a batch retried
inside one continuation is not separately tested, and faults while a
producer is suspended are covered by input mutation, eviction and
cancellation (`test_suspended_producer_survives_eviction`,
`test_stale_inputs_are_rejected`, `test_stale_by_arrangement_rebuild`,
`test_lease_released_on_every_path`), not by an allocation fault.

With the knob set and more than one worker, the legacy row cap
(`WIRELOG_JOIN_OUTPUT_LIMIT`) for a K-Fusion rule is checked against each
join's own output, as at one worker, rather than the counter a parallel
branch set shares (#959).

When this section was written (#1382), with the #1382 changes on main
`c2ca4fb8`, the full release suite passed (466 tests, tidy and abi included,
14 skipped); the knob-on gate (`WIRELOG_JOIN_BATCH_BYTES=224`,
`MALLOC_PERTURB_=165`) reported no failing test (335); ASan/UBSan over the
whole suite, with the knob off and at 224, and TSan (`-Dthreads=posix`)
reported no failure and no sanitizer report; and the 72-test oracle matrix
(knob off, 224 and 65536, each with `MALLOC_PERTURB_` 0 and 165) ran 68
tests without a failure in every cell, the other four being data- or
environment-gated skips.  The strict gate's list grew from 47 names,
measured on main `284dc96a` before #1382, to 66: 15 tests whose differential
joins read a right delta (now recorded and refused), `lftj_integration` and
`symbol_aggregates` (LFTJ), and `2d_frontier_skip` and
`multi_stratum_rule_frontier`, which assert the frontier state the insert
route leaves and fail once strict mode replaces it with a full evaluation.

## 10b. Governed join output admission

A join output that is **heap-owned** is admitted under the session governor
and holds a reservation covering its live capacity.  A **pool-owned** output
is not: `delta_pool_reset()` rewinds counters without freeing slot contents,
so a governor reference on a pooled relation would leak.  The discriminator
is `col_rel_t.pool_owned`, not `wl_plan_op_t.materialized` -- bounded mode
forces a heap output with `materialized == false`, and a materialized join
*with a projection* is pool allocated.

The ordering invariant, which `tests/test_memory_admission_join.c` asserts at
every observation point as
`col_rel_retained_bytes_for(r, r->capacity) == r->retained_reserved_bytes`:

> No relation reachable from `join.c` whose `memory_governor` is non-NULL
> ever has its `capacity` increased without a reservation covering the new
> footprint committed first, and the previous token is released only after
> the old buffers are freed.

Both growth shapes obey it.  Row append goes through
`col_rel_reserve_capacity_admitted()` one doubling at a time.  Bulk sizing
through `col_join_reserve_exact()` routes governed relations to the same
helper, which is what admits the parallel cross-join output -- that path
allocates its own relation, sizes it to `left->nrows * right->nrows` and
substitutes it for the caller's, so without admission the largest single
allocation in `join.c` would reach the materialization cache ungoverned.
Ungoverned callers keep the plain `realloc()` path, which is what leaves the
pool-owned semijoin output unchanged.

In `col_join_reserve_exact()` the governed branch runs **before** the
`nrows <= capacity` early return, and must stay there.  `col_rel_new_auto()`
allocates `COL_REL_INIT_CAP` rows up front, so a cross product that fits
inside the initial capacity performs no growth at all; with the branch below
the early return, a relation attached to the governor by
`col_join_parallel_cross()` would hold live buffers against a zero token.

The population is wider than "materialized".  A **bounded-mode** output is
also heap-owned, and when its batch producer cannot be created the operator
falls back to the serial loop without ever reaching
`col_join_batch_relation_sink_init()`.  That output was heap-owned and
ungoverned before this unit and is admitted now, so a finite budget can deny
a bounded-fallback join that previously succeeded.

Denial surfaces as `ENOMEM` and never truncates a result, and it is never
retried against a still-full governor.  Two paths matter, and they differ:

- In the **nonrecursive parallel** path, the only retry conversion is
  `EOVERFLOW` to `EAGAIN` after a round that published nothing, which the
  serial caller turns into exactly one serial re-evaluation.  `ENOMEM`
  passes through unchanged and aborts the stratum.
- In the **TDD delta** path, `EOVERFLOW` and `ENOMEM` are both hard errors
  requiring coordinator intervention; neither is retried.

Either way a denial is a non-zero status with nothing published, so it
cannot be mistaken for the empty-result backpressure path that would cause
premature fixed-point convergence.

Accounting notes, so two numbers that legitimately differ are not read as a
bug:

- `col_mat_cache` re-parents the **ledger** on insert (RELATION to CACHE) and
  leaves the governor token with the relation, so a cached join output is
  charged once on each axis.  The token is released when the entry is
  evicted, cleared or destroyed.
- `cache->total_bytes` is **nrows**-based while a governor token is
  **capacity**-based and includes timestamps, so the governor charge can run
  up to about 2x the cache's own accounting.
- `COL_MAT_CACHE_LIMIT_BYTES` is not a hard ceiling: a single oversized
  result is admitted once eviction has emptied the cache, so the bound is
  "limit plus one oversized entry".
- A **pinned** cache entry defers its release at `col_mat_cache_clear()`
  until the final pin is dropped.  The mechanism is pre-existing and
  unchanged, but the consequence is new: the deferral now holds governor
  bytes, not only ledger bytes.  Note also that `col_mat_cache_lookup()`
  itself takes an epoch pin despite its header describing the result as an
  unpinned borrowed pointer, so a diagnostic lookup before a clear defers
  that entry.
- The parallel cross-join path holds **two charged** footprints transiently
  -- the caller's placeholder plus the substitute's own token -- and briefly
  **three physical** ones, because the substitute's initial
  `COL_REL_INIT_CAP` buffers are resident and uncharged between
  `col_rel_new_auto()` and the bulk reserve's publish.  The substitute is
  attached without an admission and enters its bulk reserve with a zero
  token, so no retired token is produced.  That uncharged window is
  single-threaded inside `col_join_parallel_cross()` and always closes,
  since the bulk reserve admits `max(nrows, capacity)`.  A cross join
  therefore needs roughly `COL_REL_INIT_CAP x ocols x 8` of headroom beyond
  its result, and `wl_columnar_memory_reserved()` sampled after the join
  reports the residual, not that peak.

**Residual R1 (accepted, tracked in #1724 and follow-up #1801).** On the
materialized path the operator deep-copies its output for the evaluation stack
with a NULL governor and hands the governed original to the cache. Both
buffers are live and physically identical, so the governor currently charges
once for twice the resident bytes. The deep-copy API explicitly resets
`memory_governor` and `retained_reserved_bytes` for this transient-copy
contract; it is not a general admission policy for governed ownership.
Governing the copy requires auditing every stack consumer's success, failure,
unwind, replacement and teardown paths. That work is tracked in #1801 under
the eval-stack admission class and remains separate from the contract test
added for #1724.

**Untested by construction.** The `col_join_reserve_exact()` caller inside
`wl_columnar_join_diff_op` is not driven end to end by
`tests/test_memory_admission_join.c`; the parallel cross path covers the same
branch. Reaching the diff-op caller requires all of: a heap-owned right
relation registered under `op->right_relation`; `key_count > 0`; no right
filter expression; `!used_right_delta`; `left->nrows >= num_workers *
WIRELOG_JOIN_PAR_MIN_LEFT_ROWS`; and more than `COL_REL_INIT_CAP` output
rows, since a smaller result makes the bulk reserve a no-op.

`WL_MEM_REPORT` total reconciliation is asserted only narrowly here: the
cache-clear case proves that clearing releases exactly the output's token.
A full report-level reconciliation for join outputs is not covered.

## 10c. Plain STEP completion recovery (#1713, #2329, #2336, #2348)

A public `STEP` that starts with no delta callback and no delta observer can
retain a bounded scalar completion cursor (`plain_step_completion_pending`).
It is armed at these points:

- At W>=2, after successful TDD evaluation and merge, before workers retire:
  `col_eval_stratum_tdd_nonrecursive` uses phase `FINALIZE_NONREC`;
  `col_eval_stratum_tdd_recursive` uses `FINALIZE_RECURSIVE`, followed by
  `CANONICALIZE_RECURSIVE` for aggregate publication. The cursor saves the
  final iteration, rule base and iteration-cap outcome. A nonrecursive
  stratum evaluated through `col_eval_stratum` does not arm it,
  including its per-relation parallel path
  (`wl_columnar_eval_nonrec_relation_parallel`).
- At W=1, after each stratum commits (phase `EVALUATE_REMAINING`).
- At any worker count, just before compaction (phase `COMPACT`).

A failure in worker evaluation or in the merge arms nothing. If an earlier
stratum of the same `STEP` already armed the cursor, it stays where it was.

The cursor is kept for every nonzero return, not only `EBUSY`. The caller sees
that return from `STEP` or `SNAPSHOT`. These are the codes traced at each
point:

- Worker retirement (`tdd_cleanup_workers`): `EBUSY` when a reader holds a
  worker relation or a filter-cache pin is live. `EINVAL`, `EFAULT` and
  `EOVERFLOW` report a broken internal invariant.
- Finalization (`wl_columnar_eval_delta_consolidate`): `ENOSPC` with
  `wl_session_budget_denied` set when the memory budget refuses it, `ENOMEM`,
  `EBUSY`, `EINVAL`, and `ENOBUFS` or `EOVERFLOW` from frame admission.
- A later stratum: whatever its evaluator returns. On retry its rows are
  discarded and it runs again; strata before it do not.
- Compaction (`col_rel_compact_many`): `EBUSY`, `EAGAIN`, `EOVERFLOW`,
  `EINVAL`, `EFAULT`. It does not return `ENOMEM` or `ENOSPC`: a failed
  bookkeeping allocation, a denied admission and a failed buffer preparation
  leave the relation as it was and report success, except that a refused
  rollback reports `EAGAIN`.

The publication cutoff in `col_session_step_impl` cannot fail while a cursor
exists, because a session with evaluation control never arms one.

A later public `STEP` or `SNAPSHOT` first runs its entry checks, which can
return their own error with the cursor unchanged. It then resumes the cursor
before evaluating anything else or emitting anything. Completed worker
publication and relations already finalized are not repeated. Recursive
aggregate retry does not repeat relation normalization. Recursive convergence
frontiers and iteration accounting publish once, after finalization succeeds;
an iteration-capped stratum clears the cursor without publishing convergence
or evaluating downstream strata, preserving the partial-snapshot contract.
A `SNAPSHOT`
whose resume fails calls no tuple callback.

A finalization refused before it publishes leaves its target's rows,
generations and provenance unchanged. A refused worker retirement does not
change coordinator relation rows. A refused compaction keeps every relation's
rows, but members of the batch already compacted keep their new storage.

While the cursor is set, `col_session_insert`,
`col_session_insert_incremental`, `col_session_remove`,
`col_session_remove_incremental` and `col_session_make_compound` return
`EBUSY` once their argument and sealed-input checks pass. Only
`col_session_remove` reaches `col_session_remove_incremental`, and it refuses
first. A zero-row insert or remove returns 0 and changes no relation. The public
`wl_session_insert` and `wl_session_remove` clear `wl_session_budget_denied`
before the backend call, so a refused or zero-row call clears it too: read the
flag right after `STEP` or `SNAPSHOT`.

`wl_session_budget_denied` is true after a `STEP`, or a `SNAPSHOT` without
evaluation control, that returned `ENOSPC` and during which the governor refused
an admission, wherever that happened: a denial during worker setup, on a worker
that has retired, or at a site that sets no flag of its own leaves no session
flag behind. An internal `ENOMEM` with such a refusal is returned as `ENOSPC`,
so the facades report `WIRELOG_ERR_MEMORY_BUDGET`. The flag is false after a
call that returned 0, even if a refused admission was recovered from. A `STEP`
under evaluation control spans public calls, so it is judged against the
governor's count when its first call began, through its final return; the next
controlled `STEP` clears the flag and starts a new count once the previous
STEP's cleanup has finished, and a STEP that resumes outstanding cleanup is
judged with it. A controlled `SNAPSHOT` is not typed this way: it reports only
the denials that its refused admissions flag. While a controlled `STEP` is
parked on `EAGAIN`, the flag shows only denials that its attempt has flagged so
far; read it after the final return (#2351). The refusal can also be another
session's on a shared governor, or one this evaluation recovered from, which
mistypes an `ENOSPC` or `ENOMEM` that is not about admission. A flag set where a
denial is known can also accompany another nonzero code.

Input stays refused because the session holds an uncommitted evaluation. After
a merge, the relation holds rows that are neither normalized nor counted as
completed, and a first evaluation that started over would keep them. Recursive
W>=2 completion has the same input exclusion after a successful merge (#2336).

An evaluation can also fail with no cursor armed, for example in a `SNAPSHOT`,
in a stratum at W>=2 that fails before its merge, or in the first stratum at
W=1. Its heads may hold merged or partial rows, so the session records the
failed stratum in `uncommitted_strata_extent`. The next `STEP` or `SNAPSHOT`
that does not resume, or a `STEP` that takes a delta baseline because a callback
was installed since, discards those strata's rows and, before a first commit,
any rows retired from them, restores host input from the `$in$` shadows, resets
their frontiers and derives them again. Input is open in the meantime, so the
new evaluation uses the current input. The exception is workers the failure
retained: `col_session_insert` and `col_session_remove` return `EBUSY` until a
retry retires them, so a retry that retains them again keeps input closed. If a
reader still refuses the retirement or the clear, that retry returns the code
before evaluating anything. Otherwise a failure that repeats without a cursor is
not a dead end, since a host can shrink its input, but each retry derives those
strata again rather than resuming.

A plain `STEP` of a committed session that fails past its entry checks, a `STEP`
of one that stops at its iteration cap, observed or not, and an evaluating
`SNAPSHOT` of one that fails may each have changed the committed model already,
so the session treats that model as gone and no baseline measures a change from
it. The `STEP` that finishes the evaluation reports nothing and finishes
unobserved, and a callback observes from the following step;
`wl_session_snapshot` between the two gives the host its baseline. This holds
for a callback installed after the failure and, for a `SNAPSHOT` or a capped
`STEP`, for one already installed: a successful `SNAPSHOT` reports no events
either, and a capped observed `STEP` gives up its baseline, and a removal's
retraction pre-seed with it, so input and snapshots are no longer refused while
it caps; a retry finishes only once the evaluation fits within the cap. A
failure in the entry checks, such as an `EBUSY` while a cleanup is pending,
changes nothing, and a callback measures from the committed model as usual. A
callback installed while a cursor is pending likewise sees nothing from the
`STEP` that resumes it. An observed `STEP` that fails instead keeps its
baseline: its refusal rolls the heads back to the committed rows, dropping a
timestamp array too short to cover them rather than admitting a larger one, and
the retry reports the change exactly.

With a cursor from an earlier stratum, the failed strata past the cursor are
discarded on resume in the same way, and input stays refused.

A public memory governor reached the refused first `STEP`, the refused observed
`STEP` and the refused evaluating `SNAPSHOT` without a test hook: a second
session held the budget down, the evaluation was refused, and the second session
then went away (`tests/test_session_budget_refusal.c`). Internally a refused
admission returns `ENOSPC` or `ENOMEM`; a `STEP`, with or without evaluation
control, or an uncontrolled `SNAPSHOT` returns `ENOMEM` as `ENOSPC` when the
governor refused an admission during the call, or during the attempt of a
controlled `STEP`.

The cursor clears in two places only: the commit block of a `STEP`, or of the
drain inside a `SNAPSHOT`, that succeeds, and a stratum that reaches its
iteration cap. A `SNAPSHOT` can still fail after its drain has cleared the
cursor. So a failure that repeats on every retry refuses input until the
session is destroyed. A budget refusal at finalization is an ordinary
production outcome: it can repeat like this unless other users of a shared
governor release memory. `wl_session_destroy` needs no prior retry, but it
aborts if a reader still blocks worker retirement. There is no reset.

Arbitrary mid-operator or partial-merge rollback is outside this contract.

## 10d. TDD coverage assertion migration (#1396, unit 1)

The first coverage unit for #1396 gives three tests names that describe the
behavior they actually exercise. Test bodies and stress sizes are unchanged;
the mapping below is the assertion inventory for the rename.

| Previous test target/file | Current target/file | Preserved assertions |
| --- | --- | --- |
| `k_fusion_inline_shadow` / `test_k_fusion_inline_shadow.c` | `diff_arrangement_inline_shadow` / `test_diff_arrangement_inline_shadow.c` | Four-worker immutable inline reads, arrangement deep-copy isolation, and worker-state mutation independence |
| `e2e_tsan_inline_kfusion` / `test_e2e_tsan_inline_kfusion.c` | `inline_concurrent_read` / `test_inline_concurrent_read.c` | Concurrent inline reads plus insert/retract lifecycle cycles at the original TSan stress sizes |
| `e2e_kfusion_k4_inline` / `test_e2e_kfusion_k4_inline.c` | `nonrecursive_multiworker_authorization` / `test_nonrecursive_multiworker_authorization.c` | Scalar, nonrecursive authorization result fingerprints and counts at the existing worker widths; no compound or retraction claim |

These names identify arrangement isolation, concurrent inline access, and
multi-worker authorization results. They do not claim that these tests prove
recursive TDD worker dispatch; that end-to-end assertion is the follow-up
unit in this issue.

## Evaluation-control foundation and memory admission (#1819)

The internal `wl_session_options_t` v3 appends a retained evaluation-control
reference beside the memory governor. Verified v2 prefixes remain accepted;
`memory_governor` still overrides environment/host memory-limit resolution and
the Windows handle exactly as before. Session creation retains its own control
reference, claims a unique logical owner, and unwinds both on construction
failure; the options structure itself is never retained. Worker clones borrow
the control until the coordinator's backend teardown has drained them.

Work allowance is independent of byte admission: zero means unlimited work,
not unlimited managed memory. Exhaustion/cancellation have dedicated internal
dispositions; memory denial and accounting overflow remain genuine execution
errors. Completed attempt reports retain execution and cleanup errors separately
from the stop cause. Stopping must never discard a checked-disposal refusal or
skip required release/drain simply because work allowance is exhausted.

This commit provides primitives/attachment only. Controlled STEP/SNAPSHOT
currently return `ENOTSUP`; no public host API enables the feature yet. The
[SEMANTICS evaluation-control contract](SEMANTICS.md#evaluation-control-foundation-1819-engine-integration-pending)
defines charge-before-work accounting, retry/publication obligations and future
256-unit checkpoints. These are not additional memory-governor reservations,
RSS limits or wall-clock deadlines. #1820–#1823 implement recovery, engine
coverage and public access; #1824 validates the combined behavior.

# Relation replacement ordering and recovery

Relation growth, copy-on-write, delta overwrite, and compaction keep the old
storage charge until the old physical buffers have been retired. A prepared
replacement is admitted before publication; if preparation or publication
fails, private replacement buffers are freed before the pending reservation
is rolled back. On successful overwrite, the replacement is published, old
columns are freed, and only then is the old reservation released. This keeps
reusable budget from becoming visible while the corresponding allocation is
still resident.

Ordinary reservation-release refusal is terminal: the relation cannot safely
return with a live token whose accounting state is unknown, so that path
aborts rather than pretending the operation rolled back. Compaction has a
retryable exception because its replacement token is owned by the relation.
If commit and rollback both refuse, compaction returns `EAGAIN` and retains
the valid relation storage plus its `REPLACING` token. A later compaction call
resolves that token before reporting success; callers must preserve the
relation and its governor until that retry or checked teardown completes.

### Relation growth error provenance

Capacity reservation, row append, locked batch reservation, COW/arena
transitions and timestamp preparation retain checked admission errors.
For compatibility, an actual budget denial returns `ENOMEM` with the relation's
`memory_budget_denial_pending` flag (and the optional `denied` output) set.
Allocator failure returns `ENOMEM` without new denial evidence; accounting or
size overflow returns `EOVERFLOW`, and invalid shape or reservation state returns
`EINVAL`. JOIN and session adapters convert only confirmed budget denial to
`ENOSPC` or the continuation reservation-denied status.

Outer row/capacity operations clear stale denial evidence under their existing
ownership or writer contract. Nested preparation, including locked timestamp
allocation, preserves earlier evidence belonging to its enclosing operation.
Rejected growth preserves storage, row/timestamp contents, generations and
reservation credit; a retry starts a new operation. This status contract does
not change worker publication or coordinator rollback transactions (#1964/#1965).


### Prepared controlled growth commit (#1821 foundation)

The private `wl_columnar_memory_governor_growth_commit_prepared_t` protocol separates
reversible preparation from a finite terminal commit. It supports an original
committed token after `begin_growth`, with an exclusive caller, the expected
governor and physical owner, and a live active evaluation control. It does not
activate relation or operator paths. Existing raw and controlled commit APIs,
including their 4/9-unit costs and NULL-control delegation, are unchanged.

Preparation admits **228 conservative logical units once**, before token or
record mutation. This includes preparation184 and future finish44; an early
stop or cancellation of READY does not refund admitted work. Limit227 refuses
at that admission; limit228 can prepare successfully. Invalid original-record
arguments can consume228 without changing that record. `consumed` measures
admitted work, not exactly executed primitive operations.

The source convention counts scalar assignments, individual predicates,
executed if dispatches, returns/gotos and platform atomic/thread operations.
Arithmetic operand reads belong to their assignment/predicate. Helpers are
expanded: atomic read2, active-ID getter4, strong CAS2 and token validator25.
Control admission/poll scheduling, test callbacks and mandatory error cleanup
are excluded. No engine-owned loop is hidden behind a cleanup exclusion.

| Preparation region | Conservative slots |
|---|---:|
| Seventeen pointer/inert predicates, dispatch/error alternative, ready store, saved getter/local and inactive-id verdict | 28 |
| Thirteen record stores, thread query, validator25, classification local and result/consume/return alternatives | 50 |
| Final validator25, predicate/dispatch, expected local, strong CAS2, verdict/dispatch, immediate CLAIMED and refusal alternatives | 37 |
| At most five checkpoints, each getter/local5, identity predicates/dispatch3, return1 and caller result/dispatch/error alternative4 | 65 |
| Prepaid marker, READY, ready output and return | 4 |
| Preparation total | 184 |

Finish44 expands validator25, outer predicates/dispatch5, active getter/local5,
identity predicates/dispatch3, four token stores4, CONSUMED1 and return1. The
compile-time typedef guard enforces total228 <= quantum256 on every compiler.
The logical ceilings cover error alternatives; they are not CPU instructions
or a runtime latency guarantee.

The five successful checkpoint instrumentation ceilings are41/63/13/50/13, total180.
They represent conservative source intervals, not exact execution. The final
READY stores4 plus finish44 account for the remaining48 without a finish
callback. A stopped preclaim checkpoint plus its unclaimed consume/return costs at
most15; the extra2 already belongs to the snapshot dispatch reserve. Thus
the success label13 does not claim to count that complete error-return path.
The largest forward interval remains63; the trailing helper region is48. Caller
work between READY and finish needs its own admitted cutoff/composition proof.
A typed preclaim/claim refusal checkpoint replaces later success checkpoints;
there is never a sixth checkpoint on one path. Each checkpoint invokes the
test seam, checks the originally saved active ID, then polls zero work. It
never charges positive work to a successor attempt after a callback.

All restoration snapshots and thread/attempt/original-address bindings exist
before the one REPLACING-to-COMMITTING CAS. CLAIMED is recorded immediately
before its first callback or poll. A copied record or another thread cannot
finish or cancel it. Finish checks the same active ID before any token store;
a stale finish leaves READY reachable for original cancellation. Observation
does not pin the attempt: externally serialized host lifecycle, borrowed live
references and the existing worker-drain requirements still apply.

Cancel is mandatory cleanup and remains legal after attempt end/reset/rebegin.
It validates original authority, restores only REPLACING and consumes the
record; it neither changes the shared governor total nor refunds incoming
credit. The caller frees incoming physical storage before existing
`rollback_growth` refunds its own credit. Owning cleanup corruption aborts
instead of inventing restoration. Successful finish updates bytes to the saved
sum, clears replacement/kind, release-publishes COMMITTED and consumes the
record. It has no poll, charge, mutex, callback, allocation, CAS or retry.
No ledger gate may be held across callback-capable preparation.

`ready` is authoritative only with execution rc0. Shape/claim refusal returns
rc0/false, including a later latched negative stop after refusal was established;
the control report independently keeps that disposition. Positive accounting
or stale-attempt errors take precedence. Invalid pointers/dirty record return
EINVAL, and a genuine admitted stop propagates its negative disposition.
`test_memory_governor` uses real old/incoming buffers and an independent peer
reservation for exact admission, every checkpoint stop/error/stale edge,
original/copy/thread authority, and physical-free-before-refund checks.

### Private controlled ledger publication

`mem_ledger_publication` prepares at most two ordered alloc/free events before
claiming the ledger's writer gate. Preparation admits109 logical slots, then
166 for initial validation26, finite apply117 and release23. Each gate CAS
attempt admits28, including failure loopback and the next attempt-identity
check. Denied admissions consume no work; successful preparation totals275,
and acquisition totals275+28*n for n CAS attempts. These conservative source
ceilings include expanded helpers and error paths, not exact executed counts.
Each individual admission fits the256-slot quantum. Caller initialization and
actual relation/lease publication require separate accounting.

The source-adjacent inventory counts assignments, predicates, dispatches,
atomic/thread primitives and returns. Apply117 combines the worst FREE
validation with the more expensive ALLOC arithmetic; APPLIED release23 covers
both phase predicates. After callbacks, saved identity is checked before a
zero poll or further positive admission. No successor attempt is debited.
Acquisition can be invoked once; stopped/stale acquisition is cancel-only.

A successful CAS establishes the final cutoff. Finite apply uses current
protected saturating/clamped counters in request order, preserving peak
semantics of raw accounting. No callback, poll, charge, allocation, retry or
mutex occurs during apply/release. The real governor/storage composition test
counts the complete held sequence207 slots after CAS (208 including CAS), with
four explicit fixture publication stores. It proves composition of the helper
protocols; actual row/batch/lease publication remains separately required.
The fixture's FREE-old/ALLOC-new events do not prescribe actual relation
accounting deltas when saturation or gauge drift is involved.

Before the cutoff, cancellation consumes only original prepared authority,
never restores a numeric ledger snapshot or another reservation's credit.
After APPLIED, cancellation refuses and original release remains mandatory.
Governor cancellation restores its token phase; incoming physical storage is
freed before rollback refunds credit. Successful physical retirement likewise
precedes downsizing original credit. The independent17-byte peer reservation
remains untouched throughout composition tests. This private foundation does
not activate operators or expose enforceable public configuration.

### Caller-attempt-bound governor admission

`wl_columnar_memory_release_try` is the one-shot counterpart used when a
retirement cursor must not spin while returning a reservation. It makes at
most one strong CAS attempt to claim the token and one to credit the governor.
It supports `RESERVED`, `COMMITTED`, and `REPLACING` tokens; replacing tokens
return both the committed and overlap footprints. Retryable contention leaves
the original token live with its owner, bytes, transition metadata, and credit
intact. The result distinguishes successful release, retryable contention,
invalid token/accounting state, and replacement-size overflow. The token and
governor must remain alive and the caller must retain exclusive ownership of
the token for the call. Concurrent changes to other tokens can make the
aggregate CAS fail;
the caller retains its cursor and retries in a later slice. A successful return
releases the whole token. It does not free storage, perform a work poll, or make
cleanup safe while readers still hold the storage. The ordinary release API
remains available when retrying is permitted by its caller.

The private `wl_columnar_memory_governor_*_attempt_controlled` reserve, growth
and commit APIs require a live control and the caller's original nonzero
attempt ID. NULL control returns EINVAL; legacy APIs retain their raw delegation
and tariffs. The host serializes control lifecycle. The original token and
nonoverlapping output remain exclusively caller-owned. Token, control and
governor storage remain live through cleanup, with stable governor configuration.
Independent peer tokens may share the governor and concurrently change its
aggregate reserved total; exclusive governor ownership is not required. A hook
may change the attempt or independent peer resources; it cannot free or forge
the original token or allocate its incoming physical storage.

Entry correlation is an explicit bounded read-only exception: valid entry
executes12 logical slots included retrospectively in the first admission;
invalid/stale entry executes at most13, with consumed0. First-admission refusal
can also execute this observation without debit. No mutation, allocation or
pointer walk precedes admission; this is not prior prepayment.

| Region | Conservative admitted slots | Source obligations |
|---|---:|---|
| Entry | 74 | Bootstrap, typed shape checks, complete original snapshot, phase and work checkpoints |
| Claim | 54 | Original strong state CAS, claimed marker, preparation; includes six-slot caller continuation when first round admission refuses |
| Aggregate round | 84 | Current total/limit reads, strong CAS, credited marker, guards, work checkpoint, caller ADMITTED checkpoint; failed round pays next guard/loopback and refused-next-admission continuation |
| Publish | 29 | Reversible reserve/growth publication or finite four-slot commit terminal |

Successful reserve/growth admits157+84*n slots for n aggregate CAS attempts
(first success241); commit admits157. Limits73/127/211/240 retain respectively
0/74/128/212; commit156 retains128. Refused charges debit nothing. These are
source ceilings, not executed instruction counts. Hook work arguments label
regions and must not be added as consumed work. Expanded source equations live
beside the constants. The conservative adjacent-region no-poll ceiling168 is
below quantum256, including bootstrap from function entry. Host callbacks,
synchronous runtime/admission internals and mandatory cleanup are excluded;
this does not bound return time or cleanup retries.

Every individual callback validates saved ID before another callback, poll,
claim or positive admission. Staleness stops immediately without charging the
successor. Cancellation/accounting injected at aggregate before/after-CAS hooks
can proceed to the paid work checkpoint; unchanged ID alone does not poll them.
Completed typed INVALID/DENIED/OVERFLOW outcomes beat negative stops; positive
accounting or stale errors take precedence, and outputs are authoritative only
with rc0. Actual commit has no callback or negative poll after COMMITTED.

Snapshots precede the token claim; owned-credit markers precede after-CAS hooks.
Mandatory unwind restores only the original token and subtracts only its own
credit from current totals. Independent peer changes survive, and impossible
refund aborts. Incoming physical allocation follows successful return, and
physical free always precedes later rollback/release. Tests cover literal
boundaries, genuine RELEASED reuse, raw parity including NULL owners, all seams,
typed verdicts, real independent peer allocations and actual aggregate CAS
failures. This opt-in foundation does not activate engine operators.

### Caller-attempt-bound single mutation admission

`wl_columnar_relation_mutation_single_acquire_attempt_controlled` acquires
one initialized private scalar relation's descriptor and self-owner writer
under the caller's immutable evaluation attempt ID. The caller keeps the
relation and control alive, exclusively owns the original inert frame, and
externally serializes the control lifecycle. The attempt ID detects a changed
attempt; it does not pin any object's lifetime. Existing raw and controlled
single-admission entrypoints retain their behavior and work tariffs.

Each nonce, writer and work callback is followed by an ID check before another
callback, claim, poll or positive debit. Successful claims record the original
writer and acquired count before exposing a work callback. Failed nonce CAS
rounds are charged separately; a consumed global nonce is never rewound when a
later stage stops. Unsupported alias, lazy-owner, pool, arena, shared-column
and compound shapes are inspected only after descriptor authority is held.
No allocation or variable role expansion occurs in this entrypoint.

Success supplies the ordinary single-frame lease. Failure uses the existing
noncancellable single finish to release only this original frame's authority.
A release failure retains the remaining tokens and counts: the caller must
retry cleanup while that frame remains live or fail-stop. Copied frames and
wrong-thread finish cannot retire the original writer. Cleanup after an ended
attempt does not poll or charge a successor. An established busy verdict wins
over a negative stop; a positive stale or accounting error wins over busy.

Before the first charge, the entry performs only a bounded read-only argument
and identity check: 12 logical slots on valid entry, at most 13 on rejection.
This is an explicit uncharged exception, included retrospectively in the first
admitted region. Rejected or first-admission-denied calls can execute it with
zero consumed work. Work-region ceilings describe logical source operations,
not elapsed time or exact machine instruction counts; mandatory cleanup is
outside the forward work metric.

The admitted regions are entry 94, nonce observation 19, each nonce CAS round 39,
frame 39, each writer 45, self binding 52, borrow check 21 and final validation 144.
A first-round success consumes 498; each genuine failed nonce CAS adds 39.
The conservative adjacent-region ceiling is 165, below the 256-work quantum.
Frame storage must not overlap relation/control storage. Forward callbacks
cannot forge/free original authority or change protected descriptor shape.
Mandatory release hooks are exempt from forward ID checks. An initiating
positive error may mask a later release error; inspect and drain retained
original authority regardless of the returned error value.

### Controlled private row append

`wl_columnar_relation_append_row_controlled` materializes one scalar row under
an original descriptor/source mutation single. A NULL control delegates to raw
append. The controlled destination is an initialized private canonical heap
owner; positive width needs allocated positive capacity, and an existing
timestamp image must occupy the same capacity. Nullary non-timestamp capacity0
advances to64 without a zero-byte allocation or governor growth transaction.
Deferred timestamp ledger tracking remains valid.

The original active attempt ID is captured before callbacks and remains fixed
through single admission, scratch/payload admission, staging and publication.
A callback that finishes and restarts the control causes EINVAL before another
forward callback, claim, poll or debit of that successor. The caller retains
live storage and serializes control lifecycle. Input values remain stable during
capture; input may be a readable slice of destination columns or row_scratch.
Callbacks cannot free or alter the protected descriptor or original authority.

The complete input is captured before writes or retirement: inline through
width16, heap scratch above16. Governed scratch is reserved and committed at
its original address before malloc. This deliberate scratch requirement can
consume more memory than raw append with disjoint wide input. The incoming
payload includes a full new pointer table, lanes and timestamps beside the old
image. Auxiliary merge, backup and scratch payload remains resident and keeps
its coverage; descriptor/metadata credit is untouched. No aggregate governor
or ledger counter supplies ownership of a token.

S or P authoritative DENIED returns ENOMEM and sets
memory_budget_denial_pending. An allocator failure returns ENOMEM without
inventing that provenance. Nonzero execution rc is inspected before a typed
status; an established typed denial wins over negative cancellation, while a
positive stale/accounting error wins over both. Prior denial provenance clears
only after successful original single acquisition. Failed bootstrap/admission
preserves it.

The source-operation tariff table expands predicates, stores, arithmetic,
branches, loops, helper returns and refused-child caller continuations. It is
admitted work, not exact executed-work telemetry. Sixteen-byte copy chunks
preserve timestamp padding. Fixed scalar initialization avoids an unmetered
structure-sized zero.

| Row region | Admitted ceiling |
| --- | ---: |
| Initial single frame | 83 |
| Other original records | 63 |
| Shape and next epochs | 103 |
| Each size component | 83 |
| Each scalar lane/value | 36 |
| Each at-most16-byte copy/zero chunk | 183 |
| Each allocation/ownership marker | 32 |
| Credit validation/caller continuation | 76 |
| Original lexical publication recipe | 69 |
| Exact-one lease validation | 151 |
| Prepared-helper caller continuation | 26 |
| Publication caller glue | 48 |

AB-S admits498 on the first nonce round; AB-G reserve/begin admits241 on its
first aggregate round and commit157. Prepared governor admission228 includes
finish44. Ledger preparation109+166 includes initial26, apply117 and release23;
each gate attempt admits28. Those nested tariffs remain separate from row
caller glue. The bounded read-only root bootstrap is included retrospectively
in the first83 admission; invalid bootstrap can consume0. Maximum conservative
interprocedural polling work is248, below quantum256; byte chunks have their
own guarded polls.

Before publication the operation validates the original exact-one frame and
precomputes new pointers, capacities, epochs and ordered ledger deltas.
Successful ledger CAS is the final cutoff. The complete contiguous governed
ledger sequence, including CAS and caller/return glue, has ceiling225;
ungoverned ledger177, governed/no-ledger76, ungoverned/no-ledger28 and
nongrowth12. It executes no callback, new admission, allocation, generic lease
advance or raw ledger reconciliation. Governor finish precedes direct stores;
ledger events apply RELATION then TIMESTAMP against current counters, followed
by the timestamp tracking mirror and gate release. TIMESTAMP uses final
physical bytes minus the prior tracked mirror, supporting actual deferred
tracking from ungoverned enable_timestamps. Nongrowth and no-ledger append
preserve the mirror.

After releasing the ledger gate, old physical lanes/table/timestamps retire
before original P credit downsizes to the final retained footprint. Scratch
physical storage likewise retires before its credit releases. Failed staging
cancels original prepared records, frees incoming storage, refunds only owned
credit and drains the original single. Mandatory cleanup is noncancellable;
impossible retirement failure aborts with original authority reachable. Stopped
nongrowth can change unpublished spare cells, but rows/view/storage remain
unchanged. This API alone does not enable evaluation operators.

### Resumable private relation append growth (#1821 foundation)

`wl_columnar_relation_append_growth_attempt_t` is an internal, opt-in transaction
for two distinct self-owned heap relations with the same positive number of
INT64 columns. It rejects aliases, arena/pool relations, shared views,
compounds, timestamps and other auxiliary payload, zero-row appends, and
appends that fit the existing capacity. This narrow shape keeps the staged
footprint exact: the replacement image is one pointer table plus
`ncols * new_capacity` INT64 cells. For a governed destination, its existing
reservation must exactly cover the old image. Staging admits the full new
image beside the old one, so peak relation credit and physical payload include
both images; after publication, the old image is retired before the reservation
is downsized to the new image. This API does not reserve source, alias, scratch
or auxiliary-owner payload.

Begin binds a zero-initialized receipt to its original address, creating
thread, active control identity and attempt ID. After acquiring both
relations' gates, the first validation step snapshots their generations and
shape for commit-time revalidation. Keep the receipt and both relations at
stable addresses. The original
control must remain live for forward `advance` calls and explicit `commit`;
READY means only that private staging is complete. It has not changed the
destination. Commit is the publication cutoff. An abort before that cutoff
frees staged storage and refunds only this attempt's credit, preserving the
old destination. After publication, cleanup retires the old image and
downsizes credit. Keep descriptors, reservation and all referenced storage
alive until the receipt reaches DONE.

Each forward phase transition, lane allocation and lane/type check is admitted
before mutation. Row copies charge the number of rows and are capped at the
256-unit evaluation quantum per call; allocator latency is outside that work
bound. Cancellation or work-limit refusal before publication enters mandatory
cleanup. Once cleanup begins, the receipt no longer uses its original control:
each nonterminal `cleanup_step` needs a distinct live control with a currently
active matching attempt ID and charges one cleanup unit before one bounded
phase action. A refusal leaves that action and its resources pending. Cleanup
may continue after the original control is finished and released, but callers
must not abandon a pending receipt. DONE returns the latched primary result;
`cleanup_result` retains cleanup diagnostics.

Zero count returns `EINVAL`; unsupported shape or nongrowth returns
`ENOTSUP`; checked capacity/byte overflow returns `EOVERFLOW`; governor denial
and allocation failure return `ENOMEM`; commit generation drift returns
`EBUSY`. Work exhaustion and cancellation retain their distinct control
results. Governor denial sets `memory_budget_denial_pending`; allocator failure
does not claim that provenance. These failures are not interchangeable, and
none implicitly publishes a partial destination. The focused mutation-set
tests cover denied admission, partial allocation failure at the table and
lane stages, unsupported types and shapes, capacity overflow, stale commit,
prepublication cancellation/abort, funded cleanup refusal, and postpublication
refusal/retry. This foundation does not instrument JOIN or activate the append
path in the evaluator.

### Controlled private held batches

`wl_columnar_relation_append_batch_t` is a distinct internal wrapper around
one original `raw.single`. Begin binds either the current evaluation attempt
or NULL/raw delegation. Row, set and end take that original wrapper by pointer;
copying it does not transfer authority. Start with a zero-initialized wrapper,
keep relation/control alive, serialize their lifecycle, and end every exit
that retains authority. Reset only a fully ended wrapper for reuse. Legacy
`col_rel_append_batch_t` and its cached raw lease validation remain unchanged.

Controlled rows retain the private scalar domain of controlled row append.
Earlier published rows survive a later stop; end is not whole-batch rollback.
A new storage transition renews the lease only after its predecessor already
published one. Before releasing the old lease, the row captures every raw
input lane under its original descriptor/source writers. Input may alias old
columns or row_scratch. No old input pointer or type array is used after
release. Reacquisition keeps the original single address and saved attempt ID,
but obtains a fresh nonce and validates current destination shape. A changed
width returns ENOTSUP before any captured-lane access. FLOAT validity and
signed-zero normalization use the reacquired schema, including when a valid
peer replacement changes the type during the unlocked gap.

Wide capture has exactly one original scratch reservation and allocation.
It retains the original governor wrapper while its binding is protected,
commits scratch credit before allocation, and keeps that reference across the
unlocked renewal gap. Row-body staging borrows the completed capture instead
of allocating it again. On every exit, incoming row preparation is retired,
then physical capture is freed, original scratch credit is released, and the
original governor reference is released last. Current destination binding is
never used to refund old scratch. If capture was ungoverned and a peer legally
attaches a governor during the gap, that attachment does not retroactively
admit already-live capture; new payload admission uses the reacquired binding.
An already governed relation rejects attachment to a different governor.

A cancelled, exhausted or stale pre-release admission leaves the old held
single intact. Mandatory old release may fail with residual original authority:
the wrapper remains DRAINING and must be ended again. Once old authority has
fully drained, the saved attempt is checked before any forward callback,
poll, nonce claim or debit; reacquisition failures leave ENDED or DRAINING
according to actual retained authority. No descriptor payload is read during
the unlocked interval. Callers must separately retain relation lifetime.

Cell set validates an existing row/column and current FLOAT representation,
prechecks view epoch overflow, and publishes the cell/view under a final
funded cutoff. It changes neither storage epoch nor timestamp payload. End
validates original remaining thread-bound authority and performs mandatory
cleanup without polling or charging any current or successor attempt. It
remembers the first initiating result across cleanup retries. A positive
cleanup error takes precedence over a negative initiating stop while authority
remains; an initiating positive error retains precedence. After successful
drain, end returns the remembered initiating result, including a negative stop
following earlier published rows. Inspect DRAINING authority even when an
initiating positive error masks a cleanup error.

The held-batch region ceilings are begin170, original validation220, each
capture initialization/pin phase80, renewal128 and set70. The caller-generation
`wl_columnar_relation_append_batch_begin_attempt_controlled` entry admits the
writer against the supplied saved ID before publishing batch state or acquiring
source access. A stale ID leaves the successor accounting and batch unchanged.
Its read-only bootstrap84 includes the inert-single helper63; rejected inert
paths are bounded by78. Count the extra saved-ID argument in the actual caller.
The legacy `begin_controlled` entry still captures the current ID, then delegates;
it does not authenticate an earlier caller generation. Its ordinary wrapper9
makes the complete bootstrap93 and inert rejection87. These are the concrete
fixed metadata initialization bounds under the existing retrospective bootstrap
exception: dirty, inactive and first-refused admissions may report consumed0.
No refused action receives future body credit. The NULL-control legacy branch
adds at most10 fixed front/return operations around the unchanged raw begin;
this does not qualify the raw algorithm as controlled work.

Renewal is funded before old release and includes both original-ID guards,
reinitialization and refused-child return continuations. The caller-generation
route retains the conservative forward248 and complete post-CAS publication
through outer return225. The legacy wrapper adds one final return, giving249
and226 respectively, including controlled LFTJ/REDUCE callers that retain that
entry. Begin170 remains sufficient because its actual generic charge expansion
is replaced by the qualified saved-ID primitive; that reduction supplies no
credit to the precharge rejection or final return. Mandatory cleanup bodies
remain excluded.


### Caller-attempt-bound empty scalar schema clone

The internal `wl_columnar_relation_new_like_governed_checked_mode_attempt_controlled`
entrypoint creates a private, empty scalar relation under the supplied original
active attempt ID. NULL control delegates the exact raw mode API. This is a
new-like constructor prerequisite for logical row copy; it does not activate
an evaluator operator or clone delta weights.

The caller owns a writable, exclusive, nonoverlapping output slot containing
no live owned result. Exactly one fixed bootstrap exception normalizes that
slot to NULL before ID validation or the first charge. Thus inactive, stale or
initially refused calls may perform that store with consumed0. No source scan,
resource claim, callback or bulk context initialization is part of this
exception. All later resource work is admitted against the immutable caller ID.

Original descriptor and canonical owner reader tokens protect borrowed schema,
names and types through the constructor's last read. Real alias borrowing and
external source lifetimes remain necessary; arena/pool reset is prohibited
while those descriptors are used. The private builder acquires no additional
source readers. It receives an already pinned recipe and returns an owned local
relation. Only after mandatory source drain and another original-ID guard does
the wrapper admit the final external output store.

D covers the descriptor and owned relation name. M covers actual names, types,
Arrow schema objects, tables and format/name bytes. P covers the column grid,
optional zero timestamp storage and eager governed row scratch. The explicit
output governor is retained before its first D admission and any following
constructor checkpoint. Its retained reference and the three original credit
tokens remain reachable throughout partial allocation and Arrow initialization.
Successful publication transfers original credits and that one retained
reference into the complete local relation in a single prepaid cutoff.
Failure frees partial physical images before returning only their own credits,
then releases the retained governor reference. Impossible original token or
reader retirement fails stop while authority remains reachable.

The clone owns its source-compatible names, scalar types, graph/index/declared
width and requested optional zero timestamp image. It uses the explicit output
governor without inheriting source governor authority. Constructor D/M/P denial
retains the existing ENOSPC category. The later logical physical-row copy has a
separate contract and deliberately projects away signed timestamp weights.
Allocator internals, instrumentation and mandatory original retirement remain
outside logical forward-work accounting; no elapsed latency guarantee follows.

The constructor's conservative interprocedural source envelope is248, using
inherited governor168 plus the complete reserve caller80. The post-commit
caller is separated by the governor's actual final cutoff: final4 plus its
continuation41, with failed continuation at most60. Byte chunks use a224 paid
region for a211 conservative full caller/refusal envelope. Identity observation
uses80 for56 including a refused first claim. Pointer192 covers160. Complete
installation costs140 for moves/stores,160 through source-drain bookkeeping,
and176 including refused external publication; its paid region is220. All
24 named regions and portable compile-time bounds are adjacent to the source.
These are source-derived envelopes under the stated exclusions, not observed
instruction counts. Reached-tail telemetry may omit already admitted work when
a nested governor phase stops; charged reports remain the accounting authority.

### Caller-attempt-bound physical row-range projection

`wl_columnar_relation_copy_rows_controlled` creates a private scalar heap
relation containing physical rows `[begin, end)` in source order, preserving
duplicates and source-compatible schema/type/graph metadata. It deliberately
omits timestamps and signed multiplicities, matching the existing raw range
copy. A negative or magnitude-greater-than-one source weight does not change
the number of copied physical rows. This is not a weighted recovery snapshot.
NULL control delegates the exact raw API before output normalization. Controlled
calls use the same exclusive/nonoverlapping/no-live-result output slot contract
and fixed initial NULL-store exception as the caller-bound schema constructor.

One original descriptor/owner reader pair protects the source recipe and lanes
through the last gather. Source and owner lifetimes, including alias borrowing
and arena/pool no-reset, remain caller obligations. Range/capacity and nonempty
lane validation happen under that pair. Empty ranges and nullary rows require
no fictitious lane reads. Gather reads never call `col_rel_row` or modify source
row scratch, metadata, timestamps or governor authority.

The pinned private constructor creates the destination without reacquiring
source readers, with timestamps disabled and the explicit output governor.
The private destination has no session ledger during copying. The copy owns
its original held batch, checks its saved attempt ID immediately before the
batch's capture-on-entry begin, and retains that ID across all rows and storage
epochs. Complete inert batch initialization includes its nested original
single/set/lease/writer records and is separately prepaid; partial records are
never inspected or drained after a refused initialization.

Widths up to16 use an inline gather. A nonempty wider copy allocates one reusable
width-sized gather under its own original S token and retained explicit governor
reference. The held batch independently captures each row under its own S token.
The peak therefore includes both gather S and batch capture S, alongside the
destination D/M, old and incoming P and eager scratch. This can deny a controlled
copy at a budget where raw copy succeeds. Constructor D/M/P denial remains
ENOSPC; gather and row denial use ENOMEM. Allocator failure does not invent a
budget-denial flag, and no failed private destination is returned.

Mandatory batch end preserves the initiating result. A negative result with
ENDED and no original owners is a successful drain; retained DRAINING authority
fails stop before the lexical frame can disappear or the destination can be
destroyed under its writers. Gather physical storage is freed before its own
original credit/ref is returned. Owner then descriptor readers drain before
the original-ID guard and separately funded final external store. Cleanup never
charges a successor attempt. Forward caller branches, markers and complete
refused-child return chains are included in the copy's source-cost inventory;
allocator/instrumentation and mandatory original retirement internals retain
the explicit exclusions. No wall-clock latency bound follows.

The copy caller prepays its added success-or-failure continuation before
entering the existing constructor/source helpers; that allowance is not spent
again on each child loop iteration. Complete ordinary drain/public/child
suffixes are conservatively32/44/48 source slots. The separately funded begin
caller includes the86-slot inert read before the child's170 admission; the row
caller includes25 slots before the child's220 CHECK admission. Its15 named
regions and portable bounds are adjacent to the implementation. The composed
conservative source envelope is249, including the deepest inherited byte
failure through the copy return. It uses actual no-ledger batch terminals and
actual last-poll boundaries, rather than adding whole caller tariffs to old
internal248/168 maxima. Charged reports remain authoritative; reached-tail
labels can repeat at multiple sites financed by one earlier admission.


### Caller-attempt numeric compiler ownership

The internal `wl_columnar_expr_compile_attempt_controlled()` produces a
separate opaque `wl_columnar_expr_attempt_numeric_t`. It requires a live
control and the caller's nonzero current attempt ID; missing, inactive or stale
IDs return `EINVAL`. It does not delegate to the legacy owner representation.
The output slot must be exclusively writable and contain no live owned result.
Its fixed NULL/false initialization and initial getter/refused debit are bounded
bootstrap exceptions that can execute with consumed work zero.

The immutable encoded input remains live through both passes. Each byte and
column digit is admitted before access; unsupported or malformed numeric input
returns success with supported false before an owner is published. No raw
string, intern, crypto or extension fallback is called. This compiler unit does
not introduce a new evaluator or activate default operators.

A governed program retains its own governor reference. Before the admitted
stack token moves, the pin belongs to the compiler, while the partial owner has
no pin or credit. The successful checked move and the held/admitted/ref marker
updates occur without a callback between them. Genuine ungoverned programs
leave the embedded token EMPTY and skip reserve, move, commit and retirement.
Mandatory destruction snapshots the held/committed/reference fields before
freeing instructions and owner, then retires only its own moved credit and
finally releases the saved reference. It remains valid after attempt finish or
reset. Original tokens and destruction are exclusive; immutable program reads
require external exclusion of destruction. Callers serialize control lifecycle
and preserve stable shared-governor configuration throughout admission.

Source-adjacent accounting expands the guard9, debit-prefix13, tail26 (29 with
caller), initializer10 and move40. New ordinary destruction69 is rounded to72;
complete outward failure chains are96,100,104. The fixed bytes-helper prefix24
and decoder continuation32 include last-byte-to-next-debit refusal. The twelve
tariffs are128/224/224/192/192/224/224/224/192/224/224/160 for entry, decode,
byte, digit, pass, setup, reserve caller, allocation, store, move, commit caller
and external publication. Their full envelopes are86/176/195/161/150/191/210/
177/148/192/163/132, checked by portable typedef bounds. Nested governor return
is212; its internal168 interval is separated by actual polls and is not added
to the whole caller tariff. Conservative224 bounds logical forward intervals,
not machine instructions or elapsed time. Allocator/control internals,
instrumentation and original mandatory physical/credit/ref retirement are
explicit exclusions; new ordinary cleanup branches are included. Test phase8
is mandatory disposal with NULL control, distinct from subsequent forward hooks.


### Caller-attempt numeric execution

`wl_columnar_expr_eval_attempt_controlled` borrows the genuine immutable
program produced by the preceding compiler. The caller supplies the active
control and original attempt ID; NULL, inactive or stale control returns
EINVAL. Both output slots remain unchanged on every nonzero return. Numeric
semantic failure publishes value0/failedtrue only after the final original-ID
check, while control errors take precedence. No raw interpreter fallback,
allocation, reservation or governor-reference operation runs during evaluation.

The fixed local stack initializes only its top; each admitted numeric push
writes its value and sidefields. Raw underflow0, ignored saturated pushes,
aggregate no-ops, checked integer boundaries, finite FLOAT and negative-zero
semantics remain. Each in-range VAR lane is admitted before reading it. Phase21
observes that read before finite validation (failedfalse); phase20 and phase22
carry detected semantic failure. A stopped/stale call publishes neither slot.

Five tariffs are96/64/224/160/96 for entry/fetch/step/row/final. Full source
regions64/32/192/144/48 include expanded portable arithmetic/stack helpers and
all outward/next-refusal continuations; row includes both row and step tails.
Conservative224 bounds logical forward work, with control internals and
instrumentation excluded, not machine instructions or elapsed time. Independent
success/semantic-prefix work is192+288 per executed instruction+160 per actual
in-range VAR read, including final96 after semantic failure.

Programs may outlive compilation attempts and the caller's governor reference.
Distinct controls and output slots may read one immutable owner concurrently;
exclude destruction until all borrowed readers join. The registered numeric
fixture uses real synchronized threads and owner-only governor pinning. This
atom supplies numeric execution without activating default FILTER/MAP dispatch.
# Attempt-bound persistent cleanup frame admission

`wl_columnar_eval_stack_cleanup_begin_attempt_controlled` admits the existing
cleanup frame under the caller's original nonzero execution-attempt ID. A NULL
control delegates the existing raw entry point. The session and empty output
handle must be exclusively accessed; its governor binding remains stable.
Failure preserves the active/pending lists, counters and output. A returned
typed governor DENIED status may set `memory_budget_denied`; stale/accounting
errors before that authoritative status do not fabricate this flag.

The frame is privately allocated and zeroed in admitted chunks of at most
16 bytes. Partial initialization cleanup reads only initialized local ownership
markers. Original token moves and the committed outcome select rollback versus
release. Physical memory is freed before original credit and the retained
governor reference are released. A published frame belongs to the session and
uses the existing finish/pending/retry protocol after control destruction.
Private test observation grants no supported ownership or reader escape.

The nine logical fees are ENTRY128, SETUP160, RESERVE240, ALLOC160, ZERO224,
TOKEN128, MOVE192, COMMIT160 and EXTERNAL160. Both external-cutoff hooks share
the last fee. With `N = ceil(actual frame bytes / 16)`, independent totals are
`928 + 224*N` without a governor and `1726 + 224*N` with a governor; a real
failed governor total CAS adds84. Ordinary failure decisions and checked token
moves, zero-loop transitions, nested helper returns and refused next debits
are included. The conservative contiguous source bound is240, below256.
The read-only invalid/first-refused bootstrap may execute at consumed0 and is
bounded by28. Control/instrumentation/allocator internals and mandatory original
physical/credit/reference retirement internals remain explicit exclusions;
this is a logical-work bound, not a latency bound. The physical-freed hook is
mandatory, receives NULL control and cannot debit a successor attempt.

Attempt admission preserves the raw quota policy. Unary transactions extend
the private frame storage: both raw and controlled admission charge its actual
current size. Neither helper activates FILTER/MAP or default evaluation routes.

### Resumable reservation retirement receipt (#1821 prerequisite)

Replacement cleanup that must survive work limits uses a zero-initialized
`wl_columnar_memory_retirement_receipt_t` at its original address and on its
creating thread. Begin binds the token address, expected governor, expected
owner and either RESERVED rollback or COMMITTED release without reading the
token's mutable payload. Each step receives a live maintenance control and its
expected attempt ID, admits 64 conservative work units before changing
authority, and keeps no control pointer after return. The per-step admission is
below the 256-unit evaluation quantum, including the bounded phase dispatch,
thread/identity checks and one possible atomic transition.

The receipt claims the exact token state with one strong CAS, captures and
validates the positive byte count and non-overlap shape only after winning, then
subtracts that captured credit with one strong aggregate CAS. A lost claim
fails without reading token payload; malformed claimed payload restores the
original state without refund. Aggregate contention returns `EAGAIN` while
keeping the claim and CREDIT phase for a fresh funded retry. Underflow returns
`EOVERFLOW` with that authority still reachable. A successful subtraction
immediately publishes RELEASED and marks DONE, so a later step cannot refund
twice. ACK is receipt-local and permits receipt reuse without inspecting a
released or reused token. Status exposes phase, retained-claim authority and
terminal disposition from the receipt alone. If cancellation or work exhaustion
stops a step while the receipt owns the claim, the caller must preserve the
receipt and resume it with a fresh live maintenance attempt; it must not abandon
or reinitialize the receipt/token while the claim remains held.

The caller must finish freeing the corresponding physical storage before
beginning retirement and retain the token and governor through ACK. This
protocol bounds its own reservation transitions; it does not bound allocator,
destructor, physical teardown, overlap/downsize, or merge lifecycle work. Those
remain separate obligations for the integrating replacement path.

### Managed binary relation construction and retirement (#1821 prerequisite)

`wl_columnar_relation_managed_binary_build_t` constructs an unnamed private
binary INT64 relation through address-stable, one-action steps. A stopped step
leaves its cursor and allocations unchanged; the caller may continue the same
receipt with a fresh live attempt. A terminal allocation failure leaves every
partial pointer and committed token reachable through `build.relation`, which
must enter the managed retirement path. The builder reserves and commits one
retained token for all four payload lanes (two output columns and two merge
columns), both pointer arrays, row scratch, and the type array before
allocating those components. The descriptor reservation remains embedded
until descriptor storage is physically freed.

`wl_columnar_relation_managed_retirement_t` accepts only the narrow private
shape produced by that builder. It acquires descriptor and storage writer gates
as one round before inspecting mutable shape. A validation refusal releases
both gates and changes no ownership. Once the first token detaches, the receipt
keeps both writer sentinels, detached token slots, receipt addresses, and the
governor reference stable across every yield. Each physical pointer is freed
and cleared in its own action. Retained credit is refunded only after all
accounted arrays and lanes are gone; descriptor credit remains charged until
the descriptor allocation itself is freed.

The relation gates remain WRITER through descriptor free. The round is armed
before that free and then consumed by a local-only step that clears only the
round record; it never reads or releases gate pointers after their relation
has been reclaimed. Receipt and builder objects are creator-thread-bound and
must stay at their original addresses. Callers transfer exclusive relation
lifetime before retirement and must not use outstanding raw pointers after
that handoff. Allocator/free latency remains a non-preemptible library call;
the protocol bounds engine work between those calls, not wall-clock time.

### Managed binary candidate replacement (#1821 increment)

`wl_columnar_managed_candidate_merge_t` is a separate, immutable-input path
for unnamed private two-column INT64 relations. It rejects shared, aliased,
timestamped, compound, schema-bearing, ledger-attached, or delta-baseline inputs
before allocating output. Source must already be globally sorted; candidate rows may
be unsorted and duplicated. Both relations must use the same governor (or both
be ungoverned). The path copies both inputs into a private replacement and
scratch relation, performs bottom-up numeric sorting and deduplication, then
subtracts source rows with a resumable binary search to create the novel delta.

Every comparison cell, copied cell, builder action and state transition spends
the original attempt's work allowance, under one 64-action maximum per call.
The nested relation builders use that same attempt. Allocation and allocator
latency remain non-preemptible calls, but every allocation/admission action is
charged and every partial pointer/token remains reachable through the attempt.
The canonical union and delta stay private until `take_result` transfers both
outputs together at its no-fail cutoff. Before that cutoff, stop cleanup retires
all private builders; after it, the caller owns both outputs while the attempt
retires only scratch and releases its input-reader round. Cleanup uses a fresh
maintenance attempt and retains each retirement receipt until ACK.

This restricted primitive does not itself wire candidate replacement into all
operator paths or complete issue #1821.

## Persistent unary result replacement

The internal `wl_columnar_eval_stack_unary_*` protocol keeps the original
seven-field stack entry in place until a final saved-attempt cutoff. The
provisional output and retired original have separate persistent slots; the
existing frame result slot is never reused. Publication transfers the complete
original entry to retirement, installs the complete canonical output in the
same stack slot, and leaves stack depth unchanged. Cleanup refusal after
publication preserves the new result and the original retired authority.

Only the provisional relation pointer is writable through its accessor.
Same-frame aliases to the input, result or live stack entries are detached
without destruction during commit rejection and independently during first
abort cleanup. Inactive stack cells do not own their stale pointers. No supported
cross-frame ownership alias, raw mutation during a transaction, reentrancy or
reader escape on a private output is permitted. Frames, input and allocator
lifetimes remain the caller's responsibility.

Begin admits initialization and a separate 256-unit first-finish allowance
before exposing ACTIVE state or an output slot. The first initiating result is
latched, including zero: later finish arguments never replace it. Return that
first result when nonzero, otherwise persistent alias EINVAL, otherwise the
latest cleanup result. Genuine EBUSY retains the exact independent output or
retired input. First finish validates the original native host thread, then
clears borrowed control/snapshot bindings; serialized retries may run on a later
thread after the old control is destroyed. DONE does not dispose twice, and
reset requires inert slots. Generic frame finish rejects an active transaction
before unlinking it or consuming its handle; pending cleanup visits both new
owning slots even if another result refuses disposal.

Unary begin fees160/128/256 total544. Commit fees192/128/128-per-live-entry/128
total `448 + 128*n` for an independent output. Head aliases pay320; an alias at
live index `j` pays `320 + 128*(j+1)`. Input/output accessors have no debit and
require caller envelopes48/56; their costs and relation construction are
separate from these unit totals. All ordinary return, refusal and field-move
work is counted. The first-finish scan explicitly compares four scalar pointers
per loop, with a remainder of at most three; no hidden bulk comparison, callback
or poll splits it. Sanitizer ceiling136 plus scaffold82 and ordinary disposer14
gives232, below256. This conservative alias ceiling does not claim every alias
is reachable after earlier head checks. Retry96, DONE24 and reset64 are bounded
per-invocation inventories at the mandatory lifetime-cleanup boundary; one old
begin debit does not finance arbitrarily many retries or whole pending lists.
New cleanup guard success14/rejection15, disposer36 and continuation32 extensions
are ordinary work. Narrow physical/token/ref retirement, control, allocator and
instrumentation exclusions remain; future operators must compose adjacent work.

The enlarged frame changes admission footprint and zero-chunk count `N`.
Existing admission totals `928 + 224*N` and `1726 + 224*N` remain separate from
unary fees; the TOKEN region now includes two explicit identity/IDLE stores and
has envelope124 under its fee128. These logical source bounds are not latency
bounds, default-operator coverage or whole issue #1821 completion.
### Caller-attempt auto construction

The internal `wl_columnar_relation_new_auto_governed_attempt_controlled` and
`wl_columnar_relation_new_auto_attempt_controlled` primitives prepare empty,
untyped, scalar relations without timestamps for a later MAP transaction.
They use the supplied original attempt ID throughout construction. The governed
form requires a governor and preserves the requested logical capacity, including
zero; a positive-width zero-capacity relation still allocates one physical lane
element. The plain form uses `COL_REL_INIT_CAP` (64) and private heap storage.
It does not introduce pool or arena reuse or promise the raw operator's peak.
Generated names, schema, default graph/declaration fields and generations match
the corresponding raw constructors. FLOAT values remain raw lane bits, including
negative zero; these functions do not attach FLOAT type metadata.

The caller supplies an exclusive writable output slot with no live owned value.
A single output-NULL normalization store is the bounded bootstrap exception;
an initial refusal may consume zero work while executing the fixed rejection
scaffold. Recipe and local initialization occur only after paid admission.
NULL control delegates raw behavior: the plain wrapper maps a raw NULL result,
including a NULL name, to ENOMEM. Controlled invalid arguments return EINVAL,
with positive accounting errors and stale-attempt errors taking precedence over
cancellation. No new public API or operator dispatch is enabled here.

Four new admissions cost 128 each. Successful billing is 512 plus the actual
existing builder schedule, including all three reserve and commit caller fees
even without a governor. Each nonzero governed D/M/P child adds reserve fees
74+54+84+29 and commit fees 74+54+29; a real failed reserve CAS adds another 84.
The new wrapper envelopes are 80/64/64/64. Expanded child return chains are
18/21/24; the inherited COMMIT caller envelope is 92+20+2=114, within its 128 fee.
The conservative reserve composition is 168+82=250, within the 256 quantum.
Actual child polls separate earlier commit work from its final continuation
(at most 62); the move/install and caller edge fit 178 within the existing 220.
These are source-work bounds with the established control, allocator,
instrumentation and mandatory physical/token/reference retirement exclusions,
not whole-call latency bounds.

Until the final original-ID admission and tail succeed, the completed relation
belongs to a lexical private local. A stop destroys it with checked destruction;
an impossible private destruction refusal aborts rather than losing ownership.
A still-NULL frame slot owns nothing. After actual publication into a registered
unary frame slot, legitimate readers may make later cleanup return EBUSY; that
slot retains ownership for a serialized retry after the reader is released.
Privileged test hooks can recover an owner address from a still-live committed
reservation, but acquiring private readers is an invariant violation. The death
fixture for that violation is distinct from supported postpublication retention.

### Protected scalar source and selected-row provenance (#1821)

The opt-in internal scalar-source record holds two original readers: the
input descriptor gate and its canonical storage owner's payload gate. The
caller keeps both allocations, metadata and any pool/arena alive through End;
reader gates prevent mutation and do not pin those allocations. The original
record never moves. Init publishes its disjoint initialized flag only after
all cleanup-relevant fields and both inert reader tokens are complete. A
refused Init publishes false and the record must not be inspected or ended.
Forward calls use the original native thread, control and immutable attempt
ID; serialize lifecycle changes and exclude reentrant lifecycle calls from
hooks. End drains actual original tokens independently of the outer phase,
latches its first result including zero, and never accesses control. An ended
record returns that first result after the old control/source lifetime ends.
Wrong live thread and copied records leave original authority intact.

The existing source-slot convention counts assignments, individual evaluated
leaf predicates, controlling dispatches, explicit arithmetic/loop steps,
native thread primitives and expanded helper returns. Short-circuit connectors
route predicates without a separate slot. C12 plus assignment/predicate/if
costs15; G9 with those caller operations costs12. The prior auto-constructor
validity allowance8 conservatively exceeds its predicate/store core5; it does
not establish a different connector metric. These are logical admission
units, not CPU instructions, elapsed time or completed-work telemetry.
Control scheduling, instrumentation, allocator internals and original
mandatory physical/token/reference retirement interiors retain their existing
exclusions. Ordinary scalar-source validation, first-result bookkeeping,
drain dispatch,23 field clears and return are included.

| Source region | Admitted fee | Conservative performed envelope |
| --- | ---: | ---: |
| Init and one future first live End | 256 | 86+72=158 |
| Begin | 256 | 160 |
| Classifier/owner resolution | 224 | 176 |
| Source validation | 224 | 176 |
| Snapshot | 192 | 144 |
| Eight column accessibility checks | 224 | 208 |
| Shape publication | 128 | 96 |
| Gather entry | 128 | 96 |
| Eight gathered cells | 224 | 128 |
| Pinned-newlike entry | 128 | 96 |
| Pinned recipe | 128 | 64 |
| Pinned builder caller | 128 | 64 |
| Private output publication | 128 | 64 |
| Selected-row domain | 192 | 112 |
| Selected-row prevalidation | 256 | 228 |
| Five timestamp reads | 128 | 64 |
| Existing B2 row caller | 128 | 112 |
| Post-row revalidation | 256 | 243 |
| Five timestamp writes | 128 | 48 |

Init reserves one ordinary first-End envelope even if Init stops or the
subsequent Begin admission declines. End makes no further control debit.
The first latch and DRAINED phase permit only one live clearing episode;
repeated End has a bounded readonly9-slot bootstrap. Invalid original/thread
bootstrap is bounded18. A reader child may self-release its stopped current
claim; outer End still drains any earlier token. The conservative performed
reader interval144 plus outer/End76 is220. Refused child admissions contribute
no debit; prior caller and Init reservations fund their continuations.

An uncontended source Begin admits1376+224*ceil(width/8), separately from
Init256. Each genuine additional reader CAS round admits144. Shape admits128;
Gather admits128+224*ceil(width/8). Nullary Gather still requires nonNULL
exclusive values but reads no columns. Partial gathered data is private and
must not be published on failure. Pinned-newlike admits512 plus the existing
builder's independent actual-input schedule. Held readers protect descriptor
names/types; the recipe uses fresh output generations and the output stays
local until final publication. Unpublished failure checked-destroys the local
or aborts on corrupt ownership; it does not hand ownership to a NULL frame.
The inherited direct-builder continuation retains reserve250, byte213 and
commit114 bounds; no whole child tariff is substituted for caller work.

Selected-row append requires an original controlled HELD batch on the same
attempt, a private self-owned destination distinct from the source descriptor
and owner, matching width and stable gathered values. It admits832 plus the
independent B2 row/renewal schedule without provenance, or1088 plus that
schedule with timestamps. NoTS means no timestamp **element** access by this
wrapper; presence checks and the existing B2 destination defaults remain.
With timestamps it preserves iteration, stratum, worker, reserved field and
signed multiplicity explicitly, including zero and negative values.

The first forward action after successful B2 return guards immutable local
control/ID, then performs a real zero-charge cancellation/accounting check,
then admits the post-row region before any source/batch/lease/timestamp read.
An ID getter is not a poll. The conservative returned-success interval is
225+8 capture bookkeeping+3 child result+12 local guard/caller+1 poll entry
+4 immediate-error continuation=253. The actual zero poll separates later
post-row243; old internal child248 is not blindly extended with an outer fee.
After renewal, current original lease, expected row count and current timestamp
capacity are checked again. The final pointer is reloaded and five field
stores follow the final tail without a later hook. Late failure can leave an
appended private row; drain the batch/source and discard the entire output.

The existing creation/work fixtures are registered for unit and TSan. Work
also directly compiles unchanged governor/control sources with test-only
SESSION, MEMORY and RESIZE hooks, so the real capture-credit retirement hook
can cancel, poison accounting or restart an attempt after successful row
append. Production flags and sources do not gain these hooks. Qualification
must inspect the configured source/flags/object/link graph and actual native
links; an archive-link assumption is not link evidence. Independent literal
prefixes include nested child admissions and report the original completed
attempt. A reached-tail sum can omit prepaid caller fees and is not the
billing oracle. These primitives do not activate FILTER/MAP or complete the
operator coverage required by #1821.

### Cooperative numeric FILTER

The internal `wl_columnar_filter_op_attempt_start`, `step` and `ack` interface
adds an opt-in FILTER operation to an original cleanup frame. A NULL control
delegates to the existing raw FILTER. The normal engine dispatch is unchanged;
MAP shares this continuation; full evaluator integration remains separate work.

The controlled path gathers from a protected scalar source and builds a private
heap output. It supports numeric predicates, including an absent predicate,
and preserves selected row order, schema metadata and all five timestamp
fields. Unsupported expressions fail without an unmetered fallback. The
original stack entry is replaced only after successful completion. A stopped
attempt discards its private output and preserves the original entry.

The current contract requires original frame and control authority, serialized
use on the owning thread, and private output without escaped readers or
pool/arena aliases. Every descendant uses the saved attempt ID. Restarting a
control does not authorize old work to debit the successor. A configured work
limit of zero means unlimited; a positive limit below the first admission
refuses execution with zero consumed work.

Cleanup advances through separately scheduled stages. If FINISH retains the
original input because a reader still holds it, the operation stays at FINISH.
Each subsequent retry needs a fresh host credit. RESET begins only after
FINISH releases that ownership, and a retained RESET stays at RESET. Execution
and cleanup results are distinct; callers must retain the frame until DONE and
acknowledgment, then perform checked frame destruction.

The test host uses a finite FIFO and returns after one job. Its lifecycle
credits are one-shot: a successful non-sentinel admission consumes 512 work
units, and a sentinel consumes 291. Scheduling consumes a credit before enqueue,
including enqueue failure. A spent credit does not prove that the queued job
has returned. The external host must establish that all dependent jobs have
returned or been canceled before releasing their targets; the lifetime-ready
argument is that host's assertion, not an automatic scan of arbitrary jobs.

The source-work accounting measures scalar operations and control flow, with
each increment counted as arithmetic plus a store. It excludes instrumentation
and the established allocator, control/reference and physical retirement
interiors. It does not guarantee wall-clock latency or bounded atomic retries.
The private batch CLEAR stage now clears at most four fields per turn. Its
54 fields require fourteen CLEAR turns and eighteen total first retirement
turns. Both operators prepay thirty-six grants of 192 units: each grant assigns
64 units to current setup and 128 to future retirement, covering eighteen
256-unit retirement allowances. Retained retries require fresh host admission. Fixture setup and observation occur outside those
bounded turns. Runtime correctness and performance require separate evidence;
source accounting alone establishes neither throughput nor raw-path speed
parity.

The private numeric continuation also supports an original compiled-program
table. Its initialized prefix is the only set of discoverable slots; unused
capacity is never scanned. Each table-program turn clears and retires at most
one slot, including null slots. Separate turns retire the table allocation,
its reservation, and its governor reference, then clear the scalar markers.
Reservation refusal retains the credit stage after physical storage is gone.
The original token and reference remain reachable for a separately funded
retry. These stages precede ordinary batch retirement, so the source and
original control remain alive throughout them.

Table ownership requires advance admission: six fixed grants of 256 work units
before acquiring table resources, and one grant of 256 before each slot joins
the initialized prefix. These are conservative retirement reservations, not
completed-work telemetry. Initializing and compiling slots require their own
forward admissions. The extra table stages are dormant for FILTER. The table
record enlarges every cleanup frame, including frames used outside cooperative
numeric execution; frame admission and zeroing use the actual structure size.

### Cooperative numeric MAP

`wl_columnar_filter_map_attempt_start` uses the same persistent context and
`wl_columnar_filter_op_attempt_step`/`ack` protocol as FILTER. It is an opt-in
internal entry point; normal engine dispatch remains unchanged. NULL control
uses raw MAP. Controlled MAP compiles each effective numeric expression once,
then gathers each input row once and evaluates output columns in order.
Missing expressions use the configured projection (or the column ordinal);
out-of-range projections yield zero. The private result has generated names,
no column type array and no timestamps, matching raw MAP. Output width may
differ from input width. Unsupported expressions fail during preflight even
for zero rows; numeric evaluation failure returns ERANGE. There is no raw
fallback after controlled preflight starts.

The private auto constructor and numeric row append use the existing eight-byte
operator builders. Output capacity equals the input row count with a governor;
the ungoverned path begins at 64 rows and uses existing batch growth. Combined
input/output scratch sizing is checked before allocation. Compiled programs,
the table allocation and its original credit/reference are retired before the
ordinary batch and source stages. Stopped execution preserves every field of
the original stack entry; successful execution publishes only the complete
output. Retained FINISH and credit refusal require fresh host retry funding.
Allocation failure remains ENOMEM when cancellation arrives at the same tail;
positive accounting or stale-attempt errors take precedence.

This adds per-column compilation/table storage and conservative prepaid work,
including six fixed table grants and a retirement grant per discoverable slot.
It does not promise raw-path performance or activate the remaining operators
required by #1821. The segment binding enlarges the table-bearing cleanup frame to 2816 bytes on the
validated 64-bit Linux ABI; other ABIs use their actual structure size.

### Cooperative numeric plan segments

The internal `wl_columnar_eval_plan_numeric_attempt_*` interface composes a
nonempty `[begin, end)` slice of scalar operators from a relation plan.
The JOIN and CONSOLIDATE extensions below define the supported operator set.
The caller explicitly supplies one input relation in an original active cleanup
frame. The source-bound extension below adds VARIABLE lookup and initial delta
selection. This interface does not perform recursive dispatch or session
publication. Public session control admission and
ordinary `col_eval_relation_plan()` behavior are unchanged.

A segment holds one original operation-control reference and immutable attempt
ID through its final acknowledgement. Opcode preflight visits one operator per
host action before any operator starts. Numeric expression support is checked
by the actual child compiler, including on empty input; an expression failure
in a later operator can therefore leave an earlier private result. The unit of
transaction is one operator, not the whole slice. Intermediate results remain
reachable in the private frame and are never installed in a session by this
interface.

The original segment owns a dedicated frame binding from begin through ACK,
including between children and after DONE. Generic frame disposal and competing
standalone numeric/unary mutation return EBUSY while bound. Owner-aware child
routes require the exact original segment and native thread. The trusted host
must keep the plan, bytecode, frame, session and source storage live and immutable
and must not mutate borrowed raw stack pointers while the segment is active.
Start validates the frame before initializing caller status, so structural or
ownership refusal leaves that output untouched. Segment begin validates the
operation control before its single final frame claim; a failed claim clears
its record and releases the pin without changing the frame.
Initializing a fresh caller-owned segment is host setup work; reinitializing a
live segment or copying it does not transfer ownership.

Each action admits 384 units from a separate live host funding control and its
saved attempt ID. This covers validation before admission and current action
work, including each retained retry. The 384-unit fee is distinct from the
256-unit maximum between checks. Each opcode preflight and operator entry also
admits 128 units from the original operation before child admissions.
This control must differ from the operation control. Admission failure performs
no action and preserves pending work. Every retry and status query needs a fresh
admission; cleanup after cancellation does not borrow a successor's evaluation
budget. The caller keeps the borrowed funding control live throughout the call.
This work accounting is logical admission, not elapsed time or exact executed
instruction telemetry.

A child call writes status into the original segment and returns its protocol
result directly. The host supplies that exact result to
`wl_columnar_eval_plan_numeric_consume_result()` on a later dispatch. Consuming
an outcome twice or out of order is rejected. Child acknowledgement and starting
the next operator likewise occupy separate dispatches. A positive protocol error
parks the corresponding action for a separately funded retry; it is not semantic
success or permission to abandon the frame. A synchronous loop cannot claim the
host-return bounds. Status queries are separate admitted actions with disjoint
output storage. After DONE, segment ACK releases its frame binding and control
reference; result transfer, report completion and generic frame disposal are
separate host operations.

The source accounting distinguishes the largest interval from total current
work paid by one host admission. The read-only prefix before a successful host
admission is at most 61 units. Representative conservative ceilings are:

| Action | Largest interval | Whole current action | Host admission |
|---|---:|---:|---:|
| Begin, including failed claim rollback | 160 | 181 | 384 |
| Opcode preflight | 110 | 110 | 384 |
| Operator entry, including refused first child charge | 239 | 324 | 384 |
| Batch NEW retirement | 238 | 299 | 384 |
| Batch CLEAR retirement | 204 | 265 | 384 |
| Retained FINISH retry | 249 | 310 | 384 |
| Child acknowledgement | 140 | 201 | 384 |
| Consume child result | 100 | 100 | 384 |
| Advance | 85 | 85 | 384 |
| Release to DONE | 77 | 77 | 384 |
| Status | 90 | 90 | 384 |
| Segment acknowledgement | 210 | 210 | 384 |

Child compiler, constructor and row work retains its own admissions. Owner-aware
unary begin, input/output and commit-decision intervals are bounded by 204, 149
and 203 respectively; the existing standalone COLUMN error tail remains the
limiting 256-unit interval. Standalone FINISH and RESET plus acknowledgement
are bounded by 249 and 248. These are source-model bounds under the primitive,
allocator, reference and physical-retirement exclusions described above.
They are not counts inferred from runtime hooks.

The certified action ends at its direct return to the host. Fresh record
initialization and the external host's queue scheduling are separately owned
caller work, not free operations or hidden polling points. Adding a scheduler
inside the production evaluator requires accounting for that scheduler before
activating it. Each retained retry uses a new host admission; previously paid
child retirement allowances are not spent a second time.

### Initial source-bound numeric fragments (#1821)

`wl_columnar_eval_plan_numeric_source_attempt_begin` extends the internal
numeric segment protocol to one leading VARIABLE followed by scalar children;
the JOIN and CONSOLIDATE extensions below define the supported tails.
It claims an empty original cleanup frame and preserves that owner through
lookup, construction, execution and final ACK. The containing stratum must be
nonrecursive: this is a caller precondition because relation plans do not
carry stratum recursion metadata. Nonzero iteration, retraction, TDD and
differential session contexts are refused with ENOTSUP. Public session
controls and ordinary relation-plan dispatch remain gated as before.

The host keeps the registry array, unique relation names, descriptors,
contents, governor binding and plan immutable and live through ACK. Active
frame ownership is not a registry lock. Callbacks may cancel or restart the
operation control but must not mutate this session. Lookup visits one registry
slot or one name byte per admitted forward action; it neither builds a hash
nor delegates to raw lookup. Full names are not truncated. Delta lookup uses
exactly the raw 256-byte `$d$` name policy: three prefix bytes, at most252
source-name bytes, then NUL. FORCE_FULL selects full input, FORCE_EMPTY selects
an owned empty input, and FORCE_DELTA selects a nonempty delta or, when seeded,
an owned empty delta; without a seed it falls back to full input. AUTO,
FORCE_EMPTY_AFTER_SEED at iteration0 and unknown modes select a nonempty delta
only when it is strictly smaller than full input. Missing full names are
ENOENT. Unsupported opcodes are rejected before registry lookup/input install.

A held original scalar-source record validates the selected descriptor.
Compound representations unsupported by that scalar contract return ENOTSUP;
there is no interpreter fallback. Empty construction retains names, scalar
types and graph metadata and follows the raw VARIABLE policy of dropping
timestamps. It uses private heap storage rather than the raw pool, so its
allocation/peak behavior may differ. Authoritative ENOSPC sets the session's
memory-denial flag; allocator ENOMEM and operation stops do not fabricate it.

Before the empty constructor runs, its output slot belongs to the original
frame result entry. Source initialization, acquisition, constructor, End and
result consumption are separate host actions. Success transfers all seven
entry fields into the input exactly once, clearing the old result. A stop
before installation leaves any constructed result owned by the frame. Error
ACK drains source authority and unbinds without destroying or clearing that
result. The caller then schedules generic frame cleanup separately. Early
finish refusal preserves the handle; disposal refusal may consume it and
transfer the frame to `session.cleanup_pending`, which requires cleanup_retry.
The caller retains the session/job and initiating semantic result until that
pending cleanup completes. Arbitrary metadata destruction and pending-frame
traversal are outside this fragment's action certificate, as in supplied-input
numeric segments; ACK does not make them bounded. This API does not activate
public evaluation or close the remaining JOIN/recursive/publication coverage.

Existing distinct host384 funding applies to each successful begin, step,
consume, status or ACK action; operation128 is admitted for each source
opcode, lookup slot/byte, selection and input-install action. Existing numeric
tail preflight is charged separately. A stopped operation never supplies
cleanup work from a successor attempt. Caller initialization and external
queue scheduling remain separately owned work, not an unmetered API loop.

### Ordinary JOIN workspace and typed output (#1821)

The cooperative operator workspace now has three fixed original JOIN scratch
records and a second protected scalar-source record. These are prerequisites
for the ordinary cross/keyed JOIN implementation; this change alone does not
activate JOIN or public evaluation controls. Every cleanup frame contains the
workspace, including frames used by unlimited evaluation. Frame admission uses
its actual `sizeof`, and controlled frame clearing retains its existing
bounded byte chunks rather than treating the larger allocation as free work.

An active shared context excludes ordinary unary admission, including the
interval before its unary snapshot exists. The private context-authorized
route checks the exact embedded address before dereferencing the supplied
context, original identity/session/frame/native thread, live control pin,
saved ID and RUNNING/busy state. FILTER and MAP use this route as well. It is
an internal serialized start protocol: hosts and callbacks must not reenter
the authorized route using another operator's context. An inert frame has no
implied creator-thread identity.

`wl_columnar_relation_new_typed_operator_attempt_controlled` accepts an
immutable initialized scalar type array of the exact requested width, generates
`colN` names, uses capacity64 without timestamps, and publishes into an exclusive
original output slot only after the final saved-ID check. Width0 permits NULL
types. Invalid scalar enum lanes are checked in charged steps. Name, type-array,
governor and original control storage remain live through the call. Its recipe
never escapes. Failed unpublished lexical outputs use the existing checked
private destruction/fail-stop contract; a NULL external slot does not own those
lexical resources. The existing checked numeric-row operator wrapper also
supports typed noTS private output, including FLOAT validation and signed-zero
normalization. Its source/lease/renewal/original-ID protections remain intact.

JOIN cleanup enters its own BATCH stage. It completely drains actual original
batch authority before ending the right source or retiring any scratch storage.
Each fixed scratch record then advances through physical free, original credit
release/rollback, governor-reference release and marker clearing on separate
host turns. A refused credit release preserves the original token and reference
for a separately funded retry. The left source and original output remain
reachable through the existing common continuation. Generic frame/pending-list
destruction stays a separately scheduled caller action; no arbitrary metadata
traversal or allocator-time bound is introduced.

The JOIN forward caller must admit each owner's first retirement before that
owner becomes discoverable. Fresh independently funded host actions pay actual
cleanup dispatches and retries; a stopped operation or successor is never used
as cleanup funding. This prerequisite commit does not supply a JOIN start or
claim that unwritten start's accounting. Existing FILTER/MAP lifecycle grants
and their default execution routes remain subject to their own exact source
bounds.

The written-source inventory uses the existing logical scalar-slot convention,
not elapsed time or hook sums. The context-authorized unary entry adds21 slots
(including native validation and shared-body return): the conservative owned
family envelope is225, and its caller prefix151 fits the existing192 allowance.
The single added ACK predicate changes the existing standalone RESET+ACK
ceiling248 to249. Later COLUMN256 and FINISH249 regions are unchanged. New JOIN
retirement envelopes include their canonical caller: BATCH at most254,
right-source180, and each fixed scratch stage at most120. A fresh distinct
HOST384 grant pays each action; it does not change the polling quantum256.

Typed construction retains ENTRY128, one validation128 per scalar lane,
PREPARE128, BUILD_CALL128 and existing builder/external admissions. Conservative
local ENTRY85, lane70 and PREPARE49 fit those existing regions. Supported scalar
enums include INT32 through BOOL; invalid lanes retain typed-error precedence.
Inherited builder endpoints include both types-present metadata and noTS
construction; a future JOIN caller must prove its own suffix within the allowed
constructor caller75, rather than append arbitrary scheduling after a child.

### Controlled cross JOIN transaction (#1821)

`wl_columnar_join_op_attempt_start` uses the original cleanup frame and its
embedded continuation. A NULL control delegates to the existing raw JOIN.
The controlled path supports cross and multi-key hash JOIN on scalar inputs
during initial, serial, nonrecursive evaluation. The containing stratum must
be nonrecursive.
Right filters, materialized hints, configured join batches, differential or
retraction evaluation, TDD and parallel/shared-output execution are outside
this entrypoint's domain and return `ENOTSUP`; they do not enter raw execution.

The caller keeps the plan, session registry and names, input allocations and
bound governors stable until acknowledgement. Left and selected right have
separate original scalar-source readers, including self JOIN. Registry slots,
name bytes, projected type lanes, cross-product pairs and gathered cells each
have explicit saved-attempt admissions. The output remains private in the
original unary transaction; an execution error preserves the complete original
stack entry. Output-limit accounting is independent of work and memory limits:
the inclusive threshold returns `EOVERFLOW` and discards private output.

The result's delta flag is selected while forward work is admitted. Unprojected
ordinary results retain left-delta or selected-right-delta, including an empty
ordinary result. Projection, missing right and forced-empty selection clear it.
After both input readers and JOIN scratch drain, a dedicated JOIN decision
publishes the relation and flag within the same existing callback-free unary
cutoff. Generic FILTER/MAP publication still clears delta. Private-output delta
mutation remains invalid; callers cannot patch the published flag afterward.

Every start, shared `wl_columnar_filter_op_attempt_step`, acknowledgement and
retained retry requires a new HOST384 action grant from a separate live funding
control and its immutable attempt ID. Funding failure parks the original
continuation without entering the action. A stopped operation, or a successor
attempt on the same operation control, does not fund cleanup. Each dispatch
returns to the host before another cleanup action; an unbounded synchronous
pump does not inherit this claim. Generic frame cleanup after acknowledgement
is an external caller action under its existing retention contract.

For this written cross-JOIN caller, ENTRY192 covers current initialization142
plus20 original-pin retirement slots. First refusal returns with an inert
context (conservative160 slots through actual host return); initialized entry
and next refusal have a conservative191-slot envelope. Child-return callers
stay within73 slots, or75 including constructor output markers. Existing
COLUMN256, typed constructor253 and B2 validation252 endpoints remain bounded.
The shared publication wrapper/store yields generic DECIDE205; dedicated
JOIN_DECIDE237, SOURCE182 and same-action RESET+ACK251 are conservative maxima.
The actual host uses separate ACK dispatches and no same-action queue loop.

First-retirement capacity is84 admissions of192: each partitions64 current
payment-loop work from128 future slots. Two future shares fund each of42 named
first turns: common PROGRAM/BATCH/PHYSICAL/CREDIT/REFERENCE/SOURCE/CONTROL/
FINISH/RESET/ACK (10), JOIN_BATCH drain (at most18), three scratch records with
four stages each (12), right source (1), JOIN_DECIDE (1). Common BATCH and
ordinary DECIDE are bypassed; the reserved common-BATCH shares are unused and
forfeited with all other unused capacity. Source INIT and unary FIRST_FINISH fund their existing
primitive interiors independently; those slots are not charged twice. Before
prepayment completes no source, batch, scratch or unary output is activated;
empty cleanup after partial prepayment and every retained retry use fresh
HOST384 actions. This inventory describes admitted logical work, including
unused reservations, rather than exact executed-work telemetry.

### Controlled multi-key JOIN (#1821)

Keyed JOIN uses a private ephemeral chained hash table, preserving duplicate
multiplicity and canonical typed tuple bags. Each key name, hash key, bucket
initialization slot, insertion, left probe and candidate comparison has an
original-attempt admission. Empty-bucket misses and rejected collisions are
charged even when no output row is produced. The raw arrangement/cache and
parallel strategies remain outside this route; physical row order and memory
budget thresholds need not match them.

Exact column names take precedence. After a failed exact-name scan, the
portable `col<N>` fallback accepts ASCII whitespace before an optional sign
and decimal digits. A complete representable nonnegative value selects that
column when in range. Missing names, absent digits, negative values, trailing
ASCII junk and out-of-range representable indices use column zero. Complete
positive values above `INT_MAX` and non-ASCII bytes encountered before an
ASCII malformed suffix terminates parsing return `ENOTSUP`; exact names with those spellings remain valid. This explicit domain
avoids locale and implementation-dependent `strtol` narrowing. Positive-key
zero-width operands return `EINVAL`. Missing/forced-empty right skips key
resolution, while present empty operands still undergo key/type preflight.
FLOAT/non-FLOAT key pairs fail with `EINVAL`; different non-FLOAT types do not
match. Finite FLOAT keys share the existing signed-zero hash/equality rule.
Encountered nonfinite key bits return `EINVAL`, without a claim about global
malformed-input ordering across raw strategies.

Scratch slot0 owns the two key-index arrays, slot1 the existing type/row
staging, and slot2 the aligned heads/next image. All sizes and bucket growth
are checked; initialization advances explicitly rather than calling `calloc`.
Partial initialization needs no per-element destructor, so the existing fixed
physical/credit/reference/clear retirement stages remain sufficient. Source
readers remain held through the last value gather and append. Publication,
delta selection, HOST384 financing and separately scheduled generic cleanup
retain the cross-JOIN contract above.

The J3 source inventory bounds each parser/hash cell at112 slots and typed
match cell at120, within its128 admission. Including the separately funded
73-slot caller, new composed regions remain at most193; existing COLUMN256,
typed constructor253 and B2 validation252 remain limiting. Primitive physical,
control/ref/token exclusions remain as above. A nonempty cross JOIN now also
admits192 for selection and192 per reached left row; these are new forward
admissions rather than borrowed unused retirement shares. The three original
scratch records and84 first-retirement payments remain unchanged.

The cooperative unary admission used by FILTER/MAP requires the original
RUNNING embedded context, native thread, frame/session, pinned control and
immutable attempt ID. A standalone unary begin refuses an active operator
context. The context route shares the original admission body and does not
transfer authority through a copied context or an armed bypass flag.

`wl_columnar_relation_append_batch_mark_sorted_operator_controlled` stamps
sorted-prefix/run caches of an already sorted-and-unique, exclusively private
no-timestamp
output under its original HELD fixed-one B2 writer. Ordering and uniqueness
under scalar row comparison are caller preconditions: complete deduplication
before stamping. The helper does not scan rows to establish either property. No append may
follow the stamp. Its final control cutoff precedes callback-free cache stores;
rows, shape and generations do not change. Existing staged B2 retirement leaves
these caches intact. A failed stamp leaves them unchanged; discard the private
output when an operator fails. Its source bound requires a separately funded
caller continuation of at most 64 logical slots to the next actual poll or host
return. This preparation does not activate CONSOLIDATE
or change the default evaluator.


### Initial scalar CONSOLIDATE

`wl_columnar_filter_consolidate_attempt_start` provides an internal opt-in
sorted-distinct operation on a single original frame entry. It uses the common
FILTER step/ACK lifecycle. The default evaluator still calls raw consolidation;
NULL control delegates that same raw implementation. The containing stratum must
be nonrecursive and the session, plan, original scalar source and governor must
remain immutable and live through ACK, on one serialized native host thread.
Delta entries (including zero/one row), timestamps/weights, differential,
retraction, TDD, coordinator, shared-output and parallel contexts are rejected.

The operation pins the original scalar source, validates finite FLOAT cells and
stably sorts row indices with bottom-up merge sort. Comparisons use signed
integer lanes and numerical FLOAT order, treating signed zeros as equal. Every
comparison lane, transfer, exhausted run and duplicate candidate is paid;
all-duplicate input therefore still consumes work. Sorted-prefix and segment
hints do not replace sorting. Width zero collapses nonempty input to one tuple.

One governed scratch allocation contains the row buffer and two index arrays:
`8 * (max(width, 1) + input_rows)` bytes, with checked sizing. Local swaps move
index borrows; the context keeps the allocation base. Every supported input,
including empty/singleton input, gets a private output preserving source names,
types and graph metadata. Allocation, capacity, ownership, representative zero
bits and quota peaks can differ from raw fast paths. No allocation or speed
parity is promised. After full deduplication the original HELD B2 writer stamps
canonical sorted/unique caches; no append follows. B2 drains before scratch,
credit and source retirement; publication occurs only at the common decision.

The fixture's two-job FIFO returns through an independent witness between host
actions. Each actual start/step/ACK/retry requires a new distinct funding-control
grant before the engine action. Refusal parks the original handle. A retained
owned-input FINISH retry preserves the published output and uses fresh funding.
Fixture setup, reports and generic arbitrary-width frame destruction are external
work. This interface does not activate complete UNION queries, recursive
consolidation or default cooperative evaluation.

### Ordinary JOIN fragments in the numeric driver (#1821)

The internal numeric continuation accepts an initial nonrecursive
`VARIABLE -> JOIN/FILTER/MAP` fragment, or a prebound numeric input with a
`JOIN/FILTER/MAP` tail. The source opcode scan finishes before source
publication; the tail scan finishes before the first child. Each child uses
the original numeric record, frame, session,
native owner, operation control and saved attempt ID. JOIN rejects a different
control or successor ID before admission or mutation. The standalone NULL-owner
entry still supports its raw NULL-control route.

Generated tests cover both the JOIN prefix and complete supported single-body
operator arrays through terminal `CONSOLIDATE`, as described below. This
interface does not activate the default public evaluator or perform session
publication, stratum or recursive evaluation.
Existing JOIN shape and scalar-session restrictions still apply. A later child
failure retains the preceding committed intermediate; the fragment is not a
single rollback transaction. Protocol consumption, child retirement, ACK and
advance remain separate funded host actions.

The actual fund helper has10 logical slots after its host poll, and its caller
adds3. CHILD/ACK routing, pending stores and direct caller/engine returns give
the production driver a19-slot cleanup caller, replacing the earlier16-slot
domain. READY has19 slots after its real FORWARD poll and remains inside the
existing32-slot forward caller. The owned entry's first refusal is at most222
with that conservative32 allowance; successful initialization remains211.
New owner/control predicates precede ENTRY. They do not extend the later
COLUMN256, typed-constructor253 or B2 validation252 error-return intervals.

Replacing16 by19 once in caller-composed cleanup bounds gives FINISH252,
JOIN batch NEW241, right SOURCE169, scratch107 and JOIN_DECIDE240, all within
the256 quantum. No cleanup body, resource owner, fee or phase was added.
The 84 payments of 192 retain their 5376-current/10752-future partition: two 128
future shares for each of 42 first-retirement capacities cover even 252, and
unused shares are forfeited. Source-End and unary first-finish interiors retain
their separate original funding. A retained retry requires a new host grant.

The numeric function's pre-HOST prefix is61 slots. The test host's choice
between step and consume adds2 before that poll, so its largest whole action
is financed by63+252=315 within HOST384. The real host poll separates these
intervals; neither315 nor384 is a polling quantum. Other hosts must account for
their own routing and return work. Allocator and callback latency retain the
existing exclusions.

Integrated fixtures verify no-output collision cancellation and attempt
turnover in the first and second JOIN, independently specified first-JOIN
work limits, distinct allocation/governor/shape/output-cap failures, and real
scratch credit refusal after physical disposal. Poor host grants preserve
pending results and retained ownership. Original cleanup drains across a new
operation attempt without charging it. Chained delta/projection tests inspect
both committed JOINs before a MAP can clear their delta markers and compare
the identical fragment against raw tuple-bag results.

Generated aware-host coverage also exercises an ordinary integer FILTER. The test
requires one generated FILTER descriptor, finds the minimum configured work
limit that reaches a known-true row after predicate evaluation, and verifies the
next charged action stops with `WORK_LIMIT`. Fresh fixtures reproduce the stop;
the same operation then retries in a new generation and matches both raw output
and literal rows. This is fixture-specific boundary evidence, not a general
FILTER tariff or evidence for other types and evaluator routes.

### Complete initial scalar operator plans through CONSOLIDATE (#1821)

Both numeric opcode scans accept CONSOLIDATE, and READY calls
`wl_columnar_filter_consolidate_attempt_start_owned` directly with the original
record, frame, session, operation control and saved active ID. This route uses
all five original-owner frame getters and the common owned step/ACK lifecycle.
The standalone NULL-owner wrapper preserves raw NULL-control compatibility.
CONSOLIDATE retains its existing no-delta/no-timestamp/finite-FLOAT and initial
serial restrictions; accepting the opcode does not widen its input domain.
A failed later child preserves the preceding committed intermediate.

The parser/generator fixtures now also execute the entire original operator
array for supported single-body queries, including the terminal CONSOLIDATE.
Independent sessions with cloned sources run `col_eval_relation_plan` as the raw
reference. Literal oracles additionally require the sorted distinct results:
cross JOIN yields values `3..10`, keyed JOIN yields `4/6/8/10`, chained JOIN
yields `4/7`,
and a constant head reduces nonempty unary input to one tuple. Source/prebound,
integer/FLOAT and empty cases are covered. Direct CONSOLIDATE->MAP->CONSOLIDATE
compositions include nullary and widths 1/17/129. These are complete operator
results in a private frame; they are not published session query results.

Numeric MAP now installs a complete known result schema before its first row.
The compiled expression caches the actual result producer during its existing
second pass, preserving capped pushes, zero-filled underflow and aggregate
no-ops. Schema lookup performs no expression evaluation, instruction scan or
extension callback. Plain variables/projections preserve source physical types
(and out-of-range zero-fill remains INT64); explicit FLOAT operations produce
FLOAT, comparisons/BOOL produce BOOL and integer arithmetic produces INT64.
The private raw FLOAT-variable decoder also retains the VAR-only exported
parser used by the integer FILTER shortcut.

Raw MAP reserves its temporary native type vector in the existing scratch
admission, keeps full governed row-capacity admission before callbacks, and
uses the existing metadata setter only on the empty private output. A raw
unclassified interpreter expression lane retains the legacy untyped schema for
the whole output. Existing fixed-result scalar builtins use a pure complete-
buffer/depth/final-producer check with constant scratch; they preserve complete
result metadata without execution, crypto, interning or callbacks during schema
resolution. Runtime value validation and evaluation errors remain separate.
Opaque mixed numeric/addon fallback results are not covered by
the numeric FLOAT ordering guarantee. The temporary vector is freed before
row evaluation. Pool/arena output ownership remains available without a
governor.

Controlled MAP admits scratch and its program table before constructing the
output. The existing output-values region temporarily stores int64 type codes;
the capacity-preserving operator constructor validates each code before
conversion and copies native metadata into the owned relation. No enum pointer
aliases the int64 scratch and no recipe pointer escapes. Every other recipe
initializes the new optional code pointer to NULL. The constructor-source
recipe grows by one pointer; no live MAP context owner is added. Native typed
constructor callers retain their original capacity and call depth.

The 36 B2 retirement payments remain immediately after program-table
preparation, before type resolution/output construction. Later failures can
leave these admitted grants unused; they do not claim executed-work telemetry.
Output retirement is paid before publication, and the frame slot is captured
before original-ID arbitration. Compilation/table errors therefore precede
output-constructor errors in this controlled path; simultaneous-failure tests
assert that the later constructor is not entered. Raw initialization order
continues to admit its output before compilation. New raw compiled FLOAT
owners and type metadata can introduce ordinary allocation/admission errors
before row evaluation, including zero-row results.

Complete generated unary and keyed-JOIN bodies now verify negative FLOAT
ordering, duplicate negatives, canonical zero and empty schemas, including
mixed integer/FLOAT outputs and MAP->FILTER->MAP composition. Typed append
rejects a copied NaN/Inf FLOAT lane with EINVAL; an expression reading an
invalid FLOAT still gives MAP ERANGE. A genuinely omitted invalid source lane
is not scanned or rejected. These private results remain separate from
public/default activation and the remaining operator/configuration inventory.

The fourth READY switch case preserves the 19-slot production caller; no new
loop, child-consumption action or cleanup phase is added. The two opcode scans
add one constant predicate per visited opcode. The source scan finishes before
source publication; the tail scan finishes before the first child.
Owned CONSOLIDATE's conservative entry-refusal ceiling is `209 - 8 + 19 = 220` within
quantum 256. Its final sorted-stamp continuation is `38 + 19 = 57` within the helper's
64-slot caller allowance. The new identity/control checks precede ENTRY and do
not extend the existing COLUMN 256, constructor 253 or B2 validation 252 tails.
Common owned cleanup retains FINISH 252. The actual FIFO driver remains unchanged:
its pre-HOST prefix 63 plus 252 is financed within HOST 384 across the real host
poll. HOST 384 remains distinct from the 256 polling quantum and is not a latency
bound.

CONSOLIDATE uses its own 53 admissions of 192: 10 common lifecycle, 7 named owner
supplements and 36 B2 payments, partitioned into 3392 current and 6784 future work.
These are not the ordinary JOIN's 84 payments. SCRATCH_SIZE reserves 64 for a
refused first B2 prepayment; original source-End and unary first-FINISH interiors
retain their own original funding. Partial common prepayment can leave only
fixed context/control activation: its bounded unpaid no-child bootstrap exception
remains explicit. A retained retry always needs fresh host funding; old future
shares are never reused and the successor operation is not cleanup funding.
Allocator, reference, callback and generic arbitrary-width disposal exclusions
remain those of the existing source model.

Integrated fixtures interrupt real finite scan, compare, index/merge/pass and
duplicate-rejection work, including generated JOIN results with 57 identical
intermediate tuples. They retain the exact preceding owned result, distinguish
work/cancel/stale-attempt/allocation/quota/unsupported-shape outcomes, and verify
literal admission boundaries. Real scratch-credit refusal occurs after physical
disposal while original credit/reference/source ownership remains reachable;
peer credit survives. HOST 383 refuses pending consumption/retry, while 384 pays
one action. An external reader can retain an owned-input FINISH after committed
sorted output. Cleanup across operation turnover leaves successor consumption 0;
a fresh record on the same stable source then produces the canonical result.

The remaining activation boundary is explicit:

| Operator/dispatch family | Controlled status in this interface |
|---|---|
| Initial VARIABLE, numeric FILTER/MAP, ordinary scalar JOIN | Supported in the documented source/prebound domain |
| Initial scalar CONSOLIDATE | Supported as a child, including terminal and repeated composition |
| Initial scalar SEMIJOIN/ANTIJOIN | Supported in the named existing-right scalar domain, including numeric composition |
| Initial scalar REDUCE | Supported in the documented scalar numeric child domain |
| Initial scalar CONCAT/UNION | Supported as a two-input child and complete private composed numeric body through terminal CONSOLIDATE |
| Generated LFTJ | Supported through real default serial session composition with at most 64 input relations (not a total output-column cap); source discovery, descriptor/storage-reader admission, merge-sort, traversal, and output-cell actions are bounded. Before governor admission or allocating its private output row and copied input/scratch arrays, a resumable tariff charges one unit per scalar slot plus eight per allocation action in chunks of at most 256; a one-unit-short limit allocates none, and empty inputs allocate no row/scratch arrays. Contended reader admission resumes with the same input cursor and retires partial descriptor pins on cancellation. Reservation receipts are prepared before credit return, and successful writer-finalization refusals retry without changing semantic success. The tariff is logical, not an allocator latency bound. Writer, descriptor and scalar retirement and chunked ACK are bounded on the controlled session path; stack publication/disposal have separately bounded caller actions. Only the named allocator, Arrow and library interiors retain synchronous boundaries; their call fronts and first native iterations are included in the [source map](implementation/2298/LFTJ_SOURCE_ACCOUNTING.md). |
| LFTJ fallbacks/fused alternatives | Further implementation and path-specific qualification required |
| Differential/weighted, recursive, batch/pipeline/TDD/parallel dispatch | Further implementation and path-specific qualification required |
| Known numeric/projection MAP result schemas and FLOAT ordering/deduplication | Supported in the documented scalar domain; raw interpreter-only mixed schemas remain legacy/untyped |
| Public/default admission, production scheduling and session publication | Further bounded dispatch/publication and complete reachable-path audit required |

Unsupported opcodes fail the complete preflight before source publication or the
first child; supported opcodes with unsupported input shapes fail at that child.
There is no controlled-to-raw fallback. This increment does not complete #1821.


### Generated integer MAP work-limit boundary

The aware-host generated-operator integration fixture runs the generated
`output(x+1) :- input(x)` integer MAP over 4096 rows. Its phase-109 checkpoint
counts rows after expression evaluation and value staging. Fresh sessions find
the first configured operation allowance that reaches the 1024th row; the immediately
lower allowance and that boundary both stop with `WORK_LIMIT`, publish no
output, preserve the input relation and bytes, and drain reservations and
cleanup. Repeating the boundary gives the same checkpoint count. A new attempt
generation on the same operation then completes all rows and matches raw
execution and literal `2..4097` output. This is evidence for this generated
integer MAP and host route only; it does not establish a general work tariff or
coverage of other MAP expressions and entry paths.

### Initial scalar existence-join component

The private `wl_columnar_join_probe_op_attempt_start[_owned]` component adds
bounded SEMIJOIN and ANTIJOIN using the original unary replacement, two held
scalar sources, three JOIN scratch records and B2 batch/drain. It creates no
new live context owner or binary transaction. The ordinary JOIN entry and its
delta selection/output-limit policy remain separate. Both numeric preflights
admit these opcodes, and READY dispatch directly invokes the original owned
probe entry; pending consumption, one-step retirement and ACK keep the same
record/frame/control. Public/default dispatch remains outside this interface.

A named full right registry relation is required. A missing right returns
ENOTSUP with the original left entry uncommitted; this explicitly differs from
raw SEMI/ANTI's missing-right repush. An existing empty right is supported:
SEMI returns empty and ANTI returns all left rows. No right-delta selection,
JOIN output limit/peak update, right filter, materialized, differential,
retraction, TDD, batch, parallel or coordinator execution is enabled. Sources
must be ordinary scalar/noTS; compound and timestamped inputs are refused.

SEMI copies at most one left row after its first key match, with only left
projection lanes and canonical colN names/selected physical types (INT64 for
untyped or out-of-range zero-fill). ANTI copies one complete left row only
after its collision chain has no match, preserving left names, native type
presence and graph/declaration metadata. Zero keys test whether the right has
any row. Both results are non-delta and discard input segment boundaries.

Each registry/name byte, key comparison, right hash build/link, collision
candidate, selected lane and append has original-ID admission/checkpoints.
Rejected candidates are charged even when the result is empty. Existing84
JOIN lifecycle payments are retained for these same discoverable source,
scratch, batch, output, control and unary owners; unused named shares are
admitted slack, not executed-work telemetry. Physical scratch retires before
its original credit/reference; refusal retains those markers, and each retry
requires fresh distinct HOST funding. No successor allowance funds retirement.

The controlled route deliberately materializes valid scalar probe results.
Raw keep-all may retain relation identity/name, allocation provenance and sort
caches; these are not promised identical. Logical names/types/graph/tuples,
non-delta publication and later operators are the compatibility boundary.
Additional materialization can fail admission where raw passthrough succeeds,
and copied invalid FLOAT payloads retain typed append validation rather than
inherit an invalid-input passthrough promise. Missing-right and unsupported
shapes never silently execute raw under a nonNULL control.

Integrated tests execute complete preserved lowered bodies, through terminal
CONSOLIDATE, from actual SIP-created SEMIJOIN and parsed negation ANTIJOIN.
Literal sorted FLOAT results and independent raw cloned sessions cover source
and prebound input, empty operands, duplicates, multi-key negation and enforcing
governors. Explicit MAP -> probe -> probe -> MAP -> CONSOLIDATE compositions
cover all four probe combinations. Stops and allocation/quota/unsupported
failures at either probe retain the exact preceding owned result and prevent
later children from starting. Retained scratch credit uses real pending/child
HOST383/384 retries; operation turnover consumes no successor allowance, and
a fresh original record on the same stable source recovers canonical results.

The serial LFTJ session contract, optional-cache bounded rebuild, finite
no-output traversal, aggregate/deletion and committed-delivery evidence are
recorded in [LFTJ acceptance](implementation/2298/LFTJ_ACCEPTANCE.md).

### Initial numeric REDUCE ownership

The opt-in REDUCE child uses the existing original FILTER context without
adding a live owner or changing its layout. Scratch0 contains open-addressed
hash slots; scratch1 contains dense first-seen records with a representative
source row and aggregate state; scratch2 contains INT64 type codes, one output
row and, only for a numeric expression, one input row. Checked size arithmetic
precedes admission. Each slot initialization, hash/key comparison, accumulator
update and emitted lane receives admission and an original-attempt cutoff.
COUNT does not allocate or evaluate an unused numeric expression program.

All fixed lifecycle capacity is admitted before unary/source/scratch ownership.
The child uses the existing 84 payments of192 with64 current and128 future
shares, covering the common ten lifecycle turns, B2's eighteen turns, twelve
scratch turns, inactive right-source turn and original decision turn. PROGRAM
can now retire the genuine numeric expression owner; that owner's primitive
retirement interiors retain their own original prepaid contract. The inactive
right-source and bypassed ordinary-BATCH capacity is neither refunded nor
reused as forward work. Partial prepayment refusal owns only the fixed
context/control activation and follows the existing bounded bootstrap unwind.

The existing protected-source, typed-code constructor, numeric expression and
B2 helpers retain their own admission/retirement protocols. Each caller pays
for its new direct call and validates the original saved attempt on return.
Scratch physical disposal precedes credit release, saved reference release and
record clearing. Program retirement follows all three scratch records, then
source End and the original unary decision. A refusal retains the original
record and requires a fresh separately funded host retry; no successor control
pays for old cleanup. Admitted controlled serial composition dispatches REDUCE
through its original owned child, including a genuine composed aggregate after
LFTJ when JOIN batch mode is configured. This exception requires the canonical
frame/current thread, session/control/saved ID, admitted composed fallback bit,
busy PENDING-from-READY state, exact current REDUCE pointer and child status;
it is rechecked after the real phase1 Original check. Standalone and
noncomposed controlled primitives retain their batch-mode ENOTSUP. Raw
uncontrolled REDUCE is unchanged. The initial real Original zero separates
stack/owner validation from repeated context validation without changing the
first192 refusal status or any positive tariff. Complete changed source
intervals are recorded in
[the LFTJ source map](implementation/2298/LFTJ_SOURCE_ACCOUNTING.md).

REDUCE pays128 per scalar cell and192 for the existing-group numeric update,
whose FLOAT comparison/arithmetic dispatch is larger than an ordinary key
cell. The direct fixture child-return action defers phase/status consumption
to a later separately funded action; ACK also has its own action. FIFO and
caller continuations remain part of the complete source inventory.

The REDUCE fixture uses the existing `host_turn` and real engine/witness job
callbacks. One callback performs one funded child or result-consume action and
returns through that host turn; ordinary callback requeue/protocol and host
return work is included in the caller envelope. The next queue-pop prefix is
part of a new external host turn. Child START/STEP/ACK selection uses compatible
readonly callbacks selected before HOST admission, with no cast or owner
transfer. Exact work-limit fixtures pin ENTRY191/192; deeper hash/update/emit
stops use deterministic cancellation, not an unimplemented deep budget matrix.

The numeric driver directly dispatches REDUCE through the same genuine owner
record used by the other numeric children. Its PENDING result is consumed on
a later separately funded turn; cleanup, retained retry and ACK retain their
original action boundaries. Source-bound plans keep the complete preserved
VARIABLE-through-CONSOLIDATE body. Prebound plans start after VARIABLE, without
forging an entry, owner or phase. REDUCE adds no numeric record field or new
cleanup capacity. Full generated/composed tests compare literal typed results
and independently cloned raw execution; raw empty CONS run-cache conventions
are not imported into controlled empty results.

### Generated COUNT REDUCE work-limit boundary

The generated aware-host fixture runs a one-group integer `COUNT` REDUCE over
4096 ordered rows. Its phase-36 checkpoint reports the zero-based row being
entered before that row contributes to the count. A high-limit run completes
all rows; fresh sessions then find the first operation allowance to reach row
1023. The preceding allowance stops before that checkpoint, while the boundary
and repeated-boundary runs reach it and stop with `WORK_LIMIT`. Both leave the
output unpublished, preserve the input registry and row bytes, and drain
reservations and cleanup. The completed reports repeat the same admitted-work
total for this fixture; that total is not a phase-local tariff. A fresh attempt
generation on the same operation then publishes `COUNT=4096` and agrees with
raw execution. This evidence covers only the generated one-group integer COUNT
path through the aware host; it does not define grouped, other aggregate, FLOAT
or other-route allowances.

### Private controlled CONCAT ownership

CONCAT adds a dedicated frame-embedded continuation with two original scalar
source records, a private B2 writer/drain and one row workspace. The actual
frame `sizeof` controls admission and paid16-byte zeroing; this changes frame
size and does not introduce a fixed ABI-size promise. The workspace reserves
`max(width,1)*sizeof(int64_t)` against the selected governor; it retires physical
storage before its own credit and governor reference, before publication. Both
source ends and writer drain precede binary decision/input destruction. Candidate
and both retired entries remain owned by the binary transaction.

Eight192 payments split128 current/64 future before binary activation reserve
separate256 first capacities for the BINARY parent and ACK/reset. Another100
payments of192 reserve25 first capacities: B2 drain18, source ends2, workspace
physical/credit/reference/clear4, and DECIDE1. If no resource was initialized,
including a partial payment prefix, start returns directly to BINARY and skips
unpaid empty stages. The binary
transaction's five capacities remain separate. Every host retry/action has new
independent funding; no stopped/successor operation is debited for retirement.
The primitive allocator/control/ref and physical arbitrary-width relation
destruction exclusions retain the existing cooperative scope. This child
implements no default/session publication or full #1821 activation.


### Private complete UNION composition

The composed numeric record retains its original address/control pin through
its separate DONE/ACK. Its appended depth/mode fields use actual `sizeof`;
the cleanup frame does not gain another resource context in this step. Eight
192 payments (128 current/64 future) precede the record pin, reserving distinct
256 first capacities for pin retirement and record reset/ACK. A later private
empty-source candidate prepays another four192 payments for its own first256
retirement capacity before exposing its result slot. Partial prefixes expose no
candidate; retries never renew a first capacity. The actual-width physical
relation destructor and existing allocator/control/reference primitive exclusions
retain their documented cooperative scope.

Each composed action admits parent HOST384. A nested CONCAT binary finish/ACK
also admits B384 and A384, for a maximum1152 from the same fresh independent
funding attempt; other CONCAT actions use768. Source-candidate abort has its own
384 admission after read-only validation, for768 with its parent. Consume/status
and record ACK use384. These are financing sums, not a larger polling quantum.
A parent383 refusal leaves all parent mutable state unchanged; a deeper refusal
may consume already admitted parent work and leave PENDING, consumed on a new
host action without semantic/depth/completion promotion. No live-budget peek,
refund, successor debit or transferable reservation is used.

The original complete parsed two/three-rule UNION bodies, nested three-entry
CONCATs and repeated CONSOLIDATE are exercised, with literal sorted typed sets
and independently cloned raw full-body execution. Empty branches, FLOAT signed
zeros, widths0/1/17/129, branch MAP/FILTER/JOIN/probes/REDUCE, grammar failures,
later source/candidate/CONCAT failures, reader retention, native/LIFO/identity
checks, literal entry/HOST boundaries and genuine stable-registry retries are
separate witnesses. Controlled empty CONS cache remains zero-runs even where raw
empty CONS keeps a one-run cache. This private route does not complete #1821's
public/default and optional/recursive evaluation coverage.

The composed HOST grant is fresh and exclusively owned by the complete host
action: its control pointer, active generation and lifetime cannot finish,
reset, begin or transfer during that action. Cancellation may latch normally.
The dedicated composed funding helper validates its ID before directly charging;
this leaves the actual live host return suffix within the existing unary child
caller allowance. Original operation identity is separate and keeps all saved-ID
checks, including turnover. The legacy numeric funding helper is unchanged.

The private fresh-head result bridge embeds its original parent, composed child,
scalar reader, B2/drain and workspace owner in the cleanup frame. Frame admission
and full zeroing use the actual `sizeof` of that enlarged frame; no partial frame
is published. The named candidate has independent heap storage and governor
credit. Physical workspace disposal precedes credit refund and reference release.
A retained reader leaves the original entry or candidate reachable in the active
frame. Stack-slot disposal and later inert-slot proof have separate first-work
capacities, and a separate close-proof action precedes final parent ACK plus
mandatory empty-frame close. Materialization ends with a READY candidate before
the optional registry publication described below. The final frame-credit
invariant also applies to that publication path.

Private fresh-head publication separately owns four offside physical allocations
(registry, expected-content snapshot, hash heads and chains) and three RESERVED
credits. Admission outputs are consumed only after rc0; a nonzero controlled
reserve has already restored its prior token. Physical storage retires before
its credit. Four original-address moves transfer old credits into a journal and
new credits into the session; pre-cutoff failures reverse the completed prefix.
The candidate payload stays COMMITTED at its descriptor. Old arrays/credits
retire only after real child ACK. Original session token histories are limited
to canonical EMPTY/positive RESERVED, plus untouched noGov all-zero tokens;
RELEASED histories and governed all-zero destinations return ENOTSUP before new
publication owners. No token bytes are copied or reset to manufacture a refund.

The aware framed entry prepays a distinct first known-empty close before fresh
frame allocation. Failed parent bootstrap physically closes that newly created
inert frame before returning its bootstrap receipt. It never adopts a foreign
frame or retains a phantom failed-bootstrap owner. A successful original parent
keeps its own independent final-close capacity. The host request and reply are
external borrowed call objects and are never retained as cleanup authority.

The generated-aware JOIN coverage now runs the actual parsed and lowered
ordinary JOIN body, including its pushed-down numeric right predicate, through
the terminal CONSOLIDATE and publication callback. The product fixture uses 64
left rows and 513 right rows, of which 257 pass; the keyed fixture uses those
same physical right rows and creates 16,448 unequal candidate comparisons in a
single bucket while producing an empty result. Both fixtures assert the
generated JOIN descriptor's nonempty predicate bytes before execution. They
compare committed metadata and rows against a separately parsed raw session
and literal geometry.

The same full aware route exercises an original-operation work limit at a
source-derived 57,472-unit local boundary from the measured final right-hash
insertion through keyed candidate 128. The source charges 576 units to reach
candidate 1, then 448 for each next candidate (parent WORK, match key CELL,
phase17 CELL). One unit less reaches only 127 candidate comparisons; the exact amount
reaches candidate 128 before deterministic cancellation. It also exercises
cancellation during pair/candidate progress. It
confirms the old registry,
source descriptors and governed reservation baseline survive cleanup, then
finishes the reported stopped generation and retries with a fresh original
generation. The keyed total-reservation `T` versus `T-1` check is a measured
single-worker acceptance allowance; it does not define a source tariff or the
256-unit source quantum. HOST384 remains separate financing for each real
callback. These tests cover this generated ordinary right-filter route only.
Bounded default serial preflight for supported nonrecursive STEP plans is
described in `docs/SEMANTICS.md`; recursive, differential, weighted,
TDD/parallel, remaining LFTJ fallback/fused paths, K-fusion, and controlled
SNAPSHOT coverage remain open.

The generated product route also pins an empirical original-work boundary at
pair 128. An unlimited attempt is cancelled at that JOIN checkpoint; its
reported consumed work supplies the fixture-specific allowance. One unit less
stops before checkpoint 128 after 127 pair callbacks, while the exact
allowance reaches checkpoint 128 and deterministic cancellation. Output-cell
and B2 append charges vary between pairs, so this is not a universal product
tariff or a substitute for the keyed source-derived boundary above.

### Immutable spill segment foundation (#1372, partial)

`columnar/spill.h` provides an **internal, explicitly opened** store. Opening
requires an existing caller-controlled directory, the shared governor, a disk
quota, and a maximum encoded row size. No environment variable or public
session option enables spill yet, and existing evaluators do not use this
store automatically.

A private writer streams one row at a time into an exclusively created file.
Only a complete write publishes a segment. The process-local versioned format
encodes fields in little-endian order: scalar schema, row count, lane bits,
iteration/stratum/worker timestamps, and signed multiplicity. There is no
restart/import API or durability guarantee. Scalar INT32/INT64/UINT32/UINT64,
FLOAT and BOOL schemas have identical logical and physical columns; the caller
supplies valid self-contained lanes. STRING, compound schemas, intern IDs and
pointers are unsupported. An integer type is not permission to encode a borrowed
reference. The explicit STRING-capable entry points described below add intern
table pins; compound references still require a separate lifetime design.

Readers acquire separate handles and one-row buffers. Stable segment-relative
ordinals support sequential range iteration and individual row lookup without
mapping or loading the whole file. Each read verifies file length and the
versioned schema/header, then returns one complete row or an explicit failure.
Failed reads expose no partial row. This detects truncation and invalid metadata;
it is not a checksum or authenticated integrity format for arbitrary bit damage.
The returned row is borrowed until the same reader's next read or release.

All store/segment/reader lifecycle operations require external serialization.
Independent acquired readers may read concurrently; one reader cannot have
concurrent reads or be released during its read. Segment release returns BUSY
without changing ownership while any reader exists, and store close similarly
refuses while segments exist. The caller must release readers, then segments,
then the store; failed close/release is not implicit cancellation. Cancellation
callbacks must not reenter the store/segment. Each I/O chunk checks cancellation,
short transfers make finite progress, and interrupted I/O retries have a fixed
limit. OS I/O can still block; this primitive does not promise a syscall deadline.

`wl_columnar_spill_floor` reports managed allocation sizes. The construction
floor is `store_bytes + segment_bytes + writer_bytes`; concurrent reading needs
`store_bytes + segment_bytes + N * reader_bytes`. Each writer/reader has one
encoded row of scratch; the writer also owns a temporary pathname. Every owned
allocation (descriptor, schema, path and scratch) is admitted before allocation,
and refunded after freeing. The governor reference remains alive through store
close. Caller input/output, the governor object, allocator overhead, file
handles and OS page cache are additional resident costs; this is not an RSS
ceiling or proof that an existing input relation was reclaimed.

Quota includes headers, schema and row records and is reserved before writing.
Failure or cancellation refunds the quota and destroys the unpublished handle.
Free-space checks run before and during writes but are only observations: actual
short writes, ENOSPC, read errors and zero-progress I/O remain authoritative.
Managed-memory denial, allocation failure, quota, physical capacity, I/O,
cancellation, invalid arguments, unsupported types and arithmetic overflow have
distinct internal status values.

POSIX files use exclusive `mkstemp` creation and immediate unlink; the descriptor
owns the remaining lifetime. Windows uses exclusive creation and
`FILE_FLAG_DELETE_ON_CLOSE`. Cleanup targets only the exact owned artifact and
never scans for guessed process names. Platform-specific execution evidence is
required before claiming platform qualification.

`spill_segments` checks exact numeric/boolean rows and signed provenance,
independent readers, ordinal boundaries, a roughly 480 KB segment under a
managed allocation allowance below 4 KB, explicit floor failure, short I/O,
interruption, zero progress, partial-write failure, cancellation, truncation,
header corruption, and allocation/refcount cleanup. This is storage-primitive
coverage, not mixed resident/spilled evaluation.

Internal session options v4 now accept `spill_directory`, `spill_quota_bytes`,
and `spill_max_row_bytes`. Defaults disable spill; v2/v3 callers remain accepted
and disabled. The coordinator copies the directory and opens one store against
its existing governor. Workers borrow that same store and quota; they never
retire it, including failed creation and reuse. Shared access still requires
external lifecycle serialization, not concurrent worker creation/release.

After draining worker activity, session destruction retires store ownership.
Retirement closes admission to new segments/readers (`CLOSED`). An empty store
is freed immediately and its owner pointer becomes invalid. Existing numeric
segments retain the store and its governor; existing readers can finish reading
after the session is gone. Callers must release each reader and then each
segment. The last segment frees the retired store, after refunding its own
allocation. A borrowed store pointer remains usable only while a live segment
keeps it alive, for byte inspection or a rejected create; it must not be closed
or retired again. This does not retain callback contexts or session intern and
compound state. Standalone checked close retains its original BUSY contract.

`session_spill` checks disabled defaults, late creation failure cleanup, copied
configuration, shared-governor accounting, worker failure/reuse, empty-store
teardown, and multiple readers/segments surviving coordinator destruction with
complete final refunds. `session_options` covers bounded v2/v3 prefix reads,
invalid configurations and unsupported legacy backend rejection.

At this foundation stage, remaining work included the public opt-in API (now
available for the numeric subset below); intern/compound lifetime
pins; queue scheduling/integration for #1373; direct-column and
arrangement/index consumer audits; supported relation/trace transitions; actual
mixed resident/cold indexed execution under pressure. Retained index chains,
session state and unavoidable scratch must be included in that execution's
resident floor. This foundation does not close #1372 or qualify bounded DOOP
(#1385), and it does not make unsupported materializing paths bounded.


### Owned numeric batch payloads (#1372, partial)

`columnar/batch_payload.h` captures the first N rows of a scalar relation as an
immutable owned resident or spilled payload. Callers explicitly choose storage;
this does not activate automatic eviction. Capture holds the relation source
reader (descriptor and canonical owner) through schema validation and copying.
It retains no relation, session, callback or producer scratch pointers. Missing
physical types mean INT64; missing timestamps mean iteration/stratum/worker zero
and multiplicity +1. Numeric lane bits, types and signed metadata are preserved.
STRING, compounds, graph layouts and nullary relations are rejected. Encoding an
intern ID or pointer as an integer does not make it a supported numeric value.

Both modes expose schema, row count and stable ordinal reads. Readers pin their
payload; release returns BUSY while a reader exists. Lifecycle operations remain
externally serialized; independent acquired readers may read concurrently.
Retiring a session store leaves already acquired spilled readers valid, but new
spilled reader acquisition returns CLOSED. Resident readers remain acquirable.
Caller-owned handles must be released explicitly. The final payload owns enough
governor lifetime to refund every allocation after its storage is freed.

`wl_columnar_batch_payload_floor` reports the payload descriptor, copied schema,
resident rows (when selected), and reader descriptor. Spilled capture additionally
requires the store and spill segment/writer floor; acquired spilled readers add
the spill reader floor. The source relation, sink context and stack, governor,
allocator overhead and OS resources remain additional costs. Retaining many
small spilled batches still retains one metadata descriptor per batch. Spilled
capture rejects a store governed by a different admission governor.

`wl_columnar_join_batch_payload_sink_init` connects the existing relation-backed
continuation contract to this representation. Reserve privately captures the
batch; commit publishes one owned payload, and take transfers ownership. Abort
releases only the private stage. An untaken committed payload rejects another
publication without cursor advancement; cleanup releases untaken output. Detailed
spill status remains available in the sink context even when the continuation
returns a broader publication error. Existing FILTER/MAP and relation sinks keep
their relation-backed payload convention.

The real JOIN producer test alternates resident and spilled captures, retains
old results while scratch is reused, destroys the producer and its fixture, and
then checks each output row exactly once. It covers abort/retry, ambiguous commit,
blocked overwrite and untaken-output cleanup. Payload tests cover numeric bits,
signed metadata, partial cancellation, quota and allocation/admission failure,
reader pins, concurrent reads during retirement, and session teardown. This is
mixed batch storage evidence, not full mixed relation/index evaluation or a
working-set pressure completion claim. Compound-reference pins, automatic policy,
broader relation/index consumers remain outstanding. Public configuration for
the later numeric evaluator subset is described below.

### Reclaiming owned resident batches (#1372, partial)

`wl_columnar_batch_payload_spill` takes an exclusive owner pointer and streams
an already-owned resident numeric payload into the same governor's spill store.
Success replaces the owner and frees its old resident allocation. Schema, lane
bits, signed metadata and row ordinals are unchanged, but old owner/schema
pointers become invalid. Active readers return BUSY; already-spilled payloads
and mismatched governors return INVALID. Lifecycle operations remain externally
serialized, and cancellation callbacks must not reenter them.

The old payload stays live until the complete private segment is published.
Quota, admission, allocation, I/O, cancellation and closed-store errors preserve
the original owner and contents and release the private replacement. A retired
store pointer may only be used while a surviving segment keeps it alive.

Transition peak managed memory is the existing resident payload plus
`batch_payload_floor(..., SPILLED)`'s descriptor/schema and `spill_floor`'s
segment and writer allocations, including one-row and path scratch. Existing
store, source/index state, other payloads and readers remain additional costs.
Callers must leave this transition slack available; demotion cannot rescue an
already exhausted budget without it. Small or empty payloads may cost more
metadata after demotion. Reading adds the payload and spill reader floors.

The real JOIN regression admits source relations, arrangements, producer state
and owned outputs through a fixed 256 KiB governor. Keeping all outputs resident
is denied without cursor advancement. Demoting each completed 256-row batch
allows all 16,384 rows (512 KiB of lanes) to remain available and be checked after
producer teardown. The hand-built session shell, delta pool, governor object,
test stack, allocator overhead and OS file cache are outside this managed
measurement. This proves bounded batch reclamation, not whole-process RSS or
cold relation/index execution. A separate boundary test denies a transition
one byte below its calculated floor and succeeds exactly at the floor.
Automatic scheduling, compound-reference lifetimes and remaining #1372/#1385
acceptance criteria are still outstanding. Public configuration for the later
numeric evaluator subset is described below.


### Reference-safe STRING batches (#1372, partial)

The explicit `wl_columnar_batch_payload_capture_with_intern` and
`wl_columnar_spill_create_with_intern` entry points additionally accept STRING
columns. The caller supplies the originating intern table for every STRING ID;
matching integer IDs in an unrelated table do not establish provenance. The
table must already be attached to the same governor. Logical STRING types are
stored unchanged, and every ID must resolve before publication. Numeric-only
entry points continue to reject STRING. Compound and graph layouts remain
unsupported; integer lanes must not disguise reference-bearing values.

`wl_intern_pin_acquire` validates admission under the intern mutex. A pin prevents
table destruction and governor detach/rebind; it does not freeze append-only
intern growth or add locking to ordinary reverse lookup. `wl_intern_free`
relinquishes the original owner and closes new pin admission. Existing pins keep
strings and their stable addresses alive until the final release. Every user
must hold either the original owner or a pin throughout its access. Owner
retirement may overlap independently pinned reads; a pin's release must not
race reads using that pin. The final destruction frees storage before refunding
its governor reservation.

Resident STRING payloads own a pin; spilled payloads rely on their segment's
pin. Readers retain their payload/segment and resolve IDs with
`wl_columnar_batch_payload_resolve_string` or `wl_columnar_spill_resolve_string`.
The returned string is borrowed through reader release, including after the
program and session have been destroyed. Store retirement still rejects new
spilled readers. Intern owner retirement rejects new STRING capture/demotion
with CLOSED when a new pin is needed; an unsuccessful demotion leaves the
resident payload and its existing pin unchanged. Initial acquisition must not
race original-owner destruction. Callbacks must not reenter lifecycle operations
or destroy their source intern owner.

`wl_columnar_join_batch_payload_sink_init_with_intern` opts a real JOIN sink into
this contract. The producing table is borrowed during synchronous publication;
taken outputs independently retain their pins. The real JOIN test mixes
resident capture, direct spill and demotion, destroys its producer and program,
and resolves every retained row. Another test destroys an actual spill-enabled
session and program before reading. Tests cover partial I/O and allocation
failures, every cancellation point, invalid IDs, repeated/empty/long/UTF-8
strings, signed metadata, concurrent readers, owner retirement and final refunds.

Pinned slots, reverse-map segments and string bytes remain charged to the
original governor, even after its program owner is gone. They remain resident
and can exceed a requested working-set budget. Existing intern accounting does
not include the table descriptor (`sizeof(wl_intern)`); that descriptor,
allocator overhead and OS resources are additional resident costs. Pin counters
are embedded, and the payload/segment floor includes its new intern pointer;
no separately allocated pin metadata is omitted. This does not serialize string
bytes into a portable or cross-process spill format. Compound lifetimes, cold
relation/index execution beyond the later numeric subset and scheduling remain
outstanding; #1372 and #1385 are not complete.


### Compound arena retirement for detached consumers (#1372)

Session compound arenas now use `wl_arena_compound_arena_create_managed_ref`.
Their separately allocated admission context retains the governor and is charged
alongside the arena descriptor and generation table. The raw-governor constructor
keeps its existing accounting and requires caller-owned governor lifetime.
Generation payload/index reservations remain charged until final arena cleanup;
existing separately allocated reservation-token overhead is not newly included
in that accounting. This change does not make those resident bytes spillable.

Session destruction retires the unique arena owner after worker drain. Existing
stable GC holds and read borrows keep the arena and its governor alive; ordinary
new holds/mutations/borrows are closed. A live hold can acquire a short detached
borrow, and that borrow can survive release of its originating hold. The final
lease frees arena storage, refunds reservations, and releases the governor.
`free_checked` retains its refusal contract while holds or borrows exist.

Compound payload capture/spill still rejects compound layouts. Retaining arena
bytes does not retain nested intern references or establish logical layout and
provenance. Those contracts, broader cold indexed readers and scheduler
integration remain follow-up work; #1372 is not complete.


### Flat INLINE compound spill with explicit provenance (#1372)

`wl_columnar_batch_payload_capture_with_inline` accepts originating
`wirelog_column_t` declarations and their intern table. The source relation must
have reliable physical column types and matching INLINE arity map, compound
count and first offset. Declarations distinguish unary compounds from scalars
and expose SIDE columns hidden by an aggregate INLINE summary. Scalar types,
physical offsets, total widths and the supported arity bound are checked.

This is an explicit trusted producer capability: declarations and table must
originate from the source, and expanded arguments must be flat self-contained
scalars. Neither `wirelog_column_t` nor integer lane bits can prove that an
arbitrary value is not a nested handle. Observable SIDE and graph layouts are
rejected; nested references are outside the capability. The older numeric and
STRING capture entry points continue rejecting compound layouts.

Payloads own immutable copies of kind, type, functor ID, arity and physical
offset. Column names are excluded (`name == NULL`), as with the existing scalar
payload schema contract. Physical types remain separately accessible. The
INLINE spill format records those five fields explicitly as 20-byte records,
with a logical count and version marker; no pointers or struct padding are
written. Every read checks the persisted schema against the retained descriptors.
Verification streams one record through the already-admitted row scratch
(minimum 32 bytes), even when the full logical schema exceeds that scratch.

The `_floor_with_inline` helpers include copied logical descriptors. Spill quota
includes the logical count and encoded descriptors; creation and demotion check
that quota before publication. Both the payload and its segment retain their
own charged schema copies in spilled mode. Per-reader and writer scratch depend
on physical row width, not row count or total encoded schema size. The full
intern table remains a separately admitted resident floor and is pinned for
functor IDs even when all argument lanes are numeric. Source relations,
declaration arrays, column names, sessions and programs are not retained.

Resident capture, direct spill and transactional demotion preserve the same
semantic descriptors, lane bits and signed timestamp metadata. Demotion needs
a new intern pin and therefore returns CLOSED after the intern owner retires,
leaving the original resident payload unchanged. Already acquired readers can
resolve functors and STRING arguments after source/session/program teardown.
The explicit INLINE initializer on the existing transactional payload sink
borrows its configuration only during synchronous publication; it does not
infer JOIN output declarations or change the global batch payload convention.

The integration test evaluates a parsed program with typed INLINE input,
explicitly binds its parsed logical declaration through the existing relation
layout API, and publishes it through the transactional sink in resident, spilled and
demoted forms, then destroys the session and program before reading the results.
This proves that relation-backed sink path, not automatic INLINE JOIN scheduling.
SIDE contents live in side relations and are not preserved by merely holding
arena handles. SIDE/nested capture, broader cold indexed execution and scheduler
integration remain outstanding; #1372 stays open.

### Explicit indexed JOIN over immutable payloads (#1372)

`wl_columnar_payload_join_create` executes a bounded JOIN over two caller-owned
payloads, independently of the resident relation/arrangement registry. Each input
may be resident or spilled. Two distinct readers pin the owners, including a
self-JOIN; source relations may already be destroyed. Payload release/demotion
remains BUSY until the producer releases those readers. Already acquired readers
survive spill-store retirement.

The initial capability accepts one INT64 equality key and scalar numeric lanes.
It concatenates complete left/right rows, retaining physical types and exact lane
bits. STRING and logical INLINE schemas, FLOAT keys, and any input timestamp or
signed difference other than `{0,0,0,+1}` are rejected explicitly. Both complete
inputs are validated before publication; a retraction in the last row cannot be
silently discarded. Differential JOIN semantics require separate integration.

Construction streams right rows into a governed hash index of stable ordinals.
It retains bucket heads and one next-ordinal per right row, never reconstructed
right columns or copied keys. Candidate lookup reads the original immutable
payload by ordinal and checks exact equality, including hash collisions. Both
input readers and output relation scratch are governed. The index is an explicit
O(right rows) resident floor: bucket count is the next power of two, capped at
2^31, with at least one bucket; slot storage is `4 * (buckets + right_rows)` bytes
plus its reservation descriptor. Producer/schema copies, input payload floors,
reader buffers and output relation metadata/columns are additional. The generic
continuation's existing fixed descriptor is an additional ungoverned allocation.
`batch_bytes` bounds output lane storage only, not this full resident floor.

Each publication call examines at most 256 row/chain actions, returning PROGRESS
when no output is ready. This is a bound on scan actions, not an evaluation-control
work charge or a bound on OS I/O latency. The existing continuation freezes a
pending batch through sink reserve/append/commit failures. Durable ambiguous
commits advance once; retries do not replay their tuples. Producer I/O and
cancellation errors remain sticky in `wl_columnar_payload_join_error`, never
turning into an empty match or DONE. Cancellation of an active continuation frees
reader pins, index and output scratch. After DONE, cancellation is a no-op and
destroy is required to release those resources. Destroy also frees the producer
and continuation descriptor. Callbacks and lifecycle operations remain
synchronous and externally serialized.

Tests compare resident, direct-spilled and demoted inputs against an independent
nested-loop oracle, including boundary and duplicate keys, collisions, exact
numeric bits, concurrent self-JOIN readers, sink retries, read errors and refunds.
The fixed-budget JOIN fixture uses a 64 KiB governor with more than 512 KiB of
spilled build rows: resident payload capture is refused while the ordinal index,
input readers and streamed output fit. Its externally owned source fixture is
preparation memory and is destroyed before execution, with no governor reset or
budget increase. This establishes bounded JOIN execution over prepared payloads,
not bounded ingestion or a whole-program peak-memory claim. Preparing a payload
from a full source relation still requires that source's own resident floor.

Access audit boundary: `arrangement.c` hashes/probes resident relation columns;
`join.c`, ordinary `join_batch.c`, differential consumers and LFTJ use relation
row indexes/direct columns and retain their existing source leases. None accepts
this payload implicitly and none is marked cold. The explicit producer uses the
existing relation-backed publication sink only for its private output batch.
Automatic evaluator routing, cold relation eviction, SIDE/nested values, public
spill options and scheduling remain follow-up work. These original constructors
refuse workloads whose full resident index cannot fit; the explicit capped
variants below provide an alternative. #1385 is not qualified and #1372 is not
complete.

### Signed-weighted payload JOIN (#1372)

`wl_columnar_payload_join_create_weighted` explicitly opts into the zero-coordinate
Z-set algebra used by `col_op_join_weighted`: every matching pair emits the
concatenated tuple with the product of its two int64 multiplicities. Negative
weights represent retractions. Zero products are emitted too; the producer does
not consolidate equal tuples or apply deletions. Cancellation of equal tuple
weights is a downstream aggregation operation. Numeric physical types and exact
lane bits are retained across resident, spilled and demoted inputs and outputs.

The weighted capability accepts signed weights only when iteration, stratum and
worker coordinates are zero on every row of both inputs, including unmatched
rows. Missing input timestamps still mean weight +1. Nonzero logical times remain
UNSUPPORTED: no time ordering, epoch/frontier composition or timed differential
JOIN is inferred. The ordinary payload JOIN constructor retains its stricter
`{0,0,0,+1}` metadata requirement. Existing ordinary and differential evaluator
JOIN paths are unchanged; the rows-only differential producer is not a metadata
oracle for this capability.

Products use the existing portable checked int64 arithmetic helper, and only
matching keys are multiplied. An out-of-range product produces sticky OVERFLOW,
clears the current private output batch and publishes none of that batch. Earlier
committed batches remain visible: this is batch-level atomic publication, not
whole-JOIN rollback. Retry and ambiguous-commit behavior follow the same frozen
pending-batch contract as the ordinary producer, preserving each weight exactly
once. Output timestamps are fully initialized with zero coordinates and the
checked product. Left multiplicity is retained with its current probe row across
scan progress and publication retries.

`batch_bytes` still bounds output lane storage. Weighted output additionally
reserves timestamp capacity through the existing governed relation constructor;
that storage, retained input readers, the ordinal index and producer metadata
must all fit. Tests check exact admission and one-byte-below refusal, including
the extra timestamp capacity, and run both ordinary and weighted output under
the existing 64 KiB prepared-payload execution budget. The O(right rows) resident
index, externally prepared input floor and generic continuation's fixed
ungoverned descriptor remain as previously documented. Cancellation of an active
continuation releases input readers, index and timestamped scratch. After DONE,
`destroy` is required to release retained resources.

Coverage includes signed/zero products through resident/direct-spilled/demoted
publication, duplicate tuple cancellation, first/last and arithmetic boundary
values, nonmatching extreme weights, a partial-batch overflow after an earlier
commit, concurrent self-JOIN consumers, I/O failure, cancellation and complete
reservation refunds. General logical-time support, automatic evaluator cold
relation routing and #1373 scheduling remain separate work. Public configuration
for the later numeric evaluator subset is described below. This advances signed-difference indexed
execution but does not complete #1372 or qualify #1385.

### Capped right-window payload JOIN (#1372)

`wl_columnar_payload_join_create_bounded` and
`wl_columnar_payload_join_create_weighted_bounded` remove the full-right-index
requirement for the explicit immutable-payload execution path. They accept an
`index_bytes` cap independently of `batch_bytes`; ordinary and zero-coordinate
weighted metadata/schema contracts remain as above. The original constructors
still request a full index and never silently fall back to another algorithm.

The capped variants choose the largest window of N right rows fitting the cap,
clamped to the actual right input size. With B the next power of two at least N,
clamped to [1, 2^31], the allocation is
`sizeof(wl_columnar_memory_reservation_t) + 4 * (B + N)` bytes. The index
descriptor contains that reservation token; `sizeof` includes its alignment.
A nonempty input requires at least one row and bucket; an empty right input
still requires the descriptor and one bucket. A cap below that floor, including
zero, returns MEMORY. Very large caps are clamped to input size. Allocation and
admission use checked, wide arithmetic and the original governor.

One array is reused for disjoint contiguous right-row windows. Links are local
to a window and reads translate them to stable global payload ordinals. Every
left row probes each window; exact key comparison handles collisions. Duplicate
chains split across windows, including all-equal-key skew, cannot grow the index
or omit/repeat matching pairs. Results are multiset-equivalent to full indexing;
output ordering can differ. No row/key copies, per-window directory or new spill
files are retained. Cost is additional left scans: O(left_rows * windows +
right_rows + candidate probes), plus the constructor's full metadata-validation
scan. This is bounded window execution, not a fast partitioned external index.

Bucket clearing, index building, probing and window transitions share the
256-action publication quantum. Large windows yield PROGRESS during clear/build;
construction and its full validation scan remain synchronous with per-row
cancellation. Allocation initialization and OS I/O latency are not bounded by
that publication quantum. Both independent readers remain pinned across windows.
A pending batch freezes producer execution through rejected or ambiguous commits.
Cancellation/read errors remain sticky, and weighted overflow discards the whole
current private batch even when it spans windows; earlier committed batches
remain visible. Destruction releases the single index and all reader/output
resources; after DONE, destroy is still required.

The cap bounds index storage only. Input payload/schema floors, governed producer,
readers, types, output columns and weighted timestamps remain additional. The
existing generic continuation descriptor is still a fixed ungoverned allocation.
Tests retain the original full-index cases and exercise one-row, three-row and
short-final windows across resident/direct-spilled/demoted inputs and outputs,
concurrent consumers, signed weights, publication faults and teardown. Admission
checks cover each byte around index sizing boundaries, including bucket power-of-
two jumps. A 64 KiB enforcing-governor fixture streams 16,385 narrow spilled build
rows with a 127-row index: the full index alone exceeds the same budget and is
refused, while capped ordinary and weighted execution complete with constant-state
output verification and exact refunds. Fixture preparation is external and its
source relations are destroyed before execution without resetting the governor;
this proves bounded execution over prepared payloads, not bounded ingestion.

This addresses bounded index access for explicit numeric immutable payload JOIN.
Ordinary relation/arrangement consumers still use their resident columns/indexes;
automatic evaluator cold routing, general logical time, SIDE/nested values, public
spill configuration and scheduler integration remain separate work. #1372 stays
open and this does not qualify #1385.

### Streamed spilled-payload construction (#1372)

`wl_columnar_batch_payload_create_spilled` connects the spill layer's one-row
source callback directly to the owned payload interface. It takes an explicit
numeric scalar schema and a known `uint32_t` row count. It copies the schema,
admits the payload descriptor, and delegates row encoding, quota/capacity checks,
writer scratch and file ownership to `wl_columnar_spill_create`. No complete
source relation, intermediate resident payload or second governor is created.
STRING, compound and pointer provenance remain unsupported in this entry point;
existing relation/STRING/INLINE capture APIs retain their contracts.

The source fills every lane and the complete timestamp/signed-difference metadata
for each ascending ordinal using supplied one-row scratch. Numeric lane bits and
all metadata coordinates are retained exactly. Zero rows permit a NULL source.
Types, source contexts and cancellation state are borrowed only during the call;
the published payload retains none of them. Callbacks must not reenter or retire
involved lifecycle objects, and must not disguise ephemeral IDs or pointers as
self-contained numeric values. This API has a known-count contract, not an
unknown-length append interface.

Source errors propagate as typed statuses. Allocation/admission denial,
quota/capacity exhaustion, partial I/O errors and cancellation, including after
the final row and segment creation, leave the output owner NULL and release
private payload/segment/file resources. Existing published payloads remain valid.
Consumed source input and callback side effects are not rolled back; a retry
requires a fresh or rewound source. Reader pins, BUSY release, store retirement
and independent-reader concurrency use the same payload/segment lifecycle as
relation capture.

Construction adds `batch_payload_floor(..., SPILLED).payload_bytes` plus
`spill_floor.segment_bytes + spill_floor.writer_bytes` to the already-live store
and prior payloads. After construction only the payload and segment remain;
reader floors are charged on acquisition. Tests measure that exact writer-time
reservation, reject one byte below it without calling the source, and succeed
at the floor while preserving a previously published payload. They cover schema
copy independence, negative-zero bits, signed metadata, empty inputs, unsupported
schemas, wrong governors, quota/row-width limits, allocator failure, prefix source
failure, early/mid/late cancellation, concurrent readers and store retirement.
Existing spill I/O hooks additionally exercise short writes and injected EIO or
ENOSPC after a second input's private prefix, with unchanged first-owner contents,
disk accounting and complete refunds.

The streaming variant of the capped JOIN fixture starts with one 64 KiB enforcing
governor and uses fixed-size pull-source contexts to compute BOTH inputs directly
into spill scratch. It retains the first payload's charges while constructing
16,385 right rows; no full input relation or source array is allocated and no
ledger reset, budget increase or governor swap occurs. The full index alone
exceeds that allowance and is refused; a 127-row index completes ordinary and
signed-weighted JOIN. Constant-state output verification checks every ordinal,
negative/zero weight, duplicate-key match, window boundary and final unmatched
row; each output is released before continuing. Exhausting the remaining allowance
also explicitly denies the minimum execution floor without losing either input.

This establishes managed bounded streaming construction AND JOIN execution for
these supported numeric streams, extending the earlier prepared-input execution
proof. It is not a whole-process RSS guarantee: source contexts/stack, the governor
object, the generic continuation's fixed descriptor, allocator overhead and OS
resources remain explicit additional costs. Arbitrary callbacks can retain their
own unbounded state and must account for it separately. Existing relation-capture
paths still require their complete source relation; automatic evaluator/registry
cold routing, mutable/trace transitions, broader
compound support and #1373 scheduling remain separate work. #1372 stays open and
this does not qualify #1385.

## Controlled completed-snapshot workspace

Completed controlled snapshots reserve two private workspace allocations: a
stable entry array (including scalar-source reader records) and a contiguous
row-major tuple array. Checked multiplication/addition precedes admission;
metadata zeroing uses charged chunks of at most 128 bytes. Tokens stay at
stable stack addresses and remain RESERVED through the last callback.
Physical storage is freed before its own credits are rolled back. No shared
ledger snapshot is restored. Both paths share staging/dispatch charges and ownership behavior; enabling
the governor additionally charges its reservation-admission operations.

The snapshot tariff includes a 256-action fixed bootstrap, one action per
stratum/entry counting visit, 128-action workspace allocation/retirement
bookkeeping plus allocation admission, metadata initialization bytes,
32-action entry setup/cleanup capacity, registry slots and compared name
bytes, existing controlled scalar-source charges, and eight prepaid dispatch
actions per row. Each source INIT funds its own End; entry setup additionally
funds cleanup traversal. Source readers drain before the publication cutoff.
After cutoff the already-admitted finite callback loop and mandatory workspace
retirement run without ordinary work polls. Allocator bodies and callback
bodies remain non-preemptible; this does not exclude engine tuple preparation.

`test_controlled_snapshot_preparation` checks the independent 257/258-action
first-entry boundary, lookup/gather/cutoff/allocation cancellation, both
allocation failures, reader contention, enforcing-governor denial and exact
post-stop credit restoration. Wide multihead results and retry match the raw
snapshot; internal projection fixtures cover duplicate/missing entries, empty
strata and the optional-governor branch. These fixtures do not authorize plan
mutation during a session operation.


### Private ordinary recursive rounds (#1821 G3a)

The controlled general session transaction owns separate old-public,
previous-round and candidate-head descriptors. A complete SCC round reads only
its frozen previous inputs; child readers and terminal cleanup receipts drain
before bindings switch to next-round candidates. Original public descriptors
remain leased until coordinated publication preparation. Governed empty heads
use declaration-derived scalar INT64 widths, including when inputs are empty.

`wl_columnar_session_recursive_retire` keeps its scalar retirement receipt at a
stable transaction address. `round_owner` identifies the owning previous-head
slot through partial physical freeing and the descriptor-free credit-retirement
tail; no other path dereferences that retired descriptor. Work-limit resume
continues the receipt. Cancellation/destruction use retained maintenance control
to drain it, then every remaining private owner. No old public head is destroyed
before the common publication cutoff. Repeated successor and interruption tests
check resource baselines and zero reservations after session and program teardown;
program intern storage is released by program destruction.

## Opt-in ordinary evaluator spill JOIN (#1372)

Internal `wl_session_options_t` version 5 adds `spill_join_batch_bytes` and
`spill_join_index_bytes`. Both zero keeps existing behavior. Both positive
requires the existing spill directory/quota/row-width configuration; combining
this route with evaluation control is rejected with `EINVAL` before attachment.
Version 2, 3 and 4 option prefixes retain disabled routing, including when their
buffers contain unknown trailing bytes. This is not an installed public API.

The ordinary evaluator selects this route after operand selection and key
resolution, before acquiring an arrangement or allocating an ephemeral full
index. Eligibility requires a serial coordinator (`num_workers <= 1`), one
INT64 equality key, nonempty scalar numeric inputs without timestamps, and an
unmaterialized JOIN. Valid flattened projections (including reordered,
duplicated or omitted keys) are emitted directly into projected-width batches.
Already-evaluated right filters are supported; their cache or temporary storage
remains resident and governed. Worker, differential,
delta-seeded/retraction, controlled and TDD-bound execution is excluded, as are
STRING, graph and compound layouts. `WIRELOG_JOIN_BATCH_BYTES` retains precedence
when both features are enabled, including its strict-mode refusal. Unsupported
shapes follow their existing paths; the option does not promise bounded indexes
for an arbitrary plan. A non-NULL out-of-range projection retains the resident
path's zero-lane behavior. A NULL projection map still means concatenation,
regardless of its count. Empty inputs retain the established empty-result path.

Selected JOINs capture both inputs into session-owned ephemeral spill payloads
under source-reader authority, then use the capped window index. The batch cap
bounds output lane storage; the index cap includes its reservation descriptor,
buckets and row links. Rescanning the left snapshot for each right window trades
I/O and CPU for bounded index memory. Borrowed registry/cache sources remain
resident and unchanged. Eligible owned numeric heap intermediates instead
transfer to the payload: output schema is prepared first, then checked source
retirement refunds their resident storage before producer/index and output-row
allocation. The caller's owning slot is cleared only on success. Source readers
or aliases can refuse retirement; failed transfer preserves the source and
refunds its private payload. Pool/arena/shared backing keeps snapshot behavior,
and cross-operand aliases are not transferred. The final result is materialized
in a governed relation. Snapshot descriptors,
writer/readers, producer/batch state and output storage remain additional memory
floors. The generic continuation descriptor and OS/allocator costs retain the
limitations described above. This does not evict registry columns or implement
mutable/trace transitions or #1373 scheduling.

PROGRESS advances private scan state without publishing or charging output rows.
Only committed batches count against the ordinary JOIN row limit; equality with
the limit refuses the JOIN and a batch can overshoot it. The result stays private
until the JOIN finishes, so errors destroy that result. Existing outer STEP and
observer publication contracts still apply; this is not whole-STEP rollback.
Continuations/readers are destroyed before releasing both snapshot owners on
all exits, including self-JOIN and failure during the second capture. Successful
owned transfer is irreversible if a later operand or output fails; ordinary
operator cleanup consumes these owned intermediates without promising input
rollback. Busy left ownership remains on the evaluator stack; a refused private
heap filter is retained by the session's deferred cleanup registry. Synchronous
execution adds no controlled cancellation or work-metering guarantee.

Selected-route errors propagate without a resident retry. Spill MEMORY returns
`ENOSPC` with memory-budget-denial evidence; QUOTA/CAPACITY also return `ENOSPC`
but do not set that evidence. ALLOCATION returns `ENOMEM`, I/O returns `EIO`,
overflow `EOVERFLOW`, busy `EBUSY`, closed `EPIPE`, unsupported `ENOTSUP`, invalid
`EINVAL`, and cancellation `ECANCELED`. Producer errors are read before teardown;
sink allocation/admission errors preserve their own classification.

`test_join_spill` uses natural parsed projection and right-predicate rules as
well as an arithmetic MAP tail. Enabled and disabled execution produce identical
results and observer notifications; selected execution creates no resident
arrangement. Pinned stale filter-cache entries force the real owned-filter
fallback, checking success, second-capture/I/O/output failures and exact refunds.
Additional checks cover self-JOIN, owned FLOAT inputs,
multiple windows and no-match PROGRESS, legacy row caps, excluded shapes and
workers, disk quota/write/read failures, allocation and governor denial,
source/pin preservation and exact snapshot cleanup.

The fixed-budget session acceptance test calibrates the successful peak in a
separate fresh session, then creates enabled and disabled sessions with identical
facts and one identical enforcing allowance set before creation. There is no
budget increase, ledger reset or shared warm cache. A 4,096-row right source and
three sparse matches require an 8,192-bucket resident index plus row links. A
test-only observer at arrangement admission identifies the refused request and
proves it exceeds remaining credit; the resident path retains its existing
`ENOMEM` classification. Spill STEP completes with the exact three rows and
observer events, no full arrangement and no residual snapshot files. The same
comparison runs with a parsed equality filter retaining all right rows, so its
resident cache and temporary preparation costs are included. Admission peaks
include session creation, source preparation and observer publication.

A separate fresh-session calibration locates an allowance below the spill floor
that still prepares the inputs and selects the route. Repeating that allowance
returns `ENOSPC` with budget-denial evidence, no result notifications, no
resident retry and released source gates/snapshots. Session destruction returns
all credit; this does not assert whole-STEP rollback of retained evaluator
metadata. Subsequent insertion and removal in a sufficiently funded session
verify exact visible rows and signed notifications through the existing
incremental/retraction machinery. Those steps are not a bounded-execution claim.

This demonstrates an execution/index working set exceeding a fixed allowance,
with resident inputs, filter and output that fit. It does not demonstrate cold
registry/trace reclamation or whole-program arbitrary-budget completion. The
separate 64 KiB streamed-payload proof remains unchanged.

### Reclaiming owned JOIN intermediates

`wl_columnar_batch_payload_take` consumes a complete, exclusively owned,
canonical governed heap relation into the existing immutable spilled payload.
It checks backing and committed reservation ownership; pool/arena/shared backing,
retraction backups and deferred owners are ineligible. Numeric capture preserves
all physical lane bits, row ordinals, types and timestamp/signed-difference
metadata. STRING/compound/graph capture is not added to this transfer API.
The original relation identity ends on retirement; payload ordinals belong to
the new owner, and old relation-index caches cannot transfer with it.

The source lifecycle must be externally serialized. The backing predicate does
not grant ownership authority over a borrowed registry/cache relation. Readers
and alias borrows are transient contention, not a reason to silently retain the
source: checked retirement returns BUSY, drops the unpublished payload and
preserves the source. Every failed transfer leaves the source pointer unchanged,
with private disk and memory credit refunded. Cancellation is checked immediately
before retirement; successful retirement clears the owning slot and publishes
payload ownership without a later cancellable/error step. Concurrent readers of
the new payload use its existing pin/read/release contract after source removal.

The ordinary evaluator uses this transition for eligible owned intermediates
and private heap filters, preparing owned output schema at zero row capacity
before either operand retires. Two JOINs sharing a descriptor or storage owner
retain snapshot behavior. Pool-backed private filters also retain that behavior;
the independent heap allocation used when the session pool cannot be admitted
is transferable. Failed left cleanup preserves the evaluator entry and its
segmentation metadata; private heap-filter refusal uses deferred session cleanup.
A successful transfer followed by a later error consumes the intermediate and
cleans its payload/output rather than recreating the original relation.

The parsed multi-JOIN acceptance fixture produces 8,192 intermediate rows, then
joins them against a 32,768-row resident input to produce 64 exact results and
notifications. It calibrates in a separate fresh session, then compares two new
sessions with identical facts, fixed enforcing allowance and bounded index/batch
settings. A test-only retention policy keeps the intermediate until normal
end-of-JOIN cleanup; it changes no admission outcome or query/index setting.
The real transfer run records the retired identity and reservation refund before
producer construction and completes. The retained run fails with MEMORY at the
second producer constructor, publishing no results. Thus this evidence depends
on reclaiming resident input storage, beyond the separate index-saving proof.
The test derives its allowance from observed admission peaks rather than a
platform-specific byte total. Source preparation and observer publication are
included; host staging, OS/allocator and previously documented ungoverned costs
remain outside the managed-memory claim.

A lower fixed allowance admits source preparation but refuses execution with
budget evidence and no notifications or owned spill files. The low-level
transition-floor test separately proves failure preserves the original source
and refunds private work. Failure, late cancellation, partial I/O, quota,
reader/alias BUSY, typed/signed metadata, concurrent pins and post-transfer
producer/output errors are covered by `test_batch_payload` and `test_join_spill`.
This completes the owned intermediate subset; it does not make registry or
persistent trace storage cold, nor add differential cold execution.

### Persistent sealed projection and JOIN inputs (#1372)

The internal `wl_columnar_session_seal_input` operation converts one eligible
scalar or declared flat INLINE EDB into a session-owned immutable cold binding before the
first STEP or SNAPSHOT attempt. It captures privately, checks exclusive resident
retirement, refunds the original allocation, removes the raw registry entry,
and publishes the binding without a fallible gap. Failed capture, cancellation,
quota or retirement leaves the original registry source intact and refunds the
private work. The binding owns its schema names and payload; it preserves the
source identity, view and row ordinals while advancing the storage generation.
Generation overflow is refused before capture. Existing resident arrangements
cannot survive this transition.

Several already-loaded inputs can be sealed independently in either order,
using one stable governed node per input. All facts must be loaded before the
first seal freezes mutation; additional sealing is allowed until evaluation.
Each capture commits only its own binding. Failed later captures preserve all
earlier bindings and their disk extents, and preserve the failed resident source.
Duplicate sealing is refused. Destruction releases every node and payload before
the session store. Raw lookup of any known cold name remains an explicit error.

Complete direct/narrowly filtered projection rules over another eligible loaded
EDB can coexist whether that source is resident or already sealed. Auditing uses
that source's complete physical schema and declaration provenance, not the selected candidate's
width/types. This does not admit arbitrary resident filters or filters on IDBs,
and another source's valid projection cannot authorize an unused candidate.

The supported plan is serial, nonrecursive, and contains only audited
VARIABLE/JOIN/MAP/CONSOLIDATE operations, plus the restricted projection FILTER
described below. The cold name must have an eligible consumer: a JOIN input
or the exact direct/filtered projection body below; it cannot be a relation head
or an arbitrary VARIABLE consumer. Eligible JOINs use matching INT64/STRING equality key pairs, supported scalar lanes (including declared flat INLINE fields),
no timestamps and no right filter. Multiple eligible JOINs
may consume the same binding. A cold left source requires an initial VARIABLE/JOIN pair or the audited
direct MAP/narrow FILTER prefix described below. Both inputs can be sealed, and a self-JOIN acquires two
independent reader pins over one persistent owner. A subsequent JOIN consumes
an admitted resident intermediate. Composite rules require direct MAPs and
narrow FILTERs throughout their suffix. Cross/theta JOINs and other key types
are refused. Available source
schemas and projection bounds are checked before retirement and again at
execution; an unloaded resident counterpart is checked when its schema exists.
Spill batch/index caps must be positive. Opaque
rewrites, workers, controlled execution, delta callbacks and competing JOIN
batch modes are refused. The plan must remain immutable for the session lifetime,
and session operations remain externally serialized. The advanced public opt-in
is described below; this is not an automatic eviction policy.

Successful sealing makes all fact and compound mutation unsupported. Generic
fact/file loaders reject before staging or opening adapters, without poisoning
an otherwise usable sealed session; genuine partial-load errors still poison.
Supported STEP/SNAPSHOT execution resolves the binding before the missing-right
case and routes it through the capped payload producer without rebuilding a
resident arrangement. Schema/projection ownership is admitted before private
resident source transfer. Resident counterparts are privately captured; sealed
inputs are borrowed without rehydration. Failed attempts drop reader pins before
releasing only temporary payload owners. Missing resident right inputs preserve
the ordinary empty-result typing contract. Readers hold separate cursors and release pins before binding
cleanup. Repeated queries reuse the same owned spill segments; session teardown
releases those segments and their governed metadata. Final output remains
resident, so successful input retirement does not promise arbitrary result size.

`test_session_cold_relation` also compares all resident/cold input directions,
both seal orders, duplicate/skew and empty inputs, self-JOIN, repeated consumers,
and a two-JOIN chain with a direct scan. Fixed-allowance controls separately
prove left-only and two-owner reclamation against deliberately retained physical
allocations. A direct both-cold JOIN compares constructor/reader/index scratch
at two source cardinalities with the same caps and no output rows. A real
admitted pressure allocation proves constructor refusal and cleanup; a separate
many-match case proves the resident output floor. A no-match final result with
a large first JOIN separately proves the resident intermediate floor. These are bounded-input
claims, not a guarantee that arbitrary output or intermediate sizes fit.

`test_session_cold_relation` supplies the lifecycle and causal budget evidence.
A separate calibration run chooses an allowance for two fresh sessions with the
same parsed plan, facts and caps: 128 left rows, 32,768 right rows, and 8,192 exact
results. Both publish the same cold binding and remove the resident registry
entry. A serial test-only control retains the original physical source in a
detached owner until teardown. Only the real source refund differs: normal
retirement completes with exact callbacks; retention reaches the same bounded
producer and naturally fails a later admission with budget evidence and no
callbacks. No injected denial or extra pressure allocation drives the comparison.
The allowance covers preparation, capture and execution; host staging,
allocator/OS costs and documented unmanaged allocations remain excluded.

Separate fixed-allowance tests distinguish refusal at the simultaneous
source/capture floor from failure after successful sealing when resident output
cannot fit. The first preserves the original source; the second retains the
valid cold binding and publishes no callbacks. Tests also cover independent
concurrent readers, multiple consumers, repeated STEP/SNAPSHOT, empty inputs,
FLOAT/UINT64 projection lanes, reader/alias BUSY, quota, partial I/O, allocation
failure, cancellation, generation boundaries and complete credit refund.

### Public advanced spill configuration and sealing (#1372)

`wirelog_session_create_with_options` exposes explicit spill configuration through
installed `wirelog/wirelog-advanced.h`. Initialize `wirelog_session_options_v1_t`
with zeros, its `struct_size`, and `abi_version = 1`. Unknown versions and short
prefixes are rejected; larger descriptors have only their v1 prefix read. NULL
options retain legacy creation behavior. Existing create/create_with_snapshot
APIs are unchanged. A non-NULL descriptor normalizes into private options without
exposing a governor, control handle or internal struct layout.

The descriptor's optional scalar-addon `snapshot` uses the existing retained
snapshot contract. The program remains borrowed until session destruction;
descriptor and directory storage are needed only during construction. The
session copies its directory, seeds inline facts before returning, and unwinds
its temporary owners on failure without consuming the caller's snapshot owner.

A configured directory must already exist and remain under host control. Supply
a positive file quota and `spill_max_row_bytes >= 32`; a wider schema can require
more than that validation minimum. Set both JOIN caps positive to enable eligible
serial spill execution, or both zero for a store without JOIN routing. NULL
directory with all limits zero disables spilling. Directory creation, implicit
activation and durable/reopenable spill files are not provided.

The existing `WIRELOG_MEMORY_BUDGET` setting accepts decimal bytes with a minimum
of 268435456 (256 MiB). A smaller or malformed setting is invalid configuration,
not proof of memory exhaustion. Batch/index caps bound individual scratch units,
not the entire session. The full source must initially fit and coexist with
capture scratch; final IDB output stays resident. Public-only tests use a valid
fixed 256 MiB allowance and refuse a 4096-by-4096 JOIN's resident output with
`WIRELOG_ERR_MEMORY_BUDGET` and no callbacks. The earlier identical-budget
retained-source control remains the causal reclamation proof; this public test
qualifies the actual host boundary and output floor.

After loading all inputs, call `wirelog_session_seal_input` for one eligible
scalar or declared flat INLINE input. `wirelog_session_seal_join_input` remains a compatibility spelling
with identical eligibility, errors and lifetime. A projection-only program can
seal its source without a JOIN. It uses the exact immutable plan/mode restrictions above;
opaque optimized plans, VARIABLE reads outside the direct-projection subset, recursive, worker,
delta and controlled paths remain ineligible. The public call is synchronous and
has no cancellation callback. Success freezes all fact/compound mutation for the
session and cannot be undone. Refusal preserves the source; retry is possible
only while the lifecycle remains eligible. The first evaluation attempt closes
the seal window permanently. Use repeated STEP or repeated SNAPSHOT according to
the existing advanced API contract; do not mix evaluation modes to infer tuple
multiplicity. Externally serialize every operation on the session. Snapshot
callbacks borrow their tuples only for the callback duration.

Seal results distinguish managed-memory admission (`WIRELOG_ERR_MEMORY_BUDGET`),
allocator failure (`WIRELOG_ERR_MEMORY`), disk I/O/capacity/quota
(`WIRELOG_ERR_IO`), and unsupported/invalid/busy/generation states
(`WIRELOG_ERR_EXEC`). Errors do not inherit a prior operation's budget flag.
Constructor storage-open errors retain its existing `WIRELOG_ERR_EXEC` mapping.
The installed typed path preserves finite nonzero FLOAT values and its existing
signed-zero canonicalization; nonfinite input is rejected. Public schema syntax
does not currently expose BOOL/UINT64 declarations; internal payload tests cover
those types without implying public schema support.

This complete example uses inline facts and an existing private spill directory:

```c
#include <wirelog/wirelog-advanced.h>
#include <stdio.h>

static void show(const char *name, const int64_t *row, uint32_t ncols, void *ctx)
{
    (void)ctx;
    if (ncols == 3)
        printf("%s(%lld,%lld,%lld)\n", name, (long long)row[0],
            (long long)row[1], (long long)row[2]);
}
int main(int argc, char **argv)
{
    if (argc != 2) return 2;
    wirelog_error_t error;
    wirelog_program_t *program = wirelog_parse_string(
        ".decl a(k:int64,v:int64)\n.decl b(k:int64,v:int64)\n"
        ".decl result(k:int64,x:int64,y:int64)\na(1,11).\nb(1,101).\n"
        "result(k,x,y + 0) :- a(k,x),b(k,y).\n", &error);
    if (!program) return 1;
    wirelog_session_options_v1_t options = {0};
    options.struct_size = sizeof(options);
    options.abi_version = 1;
    options.spill_directory = argv[1];
    options.spill_quota_bytes = 1048576;
    options.spill_max_row_bytes = 64;
    options.spill_join_batch_bytes = 4096;
    options.spill_join_index_bytes = 4096;
    wirelog_session_t *session = NULL;
    error = wirelog_session_create_with_options(program,
        WIRELOG_BACKEND_COLUMNAR, 1, &options, &session);
    if (error == WIRELOG_OK)
        error = wirelog_session_seal_join_input(session, "b");
    if (error == WIRELOG_OK)
        error = wirelog_session_snapshot(session, show, NULL);
    wirelog_session_destroy(session);
    wirelog_program_free(program);
    return error == WIRELOG_OK ? 0 : 1;
}
```

After installing the library, compile the saved example with
`cc example.c $(pkg-config --cflags --libs wirelog) -o example` and pass an
existing directory as its sole argument. Expected output is `result(1,11,101)`.
Session destruction closes its files; POSIX unlinks them immediately at creation,
while Windows uses delete-on-close. Tests use an isolated directory and scoped
live-descriptor evidence on Linux; directory emptiness alone does not prove that
an anonymous POSIX descriptor closed. The production-library public test is
registered on all supported hosts. Native platform qualification depends on the
actual corresponding CI run, not a Linux macro compile.

### Bounded direct projections of sealed JOIN inputs (#1372)

An eligible sealed JOIN input can also supply an exact three-operator
`VARIABLE(cold) → MAP(columns) → CONSOLIDATE` rule. For example, alongside
`result(k,x,y + 0) :- a(k,x), b(k,y).`, a declared `keys(k)` head can use
`keys(k) :- b(k,v).`. Such a projection may also be the source's only consumer:
`wirelog_session_seal_input` supports direct and narrowly filtered standalone
reads. The compatibility `wirelog_session_seal_join_input` spelling does too.
A known but unused source or a source with unsupported consumers is refused.

Seal preflight and ordinary dispatch share the same full-body predicate. It
accepts valid reordered/repeated column indices and canonical column-reference
bytecode matching those indices and source types, with checked lengths and
integer overflow. Ordered MAP/FILTER stages may repeat after VARIABLE and before
terminal CONSOLIDATE, with at least one MAP. Each stage uses the preceding
stage's width/types; reordered/repeated MAP indices compose back to source lanes
without intermediate rowsets. Every MAP scalarizes INLINE fields, even when it
preserves width. FILTERs each accept one stage-local INT64 column compared with one integer literal using `=`, `!=`, `<`, `>`,
`<=` or `>=` (column on the left). For example, `keys(k) :- b(k,v), v >= 164.`
filters on a column that need not appear in the output. Multiple filters are
sequential conjunctions; all must accept the row. Their descriptors are decoded
once into governed plan-sized scratch, independent of source row count. Final
source-column indices are also admitted and composed once before reading. Other predicates,
arithmetic, boolean-expression predicates, concatenation,
opaque rewrites and other raw-column consumers remain explicitly unsupported.
A raw VARIABLE request for a known cold name returns ENOTSUP rather than treating
the removed registry entry as empty. No synthetic relation with missing columns
is exposed to ordinary operators.

Each projection acquires an independent payload reader and copies selected lanes
from stable source ordinals before the next read. Temporary schema and row scratch
are admitted through the session governor. The complete projected output is
separately admitted before reading; it remains private until all reads finish.
The reader and row scratch are bounded independently of source row count, but the
resident projected result, normal consolidation and head publication are not.
Output capacity is admitted for the full source row count before reading even
when the predicate rejects every row; selectivity does not remove that floor.
A narrow projection avoids full-source rehydration; this is not arbitrary-budget
or general out-of-core execution. Numeric lanes/types and duplicate rows follow the ordinary relation contract
before consolidation, including existing FLOAT signed-zero canonicalization.
Finite nonzero FLOAT bits and UINT64/BOOL lanes remain exact.

Internal and public tests exercise real parsed mixed-consumer programs, resident
parity, repeated snapshots, empty input, reordered/repeated indices, FLOAT/UINT64/
BOOL lanes, malformed projection bytecode, explicit unsupported shapes, read
failure after a private prefix, allocation refusal and cleanup/retry. A new
fixed-allowance paired run completes 8,192 projected keys plus the JOIN after
physical source reclamation, while retaining that source at the same allowance
causes genuine managed-memory refusal. Separate admission measurements show the
same temporary reader/row overhead at 128 and 8,192 source rows after excluding
resident output. A 64-column projected output exceeds a real 1 MiB allowance without
losing the cold owner; the narrow projection can then succeed at that same limit. Earlier JOIN-only proofs are
not substituted for this projection evidence. The same retained-source control,
constant-scratch comparison and output-floor refusal also run with a selective
filter. All six signed comparisons include negative and extreme literals;
public tests compare exact keys for none/some/all passing rows, empty inputs,
STEP followed by repeated snapshots, and refusal of unsupported filter bodies.

Failures release the append lease, reader and private result before refunding
credit. The persistent binding stays session-owned and valid for permitted
retries. This does not promise rollback of other heads already committed by an
earlier STEP relation, or add asynchronous cancellation/control support.

### STRING cold projection and JOIN consumers (#1372, partial)

Standalone direct and narrowly filtered projections accept actual STRING lanes,
including reordered and repeated outputs and multiple sealed inputs. Source
initialization preserves declared STRING types even for raw host inserts and
empty relations. Capture validates every STRING ID, including unused lanes,
and pins the originating session/program intern table. Runtime checks compare
table identity through the retained payload or spill-segment owner; a different
table with coincident IDs is not equivalent, even under the same governor.
The reference-aware JOIN route accepts matching INT64 or STRING keys and
STRING payload columns in either input. Legacy numeric-only payload producer
constructors retain their restrictions. Self-JOIN and chained consumers use
independent reader pins; a stored output payload acquires its own intern pin
before batch acknowledgement. An owned reference intermediate is captured
before checked retirement, preserving the same resident intermediate floor.

Projection and JOIN preserve STRING types and IDs without rehydrating full input rows.
The program must outlive public sessions; output IDs borrow that lifetime.
Payload readers retain source storage while live, including after owner
retirement. Independently retained output requires its own intern capability.
Intern strings/table storage remain resident and charged. Tests pair reclaimed
and retained STRING sources under one allowance and separately exhaust real
admission with increasing distinct strings; spilling rows cannot remove this
floor. Private output/read/allocation failures preserve the sealed binding and
release attempt resources before retry. Fixed-intern two-cardinality tests
keep JOIN scratch unchanged under fixed index/batch caps; retained-source
controls cover one and both input owners without hiding resident output costs.

### Bounded scan prefixes feeding JOIN (#1372)

A nonempty sequence of the audited direct-column MAP/FILTER stages may now
precede the first JOIN. For example, a declared `result(k,s,w)` head can use
`result(k,s,w) :- a(k,s), k >= 0, k = 1, b(s,w).` with an INT64 `k` and
STRING `s`. The parser may retain a predicate after JOIN as well as push it
before JOIN; both are audited and executed in order. This new route permits
subsequent INT64/STRING equality JOINs, canonical direct-column MAPs and the
same six INT64/literal FILTER comparisons, ending at CONSOLIDATE. It validates
actual stage-local types and widths through every JOIN projection and MAP,
including right-derived lanes. A valid prefix never grants an exception to an
unsafe suffix or another rule. Sealing and runtime use the same complete audit
for every binding; unsupported mutations are refused before scanning.

The cold prefix reads each source ordinal once, with governed row/mapping/
predicate/layout scratch independent of row count. Only its final prefix result
is materialized, privately, with capacity admitted for the **entire source row
count**, even if every predicate rejects. It is handed to the first JOIN exactly
once as an owned resident relation. FILTER-only prefixes preserve original column
names and semantic flat INLINE layout/declaration identity; any MAP produces
scalar lanes with ordinary generated names, including width-preserving maps.
A resident FILTER-only left prefix also preserves declaration identity when the
right input is cold. No fake relation with missing payload columns is used.

The suffix executes ordinary resident JOIN/MAP/FILTER operators. Its intermediate
results, output, consolidation and retained intern table are additional resident
floors; this route does not promise bounded total memory or arbitrary-budget
completion. Missing right inputs retain ordinary empty-result typing. Known
right inputs must have a supported initialized schema. The older immediate
VARIABLE/JOIN route keeps its streaming behavior and existing scope; this
extension does not globally enable FILTERs on arbitrary plans.

Tests compare scalar and INLINE STRING results across resident, left/right-only
cold, both-cold and both sealing orders; cover parsed comparisons, remapped and
right-derived suffix predicates, repeated execution, late read and suffix
allocation failures with retry. A paired workload uses the same calibrated
allowance with the actual original source retained or reclaimed: only the
reclaimed case completes. A widened all-rejected prefix still refuses its real
capacity floor and a narrower retry succeeds. Private-attempt cleanup does not
claim whole-STEP rollback of previously published heads. Mutable/differential
traces, general expressions and SIDE/nested layouts remain outside this route.

### Segmented immutable Z-set trace snapshots (#1372, internal)

`columnar/trace_store.h` adds an explicit numeric scalar trace owner composed
of existing immutable batch payloads. Append capture keeps its input owner;
append take transfers an exclusively owned governed heap relation, physically
retires its row storage, and clears the source pointer. All rows are validated
before publication: physical schemas/governors must agree and timestamp
iteration/stratum/worker/reserved coordinates must be zero. Signed int64 weights,
including negative retraction contributions and zero, remain exact. This is a
zero-coordinate Z-set, not a general logical-time trace or consolidated set.

Each append commits a stable ordinal range and storage generation. An immutable
snapshot retains only its committed boundary: later appends are invisible to it.
Total rows and segment count are each limited to UINT32_MAX, including empty
segments; generation overflow is refused before source retirement. Snapshot and
node descriptors are governed O(segment count) metadata. A snapshot directory
uses binary search (at most 32 comparisons) even across repeated empty segments,
without any O(row count) offset table. Each cursor independently retains its
snapshot and holds at most one active payload reader, so read scratch depends
on row width rather than historical cardinality. Source, payload, metadata,
transition, and output allocations remain additional resident floors.

Demotion replaces an unpinned resident segment with the existing spill format
and releases resident row storage. A snapshot pin makes demotion BUSY even if
no cursor has opened that segment. Failed admission, allocation, cancellation,
or I/O preserves the old generation and source; append take performs no
fallible work after source retirement. Retirement closes new owner operations
and keeps all owner nodes alive until the final snapshot/cursor drains. An
empty snapshot also retains that owner lifetime.

The spill store remains externally owned. Trace retirement alone permits old
snapshots to continue reading while the store stays open. After spill-store
retirement, an already opened segment reader remains usable, but later lazy
acquisition returns CLOSED. This failure is not an empty result. No successful
cross-segment drain is promised across external store retirement.

A governed per-owner mutex serializes lazy segment reader transitions so
independent cursors of the same trace can read concurrently. Actual per-reader
I/O occurs outside that lock. Explicit acquisition/release, append, demotion and
retirement remain externally serialized against reads. Different trace owners
sharing an external spill store must serialize cursor operations as well; this
does not make the spill store's lifecycle globally thread-safe.

This storage/scan contract does not automatically migrate session relations or
legacy differential arrangements.
Legacy numeric entrypoints reject STRING and compound provenance. Explicit
reference-owned storage is described below. SIDE/nested, general logical time,
mutable-session routing and #1373 scheduling remain outside these owners.

The indexed payload JOIN engine also accepts two numeric trace snapshots through
`wl_columnar_payload_join_create_trace_bounded`. Existing payload constructors,
including the production reference/projected cold JOIN route, use the same source
cursor engine and retain their eager readers and intern capabilities. Trace
cursors independently retain immutable snapshot boundaries, opening one segment
reader at a time. The same capped right-row index, output batches and 256-action
publication quantum apply across segment boundaries. Ordinary trace JOIN checks
all rows for +1 multiplicity before publication. Retiring a trace owner preserves these consumers,
but retiring its external store may yield CLOSED on later lazy acquisitions.

### Reference-owned trace storage (#1372, internal)

`wl_columnar_trace_store_create_reference` accepts scalar STRING schemas or a
complete declared flat INLINE schema with the originating governed intern table.
It copies name-less semantic declarations into aligned, governed owner storage.
The owner holds an intern pin even with no segments and for numeric-only INLINE
functors. Physical types, declaration padding, nodes and snapshot directories
are explicit resident floors; the retained intern vocabulary is additional.

Reference append APIs require the same originating table and semantic declaration
as the owner. Every source lane and layout is validated before publication or
retirement, including unused STRING fields. The caller still guarantees that raw
IDs really originate in the supplied table; equal integers cannot prove origin.
SIDE, graph and nested handles remain unsupported. Signed weights and zero
iteration/stratum/worker/reserved coordinates retain their existing contract.

Additive `batch_payload_take_with_intern` and `take_with_inline` use the existing
capture plus checked-retirement transaction. Exclusive governed heap sources
are cleared only after all fallible work succeeds. Source-reader BUSY, private
write/capacity/cancel/allocation failures preserve source and prior trace state.
Reference trace take and unpinned demotion physically release resident rows;
numeric capture/take still refuse reference owners. Session registry sealing
retains its own authority and is not redirected to exclusive-owner take.

Existing reference snapshots/cursors reuse retained intern capability after the
intern owner retires, including lazy segment switches while the spill store is
open. Cursor string resolution returns text valid through that cursor's release.
New reference owners, append and demotion need fresh pin admission and return
CLOSED after intern retirement; an owner pin never reopens admission. External
spill-store retirement separately closes later lazy readers. The same per-trace
transition lock and explicit lifecycle/cross-owner serialization rules apply.

Tests cover empty and numeric-only INLINE pins, Unicode/empty strings, odd-width
aligned multi-group declarations, capture/take/demotion, exact signed records,
old/new boundaries, source/provenance refusal, late faults and same-trace
concurrent lazy transitions. Existing numeric trace JOIN factories audit every
lane and INLINE declaration, including non-key and empty references, and refuse
these owners before publication. Reference storage alone does not widen legacy consumers.

`wl_columnar_payload_join_create_reference_trace_projected_bounded` explicitly
consumes two reference snapshots through the existing common capped JOIN engine.
Both keys must be INT64 or both STRING. The supplied originating intern must
match every STRING-bearing or INLINE input, including non-key and projected-away
fields and numeric-only INLINE functors. Complete-input ordinary multiplicity
validation still requires +1 at zero coordinates. Payload and snapshot sources
share schema/provenance validation; old payload factories retain eager readers.

Direct projections can omit keys, duplicate or reorder flattened physical lanes.
Output is scalar, without source INLINE arity maps. Each cursor retains its
snapshot boundary and owner capability across lazy segment changes; callers may
release snapshots and retire trace owners after construction. Existing reference
snapshots can construct and run producers after intern owner retirement, while
external stores must remain open for future lazy segment acquisitions.

Pending STRING output borrows the producer's retained capability. A sink retaining
independent output must capture its own intern pin before acknowledgement and
before intern owner retirement. After intern retirement that capture fails CLOSED;
the pending batch remains frozen and its borrowed IDs remain readable until
producer disposal. Retrying a frozen output does not reread segments. Successfully
captured output survives producer/input/intern-owner disposal through its own pin.
These are explicit internal consumers, with no automatic mutable-session routing.

### Signed reference consumers and memory floor (#1372, internal)

`wl_columnar_payload_join_create_weighted_reference_trace_projected_bounded`
accepts two immutable reference snapshots;
`wl_columnar_payload_join_create_reference_delta_trace_projected_bounded` accepts
an eagerly pinned reference delta payload and a lazy trace snapshot. Both reuse
the same complete provenance/schema validation, bounded window index and direct
scalar projection engine. All logical coordinates must be zero; arbitrary signed
int64 weights, including zero, emit checked matching products without consolidation.
Overflow discards only the current private batch; earlier acknowledged output
remains independently owned. Pending output and fresh intern-pin admission retain
the ordinary reference consumer contracts above. These APIs do not route legacy
differential arrangements, which retain their existing metadata semantics.

Tests interleave producers pinned before and after insertion, full cancellation
and reinsertion, comparing resolved strings, types, exact contributions and
independent weighted state sums. Both snapshot and delta variants cover MIN/MAX/zero
weights, nonmatching overflow avoidance, complete nonmatching logical-time refusal,
late I/O/cancel/store closure, frozen retries and private-batch overflow versus
previously acknowledged output. Direct projections retain scalar output semantics.

The reference causal fixture uses the same 65,536-byte allowance, four-string
vocabulary, three segments, schema/history, 127-row index cap and 256-row output
capacity. Keeping both original 512-row governed sources causes genuine JOIN
admission failure; reference take frees those allocations and permits the full
signed JOIN plus independently pinned output capture/readers within the same
allowance. Fixed vocabulary/segment/cap comparisons at 128 and 512 rows per source
show equal producer/reader/index scratch, separately from retained outputs and
O(segments) metadata. Existing legacy allowances are unchanged.

A separate fixture first spills rows, then grows distinct intern strings. An
identical governed source allocation admitted before vocabulary growth is denied
after it; failed intern growth and source admission preserve earlier snapshots,
resolvable strings and credits. Intern growth may need replacement-allocation
headroom as well as its retained floor. Spilling rows does not reclaim intern
strings retained by live owners, so no general out-of-core guarantee follows from
successful row transfer. Owner/declaration/node/directory, output and intern floors
remain additional to the explicit index/batch caps. Automatic mutable-session and
differential routing, general logical time, SIDE/nested values and scheduling
remain follow-up work; this group does not close #1372.

### Signed trace and delta consumption (#1372, internal)

`wl_columnar_payload_join_create_weighted_trace_bounded` joins two snapshot
prefixes. `wl_columnar_payload_join_create_delta_trace_bounded` joins a numeric
payload delta against a snapshot, retaining the delta reader eagerly. Both use
the same production window-index/continuation engine. All records must have zero
logical coordinates; matching pairs emit checked signed multiplicity products,
including zero. Negative records are contributions, not physical deletions.
There is no consolidation, timestamp stripping or general logical-time support.
Storage generation identifies a committed prefix and is not logical time.

A producer retains its original snapshot across later insertion/retraction
appends. New snapshots observe the new contributions. Overflow discards only the
current private batch, leaves already acknowledged output visible and becomes
sticky. Frozen output survives sink retry without additional input reads.
Trace owner retirement and external store retirement retain their distinct
contracts above. Producer operations over different trace owners sharing a store
remain serialized; this is not a global spill-store concurrency guarantee.

Tests interleave six consumers across insertion, full cancellation and reinsertion
generations, comparing exact signed contribution multisets and independent sums.
They cover both trace and delta input modes, zero/MIN/MAX weights, unmatched
potential overflow, partial-batch overflow, surviving prior output, complete
logical-coordinate refusal, failed-publication retry and cleanup. Segmented
build tests exercise the 256-action clear/build quantum and cancellation.

A paired workload uses the same 1,025-row mixed history and 65,536-byte allowance.
Keeping its two governed source chunks causes real JOIN constructor MEMORY;
transferring them to spilled segments physically retires source rows and lets
the entire signed JOIN complete. With the same three segments, schema and caps,
257 and 1,025 rows require identical constructor scratch. O(segments) directory
and node floors are measured separately by trace storage tests. A below-floor
JOIN refusal preserves a previously opened snapshot cursor and succeeds after
restoring admission. Input-transition, snapshot, reader, index, producer, output
and retained-output floors remain additional; arbitrary-budget completion is
not promised. No automatic mutable-session or legacy differential-arrangement
migration, SIDE/nested support, or #1373 scheduling is introduced.

### Follow-up scope after #1372

The sealed scalar numeric/STRING and declared flat INLINE field JOIN/projection
subsets now have actual persistent cold storage,
resident reclamation and evaluator consumers. General cold VARIABLE access beyond the audited scan/JOIN pipelines, mutable relations and automatic persistent trace/differential arrangement
integration remain separate work beyond the explicit numeric snapshot consumers. They require stable
identity/generation and pin/cleanup ownership across updates, signed differences
and retractions. Unsupported consumers remain explicitly ineligible for sealing.
SIDE/nested-reference ownership also needs a concrete provenance decision.

Public advanced configuration and explicit sealing are now available for the
subsets above. Broader consumer support and native platform qualification
remain evidence-dependent.
Existing payload and sealed-session evidence cannot replace those acceptance
requirements. Issue #1372 was closed after the chunk-loading group merged;
these broader capabilities remain explicit follow-up scope. #1373 scheduling
and #1385 DOOP qualification remain separate.

The #1821 controlled prefix-discovery consolidation optimization introduces no
additional owner or allocation. Its suffix sort and prefix merge reuse the
existing two row-index arrays, scalar source lease, private output batch and
cleanup continuation. A partial suffix sort never exposes uninitialized prefix
slots: the final merge represents the prefix by its original row indices.
Session qualification covers retained work-limit resume, cancellation retry,
insert/remove cycles and zero governor reservations after checked destruction
and release of the evaluation control and plan (including governed intern storage).

### Controlled ordinary JOIN registry image (#1821, G3b)

The general STEP transaction owns a separate registry image and ownership slots.
Metadata is copied; existing native arrangements are borrowed without copying
reservation tokens. New or invalidated indexes are separately admitted and
owned by the image. A session registry claim excludes raw get/pin/grow/free
until the image drains. Any old pin, pending transaction, deferred invalidation
or aliased arrangement prevents replacement. Source snapshots and entry
generations are revalidated before the common head/registry publication cutoff.

Registry admission includes an upper bound for all copied JOIN metadata. Before
publication, a RESERVED-only trim refunds never-allocated slack through a
retained one-CAS receipt, then commits exact array-plus-metadata credit. It does
not reuse the COMMITTED downsize contract for physically retired storage.
Abort drains a claimed trim before releasing credit. Publication transfers
canonical tokens without allocation or reclamation. Retained retirement frees
arrays, keys and descriptors before refunding their credits and governor refs.
Separate array/metadata accounting remains compatible with raw registry growth.

### Controlled append-delta ownership

The observed acyclic append host retains original source/head readers while
copying the proven input suffix into a governed private relation. Exact child
bindings borrow that relation until cleanup ACK; no delta-right index enters
the public full-source arrangement registry. The governed source map also records
append occurrences with a mode-specific marker. Exact current-child range and
alignment checks precede decoding; recursive head encodings are never interpreted
as append markers. A whole-host charged degree proof precedes plan changes, and
partial maps remain inactive on nonlinear fallback. Old-head union slots stay
zero and therefore retain their full-source reads. Combined metadata admission
failure remains ENOSPC; map malloc failure remains ENOMEM. Both drain admitted
ownership without publishing heads or advancing the pending input boundary.
Two additional operator slots per
head are admitted with the host metadata for prior-head union/consolidation.

Any precommit stop after append eligibility begins drains the private host
transaction before reset/retry; consumed work is not refunded. The published
heads and pending input boundary remain unchanged. Private delta storage retires
through the scalar retirement protocol, including after successful cutoff and
on checked destruction. Cleanup uses maintenance funding only after evaluation
has stopped; it never computes missing contributions or replays observer events.

### Controlled recursive frontier ownership

Each qualified head owns its prior accumulated relation, candidate, current row
frontier and next row frontier separately. Round zero has no owned frontier;
its exact source override borrows the source head's empty prior relation.
Later empty frontiers are real owned relations, never a request to fall back to
full input. Child generation/plan/attempt authorization and frozen snapshots
protect the exact occurrence through cleanup ACK.

The transaction reserves a parallel uint32 source map for every private operator
slot, including the old-head union tail. Allocation is governed and initialization
advances in at most 64-byte charged regions. Zero means full input; a checked
one-based head index selects the referenced SCC frontier. Tail slots remain zero.
Bindings and child generation are authenticated before integer range/alignment
checks identify an exact current-head operator slot. The complete charged degree
audit precedes frontier plan changes; a nonlinear body ignores partial map entries.
Allocation, zeroing and audit preparation may retain progress on work limits;
the sticky whole-host abort policy begins at frontier plan preparation. The map
retires with transaction metadata and owns no relations.

A qualified scalar-source lease constructs each schema-preserving next frontier
and drains lexically before the constructor action returns. The transaction
retains any published constructor output. A two-pointer private set difference
charges comparison and cursor/gather actions in four-unit regions, gathers one
INT64 cell per action into the new frontier's row scratch, then uses the
qualified controlled append with its documented scratch alias contract.
Existing constructor/append admissions cover width-dependent work and retain
their allocator and cleanup cooperative boundaries and error distinctions.

Once frontier plan preparation starts, any later precommit work limit aborts
and drains the whole private host transaction, even in a downstream stratum.
Reset/retry starts a new attempt without refunding consumed work. Cleanup
resumes a pending scalar retirement before switching owners, and enumerates
prior/current/next owners exactly once. Public heads remain unchanged before
cutoff; private row frontiers retire before successful publication. Maintenance
funding only retires ownership and never constructs missing results.

### Declaration-derived INLINE source layout (#1372)

Parsed execution plans own name-less logical compound declarations alongside
packed physical lane types. Ordinary sessions initialize flat INLINE source
metadata before loading facts or accepting host rows, including empty numeric
inputs. Logical layout scratch and retained relation metadata are governed;
failed initialization releases partial source allocations. Field projections
produce scalar outputs even when their width equals the source physical width.

Original nested/whole-compound body uses are recorded separately before lowering
loses that information. This summary restricts future cold eligibility, not
ordinary source initialization or existing resident evaluation. The declaration
record alone does not prove that a consumer supports a flat field view. SIDE
and mixed SIDE layouts retain their existing initialization behavior. Flat INLINE field consumers use this provenance as described below.

### Flat INLINE cold field consumers (#1372, partial)

The same bounded projection and JOIN paths now accept real declaration-derived
flat INLINE sources. Preflight compares logical kind/arity/offset/functor and
all physical lane types with the initialized source. The source must have an
owned plan declaration and no original unsupported body use. Nested/whole-value,
wrong-functor/arity and SIDE consumers remain ineligible even when lowering
would otherwise resemble a scalar projection. Missing declarations, invalid
functors, mismatched layouts and invalid STRING IDs refuse before retirement.
Runtime rechecks every binding against its originating declaration capability.

Capture copies semantic declarations into the payload and pins the originating
intern table, including numeric-only INLINE sources whose functor is the only
reference. Reordered/extracted output lanes keep their scalar types and do not
inherit the source arity map. STRING child keys use the same intern-identity
rule as scalar STRING JOINs. Both input directions, both-cold/self JOINs,
resident intermediate chains and independent scans share this contract.

Tests use parsed STRING-child declarations and automatically initialized source
metadata, with empty/Unicode values, physical raw inserts, multiple logical
INLINE groups and actual typed public output. Malformed layout/provenance and
allocation/write/read/cancellation failures preserve source/prior bindings and
refund private work. Numeric-only INLINE explicitly retains functor capability.
Fixed-intern/schema two-cardinality checks retain bounded JOIN scratch; paired
retained-source controls prove projection and one/two-owner JOIN reclamation.
Intern/declaration storage, resident output and intermediate floors remain.
The program must still outlive public sessions; no public lifetime shortcut,
whole compound reconstruction, SIDE or nested-handle ownership is introduced.

### Chunked immutable session inputs

`wirelog_session_begin_cold_input`, `wirelog_session_append_cold_input` and
`wirelog_session_finish_cold_input` load an initially empty declared scalar or
flat INLINE EDB without first retaining its complete rows. This route supports
ordinary MAP/FILTER scans and audited equality JOINs, including scan
prefixes, left/right/both/self and chained consumers. Finished traces, existing
sealed payloads and resident opposite inputs share the bounded JOIN engine;
trace inputs are never materialized as a full resident relation. Each side
independently pins its reader, including self JOINs. Populate other resident
inputs before beginning: successful begin freezes ordinary mutation, while
additional empty loaders and preloaded payload sealing remain available.
Evaluation refuses pending loaders without closing their finish/retry window.
Session destruction releases incomplete loads.

STRING lanes must originate in the session program's intern table. Every lane,
including unused fields, is validated; coincident foreign integers cannot prove
provenance, so originating IDs remain the caller's responsibility. Flat INLINE
loads preserve the exact declaration and functor capability, even if all child
lanes are numeric. Whole-compound, SIDE and nested uses are refused before
publication. Program lifetime still extends beyond session destruction. Intern
strings stay resident: spilling row lanes does not reclaim their table.
Read-only owner queries let pending loaders audit their retained declaration
without admitting a snapshot directory or exposing unfinalized rows.

Each append borrows one host buffer, admits a governed temporary relation and
spills/transfers it into one immutable segment. The host buffer is outside the
governor and is not retained. Owner, per-segment nodes, transition scratch,
reference declarations/intern storage and the final O(segments) snapshot directory
remain real floors. Append failures keep the prior prefix; finish admits the
directory before publication and is retryable. The scan output still reserves
full input-row capacity at its projected width, including rejecting filters:
bounded ingestion does not imply arbitrary-budget scan completion.
Legacy `seal_input` retains single-payload storage and reader costs, with only
the fixed shared cold-binding descriptor increasing for explicit trace state
(168 to 200 bytes on the measured 64-bit build, +32 bytes per binding).

The public causal fixture uses the existing minimum 256 MiB configured budget
(255,013,684 usable bytes after policy headroom), 40,960 rows of 1,024 INT64 lanes,
and 256-row chunks. Raw source lanes total 320 MiB, exceeding the configured
budget. One reused 2 MiB caller buffer is explicitly outside the governor. A
16 KiB JOIN batch and 4 KiB index cap admit the real wide intermediate row; the
encoded spill-row cap is 8,216 bytes, including 24 bytes of metadata. The JOIN
returns four exact tuples. All-resident insertion of the same data under the
same budget refuses admission; the chunked public load/finish/JOIN completes.
A full-width scan of the same loaded data separately refuses its output floor.
No test lowers the public policy minimum or changes a live governor limit.

The matching internal causal control retains actual governed source chunks
instead of transferring them. On the measured 64-bit build it refuses at 13,568
loaded rows while holding 112,017,408 bytes of source storage. Releasing those
chunks permits append retry and the same JOIN completion under the unchanged
limit. The transfer path peaks at 138,410,604 governed bytes, including session
creation (134,692,940 bytes before beginning), loading, readers and final output;
finished input ownership uses 136,089,444 bytes. These are platform measurements,
not portable ceiling assertions. The 160 segments occupy 337,187,840 spill bytes;
the separately reported trace floors are 4,304 owner bytes, 20,480 node bytes,
1,400 directory bytes and 112 bytes per cursor, with binding/payload/schema,
reader, intern and output ownership additional. Cleanup returns all reservations.
Reference tests independently exercise admission and write failures, invalid
unused STRING lanes, declaration/functor mismatch, pending/finalized pins and
retry without losing the prefix. Broader mutable/differential session routing,
logical time, SIDE/nested consumers and scheduling remain outside this group.

### Streaming cold global COUNT

An ordinary serial immutable input may feed direct global COUNT after an audited
direct-column MAP / INT64 literal FILTER prefix. The aggregate decoder is
separate from cold scan eligibility. It reads a payload or finalized trace
through the existing bounded reader, validates ordinary metadata even on
filtered-out rows, and counts physical rows without pre-consolidation. Empty
or all-filtered input produces no row, matching resident REDUCE semantics.

The prefix is not materialized. Attempt scratch is the predicate array plus
one reader/cursor and a private one-row INT64 result, independent of source
cardinality; trace node/directory and intern costs remain additional. Read,
admission, allocation or stack-publication failure destroys private ownership
and leaves the immutable source reusable. Only complete results enter the
evaluator stack. Existing projection/JOIN prefix output floors are unchanged.
Grouped COUNT accepts direct INT64/STRING scalar keys, including scalar fields
of validated flat INLINE input. A private hash index starts with eight buckets
and doubles before exceeding half occupancy. Collision lookup compares every
key lane. Index reservations cover old and new storage together during rehash;
private result growth is admitted separately. Row ordinals survive output
relocation. With fixed groups, attempt state does not grow with input rows.
Group cardinality still has a resident index/result floor; refusal discards the
whole private attempt and preserves the immutable source for retry.
Direct INT64 SUM/MIN/MAX use the same streaming path and group ownership.
Operand lanes resolve through the audited prefix; expression, operand and result
domains must agree. MIN/MAX initialize from the first surviving value. SUM uses
checked addition in source order, including across segments, and returns ERANGE
on intermediate overflow even if the mathematical final sum would fit. Zero
sums still produce a row; empty/all-filtered inputs do not.

The shared public-budget experiment uses a 2 MiB host chunk to load 320 MiB of
physical lanes under a 256 MiB budget and produces four exact SUM groups.
Resident insertion and full-width materialization refuse under that same
budget. Retaining actual governed input chunks also refuses; releasing those
owners permits retry without raising the limit. Trace segment/directory storage
and resident intern storage remain separate from aggregate attempt state.
Expressions, FLOAT/AVG, recursive/signed/control aggregation remain ineligible. The later streaming
JOIN-reduction route has its own admission contract. High distinct-group cardinality can still exhaust the
resident index/result budget.


### Composite cold JOIN keys (#1372 follow-up)

Explicit sealed and chunked inputs support two or more INT64/STRING equality
pairs, including mixed tuples and scalar fields of validated flat INLINE
inputs, through the existing ordinary bounded JOIN producer. Every pair must
match; hash collisions only select candidates. Reordered and repeated key
positions are valid. The constructor copies its two key vectors into one
separately admitted O(key count) allocation, so caller arrays need not survive
construction. One-key factories retain their existing hashing and ordering;
automatic all-resident spill selection and weighted factories stay single-key.

The capped bucket/link index still covers a bounded right-row window. No
full-input tuple index or per-row hash cache is introduced. Source readers,
key metadata, batches, resident prefixes and results remain governed floors.
An intermediate that exceeds the configured encoded-row cap is refused; a
small source does not waive this real row-width requirement. STRING and INLINE
sources require their exact originating intern and declaration capability,
including empty inputs and projected-away reference lanes. Corresponding keys
must have matching physical types; IDs are compared without remapping. Legacy
numeric factories still refuse all reference-bearing input schemas.

The admission audit and execution share resolved key positions, including
virtual col<N> names on fresh declarations and chunked bindings. Composite
rules permit the audited direct MAP/narrow INT64 FILTER prefix and suffix,
including later JOINs. Computed MAP tails retain their previous behavior for
all-one-key rules only. Source retirement occurs only after complete consumer
validation; invalid later keys and unsupported consumers preserve their owners.


The measured 64-bit producer descriptor grows from 280 to 288 bytes for the
optional key pointer, including legacy calls. Composite metadata is a 96-byte
header (including its 88-byte reservation) plus 8 bytes per equality pair:
112 bytes for two pairs, 120 for three. Runtime construction also temporarily
holds 8 bytes per pair for resolved column indices; these are released after
the producer copies them. These costs are additional to reader/index/output
floors. With two keys, a 116-byte three-row index cap and a 24-byte output batch,
reference trace self-JOIN construction reserves 2,693 bytes at both 64 and 256
rows. Both cases contain eight segments; their separately charged source owners
are 5,408 bytes. This measures constructor scratch, not total output memory.

The public composite fixture loads 40,960 rows of 1,024 INT64 lanes (320 MiB raw)
under the unchanged 256 MiB configured budget (255,013,684 usable bytes). One
reused 2 MiB host buffer is outside the governor. Every row shares the first
key; the second selects four exact output tuples. A 4 KiB index cap and 16 KiB
batch cap are used, with the actual wide encoded-row cap set to 8,216 bytes.
Chunked load/finish/JOIN succeeds; resident insertion of the same rows refuses.
A full-width scan remains a legitimate output-budget refusal under that limit.

The internal retained-chunk control uses actual governed row owners: keeping
53 chunks (112,017,408 retained bytes) refuses the next append at row 13,568.
Releasing those owners permits retry, completion and the same four-row JOIN
under the same budget. The unretained case loads all 160 segments; measured
base/loaded/peak reservations are 134,693,376 / 136,089,880 / 138,411,040 bytes.
The retained control peaks at 253,187,814 bytes. Disk use is 337,187,840 bytes;
trace owner, nodes, directory and cursor floors are separately 4,304 / 20,480 /
1,400 / 112 bytes. Values describe this build and fixture rather than universal
minimum budgets. Intern storage, resident intermediates and high-cardinality
results remain independent floors. Except for the single-JOIN reductions below,
aggregate-over-JOIN, automatic all-resident composite spilling, weighted composite APIs, SIDE/nested layouts and mutable
arrangements remain outside this group.


### Streaming COUNT and extrema over one cold JOIN (#1372 follow-up)

A serial immutable rule containing exactly one equality JOIN can feed global
COUNT or direct INT64 MIN/MAX without retaining the complete joined relation.
Both global and grouped forms are supported. At least one input must
be explicitly sealed or chunk-loaded; existing INT64/STRING composite keys and
flat INLINE scalar fields keep their full-source provenance requirements.
Direct post-JOIN MAPs and narrow INT64 literal FILTERs stream into the reduction.
Physical matching pairs remain distinct even when MAP duplicates lanes. Empty
or all-filtered streams produce no row, matching resident REDUCE.

The sink admits constant counters and O(filter count) predicate storage in
addition to the existing producer batch, index, reader and key floors. It
acknowledges only complete private batches; any failure ends that attempt and
publishes no partial aggregate. Temporary reader pins are dropped before source
owners; persistent cold input can be reused by a fresh evaluation. The final
one-row result remains governed. Pre-JOIN prefixes still materialize under
their existing source-row capacity floor.

Raw pair counts, including filtered-away pairs, retain the existing JOIN cap
and UINT32_MAX representation ceiling. Peak reporting measures raw pairs,
not reduced rows. This does not allow arbitrary-budget completion. SUM,
FLOAT/AVG and multiple JOINs in a reduction rule remain outside this group. In particular, checked SUM overflow depends on
input order and is not interchangeable with bounded window traversal.

Group keys are direct INT64/STRING lanes, including validated scalar INLINE
fields, and every key participates in equality. Output positions and types
match resident REDUCE. MIN/MAX initialize from the first surviving operand,
including INT64_MIN/MAX; empty/all-filtered input never emits a zero sentinel.
A declared but absent right EDB contributes its schema to validation and an
empty result, without constructing a fake relation. Existing non-reducing
JOIN missing-right typing is unchanged.

Before each batch, the private reducer admits index and result capacity for
current logical groups plus that batch's maximum possible new groups. Capacity
is reused rather than enlarged from cumulative pair counts. The index begins
with eight buckets, maintains half occupancy, and admits old and new tables
together during rehash. This conservative group-plus-batch floor can refuse
where exact per-batch deduplication would fit; it is not an exact-distinct-only
memory promise. Mapping, tuple, type and mutation-lease state are also charged.
Append allocates no storage; an unexpected partial-update failure poisons and
discards the entire private attempt. A failed batch is never replayed into
partly updated groups. Tests cover late reserve/read/update failures and fresh
retry, collisions, type/position preservation and high-cardinality refusal.

The dedicated public experiment uses two 512-row, 65-lane cold inputs and a
16,640-byte reusable host chunk. The generated JOIN retains 130 physical lanes
(no JOIN projection): 262,144 physical matching pairs would require 272,629,760
raw lane bytes (260 MiB), before relation overhead. Under the unchanged public
256 MiB budget, four exact COUNT groups complete. An internal test-only control
uses the identical producer/projection with the existing governed materializing
spill drain and refuses with ENOSPC. After complete private cleanup, streaming
succeeds under that same limit; this measures removal of the JOIN intermediate
floor, not merely source ingestion.

With a 16 KiB batch cap and a 1 KiB index cap, 256 and 512 rows per input
(65,536 and 262,144 pairs) both add 49,828 reserved bytes at peak in this build.
The final group index is 1,024 bytes, group relation ownership 1,675 bytes,
and reducer/mapping workspace 808 bytes in both cases (the peak also includes
producer/readers and temporary growth). Source baselines are separately
134,708,009 and 134,724,201 bytes; owned spill
usage is 283,200 and 566,400 bytes. Both inputs saturate the same bounded index
window. These measurements are fixture/build-specific; intern storage,
pre-JOIN prefixes, reader/key state, distinct groups and final output remain
independent governed floors. Dedicated default/unit/TSan budget registrations
run serially outside the duplicated regular/environment tests.

## Automatic ordinary JOIN receipt storage

The framed serial driver allocates its logical cleanup frame as the first
member of a private allocation that also owns automatic JOIN receipt storage.
The receipt remains at its final address outside the logical frame and numeric
child extents. The installed API and the manual prepared receipt layout do not
change. Governor admission, reserved-byte accounting, zeroing and physical
release use the complete allocation size. Logical-frame geometry and allocation
size are separate internal test observations.

On the native LP64 test build the logical frame is 11,440 bytes, the private
tail is 480 bytes and the allocation is 11,920 bytes; the prepared receipt is
392 bytes. These are observations, not cross-platform constants. Original
frame construction still charges 224 per actual 16-byte zeroing chunk, with
the existing constructor tariffs. Two native identity anchors are installed
inside the existing EXTERNAL admission, without another registration fee.

An automatic lease holds an additional reference to the actual launch grant.
The session retains its own completed grant and pending result while distinct
maintenance grants perform preparation, drain, FINISH and ACK. Marker ACK alone
does not release the launch grant: successful checked parent consumption releases
the native reference, followed by the session's reference. A refused consume
retains both owners. Physical frame release refuses a held launch or busy native
adapter. Request and reply output geometry protects the complete known allocation
even while its receipt is dormant.

After native selection, copied keys exclude that frame's complete allocation
through ACK and FINISH, including while a lawful nested frame parks the owner.
Binding getters validate the supplied numeric owner before normalizing their
output, so a parked-owner refusal leaves its dormant receipt untouched. The
pre-native constructor may still initialize its embedded cleanup key. Session-only
receipt reads protect the current active allocation; they do not derive an
arbitrary parked allocation from a receipt key.

The private tail also records one immutable binding pointer and generation for
the framed numeric child's lifetime. Its first paid BIND validates the complete
STATIC header or actual registered dynamic transaction while the original
generation is current. Later JOINs compare the saved pair; they cannot refresh
it after the original ends. The existing child/transaction keeps binding storage
live; the snapshot acquires no extra resource. Actual numeric ACK clears the
pair before parent consumption can release the containing owner.

An ended-original STATIC owner may use the authenticated native error cleanup
entry under a fresh numeric HOST allowance. It checks actual frame, child,
binding and consumed current-JOIN history on every action and performs no new
data work or original/successor poll. Failed publication begin can leave either
initial INERT storage or a previous JOIN's terminal ACKED receipt; both use the
remaining generic disposer, while genuine current ACKED publication history
retains typed FINISH. Terminal receipt ownership follows the real ACK transition,
whose existing full owning-field checks remain intact.

Native cleanup ACK retains full source unbinding and meaningful record/reference
release. It omits the whole LFTJ clear only for the constructor-owned framed
child that has never acquired LFTJ identity or active metadata. Generic ACK keeps
that clear. Actual mixed LFTJ-to-JOIN plans retain the fully validated generic
route. Dynamic cleanup with its original generation still current is covered;
ended dynamic outer transaction/admission cleanup remains required separately.

## Host source inspection memory (#2321)

Source inspection reads the resident source rows that inserts already store
-- a rule head's `$in$` seed shadow or a plain relation's own rows -- and
keeps no ledger, mirror or index of its own. A query allocates nothing,
reserves nothing through the governor, and does not clear budget-denial
diagnostics: it compares columns in place with O(1) auxiliary state, for
O(min(rows, max_rows) * width) work on an exact count and
O(min(rows, max_rows)) on a key query, plus metadata and name lookups.
Origin certification is one owned copy of each host-only relation's name,
captured once when the session is created, independent of history size.

`tests/test_easy_source_inspection.c` records the evidence. After histories
of 2,000 and 40,000 inserted rows (half removed again, with evaluation in
between), a count and a key query make no `malloc`, `calloc`, `realloc`,
`aligned_alloc` or `posix_memalign` call on the querying thread (the scan
runs synchronously there) at either scale, counted by interposing those
functions in the test executable (glibc, unsanitized builds), so the queries
allocate no transient heap state through them. The governor's reserved bytes
and, where `mallinfo2` is available, the allocator's in-use bytes also change
by exactly 0, while the exact count still matches the history.

### Private scalar-copy constructor cleanup and source funding

The selected scalar-copy constructor retains initialized storage, its three
real reservations and saved governor reference when forward construction
stops. Each independent192 CONSTRUCTOR_END action disposes one physical
constructor item or retires the saved reference. Refunding an admitted token
requires a separate121 check before its native operation: total313 progresses
one token, while312 consumes192 and preserves its credit, flags and phase.
The complete containing source is at most240, including the Windows C11-thread
hybrid; real checks split it into intervals of at most133. The last physical disposal
precedes token credit, and the saved reference is released last. Original END
and a live successor do not supply cleanup work. A committed17-byte peer
remains owned and unchanged until its own physical free and release.

The selected SOURCE protocol uses private phase/tail/verdict checkpoints and
`charge_attempt` with the immutable original attempt ID. Ordinary `charge`,
its locked body and mutex fronts have no controller-interior exemption.
The ADMITTED checkpoint keeps its original hook, getter, guards and zero check
in the owning reserve body, removing six actual forwarding/return operations.
Prices, work labels, native order and cumulative admitted reports are unchanged.

Only this selected constructor qualifies reserve caller160: complete current81
includes all three ordinary `ref_get` body operations; one-use terminal78
gives159. Completed typed OVERFLOW instead uses current83 and terminal28,
giving111; it does not also execute the maximal restored-error continuation.
Each arbitrary ROUND164 pays its own complete retry work. The terminal share
is used once per owning invocation, including ENTRY's seven source cells;
it is never renewed by a retry. Commit caller128 pays current80, bootstrap11
and one-use36, giving127. SOURCE100 alone does not qualify the MSVC frontend,
and these selected caller shares do not qualify generic capture caller80.
No current margin is refunded or reused.
The owning-TU original-restoration credit helper preserves the initial counter
observation and CAS ordering, including expected-value refresh. Its typed64
MSVC CAS removes generic width forwarding without excluding its ordinary
fronts or first iteration. Credited restoration including its caller fits64.
At the dominant ROUND admission, actual remaining source is235 minus the
three already evaluated call fronts, plus the compatible caller error suffix3
and both actual constructor/copier ancestor suffixes18:253, within256.
The live BUILD192 action separately pays its complete120 source, including
those18 ancestor cells. Successful and typed-result histories have their own
suffixes; no maximal error bank is added to an incompatible success suffix.
Whole source funding and actual unprocessed source are distinct from an entire
nominal fee or fee-minus-completed-work calculation.
Generic release/refund helpers and unrelated capture callers need their own
complete first-iteration source proof.

Selected output retirement uses PREPARE192+192 per finite native turn and
STEP256 plus the reached existing native1 or64 charge. Complete PREPARE
source is at most360 under384 admitted work; its longest actual interval
is246. Its child admission retains only57 one-use parent source, giving249
actual live obligations. A CREDIT turn can have whole source258 while the
actual64 and saved-ID zero checks split its intervals, with320 admitted
work. Whole source, between-check bounds and simultaneous unfinished source
are separate checks. Shared primitive prices and native validation remain.

The issuer creates flat no-timestamp output and never installs a ledger
before TAKE. The generic payload phase21 remains present, but a future
legitimate issuer reaching it needs576 plus new containing source evidence;
current512-driver tests establish no such positive. This qualification does
not enable the pending registered cache owner, default materialized driver,
strict/shared caps or general transaction intersections.


### Admission-owned private SOURCE bank

A controlled public session creates a sealed financial BANK after attaching
its original controller and before backend construction or evaluation BEGIN.
This is a narrow pre-session construction boundary on both success and failure:
only the fixed holder/two private lanes and their rollback are included. It
covers no backend traversal or later engine work and does not reuse the
read-only13 exception. A failed birth leaves the output NULL, unwinds only its
real lanes and detaches the original. Raw sessions create no BANK.

The opaque class exports neither its controllers nor their saved IDs. Actual
phase BEGIN/charge/FINISH/report operations remain real. Each successful charge
updates an exact private sum checked against all seven report fields. Only a
closed, fully reported, callback-free private lane can rearm; original and BODY
controllers retain their monotone ID contract. The external owning handle slot
must stay at its constructor address through destruction. Context storage is
zeroed, exclusive, disjoint external storage and is never copied or retained
across public activations.

The production destruction lifecycle admits256,24,160 (440 total), independently
of its configured capacity768. Its disjoint source ceilings are255,20,141;
actual between-check ceilings are235,20,20,141. Before its third positive at
least189 source cells have executed across the five supported atomic/thread
profiles, so admitted but unprocessed slack is at most251. FINISH/report and
physical free are not checks. Controllers detach/release before BANK free;
its owning admission slot is cleared before the admission itself is freed.
Existing qualified mandatory backend/extension retirement keeps its scoped
contract. These prices do not qualify other callbacks or public queries.

The common BANK phase finisher checkpoints its still-active saved generation
immediately before FINISH. A refused positive payment leaves that same phase
active with a sticky financial stop; the zero payment preserves its diagnostic
and leaves both consumed work and the private charge journal unchanged. The
four ordinary call fronts fit the existing finisher ceiling31: its prior
literal body23 becomes27. FINISH and REPORT remain ordinary settlement work,
not checkpoints. This narrows the settlement-to-caller interval without
exporting a controller, changing a positive fee, or granting native authority.
The lexical runner's remaining settlement, unbind, unlock and caller return
fronts are bounded by48 after this check. A containing caller still needs its
own bound; the cut alone does not qualify a Snapshot loop or a native action.

The reusable internal runner requires a separately source-qualified private
immutable policy and bounded SOURCE-only action. Positive fees no larger than
256 and finite capacity alone prove no source fit. Complete caller/context,
rearm, action, FINISH/report and return source, rejected branches, promise
lifetimes and slack must be established for each real integration. No arbitrary
BODY/user callback, PENDING loan or native mutation authority comes from BANK
finance. This foundation does not enable the unfinished ordinary recovery,
materialized compiler driver or policy/cap acceptance paths.

The synchronous lexical runner keeps its canonical context on its own stack,
binds the lane under the bank mutex, and clears that association after actual
phase settlement before returning. Existing external contexts still exclude a
lexical activation on the same lane; reentry cannot replace an active context.
It preserves separate financial/action results, including a constructor that
was called and failed, and exports no private controller or ID. This removes
the separate context-begin/run/end prefixes for future synchronous issuers.
It does not supply a production policy: the actual caller, first/unused,
action, late/close and repeat source/slack still require qualification. Kernel
test prices exercise lifetime and failure handling only.

### Generation-bound controller completion

The internal `wl_evaluation_control_begin_attempt()` sibling returns the exact
new generation copied before releasing its BEGIN mutex. Structural failure
returns ID0. `wl_evaluation_control_finish_attempt()` checks the attached owner
and expected generation under that same controller mutex. It distinguishes
finishing its own active generation, observing that generation already ended,
and a different generation. A different generation exposes no report and
changes no state; it does not prove that a successor is alive. A matching
ended generation returns its original seven report fields, ignoring later
execution/cleanup arguments. Protocol status is separate from `report.result`,
which is readable only when `report_valid` is true.

FINISH does not poll cancellation. Cancellation after a final zero check stays
for the next BEGIN/charge; an old footer cannot poll, debit or finish a live
successor. Existing generic methods, error/stop precedence and monotone IDs
remain unchanged. The host retains the live controller and stable attached
owner, drains workers before FINISH and serializes session/native mutation.
The new methods serialize controller transitions, not native execution.

Both new method bodies are ordinary source, outside the exact-nine qualified
interiors. Conservative complete-body ceilings are65 for BEGIN and114 for
expected-ID FINISH, including result construction/copies/returns, portable
mutex bodies9, Windows bodies6 and full reached MSVC exchange fronts. These
are local bounds, not tariffs or composed caller/check intervals. The same
corrected native convention gives the BANK lifecycle above actual payer
ceilings224/15/132 and intervals209/15/15/132, within its documented larger
ceilings and unchanged256/24/160 admissions; processed lower189/slack251
remain valid. No future CURRENT payment finances already executed BOOT work.

This additive protocol has no new production consumer. Public STEP/Snapshot
adoption, complete caller pricing and all remaining ownership/materialized/cap
acceptance require their own integration and validation.

### JOIN host SOURCE ownership and native error retirement (#2297)

Configured ordinary serial JOIN hosts construct a local SOURCE financier through
an admission-owned BANK. Its constructor performs only financial creation,
attachment and BEGIN. The record stays at its original stack address; neither
its control nor its saved ID is stored in a native frame, transaction, pending
receipt or TLS. TLS carries only the admitted session, admission and lane.
Financial permission never replaces native frame/context/thread/source/key
validation. All metered shared JOIN work uses the actual saved attempt ID.

SOURCE construction uses BANK phases 248/88/104 and a private phase capacity672.
Host construction pays HEADER105, CLASSIFY100 and REQUEST140, then checks and
settles the actual financial report before BODY. A still-active unused gateway
phase pays81 before settlement; the fresh post-BODY phase pays LATE148 (frame)
or48 (no frame), first-birth170 (private binding) or126 (default), TUPLE72 and
CLOSE176. These are SOURCE fees, not extra semantic JOIN output or native grants.
The typed native cleanup dispatcher instead uses its own 2304 capacity and
separate checked phase reports. Its ENTRY140/GUARD80 and actual saved-ID zero
precede checked close. Original AUTO native-error ownership is unchanged.

Semantic completion has a separate private capacity240. ENTRY64, conditional
bootstrap report retirement96 and WINDUP80 settle before expected Original
FINISH. A fresh224 owns that actual saved-ID FINISH and its returned result;
checked private settlement/rebegin precedes fresh RETURN208. Refused financial
birth retains semantic completion debt without dropping native ownership. The
BANK-only public footer190/54/208 constructs no new controller and works after
process-wide controller identity exhaustion.

Controlled Snapshot constructs its final-address financier before any prior
retry disposal, Original BEGIN or callback. SETUP224 pays local payload and
reservation initialization, then real checked settlement/rebegin leaves zero
admitted work across native execution. Optional160 pays prior-disposal metadata
and/or Original BEGIN and also settles before native execution. The same dormant
private generation provides the real zero checkpoint on a false typed-cleanup
probe before the original wrapper. Outer saved-ID FINISH224 settles before a
fresh RETURN208; all post-birth exits retire only this private controller. At
most four financial attempts use one controller. Existing static admission and
preflight validation precede this constructor; local constructor costs do not
claim to measure the entire public admission path.

Actual native error recovery retains the producer/frame/receipt and its creator
thread until genuine ACK and cursor retirement. A foreign-thread retry cannot
mutate them. Snapshot callback END/rebind preserves the frozen Original report
and does not charge or finish its successor. An active successor prevents
try-destroy and preserves the owning slot. Financial-only bootstrap failures
retire only their authentic saved grant; they do not invent a native frame.
The existing fully prepaid Snapshot callback-batch cutoff and mandatory scalar
source retirement qualifications remain unchanged.


Snapshot-owned inner completion uses the preborn BANK directly with208/144/80
for SOURCE bookkeeping: pending-debt checks, authentic completed financial BOOT
grant retirement, and scalar metadata reset. It performs no Native action or
Original FINISH. Its real action result remains separate from financial status.
This branch creates no generic controller after callback delivery, so exhaustion
of controller identities cannot turn completion into an endless EAGAIN loop.
The synchronous evaluating loop checks its existing dormant private generation
before each probe; the selected-false fallback keeps its separate checkpoint.
The expanded metadata actor upper92 gives CURRENT142/144, total432 and unused
admission236; its return-to-loop upper76 fits CLOSE80. These are local
post-admission SOURCE bounds, not a qualification of static public preflight.

### Public C1 admission SOURCE boundary

An owning controlled single-worker session with configured JOIN batches and an
acyclic plan of at most32 strata selects financial admission reads. The cached
bit selects payment only; actual program, callback, source and Native eligibility
remain live predicates. Worker copies explicitly clear it. The locked quiescent
STEP gate uses208/96/96; Snapshot uses212/160/96 and reads its actual backend
state once. The actual typed-frame birth-before-child invariant also covers
FILTER, ANTIJOIN and LFTJ-containing numeric frames; this does not complete LFTJ
algorithm recovery or alter its qualified row-local MAP context.

The C1 getter bound76 plus its actor5 and financial surroundings50 gives131
under CURRENT160. Snapshot FIRST210 fits212. The compatible shortest profile
processes116+41+13+68=238 before CLOSE: the updated total468 leaves230, so the old
conservative lower206 must not be reused for this policy. Complete locked-gate
return77 and the admitted scope/fronts fit CLOSE96. On every successfully
admitted STEP/Snapshot, actual SOURCE TLS is installed before body validation;
the existing allocation-free BANK footer then bounds entry work. The resulting
gate-to-next-check interval is at most254. TLS is restored before end-step
arbitration on invalid backend/input/callback paths as well as successful ones.
These local gate/entry statements do not replace the separate static-read
callback qualification.

Controlled destruction drains the same finite owned observed transaction until
its existing disposal returns a genuine terminal status. The old16-turn cap
could abort successful32-head Snapshots. Each disposal still uses its actual
maintenance owner and existing bounded reader/retirement/refund actions; real
busy/identity/error returns propagate. No evaluation, Original reset or invented
receipt completion is introduced by draining the remaining cleanup cursors.

### JOIN static metadata and owner-read SOURCE seams

The C1 public host uses explicit SOURCE mode for STEP/Snapshot static metadata;
mutation and nonC1 routes select DIRECT before execution. A SOURCE error never
selects DIRECT. The scalar read class is208/96/80. Its callbacks inspect bounded
metadata rather than scanning a whole plan, operator list or expression: strata
advance one callback at a time, and separate callbacks inspect relation shape,
MAP geometry and the fixed supported expression. The acyclic single-stratum
arm skips the irrelevant recursive seven/eight-operator matcher using the real
is_recursive flag; this does not cache or widen Native eligibility. Payload
initialization, caller return/status branches and test-only fault fronts are
ordinary source, not part of an opaque callback fee.

Snapshot's actual post-admission state read uses208/160/80, followed immediately
by the existing190/54/208 no-op BANK footer. A separate no-op after the active
Original guard pays the outer financier constructor seam. Actual read errors
retain their semantic status; the error-return footer pays the admitted public
unwind without executing a direct read or a callback. The fresh-shape read runs
before canonical publication; its error frees the unpublished allocation.

All three retirement-entry guard callers use the unchanged read-only proof
through the existing208/144/80 metadata executor on C1. The full guard ceiling79
includes native thread equality, foreign staging readers and the actual saved
WORK report proof. Callback fronts5 make84; existing surroundings72 minus old
constructor23 plus84 and result reserve1 give134/144. This is not the40-action
read class. Its conservative short-called lower181 is kernel116 plus distinct
wrapper/payload/call7, BOOT13 and minimum CURRENT45, leaving432−181=251 unused.
Financial status and action_called are checked separately; the saved action
status survives the genuine no-op return footer. No Source result replaces
Native authority, Original status or cleanup ownership.

There are three real no-op entry seams: outer STEP after typed and old-AUTO
selected-false, controlled STEP after its busy check, and drive after its busy
check. Every guard lease also ends at its own real no-op before returning.
The tight ongoing Snapshot route counts both payload associations and the
actual attempt setter: postguard return3, begin-failure2, staging2, retry3,
first association5, successor initialization1, recursive selector3,
successor-mutation selector3, skipped preflight4, absent-step1, final association
and setter10, drive call4 and busy3 total44. Previous no-op tail48 plus44,
C1 flag1 and next no-op FIRST162 is255/256; the preceding positive208 owns93
performed units. The new drive cut to guard FIRST is48+178=226. The metadata
return-to-own-footer interval is below225 and its return fronts fit CLOSE80.
These active-route numbers do not price fresh allocation or successor reset as
an opaque44 action; those branches retain their actual reader, allocator and
existing transaction/retirement payers.

Fresh admission has three additional actual no-op seams: after successful static
preflight, before the optional general-shape read and its test hook, and at the
common successful point before canonical publication. Their complete selected
windows are238/228/251/227/233, including ten-field read payload initialization,
actual status/return fronts and test hooks. Snapshot preserves its short-circuit;
a read failure frees the unpublished descriptor and returns its exact status.
The fixed expression callback explicitly compares memcmp against zero; its
expanded ceiling33 remains within the40-action class.

A genuine completed successor transaction already has active unlimited
maintenance: CUTOFF constructs it before publication, then RETIRE/FINISH drain
ownership before complete/DONE. Its disposal connector uses a real saved-ID
maintenance zero after the existing maintenance lookup succeeds. Original BEGIN
stays outside SOURCE callbacks, and no new Original poll changes pending-denial
metadata. The successful BEGIN-to-maintenance-zero window is170, paid by the
preceding208; the failed-BEGIN return uses a real no-op and its shorter branch
window255. A maintenance-zero error retains the actual transaction/status and
executes the real return footer.

Only the genuine C1 complete/successor-mutation conjunction selects the three
additional disposal no-ops: after differential drain0, before committed terminal
release, and before maintenance FINISH. These flags select payment, never Native
authority. Existing owner/thread/reader/retirement and reservation checks and
actions remain outside callbacks. The selected connector windows are190,239,254
and242 through the final reset-entry no-op. The254 packet spends all eight
reserved source cells on actual metadata-credit done initialization, arguments,
call, result store and predicates. FINISH and REPORT are not work checkpoints.
An empty-head EAGAIN exit has a compatible194-cell DIRTY/public-end packet;
reserve8 gives202 within208, without combining incompatible getter/closing arms.
The no-transaction successor instead uses its own235-cell saved-local path.

After successful actual disposal (or the genuine no-transaction completion),
the old descriptor is inert. Its reset uses SOURCE metadata chunks of at most64
byte writes under existing208/144/80, with no Native action, Original transition,
resource destructor or user hook in the callback. The conservative actor84 fits
CURRENT134/144; actual short-called lower181 leaves at most251 unused. Loop
return/advance/next-FIRST is248 and final restoration/return-footer is239; the
single test-only TLS increment gives249/240. The preloop connector is245.
All saved semantic identity/active/id, observer/general and append fields remain
outside the cleared storage and restore before further Native use. Unexpected
financial/noncalled/action errors integrity-abort; no ordinary return exposes a
partially reset canonical descriptor. NonC1 keeps its original reset. Real
successor histories assert multiple completed chunks while retaining literal,
signed/raw, report and callback oracles; the counter is not a cost oracle.


#### Failed scalar-successor terminal retry receipts (#2299 / #1953)

`wl_columnar_controlled_step.failed_retry_*` is fixed metadata, not a private
storage capability. The real observed transaction records `closed_generation`
only at actual child terminal ACK or authenticated no-frame refusal. After all
private readers/retirements/arrays and reservations are closed, maintenance
prepays192 registration units and captures the owning session, operation/control generation,
plan and public registry provenance before its physical retirement. Only the
matching genuine Original FINISH can make `failed_retry_ready` visible. This
terminal path uses the existing SOURCE FINISH224/240 stages even without JOIN
batching, preserving separate positive checkpoints around finish/publication.

| Boundary | Preserved/reset state | Legal next entry |
|---|---|---|
| Child/transaction cleanup or FINISH pending | Receipt not ready; actual resource/receipt owners retained | Existing owned cleanup only; mutation remains blocked |
| Failed private successor fully retired and Original closed | Prior public image/generation and report preserved; authentic receipt ready, no private owners | STEP retry or declared-EDB correction; uncorrected RETRYABLE snapshot stays protected |
| Failed/zero correction request | Terminal receipt and report unchanged | Same terminal boundary |
| Successful admitted EDB mutation | Only commit notification refreshes actual registry/count and marks DIRTY; logical notification baseline stays unchanged | Fresh bounded STEP or evaluating snapshot |
| New attempt accepted | Old receipt flags consumed before forward work; new private image built from real current EDB | Existing publication/cutoff protocol |

A live unrelated control generation does not become funding or replay authority.
Original-END unary retirement uses the separate authenticated owner below;
absence of physical bytes never substitutes for ACK.


#### Ordinary observed unary retirement after Original END (#2299)

`wl_columnar_controlled_step.unary_cleanup` is a distinct owning record,
registered by `wl_columnar_session_unary_cleanup_register` before framed begin
returns to any callback-capable child. Its metered shape scan admits actual
VARIABLE/FILTER/MAP/CONSOLIDATE compositions. JOIN, CONCAT and LFTJ keep their
separate recovery owners. The dormant record binds the real session/step,
transaction/head/bindings generation, frame/context, Original identity/attempt,
operation identity, native thread and receipt key. It grants no forward work.
Registration publishes once after all fallible admissions. A registration
refusal leaves no record; the fresh framed bootstrap rolls back its pin and
actual receipt before any child runs.

| Owner phase | Required live authority | Legal work |
|---|---|---|
| INERT, registered | Real frame/ctx/transaction birth; Original still active | Existing forward host only |
| CHILD | Registered root, creator thread, actual frame/ctx, binding generation/head, exact first receipt | Consume the actual pending action once, then retire existing scalar/program/table/batch/source owners; real child ACK and frame receipt ACK |
| DISPOSE | Real recorded transaction with closed child generation, no child/receipt/frame/pending grant; same head/count/generation | Existing maintenance-financed private disposal cursors |
| FINAL | Actual child/receipt ACK and transaction disposal; no retirement/source/staging debt | Fixed terminal bookkeeping and financial footer |
| DONE | Record cleared only after actual closure | Idle public STEP replay, or the existing snapshot retry entry |

`wl_columnar_session_unary_cleanup_pending` protects admission even if a deeper
proof or creator-thread check fails. Every action separately proves authority;
a financial admission is never permission. Independent SOURCE funds outer
proof/dispatch, actual framed grants fund native child actions, and transaction
maintenance funds its own disposal. Neither Original nor a new successor is
charged, cancelled, reset or finished by this path. Matching immutable Original
REPORT can preserve an already recorded positive execution error over later
identity-loss EINVAL; overwritten reports confer no inferred history. Once
latched, the native cause is frozen.

The actual receipt location is discovered once with a metered scan, before
framed begin publishes any callback-capable child. ENTRY128, one SLOT192 per
inspected record, and FINAL128 guard the copied index/full key; refusal leaves
outputs unchanged. The real frame and session record retain that index only
after exact owning key validation. Later proof, physical frame free and receipt
read/ACK validate the indexed record without rescanning; a mismatch never falls
back to a generic lookup for this owner. General component APIs keep their
existing full receipt domain.

A legal no-callback cold empty FILTER can leave its own committed FREED receipt
at0; a hot observed successor legitimately owns1. This repair preserves the
historical receipt and never manufactures its ACK. Full session generation,
receipt ID, plan epoch, operation attempt and operation identity prevent slot
reuse from creating authority. Displacement is refused both while the frame is
active and after physical free but before actual ACK. Missing lookup or denied
binding retains the actual fresh bootstrap rollback; it does not activate a
child. The fixed frame cache remains valid after framed context retirement only
for its genuine physical-free obligation.

| Financial region | Positive admissions / allowance |
|---|---|
| Registration | Fixed1536: six256 ENTRY/ROOT/BINDING/KEY/INDEX/PUBLISH regions, each funding then saved-Original zero poll; plus256 per actual plan op and the separate receipt lookup256+192*K |
| Birth capacity | max(existing,10240+512 per actual head op) covers two384 host fronts, two1536 fixed registrations and maximum32-record lookup6400; actual inspected records alone are debited |
| Repeated native proof | Four192 root/frame/binding/key regions +128 pending-result association +192 immutable-report/cause region =1088 |
| Dispatcher | Own SOURCE2304 capacity;140 selection,80 busy/thread,96 slot,1088 origin/child proof or192 retirement proof; separate60/64/96 action and128 return stages |
| Host SOURCE | Distinct2048 capacity for unary entry/gateway/late phases; gateway includes1088 proof and retains its existing financial cuts |
| Native child cell | Minimum4096 capacity: two1088 proofs +384 facade +384 framed +128 child +200 latch +32 dispatch =3304; unused capacity is not debited |
| Physical disposal | Existing per-slot prepayments and independent maintenance cursors; no whole-drain allowance |

Every new registration/lookup/proof admission is <=256. Existing host and
financial payments retain their separate documented contracts. Registration regions conservatively fit128
or192 including fixed caller/refusal tails: publication has fewer than80 fixed
source actions, root/binding/key regions fewer than160. Proof root/frame/binding/
key regions each fit192; pending association fits128; report accessor, exact-ID
check and cause-selection/return fit192. The once-metered receipt lookup removes variable receipt searches from later
indexed proof/free/read/ACK regions. SOURCE capacity covers its
own lexical phase only, never the native grant. Normal ACK clears the dormant
record; a new operation clears DONE before a new birth.

The dormant selector precedes cleanup SOURCE construction: its fixed read-only
root/active-generation observation fits128 source actions and exposes no factory
or report callback for unselected live work. Invalid inner provenance stays
selected and protected; every selected action retains the complete funded proof.
Registration capacity is derived from the actual immutable head's uint32 op count
using uint64 arithmetic (maximum fits without overflow); the per-op192 and
per-receipt192 checks remain separate.
Larger expression projection lists therefore cannot repeatedly exhaust a fixed
birth grant before reaching publication. This capacity is not a native drain
allowance and changes no executed-work charge.

Indexed generic receipt resolution is a mechanical accelerator, never a native
permission check. It uses only registered-key presence, full-key equality,
bounded index and actual slot equality/state; an invalid selected index refuses
without falling back to a search. Full root/thread/frame/binding proof remains
mandatory at each native caller. Unrelated keys retain the cheap legacy lookup.
The receipt gateway retains its original SOURCE80 prefix, then genuinely
finishes/rebegins before a separately admitted lookup224 and post-lookup32.
That fresh256 generation is finished on success and staged lookup/funding error
before native384 admission; neither the outer return81 nor later LATE work can
borrow it. Direct unary receipt reads use192 rather than104. Conservative fixed ceilings are24 prefix/arguments,80 location/full-key
checks,40 copied status and32 caller/return =176<=192. Native grant accounting
remains separate. Indexed physical frame retirement adds fixed saved-key versus
frame/record comparisons, within its existing independently prepaid256 physical
cell (conservative whole caller/free/release ceiling224); it never runs another
receipt search after binding.


Genuine receipt ACK completion has its own retained journal. A registered unary
ACK caller prepays a fixed192 region before invoking the irreversible ACK; a
one-short refusal returns resumable EAGAIN before ACK and preserves its owner.
Successful ACK records the actual full key/index, result, session receipt
generation and next receipt/plan serials before the financial-finish hook.
Normal same-Original ACK clears the dormant registration. If that hook ends
Original, the journal and registration remain until authenticated disposal.
A FREE slot or absent frame alone never proves that ACK occurred.

After such an END, the ACKED transfer uses independent SOURCE: four192 proof
regions cover root/thread/Original identity, transaction bindings, full key/index
and receipt serial/quiescence, and retained report/cause;128 prepays publication.
Only that genuine matching journal closes the actual child generation and clears
its receipt state, then selects private transaction disposal. It never repeats
ACK, reads freed frame/context storage or charges Original/successor. Reused
slots, changed serials or invalid provenance remain protected. Financial refusal
at any proof/transition is resumable and leaves publication for a funded retry.
Indexed receipt status/retry/ACK SOURCE lookup uses the separate224+32 generation
above; direct copied-status accounting is96. These funds remain distinct from
the native child grant. Host TUPLE is96 only for registered unary ownership,
with actual processed lower16 before CLOSE176; other routes keep72/CLOSE176.

### Observed JOIN plus scalar callback END (#2299)

An ordinary observed nonC1/nonbatch composed JOIN head requiring scalar
fallback owns its native retirement before any scalar/library callback can
replace the evaluation attempt. This genuine
JOIN_DYNAMIC birth binds the actual receipt index and complete key; pure unary,
LFTJ and legacy C1 lifetimes remain distinct. Registration charges actual
256 packets (1536+256 per visited eligible plan record); initial financier
capacity10240+512 per actual plan record covers at most two metered shape scans
and bounded lookup, without charging unused capacity as work. An Original-funded readonly decoder pass caches a transaction-head/generation
fact before first host finance or child activation. Numeric AUTO and C1/batch
legacy routes keep their existing owners. New scalar-head SOURCE financing
selects capacity2048 without granting native permission or
enabling C1. Each fresh packet observes the saved Original with atomic zero
debit after independent funding; funding refusal wins before that poll.
Registered/native retirement never uses these fresh polls. Current and
successor controls never finance mandatory retirement.
Existing genuinely indexed key checks, real receipt ACK and private transaction
disposal close the route, including END after successful ACK; tests require
active/pending/reserved0 and governor/pin balance before retry and destruction.

### One-column observed FILTER protocol (#2299)

Four-op VARIABLE/FILTER/MAP/CONSOLIDATE heads use the general private observed
transaction, including numeric FILTER. This repairs scalar-error observer debt
before it is born, rather than ignoring an actual observer at mutation admission.
Three-op identity projection retains its prior narrow admission/behavior. The
fixed preflight payload adds at most6 actions, complete payload26; SOURCE retains
its existing208/96/80 reader while DIRECT remains a direct fixed read.

APPEND_AUDIT uses the existing readonly Original classifier for supported,
nonempty FILTERs. PRE128 + child fees + POST128 describes append eligibility;
scalar requirements choose canonical general execution before append copying or
old-head CONCAT rewriting. Numeric FILTER still uses the real append plan.
Each new parent interval is bounded by42+56+24=122 under128/quantum256; scalar
fallback and numeric continuation are mutually exclusive fixed tails. The actual
transaction owns partial frontier metadata; a boolean never supplies native
permission. Genuine canonical unary proof/ACK and the R1 terminal receipt allow
post-error input correction, and no raw observer policy or public API is changed.
